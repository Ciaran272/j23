# ============================================================
# PA Champion v2.1 · 聚宽回测策略
# ============================================================
# 逻辑：每日读取预计算信号 CSV，按 target_position 调仓 161128
# 回测期：2020-01-02 ~ 2026-05-21
# 成本：佣金 0.005%（万0.5）/ 无最低佣金 / 滑点 0.2%（type='fund'）
# 初始资金：50000
#
# 用法：
#   1. 上传 daily_signal_history_v21_2026-05-23.csv 到聚宽研究环境
#   2. 复制本文件全部内容到聚宽"策略回测"代码框
#   3. 设置回测起止日期 2020-01-02 ~ 2026-05-21
#   4. 初始资金 50000
#   5. 运行回测
# ============================================================

import pandas as pd
from io import StringIO


def initialize(context):
    # ========== A 股 LOF 标准配置 ==========
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)

    set_order_cost(OrderCost(
        open_tax=0,
        close_tax=0,
        open_commission=0.00005,
        close_commission=0.00005,
        min_commission=0,
    ), type='fund')

    set_slippage(FixedSlippage(0.002))

    # ========== 读取信号 CSV ==========
    body = read_file('daily_signal_history_v21_2026-05-23.csv')
    df = pd.read_csv(StringIO(body.decode('utf-8')))
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)

    g.signals_df = df
    g.target_security = '161128.XSHE'
    g.half_size_mode = False

    # ========== 统计 ==========
    g.trade_count = 0

    # ========== 调度 ==========
    run_daily(before_trading, time='before_open',
              reference_security=g.target_security)
    run_daily(market_open, time='09:30',
              reference_security=g.target_security)
    run_daily(after_trading, time='after_close',
              reference_security=g.target_security)

    log.info('PA Champion v2.1 初始化完成')
    log.info('信号 CSV: %d 行, 范围 %s ~ %s'
             % (len(df), df.index.min().date(), df.index.max().date()))
    log.info('标的: %s | 半仓模式: %s' % (g.target_security, g.half_size_mode))


def before_trading(context):
    today = pd.Timestamp(context.current_dt.date())

    if today not in g.signals_df.index:
        g.target_position = None
        return

    target = g.signals_df.loc[today, 'target_position']

    if g.half_size_mode:
        target *= 0.5

    g.target_position = target


def market_open(context):
    if g.target_position is None:
        return

    total_value = context.portfolio.total_value
    current_value = context.portfolio.positions_value
    current_ratio = current_value / total_value if total_value > 0 else 0

    # 偏差 < 5% 不调仓（减少交易摩擦）
    if abs(current_ratio - g.target_position) < 0.05:
        return

    order_target_value(g.target_security, total_value * g.target_position)
    g.trade_count += 1
    log.info('%s 调仓: %.2f%% -> %.2f%% (第 %d 次)'
             % (context.current_dt.date(),
                current_ratio * 100,
                g.target_position * 100,
                g.trade_count))


def after_trading(context):
    pass
