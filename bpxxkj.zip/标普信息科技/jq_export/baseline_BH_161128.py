# ============================================================
# 基线策略：BH-161128（Buy and Hold 买入持有）
# ============================================================
# 用途：作为 PA Champion v2.1 的对照组
# 逻辑：第一个交易日满仓买入 161128，之后不操作，持有到结束
# 回测期：2020-01-02 ~ 2026-05-21（与主策略对齐）
# 成本：佣金 0.005%（万0.5）/ 无最低佣金 / 滑点 0.2%（type='fund'）
#
# 用法：
#   1. 复制本文件全部内容到聚宽"策略研究"或"策略回测"代码框
#   2. 设置回测起止日期 2020-01-02 ~ 2026-05-21
#   3. 初始资金 100000（与主策略保持一致）
#   4. 运行回测，记录结果（AnnRet / Sharpe / MaxDD / 交易次数）
# ============================================================

def initialize(context):
    # ---------- A 股 LOF 标准配置 ----------
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)

    set_order_cost(OrderCost(
        open_tax=0,
        close_tax=0,
        open_commission=0.00005,    # 万0.5
        close_commission=0.00005,   # 万0.5
        min_commission=0,
    ), type='fund')

    set_slippage(FixedSlippage(0.002))  # 滑点 0.2%

    # ---------- 标的 ----------
    g.target_security = '161128.XSHE'  # 标普信息科技 LOF
    g.bought = False                   # 是否已建仓

    # ---------- 调度：每日 09:30 检查一次 ----------
    run_daily(market_open, time='09:30', reference_security=g.target_security)

    log.info('基线策略 BH-161128 初始化完成')
    log.info('标的: %s' % g.target_security)
    log.info('成本: 佣金 0.03% / 滑点 0.2%')


def market_open(context):
    """第一个交易日满仓买入，之后不再调仓。"""
    if g.bought:
        return

    total_value = context.portfolio.total_value
    order_value(g.target_security, total_value * 0.995)  # 留 0.5% 现金缓冲手续费

    g.bought = True
    log.info('%s 建仓完成 -> 满仓持有 161128 至回测结束'
             % context.current_dt.date())


def after_trading_end(context):
    """收盘后输出当日净值，便于人工核对。"""
    pos = context.portfolio.positions.get(g.target_security)
    if pos is not None and pos.total_amount > 0:
        log.info('持仓: %d 股, 市值: %.2f, 总资产: %.2f'
                 % (pos.total_amount,
                    pos.value,
                    context.portfolio.total_value))
