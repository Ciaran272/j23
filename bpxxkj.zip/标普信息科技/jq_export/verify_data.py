"""PA Champion v2.1 数据交付规范 · 11 项自检"""
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import pandas as pd
from pathlib import Path

CSV = Path(__file__).parent / 'daily_signal_history_v21_2026-05-23.csv'
DIAG = Path(__file__).parent / 'signal_diagnostics_v21_2026-05-23.csv'
WEIGHTS = Path(__file__).parent / 'f52_weights_history_2026-05-23.csv'

def mark(ok):
    return '[PASS]' if ok else '[FAIL]'

def warn_mark(ok):
    return '[PASS]' if ok else '[WARN]'

print('=' * 60)
print('PA Champion v2.1 · 数据自检')
print('=' * 60)

df = pd.read_csv(CSV, parse_dates=['date'])
print(f'\n文件: {CSV.name}')
print(f'行数: {len(df)}')
print(f'列: {list(df.columns)}')

# 检查 1
print('\n--- 检查 1：行数 ---')
ok1 = 1500 <= len(df) <= 1560
print(f'  {mark(ok1)} 行数 = {len(df)}（预期 1500-1560，约 1544）')

# 检查 2-3
print('\n--- 检查 2-3：date 唯一性 + 排序 ---')
ok2 = bool(df['date'].is_unique)
ok3 = bool(df['date'].is_monotonic_increasing)
print(f'  {mark(ok2)} date 唯一: {ok2}')
print(f'  {mark(ok3)} date 升序: {ok3}')

weekdays = df['date'].dt.dayofweek
weekend_count = int(((weekdays == 5) | (weekdays == 6)).sum())
ok3b = weekend_count == 0
print(f'  {mark(ok3b)} 无周末日: {weekend_count}')

# 检查 4-5
print('\n--- 检查 4-5：target_position 合法性 ---')
unique_vals = sorted(df['target_position'].unique())
ok4 = set(unique_vals).issubset({0.0, 0.5, 1.0})
ok5 = df['target_position'].isna().sum() == 0
print(f'  {mark(ok4)} 取值范围: {unique_vals}')
print(f'  {mark(ok5)} 无 NaN')

# 检查 6
print('\n--- 检查 6：仓位分布 ---')
dist = df['target_position'].value_counts(normalize=True).sort_index()
counts = df['target_position'].value_counts().sort_index()
empty_pct = dist.get(0.0, 0) * 100
half_pct = dist.get(0.5, 0) * 100
full_pct = dist.get(1.0, 0) * 100
print(f'  空仓 (0.0): {counts.get(0.0, 0):>4} 天 ({empty_pct:>5.1f}%)（预期 ~20%）')
print(f'  半仓 (0.5): {counts.get(0.5, 0):>4} 天 ({half_pct:>5.1f}%)（预期 ~24%）')
print(f'  满仓 (1.0): {counts.get(1.0, 0):>4} 天 ({full_pct:>5.1f}%)（预期 ~56%）')
ok6 = (10 <= empty_pct <= 30) and (15 <= half_pct <= 35) and (45 <= full_pct <= 70)
print(f'  {warn_mark(ok6)} 分布在合理区间')

# 检查 7
print('\n--- 检查 7：日期范围 ---')
start_date = df['date'].min()
end_date = df['date'].max()
ok7 = start_date <= pd.Timestamp('2020-01-03') and end_date >= pd.Timestamp('2026-05-20')
print(f'  起始: {start_date.date()}（预期 ≤ 2020-01-02）')
print(f'  结束: {end_date.date()}（预期 ≥ 2026-05-20）')
print(f'  {mark(ok7)} 时间跨度: {(end_date - start_date).days / 365:.2f} 年')

# 检查 8
print('\n--- 检查 8：关键日期抽查 ---')
key_dates = {
    '2020-01-02': '建仓初期',
    '2020-03-23': 'COVID 底（应空仓或半仓）',
    '2022-10-13': '美股 22 年熊市底（应空仓）',
    '2023-04-03': 'AI 大涨期（应满仓）',
    '2023-07-19': 'NVDA 大涨期（应满仓）',
    '2024-08-05': 'AI 二次回调',
    '2026-05-21': '最近交易日',
}
for d, note in key_dates.items():
    ts = pd.Timestamp(d)
    rows = df[df['date'] == ts]
    if len(rows) > 0:
        row = rows.iloc[0]
        print(f'  {d} ({note}): target = {row["target_position"]:.1f}, '
              f'f11={row["f11_pos"]}, f52={row["f52_pos"]:.2f}, '
              f'ema={row["ema"]:.3f}, vol_ratio={row["vol_ratio"]:.3f}')
    else:
        print(f'  {d}: 不在数据中（可能非 A 股交易日）')

# 检查 9
print('\n--- 检查 9：COVID 期减仓 ---')
covid = df[(df['date'] >= '2020-02-25') & (df['date'] <= '2020-04-10')]
covid_empty = (covid['target_position'] == 0.0).sum()
covid_half = (covid['target_position'] == 0.5).sum()
covid_full = (covid['target_position'] == 1.0).sum()
print(f'  2020-02-25 ~ 2020-04-10: 共 {len(covid)} 天')
print(f'  空仓 {covid_empty} / 半仓 {covid_half} / 满仓 {covid_full}')
ok9 = (covid_empty + covid_half) >= len(covid) * 0.4
print(f'  {warn_mark(ok9)} 减仓占比 {(covid_empty + covid_half) / len(covid):.1%}（预期 ≥ 40%）')

# 检查 10
print('\n--- 检查 10：AI 大涨期 (2023-04 ~ 2023-12) ---')
ai_period = df[(df['date'] >= '2023-04-01') & (df['date'] <= '2023-12-31')]
ai_full = (ai_period['target_position'] == 1.0).sum()
print(f'  共 {len(ai_period)} 天，满仓 {ai_full} 天 ({ai_full / len(ai_period):.1%})')
ok10 = ai_full / len(ai_period) >= 0.5
print(f'  {warn_mark(ok10)} 满仓占比 {ai_full / len(ai_period):.1%}（预期 ≥ 50%）')

# 检查 11
print('\n--- 检查 11：文件编码 ---')
with open(CSV, 'rb') as f:
    head = f.read(3)
is_bom = head[:3] == b'\xef\xbb\xbf'
try:
    with open(CSV, 'r', encoding='utf-8') as f:
        f.read(1024)
    ok11 = True
    print(f'  [PASS] UTF-8 可读{"（带 BOM）" if is_bom else "（无 BOM）"}')
except UnicodeDecodeError:
    ok11 = False
    print('  [FAIL] 非 UTF-8 编码')

# 总结
print('\n' + '=' * 60)
results = [ok1, ok2, ok3, ok3b, ok4, ok5, ok6, ok7, ok9, ok10, ok11]
passed = sum(results)
total = len(results)
print(f'总结: {passed} / {total} 项通过')
if passed == total:
    print('[PASS] 全部通过，可交付聚宽')
else:
    print('[WARN] 部分项需复核')
print('=' * 60)

# 辅助 CSV 检查
print('\n=== 辅助 CSV ===')
diag = pd.read_csv(DIAG, parse_dates=['date'])
print(f'\n{DIAG.name}: {len(diag)} 行 × {len(diag.columns)} 列')

print('\n--- 一致性：主 CSV vs 诊断 CSV ---')
ok_same_len = len(diag) == len(df)
print(f'  {mark(ok_same_len)} 行数一致: {len(df)} == {len(diag)}')
merged = df[['date', 'target_position']].merge(
    diag[['date', 'target_position']], on='date', suffixes=('_main', '_diag')
)
mismatch = (merged['target_position_main'] != merged['target_position_diag']).sum()
print(f'  {mark(mismatch == 0)} target_position 一致: {len(merged) - mismatch} / {len(merged)}')

# vol_boost 触发率
boost_col = df['vol_boost_triggered']
if boost_col.dtype == 'bool':
    boost_count = int(boost_col.sum())
else:
    boost_count = int((boost_col.astype(str).str.lower() == 'true').sum())
print(f'\n  vol_boost_triggered 触发: {boost_count} 天 ({boost_count / len(df):.1%})')

# 权重和
weights = pd.read_csv(WEIGHTS)
print(f'\n{WEIGHTS.name}: {len(weights)} 行（季度）')
print(f'  覆盖: {weights["quarter"].iloc[0]} ~ {weights["quarter"].iloc[-1]}')
weights['w_sum'] = weights[['w_nvda', 'w_aapl', 'w_msft', 'w_avgo']].sum(axis=1)
w_min, w_max = weights['w_sum'].min(), weights['w_sum'].max()
print(f'  权重和范围: [{w_min:.4f}, {w_max:.4f}]（预期接近 1.0）')

# 持仓状态变化次数（换手频率）
print('\n--- 持仓变化频率 ---')
changes = (df['target_position'].diff().abs() > 0).sum()
print(f'  状态切换: {changes} 次 / {len(df)} 天 = {changes / len(df):.1%}')
print(f'  平均持仓周期: {len(df) / changes:.1f} 天/次（仅供参考）')
