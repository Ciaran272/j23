# XLK → 161128 择时研究 — README

> 一份用 XLK（标普 500 信息科技 ETF）作为信号源给 A 股 LOF 161128 做 T+1 择时的完整研究记录。
>
> 研究期：2026-05-22（一日完成）  样本期：2020-01-02 ~ 2026-05-21（6.4 年）

---

## 一、结论（如果只读一段）

### 双冠军（Walk-forward 验证 Test 期 Sharpe 都是 1.11）

| 性格 | 策略 | 年化 | Test Sharpe | Test MaxDD | 实施 |
|---|---|---|---|---|---|
| **追求绝对收益** | F1.1 MA5/c4 单独 | 19.81% | 1.11 | -22.37% | 极简（只需 XLK 日 K）|
| **追求风险调整收益** | PosAvg F1+F5 only | 17.92% | 1.11 | **-17.72%** | 中（XLK + 4 只龙头股）|

**两个策略当前（2026-05-21 信号）均给出 100% 满仓**。

### 一句话研究心得
1. 策划案 §1 / §4.2 / §5.2 / §7 / §9.1 的 **spec 默认参数全部偏差** —— 都偏"灵敏触发"，但 XLK 数据偏好"严格触发 + 长平滑"。这不是单点过拟合，是结构性差异（A 股 / CSI300 经验 vs 高趋势美股 ETF）。
2. F4.2 RSRS_v3 **严重过拟合**（Sharpe 衰减 -64.7%），剔除。
3. F7 极端事件过滤器（暴跌 + VIX）**整族失败**，即便最保守阈值 VIX > 50 在 2020 COVID 仍亏 7 个百分点 —— V 形反弹来得太快，"等 VIX 降下来"= 卖底买顶。
4. F9.1 spec 投票法（信号转 {-1,0,+1}）失败；非 spec **PosAvg 变体**（直接位置加权平均）反而工作良好。

---

## 二、文档地图

| 文件 | 内容 |
|---|---|
| [XLK_161128_择时策划案_v1.0.md](XLK_161128_择时策划案_v1.0.md) | **原始策划案**（未修改）— 26 个因子定义、数据 Shopping List、回测注意事项 |
| [XLK_161128_回测结果记录.md](XLK_161128_回测结果记录.md) | **累积测试记录 v0.7** — 每个因子的完整网格 + walk-forward + 年度分解 + 机制分析 |
| **README_XLK_161128_研究.md**（本文档）| 总索引 + 快速上手 |

---

## 三、代码索引（共 9 个新脚本 + 1 个数据更新脚本）

### 数据拉取（[scripts/](scripts/)）

| 脚本 | 用途 | 输出 |
|---|---|---|
| [refresh_xlk.py](scripts/refresh_xlk.py) | 更新 XLK + 161128 日 K（**预先存在**，本研究继续用）| `XLK.csv`, `161128_SZ.csv` |
| [download_top4_holdings.py](scripts/download_top4_holdings.py) | 拉 NVDA / AAPL / MSFT / AVGO 日 K | `NVDA.csv` 等 4 个文件 |
| [download_vix.py](scripts/download_vix.py) | 拉 ^VIX 日 K | `VIX.csv` |

### 单因子（按策划案 F* 命名）

| 脚本 | 因子 | 默认运行 | `--grid` 行为 |
|---|---|---|---|
| [strategy_F1_1_xlk_baseline.py](scripts/strategy_F1_1_xlk_baseline.py) | F1.1 XLK MA / 连续确认 | spec MA5/c2 + MA5/c4 + BH | 32 个组合（MA × confirm）|
| [strategy_F5_2_top4_consistency.py](scripts/strategy_F5_2_top4_consistency.py) | F5.2 Top4 权重加权一致性 | spec MA5/c2 + MA5/c4 + F1.1 对照 | 32 个组合 |
| [strategy_F4_2_rsrs_v3.py](scripts/strategy_F4_2_rsrs_v3.py) | F4.2 RSRS_v3（β + R² × Z）| spec N18/L600/t0.7 + F1.1 对照 | 18 个组合（N × lookback × threshold）|

### 合成与验证

| 脚本 | 用途 |
|---|---|
| [strategy_F9_1_voting_ensemble.py](scripts/strategy_F9_1_voting_ensemble.py) | F9.1 三因子投票合成（spec vote + 非 spec PosAvg 变体）|
| [strategy_walk_forward.py](scripts/strategy_walk_forward.py) | Train 2020-2024 / Test 2025-2026 验证（含 PosAvg F1+F5 only 剔除 F4.2 变体）|

### 滤波器与实战

| 脚本 | 用途 |
|---|---|
| [strategy_F7_filters.py](scripts/strategy_F7_filters.py) | F7.1（暴跌否决）+ F7.2（VIX 上限）应用到双冠军 + ablation |
| [strategy_F72_extreme_sweep.py](scripts/strategy_F72_extreme_sweep.py) | F7.2 VIX 阈值扫描（30/35/40/45/50）|
| **[print_today_signal.py](scripts/print_today_signal.py)** | **每日跑：基于最新美股收盘输出双冠军的目标仓位** |

---

## 四、因子测试矩阵（7 个因子）

| 因子 | spec 默认 | 网格最优 | spec 排名 | Test Sharpe | 结论 |
|---|---|---|---|---|---|
| **F1.1** | MA5/c2 | **MA5/c4** | 28/32 ❌ | **1.11** ★★ | **冠军之一** |
| **F5.2** | MA5/c2 (per-stock) | MA13/c1 | 27/32 ❌ | 0.94 | 单用不及 F1.1，合成有价值 |
| F4.2 | N18/L600/t0.7 | N26/L250/t1.0 | 13/18 ❌ | **0.37** 💥 | **过拟合，剔除** |
| F9.1 vote (spec) | Eq-weight | — | — | 0.85 | spec 投票失败 |
| **F9.1 PosAvg F1+F5+F4** | — | — | — | 0.98 | 不如 F1+F5 only |
| **F9.1 PosAvg F1+F5 only** | — | — | — | **1.11** ★★ | **冠军之二** |
| F7.1 暴跌否决 | 单日 -2.5% / 两日 -4% | — | — | 0.73 💥 | **失败（V 形反弹被错过）** |
| F7.2 VIX 上限 | >35 零 / >25 半 | — | — | 1.08 | 无害但也无益 |
| F7.2 极端 VIX>50 | — | — | — | 1.11（Test 未触发）| **2020 仍亏 7 点** |

**spec 默认参数有 5/7 是显著偏差**（F1.1 / F5.2 / F4.2 / F7.1 / F7.2 / F9.1 vote）。

---

## 五、数据索引

**目录**：`C:\Users\Administrator.DESKTOP-P7K8HNB\.qlib\research_data\161128_study\`

### 原始日 K（CSV 格式）

| 文件 | 标的 | 范围 | 用于 |
|---|---|---|---|
| `XLK.csv` | 标普信息科技 ETF | 2017-01-03 ~ 2026-05-21 | F1.1 / F4.2 / F7.1 |
| `NVDA.csv` / `AAPL.csv` / `MSFT.csv` / `AVGO.csv` | Top4 重仓股（含 Adj Close）| 同上 | F5.2 |
| `VIX.csv` | CBOE 波动率指数 | 同上 | F7.2 |
| `161128_SZ.csv` | A 股 LOF（聚宽 jqdatasdk）| 2020-01-02 ~ 2026-05-21 | 所有回测的标的 |

### 各因子输出目录

| 子目录 | 内容 |
|---|---|
| `F1_1/` | F1.1 spec default daily + grid 全 32 行 + summary |
| `F5_2/` | F5.2 spec default daily + grid 全 32 行 + summary |
| `F4_2/` | F4.2 spec default daily + grid 全 18 行 + summary |
| `F9_1/` | F9.1 五种合成方案 daily + summary（含 Vote/Sharpe-weight/F1.1-dom/PosAvg-Eq/PosAvg-F1Dom）|
| `walk_forward/` | 每个因子的 train 选参 / test 评估表 + PosAvg train/test daily |
| `F7/` | F7.1 / F7.2 / 双开 / F7.2 极端阈值扫描的 daily + summary |

---

## 六、快速上手

### 1. 今天该满仓还是空仓？（每日例行）

```powershell
# 美股收盘后（北京时间次日清晨）跑一次
python scripts/refresh_xlk.py             # 拉最新 XLK + 161128 数据
python scripts/download_top4_holdings.py  # 拉最新 NVDA/AAPL/MSFT/AVGO（PosAvg 需要）
python scripts/print_today_signal.py       # 输出双冠军今日目标仓位
```

输出示例（2026-05-21 数据）：
```
方案 A — F1.1 MA5/c4 单独: 目标仓位 100%
方案 B — PosAvg F1+F5 only: 目标仓位 100%
```

### 2. 复现某个因子的全部测试

```powershell
# 单因子 + 网格
python scripts/strategy_F1_1_xlk_baseline.py            # spec 默认
python scripts/strategy_F1_1_xlk_baseline.py --grid     # 32 个组合网格

# Walk-forward（含所有因子选参 + PosAvg 合成 + F4.2 剔除变体）
python scripts/strategy_walk_forward.py

# F7 完整 ablation
python scripts/strategy_F7_filters.py
python scripts/strategy_F72_extreme_sweep.py
```

### 3. 修改参数 / 加新因子

所有因子脚本都遵循统一架构：
- `build_*_signal()` 生成美股端信号 (date, signal_position)
- `align_*_to_lof()` 把美股 T-1 信号对齐到 A 股 T 开盘前
- `backtest()` / `backtest_float()` 计算每日 gross/net return + equity
- `compute_metrics()` 输出 AnnRet / Sharpe / MaxDD / Calmar / Hold% / Trades

通过这套 API 加新因子最简单的方法：模仿 [strategy_F1_1_xlk_baseline.py](scripts/strategy_F1_1_xlk_baseline.py)。

---

## 七、关键参数 & 约束

| 项 | 值 | 说明 |
|---|---|---|
| 回测期 | 2020-01-02 ~ 2026-05-21 | 161128 数据起始 |
| Train / Test 分割 | 2020-01 / 2024-12（5y）+ 2025-01 / 2026-05（1.4y）| Walk-forward |
| 手续费 | 0.2% / 边（双向 0.4%）| 含基金申赎或场内买卖 |
| 滑点 | 0.1% | LOF 流动性折扣 |
| 调仓时点 | A 股 T 日开盘 | 信号源于 T-1 日美股收盘 |
| 信号对齐 | `pd.merge_asof(direction="backward", allow_exact_matches=False)` | 严格防未来 |
| F1.1 信号源 | XLK adjclose | 含拆股+分红调整 |
| F5.2 信号源 | NVDA/AAPL/MSFT/AVGO adjclose | NVDA 2024-06-10 拆股 / AAPL 2020-08-31 拆股已自动处理 |

---

## 八、最终冠军：选择指南

### 方案 A — F1.1 MA5/c4 单独 ★

**适合**：追求绝对收益、能容忍 -22% 单次回撤、想最简单部署

**规则**：
- XLK 连续 4 日收盘 > MA5 → 满仓
- XLK 连续 4 日收盘 < MA5 → 空仓
- 其他 → 维持上日仓位

**数据需求**：只需 XLK 日 K

### 方案 B — PosAvg F1+F5 only ★★

**适合**：追求风险调整后收益（Calmar 1.01 全场最高）、严格控制最大回撤

**规则**：
- F1.1 位置 = 上面方案 A
- F5.2 位置 = (NVDA 上 + AAPL 上 + MSFT 上 + AVGO 上 in MA13) 加权得分映射到 {0, 0.25, 0.5, 0.75, 1.0}
- 最终位置 = **0.5 × F1.1 + 0.5 × F5.2**

**数据需求**：XLK + NVDA + AAPL + MSFT + AVGO 日 K

### 不推荐
- F4.2 RSRS_v3（任意参数）— Test Sharpe 衰减 64.7%
- F7.1 / F7.2 任何变体 — 即便最保守阈值在 2020 仍亏 7 个百分点
- F9.1 spec vote 投票法 — 信号转 {-1,0,+1} 损失信息

---

## 九、未做的部分（未来方向）

1. **ATR 动态止损**：基于波动率的硬止损线（spec 中 F8.1 提到但本次未测）
2. **仓位 EMA 平滑**：用 5 日 EMA 平滑信号位置，可能进一步降换手
3. **持续 walk-forward**：每年滚动重新选参（本次只做了单次 5y/1.4y 分割）
4. **A 股 LOF 折溢价**：策划案 §11.4 提到 IOPV 折溢价，本次未实测
5. **实盘部署**：自动化每日信号 + LOF 流动性监测 + 调仓日志

---

## 十、变更日志

| 日期 | 版本 | 内容 |
|---|---|---|
| 2026-05-22 | v1.0 | 一日完成的全套研究 — 7 个因子 + 6.4 年回测 + walk-forward + F7 ablation + 实战信号脚本 |
