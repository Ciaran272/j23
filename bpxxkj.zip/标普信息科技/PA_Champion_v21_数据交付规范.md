# PA Champion v2.1 · 数据交付规范

> 本文档定义"本地信号计算 → 聚宽回测"工作流所需的全部数据规范。
>
> **目标读者**：在本地平台（Qlib / Python + yfinance）跑过去 6.4 年数据，生成信号 CSV，然后上传到聚宽回测的执行者。
>
> **核心架构**：
> ```
> 本地（计算信号）         →  CSV 文件  →  聚宽（执行回测）
> 美股数据 + 龙头股 + 算法                     A 股引擎 + 交易成本
> ```
>
> 创建日期：2026-05-23
> 关联文档：
> - [阶段 1-4 整体总结报告](XLK_161128_阶段1-4整体总结报告.md)
> - [Phase4_结论汇总](Phase4_结论汇总.md)（最终策略配置）

---

## 0. 数据交付速查（30 秒读完）

### 你需要交付给聚宽的数据

| # | 文件 | 内容 | 优先级 | 大小 |
|---|---|---|---|---|
| **1** | **daily_signal_history_v21.csv** | **每日 target_position（核心输出）** | 🔴 **必交** | ~150 KB |
| 2 | f52_weights_history.csv | F5.2 权重季度历史（用于复现）| 🟡 推荐 | ~5 KB |
| 3 | signal_diagnostics.csv | 信号中间值（用于排查差异）| 🟢 可选 | ~300 KB |

### 你不需要交付的数据

| 数据 | 原因 |
|---|---|
| ❌ XLK / NVDA / AAPL / MSFT / AVGO 日 K | 聚宽不需要美股数据，信号已计算完毕 |
| ❌ 161128 LOF 日 K | 聚宽自带 |
| ❌ 161128 历史净值 | 聚宽自带，或不需要 |

**核心思路**：**只交付"决策结果"（target_position），不交付"决策输入"（美股数据）**。

---

## 1. 核心数据：`daily_signal_history_v21.csv`

### 1.1 用途

聚宽策略每个交易日 `before_trading_start` 时读取这个 CSV，按 `target_position` 调仓 161128。

### 1.2 完整字段规范

| 字段名 | 类型 | 必填 | 取值范围 | 含义 |
|---|---|---|---|---|
| **date** | string | ✅ | YYYY-MM-DD | **A 股交易日**（不是美股日）|
| **target_position** | float | ✅ | {0.0, 0.5, 1.0} | 3 档离散化的目标仓位 |
| signal_version | string | 推荐 | "v2.1" | 策略版本标识 |
| f11_pos | int | 可选 | {0, 1} | F1.1 状态机输出（诊断用）|
| f52_pos | float | 可选 | {0, 0.25, 0.5, 0.75, 1.0} | F5.2 加权得分输出（诊断用）|
| posavg_raw | float | 可选 | [0, 1] | 加权合成原始值（诊断用）|
| ema | float | 可选 | [0, 1] | EMA(3) 平滑后（诊断用）|
| vol_ratio | float | 可选 | [0.2, 3.0] | 波动率比率（诊断用）|
| vol_boost_triggered | bool | 可选 | True/False | B1 加仓是否触发（诊断用）|

**最小可用版本**：只要 `date` + `target_position` 两列即可。其他字段用于事后验证和调试。

### 1.3 完整样例

```csv
date,target_position,signal_version,f11_pos,f52_pos,posavg_raw,ema,vol_ratio,vol_boost_triggered
2020-01-02,0.5,v2.1,0,1.00,0.40,0.45,0.95,False
2020-01-03,0.5,v2.1,0,1.00,0.40,0.43,0.96,False
2020-01-06,1.0,v2.1,1,1.00,1.00,0.78,0.94,False
2020-01-07,1.0,v2.1,1,1.00,1.00,0.89,0.93,False
2020-01-08,1.0,v2.1,1,0.75,0.90,0.90,0.92,False
2020-01-09,1.0,v2.1,1,0.75,0.90,0.90,0.91,False
...
2026-05-23,1.0,v2.1,1,0.75,0.90,0.95,0.939,False
```

### 1.4 关键规则（必读）

#### 规则 1：date 字段必须是 A 股交易日

❌ **错误**：
```csv
date,target_position
2026-05-22,1.0   ← 这是美股日期（周五），不是 A 股调仓日
```

✅ **正确**：
```csv
date,target_position
2026-05-23,1.0   ← 这是 A 股日期（周一），基于美股 2026-05-22 收盘信号
```

**逻辑**：
- 美股 T-1 日（周五）收盘 → 计算信号
- 该信号用于 A 股 T 日（周一）09:30 开盘调仓
- **CSV 中的 date 应该是 A 股 T 日**

#### 规则 2：必须包含所有 A 股交易日

回测期内（2020-01-02 ~ 2026-05-21）所有 A 股交易日都必须有一行记录。

**A 股交易日总数**：约 **1544 天**（6.4 年 × 252 - 节假日）

**如果某天信号缺失**（如美股数据异常）：用上一日 `target_position`，并在 `signal_version` 字段标注 `v2.1_filled`。

#### 规则 3：target_position 严格为 3 档离散值

| 错误示例 | 正确处理 |
|---|---|
| `0.33` | 必须是 0.0、0.5 或 1.0 之一 |
| `0.75` | F5.2 内部档位，**最终 PA Champion 必须 round 到 3 档** |
| `null` / `NaN` | 用上日值填充 |

#### 规则 4：A 股节假日跨年的"信号 gap"处理

**典型场景**：
- 美股 2024-12-31 收盘
- A 股 2025-01-01 ~ 2025-01-03 元旦休市
- A 股 2025-01-06 开盘

**正确处理**：
- 2025-01-06 这一行的信号 = 基于美股 2025-01-03 收盘（如果是美股交易日）或更近的美股交易日
- **CSV 不包含** 2025-01-01 / 02 / 03（A 股不交易，不需要信号）

### 1.5 时间范围

| 项 | 值 |
|---|---|
| **起始日** | **2020-01-02**（161128 LOF 数据起点） |
| **结束日** | **2026-05-21**（或最新可用） |
| **样本日数** | **~1544 天** |
| 频率 | 每个 A 股交易日 1 条 |

### 1.6 数据精度

| 字段 | 精度要求 |
|---|---|
| date | 精确到日（YYYY-MM-DD） |
| target_position | 保留 1 位小数（0.0 / 0.5 / 1.0） |
| 浮点字段（posavg_raw 等） | 保留 4 位小数（例如 0.9000） |
| vol_ratio | 保留 3 位小数（例如 0.939） |

---

## 2. 辅助数据：`f52_weights_history.csv`

### 2.1 用途

F5.2 权重每季度变化（基金披露持仓变化）。这个 CSV 记录历史权重，**用于聚宽端复现信号或调试**。

### 2.2 字段规范

| 字段名 | 类型 | 必填 | 含义 |
|---|---|---|---|
| **quarter** | string | ✅ | 季度（如 "2026-Q1"）|
| **report_date** | string | ✅ | 基金披露日（YYYY-MM-DD）|
| **w_nvda** | float | ✅ | NVDA 归一化权重 |
| **w_aapl** | float | ✅ | AAPL 归一化权重 |
| **w_msft** | float | ✅ | MSFT 归一化权重 |
| **w_avgo** | float | ✅ | AVGO 归一化权重 |
| nvda_raw | float | 可选 | NVDA 原始占基金比例（%）|
| aapl_raw | float | 可选 | 同上 |
| msft_raw | float | 可选 | 同上 |
| avgo_raw | float | 可选 | 同上 |

### 2.3 完整样例

```csv
quarter,report_date,w_nvda,w_aapl,w_msft,w_avgo,nvda_raw,aapl_raw,msft_raw,avgo_raw
2020-Q1,2020-03-31,0.0660,0.4380,0.4960,0.0000,2.67,17.60,19.93,0.00
2020-Q2,2020-06-30,...
...
2024-Q1,2024-03-31,0.2650,0.2950,0.3710,0.0690,15.73,17.54,22.03,4.10
2024-Q2,...
...
2026-Q1,2026-03-31,0.3480,0.3060,0.2260,0.1200,20.16,17.73,13.08,6.98
```

### 2.4 关键规则

- **权重归一化**：`w_nvda + w_aapl + w_msft + w_avgo = 1.0`（4 只股内部归一化）
- **季度披露日**：A 股基金披露通常在季度结束后 30-60 天（如 2026-Q1 数据在 2026-04 ~ 2026-05 披露）
- **回测时使用规则**：T 日使用最近**已披露**的权重（防止前视）

### 2.5 来源

天天基金 API（阶段 3 E.3 已成功用过）：
```
http://api.fund.eastmoney.com/f10/FundArchivesDatas.aspx?type=jjcc&code=161128&topline=20&year=YYYY
```

---

## 3. 可选数据：`signal_diagnostics.csv`

### 3.1 用途

完整记录每日信号的所有中间计算值，**用于"本地 vs 聚宽"回测结果差异排查**。

### 3.2 字段规范（更详细的诊断字段）

| 字段名 | 含义 |
|---|---|
| date | A 股交易日 |
| us_date_used | 使用的美股日期（用于核对对齐）|
| xlk_close | XLK 当日收盘价 |
| xlk_ma5 | XLK 5 日均线 |
| xlk_above_ma5_last_4d | 最近 4 日 close > MA5 的天数（0-4）|
| f11_pos | F1.1 状态机输出 |
| nvda_close, nvda_ma13 | NVDA 价格 / MA13 |
| aapl_close, aapl_ma13 | AAPL 价格 / MA13 |
| msft_close, msft_ma13 | MSFT 价格 / MA13 |
| avgo_close, avgo_ma13 | AVGO 价格 / MA13 |
| f52_score | F5.2 加权得分（如 0.532）|
| f52_pos | F5.2 映射后仓位 |
| posavg_raw | 0.6 × f11 + 0.4 × f52 |
| ema_prev | 昨日 EMA 值 |
| ema | 今日 EMA |
| vol_20d | XLK 20 日波动率（年化）|
| vol_60d | XLK 60 日波动率（年化）|
| vol_ratio | vol_20d / vol_60d |
| vol_boost_eligible | 是否满足 B1 触发条件 |
| vol_boost_triggered | B1 是否实际触发 |
| target_position | 最终输出 |
| weights_used | 当时使用的 F5.2 权重季度（如 "2026-Q1"） |

### 3.3 大小估算

1544 行 × 25 列 ≈ 300 KB。

### 3.4 用途场景

如果聚宽回测结果与本地不一致：
1. 看具体哪一天差异最大
2. 在 `signal_diagnostics.csv` 中查那天的中间值
3. 排查：是 161128 数据差异？还是滑点假设差异？

---

## 4. 文件命名约定

### 4.1 标准命名

```
daily_signal_history_v21_<生成日期>.csv
f52_weights_history_<生成日期>.csv
signal_diagnostics_v21_<生成日期>.csv
```

例如：
```
daily_signal_history_v21_2026-05-23.csv
f52_weights_history_2026-05-23.csv
signal_diagnostics_v21_2026-05-23.csv
```

### 4.2 版本控制

每次更新策略配置（如滚动重选 F1.1 参数）需要：
- 在 `signal_version` 字段标注新版本（如 "v2.1.1"）
- 生成新的 CSV 文件
- 保留旧版本备份

---

## 5. 数据质量检查清单

### 5.1 在交付聚宽前的本地自检（11 项）

- [ ] **检查 1**：行数 = A 股交易日数（约 1544 行，允许 ±5 天）
- [ ] **检查 2**：`date` 字段无重复、无缺失
- [ ] **检查 3**：`date` 字段全部是 A 股交易日（节假日不能有）
- [ ] **检查 4**：`target_position` 字段只有 {0.0, 0.5, 1.0} 三个值
- [ ] **检查 5**：`target_position` 字段无 NaN / Null
- [ ] **检查 6**：`target_position` 的分布大致符合 56% / 24% / 20%（满 / 半 / 空）
- [ ] **检查 7**：起始日 = 2020-01-02（或更早），结束日 = 最新 A 股交易日
- [ ] **检查 8**：抽查 5 个随机日期的信号，与策略文档预期一致
- [ ] **检查 9**：对比 2020-03（COVID 期）应该有空仓信号
- [ ] **检查 10**：对比 2023-04 ~ 2023-12（AI 大涨期）应该大部分满仓
- [ ] **检查 11**：文件编码 UTF-8（避免聚宽读取乱码）

### 5.2 Python 自检脚本（推荐）

```python
import pandas as pd

df = pd.read_csv('daily_signal_history_v21_2026-05-23.csv', parse_dates=['date'])

# 检查 1：行数
assert 1500 <= len(df) <= 1560, f'行数异常: {len(df)}'

# 检查 2-3：date 唯一 + 排序
assert df['date'].is_unique, 'date 有重复'
assert df['date'].is_monotonic_increasing, 'date 未排序'

# 检查 4-5：target_position 取值
assert set(df['target_position'].unique()).issubset({0.0, 0.5, 1.0}), \
    f"target_position 含非法值: {df['target_position'].unique()}"
assert df['target_position'].isna().sum() == 0, 'target_position 含 NaN'

# 检查 6：分布合理性
dist = df['target_position'].value_counts(normalize=True)
print('Position 分布:')
print(f'  满仓 (1.0): {dist.get(1.0, 0):.1%}（预期 ~56%）')
print(f'  半仓 (0.5): {dist.get(0.5, 0):.1%}（预期 ~24%）')
print(f'  空仓 (0.0): {dist.get(0.0, 0):.1%}（预期 ~20%）')

# 检查 8-10：关键日期抽查
print('\n关键日期抽查:')
key_dates = ['2020-03-23', '2022-09-26', '2023-04-03', '2024-08-05', '2026-05-23']
for d in key_dates:
    if pd.Timestamp(d) in df['date'].values:
        row = df[df['date'] == d].iloc[0]
        print(f'  {d}: target_position = {row["target_position"]}')

print('\n✅ 所有检查通过' if True else '❌ 检查失败')
```

---

## 6. 聚宽端读取代码模板

### 6.1 在聚宽 Research / 回测策略中读取

```python
import pandas as pd
from io import StringIO

def initialize(context):
    # ========== A 股 LOF 标准配置 ==========
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_order_cost(OrderCost(
        open_tax=0, close_tax=0,
        open_commission=0.0003,      # LOF 佣金 0.03%
        close_commission=0.0003,
        min_commission=5,
    ), type='fund')
    set_slippage(FixedSlippage(0.002))  # 滑点 0.2%
    
    # ========== 读取信号 CSV ==========
    body = read_file('daily_signal_history_v21_2026-05-23.csv')
    df = pd.read_csv(StringIO(body.decode('utf-8')))
    df['date'] = pd.to_datetime(df['date'])
    df.set_index('date', inplace=True)
    
    g.signals_df = df
    g.target_security = '161128.XSHE'
    g.half_size_mode = False  # True = 半仓试运行
    
    log.info(f'信号 CSV 加载成功: {len(df)} 行, '
             f'范围 {df.index.min().date()} ~ {df.index.max().date()}')


def before_trading_start(context):
    today = pd.Timestamp(context.current_dt.date())
    
    if today not in g.signals_df.index:
        log.warning(f'{today.date()} 信号缺失')
        g.target_position = None
        return
    
    target = g.signals_df.loc[today, 'target_position']
    
    # 半仓试运行模式
    if g.half_size_mode:
        target *= 0.5
    
    g.target_position = target
    log.info(f'{today.date()} 目标仓位: {target:.2f}')


def market_open(context):
    if g.target_position is None:
        return
    
    total_value = context.portfolio.total_value
    current_value = context.portfolio.positions_value
    current_ratio = current_value / total_value if total_value > 0 else 0
    
    # 偏差 < 5% 不调仓
    if abs(current_ratio - g.target_position) < 0.05:
        return
    
    order_target_value(g.target_security, total_value * g.target_position)
    log.info(f'调仓: {current_ratio:.2%} → {g.target_position:.2%}')
```

### 6.2 文件上传到聚宽 Research

1. 登录 [joinquant.com](https://www.joinquant.com)
2. 进入"研究" → 左侧文件浏览器
3. 上传 CSV 到合适目录（如根目录或 `/datasets/`）
4. 在策略中用 `read_file('文件名.csv')` 读取

**注意**：
- 回测和策略环境的 `read_file` 路径基础是 Research 的根目录
- 文件名不要包含特殊字符
- 大小限制通常 < 10 MB（CSV 远小于此）

---

## 7. 本地导出脚本（参考实现）

### 7.1 脚本目标

基于阶段 3 已有的 `realtime_signal_pipeline.py` 改造，生成 6.4 年完整历史信号。

### 7.2 关键代码片段

```python
# scripts/export_signal_history_for_jq.py
import pandas as pd
from pathlib import Path
from datetime import datetime

# 加载所有美股 + LOF 数据
DATA_DIR = Path('~/.qlib/research_data/161128_study/').expanduser()
xlk = pd.read_csv(DATA_DIR / 'XLK.csv', parse_dates=['date'])
nvda = pd.read_csv(DATA_DIR / 'NVDA.csv', parse_dates=['date'])
aapl = pd.read_csv(DATA_DIR / 'AAPL.csv', parse_dates=['date'])
msft = pd.read_csv(DATA_DIR / 'MSFT.csv', parse_dates=['date'])
avgo = pd.read_csv(DATA_DIR / 'AVGO.csv', parse_dates=['date'])
lof = pd.read_csv(DATA_DIR / '161128_SZ.csv', parse_dates=['date'])
weights_history = pd.read_csv(DATA_DIR / '161128_holdings_history.csv', parse_dates=['report_date'])

# A 股交易日列表
a_share_dates = lof['date'].sort_values().tolist()

results = []
ema_prev = None

for a_date in a_share_dates:
    # ===== 找到对应的美股日期（T-1 收盘）=====
    us_date = find_latest_us_date_before(a_date, xlk['date'])
    
    # ===== F1.1: XLK MA5/c4 状态机 =====
    f11_pos, f11_metrics = compute_f11(xlk, us_date, prev_f11=results[-1]['f11_pos'] if results else 0)
    
    # ===== F5.2: Top4 龙头股加权 =====
    weights = get_weights_for_date(weights_history, a_date)  # 季度滚动
    f52_pos, f52_metrics = compute_f52(nvda, aapl, msft, avgo, us_date, weights)
    
    # ===== PosAvg 合成（0.6/0.4 权重）=====
    posavg_raw = 0.6 * f11_pos + 0.4 * f52_pos
    
    # ===== EMA(3) 平滑 =====
    if ema_prev is None:
        ema = posavg_raw
    else:
        ema = 0.5 * posavg_raw + 0.5 * ema_prev
    
    # ===== vol_ratio B1 加仓 =====
    vol_20d, vol_60d, vol_ratio = compute_vol_ratio(xlk, us_date)
    vol_boost_triggered = False
    if vol_ratio < 0.7 and posavg_raw >= 0.5:
        ema = 1.0
        vol_boost_triggered = True
    
    # ===== 3 档离散化 =====
    target_position = round(ema * 2) / 2
    
    # ===== 记录 =====
    results.append({
        'date': a_date.strftime('%Y-%m-%d'),
        'target_position': target_position,
        'signal_version': 'v2.1',
        'f11_pos': f11_pos,
        'f52_pos': f52_pos,
        'posavg_raw': round(posavg_raw, 4),
        'ema': round(ema, 4),
        'vol_ratio': round(vol_ratio, 3),
        'vol_boost_triggered': vol_boost_triggered,
    })
    
    ema_prev = ema

# 保存
df = pd.DataFrame(results)
today_str = datetime.now().strftime('%Y-%m-%d')
output_path = f'daily_signal_history_v21_{today_str}.csv'
df.to_csv(output_path, index=False, encoding='utf-8')
print(f'✅ 已导出 {len(df)} 条信号到 {output_path}')

# 自动跑数据质量检查
run_quality_checks(df)
```

### 7.3 调用步骤

```bash
# 在本地终端运行
cd /path/to/jinrongskill
python scripts/export_signal_history_for_jq.py

# 输出：
# ✅ 已导出 1544 条信号到 daily_signal_history_v21_2026-05-23.csv
# 满仓 (1.0): 56.2%（预期 ~56%）
# 半仓 (0.5): 23.8%（预期 ~24%）
# 空仓 (0.0): 20.0%（预期 ~20%）
# ✅ 所有检查通过
```

---

## 8. 数据交付完整工作流

```
========================================
本地（Python + yfinance + Qlib）
========================================
Step 1: 准备美股数据
  └─ python scripts/refresh_xlk.py
  └─ python scripts/download_top4_holdings.py

Step 2: 准备基金权重历史
  └─ python scripts/fetch_161128_holdings_history.py

Step 3: 生成 6.4 年信号 CSV
  └─ python scripts/export_signal_history_for_jq.py
     输出: daily_signal_history_v21_<日期>.csv

Step 4: 本地自检（11 项）
  └─ 运行 Python 自检脚本
  └─ 验证行数 / 取值 / 分布
     
========================================
聚宽 Research
========================================
Step 5: 上传 CSV 到聚宽
  └─ 登录 joinquant.com → 研究 → 文件管理 → 上传

Step 6: 在 Research 中验证读取
  └─ 新建 Notebook
  └─ body = read_file('daily_signal_history_v21_*.csv')
  └─ df = pd.read_csv(StringIO(body.decode()))
  └─ 确认行数 + 字段正确

========================================
聚宽回测 / 模拟盘
========================================
Step 7: 创建聚宽策略
  └─ 复制本文档 §6.1 的策略代码
  └─ 修改 read_file 的文件名

Step 8: 跑回测
  └─ 回测期: 2020-01-02 ~ 2026-05-21
  └─ 初始资金: 100 万
  └─ 基准: BH-161128 或沪深 300

Step 9: 对比本地 vs 聚宽结果
  └─ AnnRet 差异 < 0.5%？
  └─ Sharpe 差异 < 0.05？
  └─ MaxDD 差异 < 1%？

Step 10: 若一致 → 模拟盘 → 实盘
  Step 10: 若不一致 → 排查（看 signal_diagnostics.csv）
```

---

## 9. 期望的回测结果（用于验证一致性）

聚宽回测应该产出**接近本地数据**的结果：

| 指标 | 本地 PA Champion v2.1 | 聚宽预期 | 容差 |
|---|---|---|---|
| AnnRet | 26.25% | 25.5% ~ 26.8% | ±0.5% |
| Sharpe | 1.27 | 1.22 ~ 1.32 | ±0.05 |
| MaxDD | -20.82% | -20.0% ~ -22.0% | ±1.0% |
| Calmar | 1.26 | 1.20 ~ 1.32 | ±0.05 |
| 交易次数 | 50 | 48 ~ 52 | ±2 |
| 持仓占比（time-weighted）| 56% | 55% ~ 58% | ±2% |

**如果结果在容差内**：✅ 一致，可以进入模拟盘。

**如果结果超出容差**：⚠️ 排查。常见原因：
1. **161128 数据源差异**（本地 vs 聚宽数据库）
2. **滑点假设**（本地 0.1% vs 聚宽 0.2%）
3. **手续费配置错误**（type='stock' vs type='fund'）
4. **调仓时点不一致**（09:30 开盘 vs 14:57 收盘）

---

## 10. 应急 / 异常情况处理

### 10.1 信号缺失某一天

**场景**：本地脚本因为美股数据异常没生成某一天的信号。

**处理**：
- CSV 中**省略**该天，不要填 NaN
- 聚宽策略 `before_trading_start` 时检测到当天没记录 → `target_position = None`，**不调仓**（维持上日）

### 10.2 半仓试运行

**场景**：阶段 3 D.1.4 计划的"6 个月半仓试运行"。

**处理（两种方式）**：

**方式 A**：策略代码内部减半
```python
g.half_size_mode = True
# before_trading_start:
target *= 0.5
```

**方式 B**：导出两份 CSV
```
daily_signal_history_v21_full.csv     # 原版（1.0 / 0.5 / 0.0）
daily_signal_history_v21_halfsize.csv # 减半（0.5 / 0.25 / 0.0）
```

**推荐方式 A**——更灵活，可随时切换。

### 10.3 滚动更新（实盘场景）

**场景**：实盘运行 1 年后，需要扩展信号 CSV 到最新日期。

**处理**：
- 不要重新生成全部 6.4 年（避免历史信号变化引起的回测漂移）
- 每日**追加**新一行到现有 CSV
- 定期（每月/每季度）做完整重生成对比，确认无漂移

### 10.4 权重季度更新

**场景**：基金披露新季度持仓（如 2026-Q2）。

**处理**：
- 更新 `f52_weights_history.csv`，追加 2026-Q2 行
- 重新生成信号 CSV（仅 2026-Q2 披露日之后的信号会变）
- 旧信号保持不变（防止前视）

---

## 11. 字段定义速查表

### 11.1 核心 CSV 字段一览（再次明确）

| 字段 | 类型 | 必填 | 取值 | 示例 |
|---|---|---|---|---|
| **date** | str | ✅ | YYYY-MM-DD | "2026-05-23" |
| **target_position** | float | ✅ | 0.0 / 0.5 / 1.0 | 1.0 |
| signal_version | str | 推荐 | 字符串 | "v2.1" |
| f11_pos | int | 可选 | 0 / 1 | 1 |
| f52_pos | float | 可选 | 0.00, 0.25, 0.50, 0.75, 1.00 | 0.75 |
| posavg_raw | float | 可选 | [0, 1] | 0.9000 |
| ema | float | 可选 | [0, 1] | 0.9500 |
| vol_ratio | float | 可选 | (0, ∞) | 0.939 |
| vol_boost_triggered | bool | 可选 | True / False | False |

### 11.2 阈值速查

| 决策点 | 阈值 |
|---|---|
| F1.1 连续日数 | 4（连续 4 日同向才切换状态）|
| F5.2 score → 1.00 | ≥ 0.75 |
| F5.2 score → 0.75 | ≥ 0.50 |
| F5.2 score → 0.50 | ≥ 0.30 |
| F5.2 score → 0.25 | ≥ 0.15 |
| F5.2 score → 0.00 | < 0.15 |
| PosAvg 权重 | [0.6, 0.4]（F1.1, F5.2）|
| EMA span | 3（α = 0.5）|
| vol_ratio 短期窗口 | 20 日 |
| vol_ratio 长期窗口 | 60 日 |
| vol_ratio B1 阈值 | < 0.7 |
| B1 触发的 raw 下限 | ≥ 0.5 |
| 3 档离散化边界 | 0.25, 0.75 |
| 调仓偏差阈值 | 5% |

---

## 12. 常见问题 FAQ

### Q1: 为什么要交付 6.4 年完整历史，而不是只交付当日信号？

**A**: 因为聚宽回测需要历史数据来验证策略。**回测 6.4 年 = 1544 个调仓决策 = 1544 行 CSV**。

实盘时只需要每日追加 1 行新信号即可。

### Q2: 如果未来策略升级到 v2.2，需要重做这个交付吗？

**A**: 需要。每次策略配置变化（如权重、EMA span、vol_ratio 阈值）都会改变历史信号。建议：
- 新版本生成新 CSV（`v22` 后缀）
- 旧版本 CSV 保留备份
- 聚宽策略代码更新文件名

### Q3: 聚宽自带 161128 数据，本地为什么还要拉？

**A**: 本地拉 161128 数据**只用于辅助计算和验证**，**不用于聚宽端**。
- 本地：导出信号 + 数据完整性检查
- 聚宽：从聚宽数据库读取 161128，按信号调仓

### Q4: CSV 上传到聚宽后多久能用？

**A**: 通常立即可用。如果 `read_file` 报错，等 1-2 分钟刷新一下页面。

### Q5: 一定要用 read_file 吗？能不能 hardcode 信号到代码里？

**A**: 不推荐 hardcode。原因：
- 1544 行数据 hardcode 太长
- 修改不便
- 不利于版本管理

正确做法：CSV + read_file。

---

## 13. 一份打勾就走的检查清单

在交付前，逐项打勾：

### 本地导出阶段
- [ ] daily_signal_history_v21_<日期>.csv 已生成
- [ ] 行数 ~1544（误差 ±5）
- [ ] target_position 只有 {0.0, 0.5, 1.0}
- [ ] date 字段是 A 股交易日（不是美股日）
- [ ] 分布约 56% / 24% / 20%（满 / 半 / 空）
- [ ] 11 项自检全部通过
- [ ] UTF-8 编码

### 聚宽上传阶段
- [ ] 已上传到聚宽 Research
- [ ] read_file 测试成功（在 Research Notebook 中验证）
- [ ] 行数读取正确

### 聚宽回测阶段
- [ ] 策略代码已部署
- [ ] 回测期 2020-01-02 ~ 2026-05-21
- [ ] 手续费 type='fund'（不是 'stock'）
- [ ] 滑点 0.2%
- [ ] 调仓时点 09:30
- [ ] 偏差阈值 5%

### 结果验证阶段
- [ ] AnnRet 在 25.5% ~ 26.8% 区间
- [ ] Sharpe 在 1.22 ~ 1.32 区间
- [ ] MaxDD 在 -22% ~ -20% 区间
- [ ] 交易次数 48 ~ 52
- [ ] 与本地结果差异在容差内

**全部打勾 → 进入模拟盘 → 6 个月观察 → 实盘**。

---

## 14. 变更日志

- **v1.0** (2026-05-23)：数据交付规范初版。基于 PA Champion v2.1 配置（F1.1 MA5/c4 + F5.2 MA13/c1 + PosAvg 权重 0.6/0.4 + EMA(3) + 3 档离散化 + vol_ratio B1 加仓）。包含核心 CSV 规范 + 辅助 CSV + 数据质量检查 + 聚宽端读取代码 + 工作流 + FAQ。

---

**🚀 本规范是阶段 1-4 研究 → 聚宽实盘部署的标准交付接口**
