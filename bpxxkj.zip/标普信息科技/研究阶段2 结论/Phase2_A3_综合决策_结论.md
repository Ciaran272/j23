# Phase 2 · A.3 综合决策报告

> 阶段 2 Phase A 收官：把 A.1 信号相关性 + A.2 EMA 平滑实验的结论捏合成最终方案。
>
> 完成日期：2026-05-22
> 关联：
> - [阶段 2 策划案 §A.3](XLK_161128_研究阶段2_策划案.md)
> - [A.1 信号相关性诊断 结论](Phase2_A1_信号相关性诊断_结论.md)
> - [A.2 EMA 平滑实验 结论](Phase2_A2_EMA平滑实验_结论.md)

---

## 一句话结论

**Phase A 最终方案：PosAvg + EMA(span=3) + 3 档离散化**（Sharpe 1.18，年化 24.18%）。

---

## 1. 决策树遍历

按策划案 §A.3 的判定路径：

```
A.1 Pearson < 0.7 ?
└── 实测 0.5813 < 0.7 → 是 → F5.2 有独立信号
    └── A.2 最优 EMA Sharpe > baseline + 0.03 ?
        └── 实测 1.18 - 1.09 = +0.09 → 是 (差 0.09 > 0.03)
            └── ★ 最终方案 = PosAvg + EMA(span=3) + 离散化 ★
```

**注**：策划案默认假设是"5 档离散"，但 A.2 实测发现**3 档离散更优**（Sharpe 1.18 vs 5档同 span 的 1.09，且 MaxDD 更优）。决策树文字模板做了相应替换。

---

## 2. Phase A 最终方案 — 完整定义

### 2.1 信号生成（每个美股交易日 T-1 收盘后计算）

```python
# Step 1: F1.1 base position（XLK MA5/c4，状态机）
f11_position = 1 if (XLK 最近 4 日均 close > MA5) else \
               0 if (XLK 最近 4 日均 close < MA5) else \
               f11_position_prev_day  # maintain

# Step 2: F5.2 base position（Top4 MA13/c1，加权得分）
nvda_above = 1 if (NVDA close > MA13) else 0
aapl_above = 1 if (AAPL close > MA13) else 0
msft_above = 1 if (MSFT close > MA13) else 0
avgo_above = 1 if (AVGO close > MA13) else 0
score = 0.348 * nvda_above + 0.306 * aapl_above + 0.226 * msft_above + 0.120 * avgo_above
f52_position = (
    1.00 if score >= 0.75 else
    0.75 if score >= 0.50 else
    0.50 if score >= 0.30 else
    0.25 if score >= 0.15 else
    0.00
)

# Step 3: PosAvg 合成
posavg_raw = 0.5 * f11_position + 0.5 * f52_position

# Step 4: EMA 平滑（span=3）
posavg_smoothed_t = (2/4) * posavg_raw_t + (2/4) * posavg_smoothed_t_minus_1
# 即 EMA 系数 alpha = 2/(span+1) = 2/4 = 0.5

# Step 5: 3 档离散化
target_position = round(posavg_smoothed * 2) / 2  # 取整到 {0, 0.5, 1.0}
```

### 2.2 调仓时点
- A 股 T 日 09:30 开盘前依据上述 `target_position` 调整 161128 持仓
- 信号源自 T-1 日美股收盘（北京时间 T 日清晨 4:00 或 5:00，夏令时差异）

### 2.3 数据需求
- 5 只美股标的日 K：XLK / NVDA / AAPL / MSFT / AVGO（adjclose 含拆股复权）
- A 股 LOF 161128 日 K（聚宽）

### 2.4 关键参数

| 参数 | 值 | 来源 |
|---|---|---|
| F1.1 MA 窗口 | 5 | Phase 1 网格最优 |
| F1.1 confirm 天数 | 4 | Phase 1 网格最优 |
| F5.2 MA 窗口 | 13 | Phase 1 网格最优 |
| F5.2 confirm 天数 | 1 | Phase 1 网格最优 |
| F5.2 权重 | [0.348, 0.306, 0.226, 0.120] | 基金持仓权重归一化 |
| F5.2 仓位映射阈值 | [0.75, 0.50, 0.30, 0.15] | 策划案 v1.0 §5.2 原文 |
| PosAvg 因子权重 | [0.5, 0.5] | A.1 验证 F1.1/F5.2 部分独立后取等权 |
| EMA span | 3 | A.2 网格最优 |
| 离散化档数 | 3 (0/0.5/1) | A.2 网格最优 |

---

## 3. 实测表现汇总

| 指标 | Phase A 新方案 | PosAvg baseline | F1.1 MA5/c4 单独 | BH-161128 |
|---|---|---|---|---|
| 年化 | **24.18%** | 21.13% | 21.42% | 22.70% |
| Sharpe | **🏆 1.18** | 1.09 | 1.06 | 0.90 |
| MaxDD | -25.06% | -22.77% | -24.07% | **-34.68%** |
| Calmar | **0.97** | 0.93 | 0.89 | 0.65 |
| 交易数（6.4 年）| 48 | 68 | 48 | 0 |
| 平均持仓天数 | 8.2 | 3.1 | — | — |
| 持仓占比 | 56.0% | 40.4% | 66.6% | 100% |

**首次在所有风险调整指标上明确超越 BH**（Sharpe +0.28, Calmar +0.32, MaxDD 省 10 点）。

---

## 4. 保留的备选方案

A.2 测出的另一候选 **span1_3-level**（仅 3 档离散化，无 EMA）也明确改善 baseline，作为"极端风险厌恶用户备选"：

| 指标 | span1_3-level | 新冠军 span3_3-level |
|---|---|---|
| 年化 | 22.08% | **24.18%** |
| Sharpe | 1.09 | **1.18** |
| **MaxDD** | **-19.90%** ★ | -25.06% |
| **Calmar** | **1.11** ★ | 0.97 |
| 交易数 | 65 | 48 |

**Phase A 输出共 3 个候选**（按风险偏好排序）：

| 候选 | 适用场景 |
|---|---|
| **A. 新冠军 span3_3-level** | 追求 Sharpe + 平衡（默认推荐）|
| B. span1_3-level | 极端风险厌恶 — Calmar 1.11 全场最高 |
| C. F1.1 MA5/c4 单独 | 想极简实施 — 只需 XLK 日 K |

---

## 5. 关键警告（进入 Phase B 前必读）

1. **新冠军是从 24 个组合里挑出的"样本内最优"** — Phase B walk-forward 必须验证它在不同 Train/Test 分割下是否仍最优
2. **MaxDD 略恶化**（-22.77% → -25.06%，多亏 2.3 个点）— 接受这个代价换 Sharpe +0.09 和 AnnRet +3.05%。如果实盘后用户对这 2.3 点回撤过度敏感，降级到候选 B
3. **EMA 是有记忆的状态变量** — 实盘冷启动时需要至少 5-10 日"暖机"，让 EMA 收敛到合理值。否则前几日的目标仓位会有偏差
4. **3 档离散化在切换瞬间会有"跳跃式调仓"** — 从 0.5 突然到 1.0（半仓→满仓）单次调动 50% 资金。LOF 流动性差时这个冲击需要监控
5. **2026-05-22 当前信号**：F1.1=1, F5.2=1（score 0.88），PosAvg_raw = 1.0，EMA_smoothed = 1.0，3 档离散 = **1.0（满仓）** —— 与 Phase 1 双冠军一致

---

## 6. Phase B 将测试的问题

Phase A 新冠军在 2020-2026 全样本上选出。Phase B 用 expanding window 验证其稳健性：

| Split # | Train | Test | 关键问题 |
|---|---|---|---|
| 0 (建议加) | 2020-2021 | 2022（熊市）| Train 期没见过熊市，新冠军能否生存？|
| 1 | 2020-2022 | 2023（AI 大涨）| MA5/c4 + EMA3 + 3档 在 2023 是否有效？|
| 2 | 2020-2023 | 2024 | 稳定上涨期表现 |
| 3 | 2020-2024 | 2025 | 高位震荡期表现 |
| 4 | 2020-2025 | 2026 YTD | 当前阶段表现 |

**特别关注**：
- 早期 split（#0, #1）选出的最优参数是否包含 MA5/c4 + EMA(3) + 3档？还是不同的参数组合？
- 若早期 split 选出的是 baseline 参数 → "EMA + 3档"是 2024 后才被识别 → 偏置警告
- 若早期 split 也选出相同参数 → 强稳健性 → 直接上线

---

## 7. 实施清单（如果 Phase B 通过后上线）

- [ ] 每日 17:00（北京时间，美股盘前）跑数据更新脚本：`refresh_xlk.py` + `download_top4_holdings.py`
- [ ] 每日次日 04:30（美股收盘后）跑 `print_today_signal_phaseA.py`（新版，含 EMA 平滑）
- [ ] 信号输出格式：`目标仓位（0 / 0.5 / 1）` + `当前持仓` + `调仓金额` + `预计成本`
- [ ] 调仓窗口：A 股 09:30 开盘竞价
- [ ] 每周对账：实际成交价 vs 预期，检查滑点是否在 0.1% 假设内
- [ ] 每月评审：实际 Sharpe / MaxDD 是否在历史区间，若 30 日滚动 Sharpe 持续 < 0.5 → 触发凯利动态减仓（Phase C-3 实现后）

---

## 8. Phase A 输出总结（给 Phase B/C 用）

```yaml
phase_a_output:
  champion:
    name: "PosAvg + EMA(3) + 3-level"
    factors:
      F1.1: {ma_window: 5, confirm_days: 4}
      F5.2: {ma_window: 13, confirm_days: 1}
    posavg_weights: [0.5, 0.5]
    ema_span: 3
    discretization: 3-level  # round to {0, 0.5, 1}
    full_period_metrics:
      ann_ret_pct: 24.18
      sharpe: 1.18
      max_dd_pct: -25.06
      calmar: 0.97
      trades: 48
      avg_hold_days: 8.2

  alternatives:
    - name: "PosAvg + 3-level (no EMA)"
      ema_span: 1
      discretization: 3-level
      adv: "MaxDD -19.90%, Calmar 1.11"
      use_case: "extreme risk-averse"
    - name: "F1.1 MA5/c4 alone"
      no_ensemble: true
      adv: "极简，只需 XLK"
      use_case: "minimal implementation"

  caveats:
    - "样本内最优，需 Phase B 验证"
    - "MaxDD 略恶化 -2.3 点"
    - "EMA 需 5-10 日暖机"
    - "3 档跳跃式调仓影响流动性"

  current_signal_2026_05_22:
    f11_position: 1.0
    f52_score: 0.880
    f52_position: 1.0
    posavg_raw: 1.0
    posavg_smoothed: 1.0
    target_position: 1.0  # 满仓
```

---

## 9. 变更日志

- **2026-05-22 v1.0**：Phase A 综合决策。**新冠军：PosAvg + EMA(3) + 3档离散化（Sharpe 1.18）**。保留 2 个备选。进入 Phase B walk-forward 验证。
