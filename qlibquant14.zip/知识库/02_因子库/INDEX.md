---
name: index-02-factor-library
description: 一级分类 02_因子库 —— Alpha-101/GTJA-191 算子词典与公式、Barra 风格因子、基本面因子、技术指标、A 股实证基准、另类数据清单
category: 02_因子库
tags: [alpha101, gtja191, barra, 基本面因子, 技术指标, talib, rsrs, 另类数据]
created: 2026-05-16
updated: 2026-05-29
status: stable
---

# 02_因子库 · 索引

本分类回答**"用什么打 alpha"**——收录所有可直接使用或参考的因子表达式、算子定义、A 股实证基准。是整本知识库**体量最大**的一级分类。

## 范围

- **因子公式表达式**：Alpha-101 全部 101 条 + GTJA-191 全部 191 条，作为查询表入库
- **聚宽 Python 实现**：先 10 个样板（覆盖代表性算子组合），其余按需补全
- **A 股实证基准**：来自因子投资 ch3 的 t 值 / 月均超额 / 双重排序数字，作为"我的因子是否合理"的对照表

---

## 二级分类与内容来源

| # | 二级分类 | 一句话定位 | 主要来源 |
|---|---|---|---|
| 2.1 | 算子词典 | rank / ts_rank / delay / correlation / decay_linear / indneutralize / SMA / WMA / REGBETA 等 30+ 算子的语义、命名映射、聚宽实现 | Alpha-101 附录 A.2 + GTJA-191 附录 2 + 新写聚宽实现 |
| 2.2 | 价量公式因子库 | Alpha-101 的 101 条 + GTJA-191 的 191 条因子表达式 | Alpha-101 附录 A.1 + GTJA-191 ch3.3 |
| 2.3 | Barra 风格因子 | CNE5 九大类风格因子完整定义与矩阵推导 | 因子投资 ch7.2 + Python 实战表 7-1 |
| 2.4 | 基本面因子 | 市场 / 规模 / 价值 / 动量 / 盈利 / 投资 / 换手率 + A 股财务数据 PIT 处理 | 因子投资 ch3 |
| 2.5 | 技术指标 | MA / EMA / MACD / RSI / KDJ / BOLL 布林带 / Talib K 线形态 / RSRS 四版本 / 波动率因子 | Whale-Quant ch03 + Python 实战 ch5/ch7 + MyInvestPilot |
| 2.6 | A 股因子实证基准库 | t 值 / 月均超额 / 双重排序结果，作为"对照表" | 因子投资 ch3/ch4.3 + GTJA-191 ch3.4/ch3.6.2 |
| 2.7 | 另类数据备查清单 | 30+ 类替代数据 + 8 类特征清单（仅作 brainstorming 索引） | Marti ch3 + ch4.3.4-4.3.9 |

---

## 详细内容计划

### 2.1 算子词典
- Alpha-101 附录 A.2：rank / delay / correlation / covariance / delta / decay_linear / indneutralize / ts_rank / ts_min / ts_max / ts_argmax / ts_argmin / stddev / sum / product / scale / signedpower 等 21 个
- GTJA-191 附录 2：RANK / MAX / MIN / STD / CORR / COVIANCE / DELTA / SUM / MEAN / TSRANK / TSMIN / TSMAX / PROD / COUNT / REGBETA / REGRESI / SMA / WMA / SUMIF / DECAYLINEAR / FILTER / HIGHDAY / LOWDAY / SEQUENCE / SUMAC 等 30+
- **新写**：Alpha-101 ↔ GTJA-191 命名映射表（rank↔RANK、ts_rank↔TSRANK、decay_linear↔DECAYLINEAR、indneutralize↔风格中性预处理）
- **新写**：每个算子的 pandas / jqdatasdk 实现示例

### 2.2 价量公式因子库
- Alpha-101 全 101 条（附录 A.1），**标注 4 个 delay-0 因子 #42 / #48 / #53 / #54**（需在 close 附近交易）
- GTJA-191 全 191 条（ch3.3），**标注 OCR 损坏需回 PDF 校对的 Alpha49-Alpha51 / Alpha137 / Alpha146 / Alpha152 / Alpha156-Alpha157 / Alpha165-Alpha166 / Alpha170-Alpha172 / Alpha186 / Alpha190**
- **聚宽实现样板（10 个）**：
  - Alpha-101：#1（成交量分位排序）、#101（日内动量）、#42 / #48 / #53 / #54（4 个 delay-0）
  - GTJA-191：Alpha1（成交量背离）+ 2-3 个高 IC 简单因子
- **A 股化注记**：行业分类映射（GICS → 中信 / 申万）、IndClass 的处理
- **OCR 校对注记**：Alpha-101 中约 12 个截图型 alpha（#25-#36 一带、#38-#40、#43、#67 等）必须打开 `Alpha-101_origin.pdf` 翻附录 A 对应页

### 2.3 Barra 风格因子
- 因子投资 ch7.2 CNE5 完整推导（**矩阵公式 OCR 重灾区**：式 7.19-7.40 全部回 PDF）
- Python 实战表 7-1：流动性 STOM / STOQ / STOS / STOA / Ins / Size / non-linear-size / Market cap / MSM / MSQ / MSS；动量 RSTR_barra / RSTR_m24 / RSTR_m12 / RSTR_m6 / RSTR_m3 / RSTR_m1；波动率 DASTD / CMRA / HSIGMA / Beta / Yieldvol_X / High_low_X / VOL_X 等 40+
- **新写**：A 股 Barra 因子的聚宽实现
- **OCR 校对注记**：表 7-1 中 RSTR 系列的 L/T 参数前后不一致（疑似 OCR + 作者笔误叠加），所有半衰期值要交叉验证

### 2.4 基本面因子
- 因子投资 ch3 全章：市场 / 规模 / 价值 BM / 动量 / 盈利 ROA-ROE / 投资 AG-Inv / 换手率
- 因子投资 ch3.1 **A 股财务数据处理**（核心 A 股特化）：
  - 报告期 / 财务报表 / 基准报告期 / 调整和更正
  - 单季度数据 / TTM 数据构造
  - PIT（point-in-time）处理避免未来函数
- Marti ch4.3.3 基本面特征 15 项清单（仅作补充检查表）
- **聚宽落地笔记**：`get_fundamentals` / `valuation` / `income` / `cash_flow` / `balance` 接口

### 2.5 技术指标
- Whale-Quant ch03：MA / SMA / EMA / RSI / 随机指标 / MACD / 成交量
- Python 实战 ch5.1：Talib MA / EMA / MACD / MACD 斜率
- Python 实战 ch5.1.5：国内版 SMA_CN / RSI_CN / KDJ_CN / MACD_CN
- Python 实战 ch5.2.1：ADX / ADR / ADOSC / ATR
- Python 实战 ch5.2.2：Talib 45 个 K 线形态识别函数清单（CDL 系列）
- Python 实战 ch7.2：**RSRS 阻力支撑相对强度** 四版本（标准 / 标准分 / 修正 / 右偏）—— A 股招牌择时因子
- Python 实战 ch7.3：波动率因子（对数收益率自波动 / 简单自波动 / 收盘价 Beta / 收益率 Beta）
- MyInvestPilot Bollinger Bands：BOLL 中轨/上下轨/%B/带宽 + 均值回归/突破双模式 + ETF/QDII 适配
- **聚宽落地笔记**：聚宽自带 talib / `get_price`

### 2.6 A 股因子实证基准库
- 因子投资 ch3 各因子的：等权 / 市值加权 t 值、月均超额、10 组单调性、与市值的双重排序结果
- 因子投资 ch4.3 CH-3 vs FF3 在 A 股的对比数字
- 因子投资 ch3.3 规模因子在 2017 后崩塌的实证注脚
- GTJA-191 ch3.4 因子检验：日度 IC=0.057、T_stat=18.23、胜率 88.7%
- GTJA-191 ch3.6.2 实证：2012-2017 较中证 500 年化超额 50.2%、IR=4.67、最大回撤 5.9%（扣交易成本后）
- **A 股化注记**：所有数字标实证窗口 + "未含 / 含交易成本"边界；提醒 2021-2025 五年因子表现剧变需独立验证

### 2.7 另类数据备查清单
- Marti ch3 替代数据 30+ 类：新闻 / 社交媒体 / 地理位置 / 环境 / 加密资产 / 天气 / 卫星 / IoT / 政府 / 供应链 / NLP / 网络流量 / 情感 / 地理空间 / 音频 / 视频 / 文本 / 行为 / 图像 / 人口统计 / 传感器 / 客户 / 人类活动 / 交通 / 消费者情绪 / 就业 / 政治 / 零售 / 运输
- Marti ch4.3.4 情绪特征 20+ 项 / ch4.3.5 文本特征 8 项 / ch4.3.6-4.3.9 音频 / 图像 / 视频 / 网络特征
- **取舍**：仅作 brainstorming 索引清单，**不展开具体方法**；遇到具体方向需求时再回 Marti 原文或外部资料

---

## 文件清单

按二级分类的文件清单：

### 2.1_算子词典 ([INDEX](2.1_算子词典/INDEX.md))
- [算子_alpha101_定义.md](2.1_算子词典/算子_alpha101_定义.md) — Alpha-101 论文附录 A.2 的 21 个算子 + A.3 输入数据
- [算子_gtja191_定义.md](2.1_算子词典/算子_gtja191_定义.md) — GTJA-191 附录 2 表 15 的 19 个数据变量 + 30+ 算子（含 3 处 OCR 修正）
- [算子_命名映射.md](2.1_算子词典/算子_命名映射.md) — Alpha-101 ↔ GTJA-191 命名映射表
- [算子_聚宽实现.md](2.1_算子词典/算子_聚宽实现.md) — 全部算子的 pandas / jqdatasdk 实现

### 2.2_价量公式因子库 ([INDEX](2.2_价量公式因子库/INDEX.md))
- [alpha101_全部公式.md](2.2_价量公式因子库/alpha101_全部公式.md) — Alpha-101 全 101 条公式 + delay-0 / indneutralize 标注
- [gtja191_全部公式.md](2.2_价量公式因子库/gtja191_全部公式.md) — GTJA-191 全 191 条公式 + 4 级 OCR 状态标注（含 6 个完全缺失）
- [公式_聚宽样板实现.md](2.2_价量公式因子库/公式_聚宽样板实现.md) — 10 个代表性因子的完整聚宽 Python 实现样板

### 2.3_Barra风格因子 ([INDEX](2.3_Barra风格因子/INDEX.md))
- [CNE5_模型推导.md](2.3_Barra风格因子/CNE5_模型推导.md) — Barra CNE5 完整推导（国家 + 28 行业 + 10 风格）+ WLS + 纯因子组合 + 协方差调整
- [九大风格因子_定义.md](2.3_Barra风格因子/九大风格因子_定义.md) — 10 大类风格细类定义（GTJA-191 附录 1 表 14；文件名保留兼容性）
- [BARRA_A股因子名录.md](2.3_Barra风格因子/BARRA_A股因子名录.md) — Python 实战表 7-1 的 41 个 A 股 Barra 因子名录 + OCR 校对
- [BARRA_聚宽实现.md](2.3_Barra风格因子/BARRA_聚宽实现.md) — 10 大风格因子聚宽实现 + 半衰加权 + 标准化 + CNE5 求解器框架

### 2.4_基本面因子 ([INDEX](2.4_基本面因子/INDEX.md))
- [财务数据处理_PIT.md](2.4_基本面因子/财务数据处理_PIT.md) — A 股财报披露 + 4 种记录类型 + 单季度/TTM + PIT 原则
- [价值与盈利因子.md](2.4_基本面因子/价值与盈利因子.md) — 价值（BM/EP/SP）+ 盈利（ROA/ROE/GP）+ CH-3 为何用 EP 替代 BM
- [投资与质量因子.md](2.4_基本面因子/投资与质量因子.md) — 投资（AG/Inv）+ F-Score 9 项打分 + 换手率反转
- [基本面因子_聚宽实现.md](2.4_基本面因子/基本面因子_聚宽实现.md) — get_fundamentals 完整用法 + F-Score 代码 + 端到端 4 因子策略

### 2.5_技术指标 ([INDEX](2.5_技术指标/INDEX.md))
- [经典技术指标_MA_RSI_MACD_KDJ.md](2.5_技术指标/经典技术指标_MA_RSI_MACD_KDJ.md) — 趋势/摆动/动量经典 + **国内版 SMA_CN vs 国际 EMA 对照**
- [布林带BOLL_波动通道.md](2.5_技术指标/布林带BOLL_波动通道.md) — BOLL 中轨/上下轨/%B/带宽公式 + 均值回归与突破双模式 + Qlib 表达式 + A 股 ETF/QDII 适配
- [Talib_K线形态.md](2.5_技术指标/Talib_K线形态.md) — Talib **45 个 CDL 函数完整清单** + A 股实证（弱）
- [RSRS_四版本_A股招牌择时.md](2.5_技术指标/RSRS_四版本_A股招牌择时.md) — RSRS 四版本 + 光大证券原研报 + **完整可跑择时策略**
- [波动率与其他.md](2.5_技术指标/波动率与其他.md) — HV/IVOL/Beta + OBV/VR/MFI/ATR/CCI + A 股**最强技术因子排行**

### 2.6_A股因子实证基准库 ([INDEX](2.6_A股因子实证基准库/INDEX.md))
- [单因子实证表_完整.md](2.6_A股因子实证基准库/单因子实证表_完整.md) — 30+ 单因子 t 值 / 月均超额对照表（含**A 股最强 5 alpha 排行**：-TVR_1 / STOM_barra / -IVOL / EP / -AG）
- [多因子组合实证.md](2.6_A股因子实证基准库/多因子组合实证.md) — GTJA-191 极致（IR=4.67）+ 3.1 工业级（IR=0.3-0.8）+ 4.1 三种配权 + RSRS 择时
- [失效案例库.md](2.6_A股因子实证基准库/失效案例库.md) — A 股 4 个典型失效（小市值2017 / 动量 / 白马股2021 / DMA2024）+ 衰减形态 + 防御

### 2.7_另类数据备查清单 ([INDEX](2.7_另类数据备查清单/INDEX.md)) ✓ 已成型
- [替代数据30类清单.md](2.7_另类数据备查清单/替代数据30类清单.md) — Marti ch3 30+ 类替代数据 + A 股可获取性分类（8 易 / 8 中 / 14 难）+ 推荐工具
- [六类特征清单.md](2.7_另类数据备查清单/六类特征清单.md) — Marti ch4.3.4-4.3.9 情绪/文本/音频/图像/视频/网络特征 + A 股 ML 可行性

---

[← 返回主索引](../INDEX.md)
