---
name: ic-half-life-decay
description: IC 半衰期衰减分析 —— 计算因子 IC 在 lag 1-200 的衰减曲线，标注半衰期位置，量化因子信号的"保质期"
category: 02_因子库/2.6_A股因子实证基准库
tags: [IC, 半衰期, 因子衰减, 信号持续性, 调仓频率, 聚宽实现]
created: 2026-05-19
updated: 2026-05-19
status: with-jq-impl
---

# IC 半衰期衰减分析

## TL;DR

把因子值与未来第 1、2、3 … N 天的收益分别算 Rank IC，画出衰减曲线。IC 降到初始值一半的 lag 天数 = **半衰期**。半衰期决定了因子的最优调仓频率——半衰期 5 天的因子不适合月度调仓，半衰期 40 天的因子不适合日度调仓。

## 来源

- ShenzhenLime/quant `factor_analyze.py` § `ic_half_life`（MIT 协议）
- 概念等价于 Barra USE4 Technical Notes "Alpha Decay" 章节

## 1. 为什么需要 IC 半衰期

### 问题

因子 IC = 0.05 看起来不错，但这个 IC 是"因子值 → 下一期收益"的相关性。如果"下一期"是 1 天，那月度调仓时因子信号早就过期了。

| 半衰期 | 含义 | 适合的调仓频率 |
|---|---|---|
| 1-3 天 | 极短命信号（日内动量/反转） | 日度 |
| 5-10 天 | 短期信号（周度动量/事件） | 周度 |
| 15-30 天 | 中期信号（基本面/价值） | 月度 |
| 60+ 天 | 长期信号（质量/成长） | 季度 |

### 实用价值

1. **选调仓频率**：半衰期 × 0.5 ~ 0.8 ≈ 最优调仓间隔
2. **判断因子失效**：半衰期缩短 = 因子被拥挤/失效的早期信号
3. **多因子组合**：短半衰期因子 + 长半衰期因子搭配，覆盖不同时间尺度

**A 股化注记**：
- A 股短期反转因子半衰期约 3-5 天（比美股更短，散户结构导致）
- A 股价值因子半衰期约 40-60 天（与美股接近）
- A 股动量因子半衰期极短且不稳定（长期动量在 A 股失效）

## 2. 方法论

### 2.1 算法

```
输入：因子值 DataFrame（日期 × 股票）、收益率 DataFrame
输出：IC 衰减曲线 + 半衰期天数

for lag in 1, 2, ..., max_lag:
    1. 把因子值与 lag 天后的收益对齐
    2. 每天截面算 Spearman Rank IC
    3. 取所有天的 IC 均值 → IC(lag)

半衰期 = 第一个满足 |IC(lag)| < |IC(1)| / 2 的 lag
```

### 2.2 注意事项

| 陷阱 | 处理 |
|---|---|
| 停牌股在 lag 期间无收益 | 剔除停牌日的股票 |
| 涨跌停导致收益截断 | 不影响 rank IC（排序不变） |
| 样本量随 lag 增大而减少 | 设最小样本量阈值（如 100 只） |
| IC(1) 本身就很小 | 如果 |IC(1)| < 0.02，半衰期无意义 |

## 3. 聚宽落地实现

```python
"""
IC 半衰期衰减分析 —— 聚宽研究环境实现
"""
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from jqdata import *
from jqfactor import get_factor_values


def ic_decay_curve(
    universe="000906.XSHG",
    factor_name="market_cap",
    start_date="2019-01-01",
    end_date="2023-12-31",
    max_lag=60,
    min_stocks=100,
):
    """
    计算因子 IC 衰减曲线

    Args:
        universe: 股票池指数代码
        factor_name: jqfactor 因子名
        start_date/end_date: 计算区间
        max_lag: 最大滞后天数
        min_stocks: 每天最少股票数

    Returns:
        dict: {"ic_curve": Series(lag→IC), "half_life": int or None}
    """
    trade_days = list(get_trade_days(start_date, end_date))

    # 获取股票池
    pool = get_index_stocks(universe, date=trade_days[-1])

    # 获取因子值（日频）
    factor_data = get_factor_values(
        pool, factors=[factor_name],
        start_date=start_date, end_date=end_date, count=None
    )[factor_name]  # DataFrame: date × stock

    # 获取收益率
    prices = get_price(
        pool, start_date=start_date, end_date=end_date,
        fields=["close"], panel=False
    )
    close_pivot = prices.pivot(index="time", columns="code", values="close")
    daily_ret = close_pivot.pct_change()

    # 对齐日期索引
    common_dates = factor_data.index.intersection(daily_ret.index)
    factor_data = factor_data.loc[common_dates]
    daily_ret = daily_ret.loc[common_dates]

    ic_by_lag = {}

    for lag in range(1, max_lag + 1):
        # 未来 lag 天的累计收益
        future_ret = daily_ret.shift(-lag)  # shift 负数 = 未来
        # 实际上要用累计收益而非单日
        cum_ret = close_pivot.shift(-lag) / close_pivot - 1

        ics = []
        for i in range(len(common_dates) - lag):
            date = common_dates[i]
            fac_row = factor_data.iloc[i].dropna()
            ret_row = cum_ret.iloc[i].dropna()

            # 取交集
            common_stocks = fac_row.index.intersection(ret_row.index)
            if len(common_stocks) < min_stocks:
                continue

            f = fac_row[common_stocks].values
            r = ret_row[common_stocks].values

            # Spearman Rank IC
            ic, _ = spearmanr(f, r)
            if not np.isnan(ic):
                ics.append(ic)

        ic_by_lag[lag] = np.mean(ics) if ics else np.nan

    ic_curve = pd.Series(ic_by_lag)

    # 计算半衰期
    half_life = None
    ic_1 = abs(ic_curve.get(1, 0))
    if ic_1 > 0.02:  # IC(1) 太小则无意义
        threshold = ic_1 / 2
        for lag, ic_val in ic_curve.items():
            if abs(ic_val) < threshold:
                half_life = lag
                break

    return {"ic_curve": ic_curve, "half_life": half_life, "ic_1": ic_1}


def ic_decay_plot(result, factor_name="factor", title=None):
    """可视化 IC 衰减曲线 + 半衰期标注"""
    import matplotlib.pyplot as plt

    ic_curve = result["ic_curve"]
    half_life = result["half_life"]

    fig, ax = plt.subplots(figsize=(12, 5))

    # IC 曲线
    ax.bar(ic_curve.index, ic_curve.values, width=0.8,
           color=["#d32f2f" if v > 0 else "#388e3c" for v in ic_curve.values],
           alpha=0.7)

    # 半衰期标注
    if half_life:
        ax.axvline(x=half_life, color="blue", linestyle="--", linewidth=1.5)
        ax.annotate(
            f"半衰期 = {half_life} 天",
            xy=(half_life, ic_curve.iloc[0] * 0.5),
            xytext=(half_life + 5, ic_curve.iloc[0] * 0.7),
            arrowprops=dict(arrowstyle="->", color="blue"),
            fontsize=11, color="blue",
        )

    # IC(1)/2 水平线
    ic_1 = result["ic_1"]
    ax.axhline(y=ic_1 / 2, color="gray", linestyle=":", alpha=0.5)
    ax.axhline(y=-ic_1 / 2, color="gray", linestyle=":", alpha=0.5)

    ax.set_xlabel("Lag (交易日)")
    ax.set_ylabel("Rank IC")
    ax.set_title(title or f"{factor_name} IC 衰减曲线")
    plt.tight_layout()
    plt.show()


def recommend_rebalance_freq(half_life):
    """根据半衰期推荐调仓频率"""
    if half_life is None:
        return "IC(1) 过小，因子信号不显著"
    if half_life <= 3:
        return f"半衰期 {half_life} 天 → 建议日度调仓（或放弃，成本可能吃光收益）"
    elif half_life <= 10:
        return f"半衰期 {half_life} 天 → 建议周度调仓"
    elif half_life <= 30:
        return f"半衰期 {half_life} 天 → 建议月度调仓"
    elif half_life <= 60:
        return f"半衰期 {half_life} 天 → 建议月度或季度调仓"
    else:
        return f"半衰期 {half_life} 天 → 建议季度调仓（长期因子）"
```

## 4. A 股典型因子半衰期参考

| 因子 | 半衰期（交易日） | 推荐频率 | 备注 |
|---|---|---|---|
| 5 日反转（-ret_5d） | 3-5 | 日度/周度 | A 股最强 alpha，但衰减极快 |
| 20 日换手率（-TVR_20） | 8-12 | 周度 | 交易摩擦类 |
| 特质波动率（-IVOL） | 15-25 | 月度 | 风险类 |
| EP（市盈率倒数） | 40-60 | 月度/季度 | 价值类 |
| ROE（净资产收益率） | 60-90 | 季度 | 质量类 |
| 市值（-ln_cap） | 30-50 | 月度 | 2017 后半衰期缩短 |

**注意**：以上数字为经验估计，不同样本期和股票池会有差异。建议用上方代码在自己的回测区间实测。

## 5. 与因子失效的关系

IC 半衰期是**因子健康度的动态监控指标**：

| 信号 | 含义 |
|---|---|
| 半衰期稳定 | 因子信号持续性正常 |
| 半衰期逐年缩短 | 因子被拥挤，信号被更快消化 |
| 半衰期突然归零 | 因子失效（IC(1) 本身变为 0） |
| 半衰期变长 | 罕见，可能是市场结构变化（如散户退出） |

**实操建议**：每季度重算一次核心因子的半衰期，与历史值对比。如果缩短 > 30%，考虑降低该因子权重或提高调仓频率。

## 参考与延伸

- [[empirical-single-factor-table]] — 单因子实证表（IC 数值的静态快照）
- [[empirical-factor-decay-cases]] — 失效案例库（半衰期归零的 4 个案例）
- [[backtest-factor-decay]] — 因子失效与拥挤（半衰期缩短是拥挤的早期信号）
- [[pathway-robustness-test]] — Pathway 鲁棒性测试（半衰期决定 pathway 测试的 freq 参数）
- [[index-04-04-trading-cost-capacity]] — 成本与容量（半衰期短 → 高频调仓 → 成本约束更紧）
