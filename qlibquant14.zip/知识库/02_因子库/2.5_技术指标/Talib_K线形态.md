---
name: talib-k-line-patterns
description: Talib 库 45 个 K 线形态识别函数完整清单 —— CDL* 系列函数 + 经典形态含义 + A 股实证有效性 + 聚宽实现
category: 02_因子库/2.5_技术指标
tags: [Talib, K线形态, CDL, 烛台图, 单根K线, 双根K线, 三根K线, A股]
created: 2026-05-17
updated: 2026-05-17
source: 原始资料文件/Python量化交易实战/Python量化交易实战.md (ch5.2.2)
status: with-jq-impl
---

# Talib K 线形态识别 45 个函数

## TL;DR

Talib 库提供 **45 个 K 线形态识别函数**（CDL* 系列）——从单根 K 线（如 CDLDOJI 十字星）到三根 K 线（如 CDLMORNINGSTAR 早晨之星）。本文给出完整清单 + 经典形态含义 + **A 股实证有效性**（多数不显著）+ 聚宽实现。**警告**：K 线形态在 A 股**整体显著性弱**——多数论文未实证其量化有效性。

## 来源

- **Python 实战 ch5.2.2**：[Python量化交易实战.md](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — 45 个 CDL 函数清单
- **Talib 官方文档**：https://github.com/mrjbq7/ta-lib

---

## 1. 函数命名与输出

### 调用约定

```python
import talib

# 通用接口
signal = talib.CDLPATTERN(open, high, low, close)

# 输出：(n,) 数组
# 100 = 强多头形态
# -100 = 强空头形态
# 0 = 无信号
# 部分函数返回 200, -200（罕见的极强信号）
```

### 输入要求

- 4 个 1D 数组：open / high / low / close
- 长度必须相同
- 通常用 numpy array（pandas Series 也行）

---

## 2. 45 个 CDL 函数完整清单

### 2.1 反转形态（最常见）

| 函数 | 中文 | 涉及 K 线数 | 多空信号 |
|---|---|---|---|
| **CDLDOJI** | 十字星（同价开收）| 1 | 反转 |
| **CDLDOJISTAR** | 十字星（带跳空）| 2 | 反转 |
| **CDLDRAGONFLYDOJI** | 蜻蜓十字 | 1 | **看多** |
| **CDLGRAVESTONEDOJI** | 墓碑十字 | 1 | **看空** |
| **CDLHAMMER** | 锤子线 | 1 | **看多反转** |
| **CDLHANGINGMAN** | 上吊线 | 1 | **看空反转** |
| **CDLINVERTEDHAMMER** | 倒锤子线 | 1 | 看多反转 |
| **CDLTAKURI** | 探水竿（长下影十字）| 1 | 看多 |
| **CDLBELTHOLD** | 捉腰带 | 1 | 多空通用 |
| **CDLHIGHWAVE** | 长腿十字 | 1 | 反转 |

### 2.2 双 K 线反转

| 函数 | 中文 | 多空信号 |
|---|---|---|
| **CDLENGULFING** | 吞没（看涨/看跌）| 强反转 |
| **CDLHARAMI** | 母子线（孕线）| 反转 |
| **CDLHARAMICROSS** | 母子十字 | 反转（更强）|
| **CDLDARKCLOUDCOVER** | 乌云压顶 | **看空** |
| **CDLPIERCING** | 刺穿线 | **看多** |
| **CDLINNECK** | 颈内线 | 看空（弱）|
| **CDLONNECK** | 颈上线 | 看空（弱）|
| **CDLTHRUSTING** | 插入线 | 看空 |
| **CDLCOUNTERATTACK** | 反击线 | 反转 |
| **CDLHOMINGPIGEON** | 家鸽 | 看多 |
| **CDLHIKKAKE** | Hikkake 模式 | 反转突破 |
| **CDLHIKKAKEMOD** | Hikkake 修正 | 同上 |

### 2.3 三 K 线反转

| 函数 | 中文 | 多空信号 |
|---|---|---|
| **CDLMORNINGSTAR** | 早晨之星 | **强看多** |
| **CDLEVENINGSTAR** | 黄昏之星 | **强看空** |
| **CDLMORNINGDOJISTAR** | 早晨十字星 | 看多（更强） |
| **CDLEVENINGDOJISTAR** | 黄昏十字星 | 看空（更强） |
| **CDL3WHITESOLDIERS** | 红三兵 | **强看多** |
| **CDL3BLACKCROWS** | 三只乌鸦（黑三兵）| **强看空** |
| **CDL3INSIDE** | 三内升 / 三内跌 | 反转 |
| **CDL3OUTSIDE** | 三外升 / 三外跌 | 反转 |
| **CDL3LINESTRIKE** | 三线打击 | 趋势中反转（罕见）|
| **CDL3STARSINSOUTH** | 南方三星 | 看多（罕见）|
| **CDLABANDONEDBABY** | 弃婴（多/空）| **极强反转** |
| **CDLADVANCEBLOCK** | 大敌当前 | 看空 |
| **CDLSTALLEDPATTERN** | 步步为营 | 看空 |
| **CDLSTICKSANDWICH** | 条形三明治 | 看多 |
| **CDLUNIQUE3RIVER** | 奇特三河床 | 看多（罕见）|

### 2.4 持续 / 持平形态

| 函数 | 中文 | 含义 |
|---|---|---|
| **CDL2CROWS** | 两只乌鸦 | 看空 |
| **CDLUPSIDEGAP2CROWS** | 向上跳空两乌鸦 | 看空 |
| **CDLIDENTICAL3CROWS** | 相同的三只乌鸦 | 看空 |
| **CDLGAPSIDESIDEWHITE** | 跳空并列白线 | 趋势延续 |
| **CDLXSIDEGAP3METHODS** | 跳空三法 | 趋势延续 |
| **CDLTASUKIGAP** | 跳空回补缺口 | 持续 |
| **CDLRISEFALL3METHODS** | 上升 / 下降三法 | 持续 |
| **CDLSEPARATINGLINES** | 分离线 | 持续 |
| **CDLBREAKAWAY** | 脱离 | 趋势开始 |
| **CDLLADDERBOTTOM** | 梯底 | 看多 |
| **CDLTRISTAR** | 三星 | 反转 |
| **CDLKICKING** | 反冲 | 强趋势 |
| **CDLKICKINGBYLENGTH** | 反冲（按长度）| 同上 |
| **CDLCONCEALBABYSWALL** | 隐藏婴儿吞没 | 看多 |
| **CDLCLOSINGMARUBOZU** | 收盘秃头 | 强趋势 |
| **CDLMARUBOZU** | 秃头光脚 | 强趋势 |
| **CDLLONGLINE** | 长线 | 强趋势 |
| **CDLSHORTLINE** | 短线 | 弱信号 |
| **CDLSPINNINGTOP** | 纺锤顶 | 犹豫 |
| **CDLRICKSHAWMAN** | 黄包车夫 | 犹豫 |
| **CDLLONGLEGGEDDOJI** | 长腿十字 | 反转 |

---

## 3. A 股实证有效性

### 3.1 整体结论

**A 股 K 线形态因子整体不显著**——多数学术论文未实证。Python 实战 ch5.2.2 仅列举名称，**未做实证**。

### 3.2 几个例外（业界经验，未严谨学术实证）

| 形态 | A 股经验观察 | 备注 |
|---|---|---|
| **CDLENGULFING（吞没）** | 弱信号 | 与成交量结合更可靠 |
| **CDLMORNINGSTAR / EVENINGSTAR**（早晨之星 / 黄昏之星）| 中等信号 | 极端位置（前期高/低）更显著 |
| **CDLDOJI（十字星）** | 整体信号弱 | 单独使用易反向 |
| **CDLHAMMER（锤子线）** | 反转信号 | 配合趋势中后段 |

### 3.3 为什么 K 线形态在 A 股弱

1. **A 股短期反转占优**——大多数"看多形态"出现在下跌中，更可能继续下跌
2. **涨跌停制度扭曲 K 线**——尾盘集合竞价的影响放大
3. **散户行为**——K 线形态被广泛学习，**信号被快速吃掉**
4. **样本量小**——三 K 线形态在 A 股某只股票上一年可能仅出现 5-10 次

### 3.4 学术研究

- **Cap et al. (2015)** 等少数论文实证：K 线形态在美股**统计显著但经济意义有限**
- **A 股专门实证**：极少见严肃学术论文

---

## 4. 聚宽实现框架

### 4.1 单形态信号

```python
import talib
import numpy as np
import pandas as pd


def detect_pattern(open_, high, low, close, pattern_name='CDLENGULFING') -> pd.Series:
    """检测单个 K 线形态
    
    Args:
        open_, high, low, close: pd.Series
        pattern_name: 形态函数名
    
    Returns: pd.Series, 100/-100/0
    """
    func = getattr(talib, pattern_name)
    signal = func(open_.values, high.values, low.values, close.values)
    return pd.Series(signal, index=close.index)


# 用法
engulfing = detect_pattern(open_, high, low, close, 'CDLENGULFING')
print(engulfing[engulfing != 0])  # 输出所有有信号的日期
```

### 4.2 批量计算所有 45 个形态

```python
ALL_CDL_PATTERNS = [
    name for name in dir(talib) if name.startswith('CDL')
]


def compute_all_patterns(open_, high, low, close) -> pd.DataFrame:
    """计算所有 K 线形态，返回 (T, 45) DataFrame"""
    results = {}
    for pattern in ALL_CDL_PATTERNS:
        try:
            signal = detect_pattern(open_, high, low, close, pattern)
            if signal.abs().sum() > 0:  # 过滤掉全 0 的形态
                results[pattern] = signal
        except Exception:
            continue
    return pd.DataFrame(results)


# 用法
all_signals = compute_all_patterns(open_, high, low, close)
# 找出"今天出现"的所有形态
today_signals = all_signals.iloc[-1][all_signals.iloc[-1] != 0]
print(today_signals)
```

### 4.3 形态组合策略

```python
def bullish_pattern_score(open_, high, low, close) -> pd.Series:
    """看多形态综合打分（每出现一个看多形态 +1）"""
    bullish_patterns = [
        'CDLENGULFING', 'CDLMORNINGSTAR', 'CDLHAMMER',
        'CDL3WHITESOLDIERS', 'CDLPIERCING', 'CDLABANDONEDBABY',
    ]
    score = pd.Series(0, index=close.index)
    for pattern in bullish_patterns:
        signal = detect_pattern(open_, high, low, close, pattern)
        score += (signal > 0).astype(int)
    return score


def bearish_pattern_score(open_, high, low, close) -> pd.Series:
    """看空形态综合打分"""
    bearish_patterns = [
        'CDLENGULFING', 'CDLEVENINGSTAR', 'CDLHANGINGMAN',
        'CDL3BLACKCROWS', 'CDLDARKCLOUDCOVER', 'CDLABANDONEDBABY',
    ]
    score = pd.Series(0, index=close.index)
    for pattern in bearish_patterns:
        signal = detect_pattern(open_, high, low, close, pattern)
        score += (signal < 0).astype(int)
    return score
```

---

## 5. 实务建议

### 5.1 不推荐做"单形态择时"

**A 股 K 线形态单独使用信号弱**——不建议作为唯一交易信号。

### 5.2 推荐组合用法

#### 用法 1：作为辅助信号

```python
# 价值因子选股 + K 线形态辅助过滤
top_value_stocks = select_by_ep(top_n=100)
filtered = top_value_stocks[bullish_pattern_score(...) >= 1]
```

#### 用法 2：与成交量结合

```python
# 看多形态 + 成交量放大 = 更可靠
signal = (engulfing > 0) & (volume > volume.rolling(20).mean() * 1.5)
```

#### 用法 3：极端位置触发

```python
# 在下跌中后段（RSI < 30）出现锤子线 = 强烈反转
trigger = (rsi < 30) & (CDLHAMMER > 0)
```

### 5.3 严肃量化中的角色

- **特征**：把 45 个 CDL 信号作为机器学习的输入特征
- **过滤器**：先选股，再用 K 线形态过滤
- **不要作主信号**——除非有充分实证支持

---

## 6. 与其他技术指标的关系

| 维度 | K 线形态 | MA/MACD/RSI |
|---|---|---|
| **看的时间尺度** | 1-3 天 | 多日累积 |
| **信号频率** | 稀疏（特定日触发）| 每日 |
| **方向性** | 离散（看多 / 看空）| 连续 |
| **A 股有效性** | **弱** | 中 |
| **可量化研究** | 有限 | 充分 |

**实务定位**：**K 线形态是"传统技术分析的精华"**，但量化时代价值被显著稀释——大多作为辅助特征。

---

## 综合观察

- **45 个 CDL 函数覆盖主流 K 线形态**——单根 / 双根 / 三根
- **A 股 K 线形态整体不显著**——多数学术未实证
- **不要单独用作交易信号**——必须配合其他指标 / 因子
- **机器学习中可作特征**——把 45 个信号一起喂模型，可能有微弱预测力
- **GTJA-191 / Alpha-101 都未使用 CDL 形态作为因子**——侧面印证有效性弱
- **业界经验**：吞没 / 早晨之星 / 锤子线在**极端位置 + 高成交量**触发时较可靠

## 参考与延伸

- [[classical-technical-indicators]] — 经典技术指标（MA/MACD/RSI/KDJ/Bollinger）
- [[rsrs-four-versions]] — A 股招牌择时因子
- [[volatility-and-other-indicators]] — 波动率因子
- [Python 量化交易实战 ch5.2.2](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — 45 函数清单原文
- [Talib 官方文档](https://github.com/mrjbq7/ta-lib) — 完整 API 参考
- [TA-Lib K 线形态识别](https://github.com/mrjbq7/ta-lib/blob/master/docs/func_groups/pattern_recognition.md)
