---
name: classical-technical-indicators
description: 经典技术指标完整方法论 —— MA/EMA 趋势 + MACD 动量 + RSI 摆动 + KDJ 随机 + Bollinger 通道 + A 股国内版（SMA_CN）+ 聚宽实现
category: 02_因子库/2.5_技术指标
tags: [技术指标, MA, EMA, MACD, RSI, KDJ, Bollinger, 国内版, 聚宽, Talib]
created: 2026-05-17
updated: 2026-05-29
status: with-jq-impl
---

# 经典技术指标：MA / EMA / MACD / RSI / KDJ / Bollinger

## TL;DR

A 股最常用的 6 大经典技术指标完整方法论：**趋势型**（MA / EMA / Bollinger）/ **动量型**（MACD）/ **摆动型**（RSI / KDJ）。**关键 A 股化**：所有"指数加权"指标在 A 股需用 **SMA_CN**（指数加权 Y_t = m/n × A_t + (n-m)/n × Y_{t-1}）—— 通达信 / 东方财富等行情软件都用此版本，**不是国际 EMA**。

## 来源

- **Whale-Quant ch03**：[ch03_股票数据获取.md](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/_github_source/docs/) — 经典指标教学
- **Python 实战 ch5 / ch7.1.2**：[Python量化交易实战.md](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — Talib + 国内版重写
- **MyInvestPilot MACD Strategy**：`https://www.myinvestpilot.com/docs/strategies/macd-strategy` — MACD 金叉死叉 / 零轴 / 背离 / 参数组合说明（作为策略化补充）
- 配套 [[operator-gtja191-definition]] § SMA 算子（A 股版指数加权）

---

## 1. 趋势型指标

### 1.1 简单移动平均（SMA / MA）

#### 公式

$$\text{MA}_n = \frac{1}{n} \sum_{i=0}^{n-1} P_{t-i}$$

**含义**：过去 n 日收盘价的算术平均。

#### 常见周期

| 周期 | 含义 |
|---|---|
| **MA5** | 短期均线（1 周）|
| **MA10** | 中短期 |
| **MA20** | 月线 |
| **MA60** | 季线 |
| **MA120** | 半年线 |
| **MA250** | 年线 |

#### 应用

- **金叉**：短期均线上穿长期均线（看多信号）
- **死叉**：短期均线下穿长期均线（看空信号）
- **多头排列**：MA5 > MA10 > MA20 > MA60（强势）
- **空头排列**：MA5 < MA10 < MA20 < MA60（弱势）

#### 聚宽实现

```python
import pandas as pd

def ma(close: pd.Series, n: int) -> pd.Series:
    """简单移动平均"""
    return close.rolling(n).mean()


# 使用
ma5 = ma(close, 5)
ma20 = ma(close, 20)
```

---

### 1.2 指数加权移动平均（EMA）—— 国际通用版

#### 公式

$$\text{EMA}_t = \alpha \cdot P_t + (1 - \alpha) \cdot \text{EMA}_{t-1}$$

其中 $\alpha = 2/(n+1)$，常用 n = 12（短期）/ 26（长期）。

#### 与 MA 的差异

- MA 等权——每天权重相同
- EMA **越近的权重越大**——对最新数据更敏感

#### 聚宽实现

```python
def ema(close: pd.Series, n: int) -> pd.Series:
    """指数加权移动平均（国际通用）
    
    pandas.ewm 的 span 参数 = 2/α - 1
    """
    return close.ewm(span=n, adjust=False).mean()
```

---

### 1.3 SMA_CN（A 股版指数加权）—— **必须区分！**

#### 公式

$$\text{SMA\_CN}_t = \frac{m}{n} \cdot A_t + \frac{n-m}{n} \cdot \text{SMA\_CN}_{t-1}$$

其中 m 和 n 是参数（通常 m=1，n 为周期）。

#### 与国际 EMA 的关系

```
EMA(n) ≈ SMA_CN(2n-1, 2)   或   SMA_CN(n, 1) 的衰减率不同
```

**A 股技术指标体系（通达信 / 东方财富 / 雪球）全部用 SMA_CN**——而非国际 EMA。

#### 聚宽实现

```python
def sma_cn(close: pd.Series, n: int, m: int = 1) -> pd.Series:
    """A 股版指数加权 SMA
    
    Y_t = (m/n) * A_t + ((n-m)/n) * Y_{t-1}
    等价于 pandas.ewm(alpha=m/n, adjust=False)
    """
    return close.ewm(alpha=m / n, adjust=False, min_periods=1).mean()
```

详见 [[operator-gtja191-definition]] § SMA。

---

### 1.4 Bollinger 通道（BOLL）

#### 公式

```
MID = MA(close, n)       # 中轨：n 日均线
UPPER = MID + k × STD    # 上轨
LOWER = MID - k × STD    # 下轨
```

通常 **n = 20、k = 2**。

#### 应用

- **股价触上轨**：超买（可能反转）
- **股价触下轨**：超卖（可能反转）
- **通道收窄**：低波动（盘整）
- **通道扩大**：高波动（趋势中）

#### 聚宽实现

```python
def bollinger(close: pd.Series, n: int = 20, k: float = 2.0):
    """Bollinger 通道
    
    Returns: (upper, mid, lower)
    """
    mid = close.rolling(n).mean()
    std = close.rolling(n).std()
    upper = mid + k * std
    lower = mid - k * std
    return upper, mid, lower
```

---

### 1.5 BIAS 乖离率

#### 公式

$$\text{BIAS}(n) = \frac{C_t - \text{MA}(C, n)}{\text{MA}(C, n)} \times 100$$

**含义**：当前价格相对于 n 日均线的偏离百分比。**A 股最经典的超买超卖指标之一**，通达信/东方财富/雪球均内置。

#### 常用窗口

| 因子 | 含义 | 经验阈值 |
|---|---|---|
| BIAS5 | 短期乖离 | ±3% 警戒 |
| BIAS10 | 中短期乖离 | ±5% 警戒 |
| BIAS20 | 中期乖离 | ±8% 警戒 |
| BIAS60 | 长期乖离 | ±15% 警戒 |

#### Qlib 表达式

```python
# BIAS5
"($close - Mean($close, 5)) / Mean($close, 5) * 100"

# BIAS10
"($close - Mean($close, 10)) / Mean($close, 10) * 100"

# BIAS20
"($close - Mean($close, 20)) / Mean($close, 20) * 100"

# BIAS60
"($close - Mean($close, 60)) / Mean($close, 60) * 100"
```

#### 聚宽实现

```python
def bias(close: pd.Series, n: int = 5) -> pd.Series:
    """乖离率 BIAS"""
    ma = close.rolling(n).mean()
    return (close - ma) / ma * 100
```

#### 应用

- **BIAS 极正（>10%）**：超买，可能回落
- **BIAS 极负（<-10%）**：超卖，可能反弹
- **零轴穿越**：股价穿越均线时 BIAS 由负转正（看多）或由正转负（看空）
- **多周期组合**：BIAS5 / BIAS10 / BIAS20 同时回正 = 短中长期均回归均线 = 强势确认

#### A 股化注记

- **A 股反转占优**：极端 BIAS 后的反转信号在 A 股有效
- **小盘股阈值更宽**：小盘股波动大，BIAS5 ±5% 才算极端，大盘股 ±3% 已算极端
- **作为 ML 特征**：4 个窗口的 BIAS 作为特征输入贡献显著（与 ROC 不同时间尺度上互补）
- **与 RSI/KDJ 联用**：BIAS 是"价格端"超买超卖，RSI/KDJ 是"涨跌幅端"超买超卖，二者共同极端时反转信号最强

#### 与 Price 动量比的等价性

BIAS 与 [[trend-momentum-supplement]] § Price 动量比 数学上等价：
```
BIAS(n) / 100 = $close / Mean($close, n) - 1
```

知识库统一用 BIAS 命名（A 股语境），保留 Price1m/3m/1y 作为动量视角的引用。

---

## 2. 动量型指标

### 2.1 MACD（国际通用版）

#### 公式

```
DIF = EMA(close, 12) - EMA(close, 26)
DEA = EMA(DIF, 9)
MACD = 2 × (DIF - DEA)    # MACD 柱
```

#### 应用

- **DIF 上穿 DEA**：金叉（看多）
- **DIF 下穿 DEA**：死叉（看空）
- **MACD 柱 > 0**：多头力量
- **MACD 柱 < 0**：空头力量
- **零轴过滤**：DIF / MACD 柱在零轴上方时，多头信号质量更高；零轴下方的金叉更像弱反弹
- **底背离**：价格新低但 DIF / MACD 柱不创新低（看多反转，较难稳定量化）
- **顶背离**：股价新高但 MACD 不创新高（看空）

#### 常见参数组合

| 参数 | 风格 | 说明 |
|---|---|---|
| `(6, 12, 9)` | 短线 | 更敏感，假信号更多 |
| `(12, 26, 9)` | 标准 | 最常见配置 |
| `(19, 39, 9)` | 长线 | 更平滑，信号更少 |

**实务建议**：

- 金叉 / 死叉只是触发信号，最好再叠加零轴、长期均线或成交量确认。
- 震荡市中 MACD 容易反复金叉死叉，适合做趋势确认，不适合单独做高频反复交易。
- 背离信号主观性较强，若要量化，必须明确“价格新高/新低”和“DIF/MACD 不创新高/低”的窗口定义。

#### 聚宽实现

```python
def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    """MACD（国际通用）
    
    Returns: (dif, dea, macd_hist)
    """
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    dif = ema_fast - ema_slow
    dea = dif.ewm(span=signal, adjust=False).mean()
    macd_hist = 2 * (dif - dea)
    return dif, dea, macd_hist
```

#### Qlib 表达式注意

Qlib Expression Engine 可以直接写出 DIF：

```python
dif = "EMA($close, 12) - EMA($close, 26)"
```

但严格的 `DEA = EMA(DIF, 9)` 属于对表达式结果再做 EMA。当前本地 Qlib 参考建议用 `Mean(DIF, 9)` 近似，或用 Python 预计算后导入自定义字段：

```python
# 近似 DEA
dea_approx = "Mean(EMA($close, 12) - EMA($close, 26), 9)"

# MACD 柱近似
macd_hist_approx = (
    "2 * (EMA($close, 12) - EMA($close, 26) "
    "- Mean(EMA($close, 12) - EMA($close, 26), 9))"
)
```

若研究目标是和行情软件或交易信号精确对齐，建议使用 Python 函数计算 MACD 后作为自定义字段导入 Qlib，而不是依赖嵌套表达式近似。

---

### 2.2 MACD_CN（A 股国内版）

#### 公式（与国际版完全不同！）

```
DIF = SMA_CN(close, 13, 2) - SMA_CN(close, 27, 2)
DEA = SMA_CN(DIF, 10, 2)
MACD = 2 × (DIF - DEA)
```

#### 关键差异

| 参数 | 国际版 | A 股国内版 |
|---|---|---|
| 短期 | EMA(12) | **SMA_CN(13, 2)** |
| 长期 | EMA(26) | **SMA_CN(27, 2)** |
| 信号线 | EMA(9) | **SMA_CN(10, 2)** |
| 加权方式 | $\alpha = 2/(n+1)$ | $\alpha = m/n$ |

**实务**：国内行情软件（通达信 / 东方财富 / 同花顺）显示的 MACD **都是国内版**——与国际版**数值不同**！

#### 聚宽实现

```python
def macd_cn(close: pd.Series):
    """MACD 国内版"""
    dif = sma_cn(close, 13, 2) - sma_cn(close, 27, 2)
    dea = sma_cn(dif, 10, 2)
    macd_hist = 2 * (dif - dea)
    return dif, dea, macd_hist
```

GTJA-191 Alpha89 即用此版本：

```
2 * (SMA(CLOSE,13,2) - SMA(CLOSE,27,2) - SMA(SMA(CLOSE,13,2)-SMA(CLOSE,27,2),10,2))
```

详见 [[factor-gtja191-all-formulas]] Alpha89。

---

## 3. 摆动型指标

### 3.1 RSI（相对强弱指标）

#### 国际通用版

```
UP = max(close - close_prev, 0)
DOWN = max(close_prev - close, 0)
RS = average(UP, n) / average(DOWN, n)
RSI = 100 - 100 / (1 + RS)
```

n 常用 **6 / 12 / 24**（短中长期）。

#### A 股国内版（RSI_CN）

```
RSI = SMA_CN(max(close - close_prev, 0), n, 1) / SMA_CN(|close - close_prev|, n, 1) × 100
```

**国内版用 SMA_CN 而非简单平均**——与国际版数值有差异。

#### 应用

- **RSI > 70**：超买（可能反转下跌）
- **RSI < 30**：超卖（可能反弹）
- **RSI > 50**：多头
- **RSI < 50**：空头

#### 聚宽实现

```python
def rsi(close: pd.Series, n: int = 14) -> pd.Series:
    """RSI（国际通用）"""
    diff = close.diff()
    up = diff.where(diff > 0, 0)
    down = -diff.where(diff < 0, 0)
    rs = up.rolling(n).mean() / down.rolling(n).mean()
    return 100 - 100 / (1 + rs)


def rsi_cn(close: pd.Series, n: int = 6) -> pd.Series:
    """RSI A 股国内版（SMA_CN 加权）"""
    diff = close.diff()
    up = diff.where(diff > 0, 0)
    abs_diff = diff.abs()
    return sma_cn(up, n, 1) / sma_cn(abs_diff, n, 1) * 100
```

GTJA-191 Alpha63 / Alpha67 / Alpha79 是 6/24/12 期 RSI 国内版。

---

### 3.2 KDJ（随机指标）

#### 公式

```
RSV = (close - LLV(low, n)) / (HHV(high, n) - LLV(low, n)) × 100
K = SMA_CN(RSV, m1, 1)       # 国内常用 m1=3
D = SMA_CN(K, m2, 1)         # 国内常用 m2=3
J = 3 × K - 2 × D
```

**国内常用参数**：n=9, m1=3, m2=3。

#### 应用

- **K 上穿 D（金叉）**：看多
- **K 下穿 D（死叉）**：看空
- **J > 100 或 J < 0**：超买 / 超卖（J 可超越 100 或低于 0）

#### 聚宽实现

```python
def kdj_cn(close: pd.Series, high: pd.Series, low: pd.Series,
           n: int = 9, m1: int = 3, m2: int = 3):
    """KDJ A 股国内版"""
    hhv = high.rolling(n).max()
    llv = low.rolling(n).min()
    rsv = (close - llv) / (hhv - llv) * 100
    k = sma_cn(rsv, m1, 1)
    d = sma_cn(k, m2, 1)
    j = 3 * k - 2 * d
    return k, d, j
```

GTJA-191 Alpha57 / Alpha96 即用 KDJ 国内版结构。

---

### 3.3 CCI（顺势指标）

```
TP = (high + low + close) / 3
MA_TP = MA(TP, n)
MD = MA(|TP - MA_TP|, n)
CCI = (TP - MA_TP) / (0.015 × MD)
```

n 常用 20。

- **CCI > +100**：超买
- **CCI < -100**：超卖

聚宽实现略——类似 RSI / KDJ 风格。

---

## 4. 成交量型指标

### 4.1 OBV（能量潮）

```
OBV_t = OBV_{t-1} + sign(close_t - close_{t-1}) × volume_t
```

**含义**：量能累计——价涨量增、价跌量减时，OBV 上升。

```python
def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """OBV 能量潮"""
    direction = (close.diff() > 0).astype(int) - (close.diff() < 0).astype(int)
    return (direction * volume).cumsum()
```

### 4.2 VR（成交量比率）

```
UP_VOL = sum(volume[close > close_prev], n)
DOWN_VOL = sum(volume[close < close_prev], n)
VR = UP_VOL / DOWN_VOL × 100
```

n 常用 26。

- **VR > 150**：上涨能量强
- **VR < 70**：下跌能量强

### 4.3 MFI（资金流量指标）

```
TP = (high + low + close) / 3
MF = TP × volume
PMF = sum(MF[TP > TP_prev], n)   # 正向资金流
NMF = sum(MF[TP < TP_prev], n)   # 负向资金流
MFI = 100 - 100 / (1 + PMF / NMF)
```

类似带成交量加权的 RSI。

---

## 5. A 股技术指标的实证有效性

| 指标 | A 股有效性 | 备注 |
|---|---|---|
| **MA 金叉死叉** | **弱**（短期反转更显著） | 单独使用不显著 |
| **MACD** | **中**（趋势中有效） | 与成交量结合更好 |
| **RSI 国内版** | **中** | RSI < 30 抄底有效（A 股反转）|
| **KDJ** | **中** | 同 RSI，超买卖反转 |
| **Bollinger 突破** | **强**（趋势型策略）| 双 BOLL 策略 A 股经典 |
| **OBV** | 中 | 量价背离信号 |
| **MFI** | 中 | 与 OBV 类似 |

**核心实证**：

- **A 股短期反转占优**——RSI/KDJ 的超买卖反转信号比"动量延续"更有效
- **MACD 在主升浪期间有效**——震荡市失效
- **Bollinger 通道突破策略**A 股长期有效（特别是结合成交量）

---

## 6. 完整聚宽实现框架

```python
import pandas as pd
import numpy as np


def sma_cn(s, n, m=1):
    """A 股版 SMA"""
    return s.ewm(alpha=m / n, adjust=False, min_periods=1).mean()


class TechnicalIndicators:
    """A 股技术指标计算器（统一接口）"""
    
    @staticmethod
    def ma(close, n):
        return close.rolling(n).mean()
    
    @staticmethod
    def ema(close, n):
        return close.ewm(span=n, adjust=False).mean()
    
    @staticmethod
    def macd(close, fast=12, slow=26, signal=9):
        ema_f = close.ewm(span=fast, adjust=False).mean()
        ema_s = close.ewm(span=slow, adjust=False).mean()
        dif = ema_f - ema_s
        dea = dif.ewm(span=signal, adjust=False).mean()
        return dif, dea, 2 * (dif - dea)
    
    @staticmethod
    def macd_cn(close):
        """国内版 MACD（与 GTJA Alpha89 一致）"""
        dif = sma_cn(close, 13, 2) - sma_cn(close, 27, 2)
        dea = sma_cn(dif, 10, 2)
        return dif, dea, 2 * (dif - dea)
    
    @staticmethod
    def rsi_cn(close, n=6):
        diff = close.diff()
        up = diff.where(diff > 0, 0)
        ab = diff.abs()
        return sma_cn(up, n, 1) / sma_cn(ab, n, 1) * 100
    
    @staticmethod
    def kdj_cn(close, high, low, n=9, m1=3, m2=3):
        hhv = high.rolling(n).max()
        llv = low.rolling(n).min()
        rsv = (close - llv) / (hhv - llv) * 100
        k = sma_cn(rsv, m1, 1)
        d = sma_cn(k, m2, 1)
        return k, d, 3 * k - 2 * d
    
    @staticmethod
    def bollinger(close, n=20, k=2.0):
        mid = close.rolling(n).mean()
        std = close.rolling(n).std()
        return mid + k * std, mid, mid - k * std
    
    @staticmethod
    def obv(close, volume):
        direction = (close.diff() > 0).astype(int) - (close.diff() < 0).astype(int)
        return (direction * volume).cumsum()
```

---

## 综合观察

- **A 股技术指标必须用国内版**——SMA_CN / MACD_CN / RSI_CN / KDJ_CN——与国际版数值不同
- **核心 SMA_CN 公式**：$Y_t = m/n \cdot A_t + (n-m)/n \cdot Y_{t-1}$，等价于 `ewm(alpha=m/n, adjust=False)`
- **A 股反转占优**：RSI/KDJ 超买卖反转信号比"动量延续"更有效（散户结构）
- **MACD 趋势市有效，震荡市失效**——配合成交量更稳
- **Bollinger 通道**A 股长期有效，特别是结合成交量
- **GTJA-191 Alpha 中 KDJ/RSI/MACD 国内版的对应**：Alpha57/96（KDJ）、Alpha63/67/79（RSI）、Alpha89（MACD）

## 参考与延伸

- [[talib-k-line-patterns]] — Talib 45 个 K 线形态
- [[rsrs-four-versions]] — RSRS 阻力支撑相对强度（A 股招牌择时）
- [[volatility-and-other-indicators]] — 波动率类指标
- [[operator-gtja191-definition]] § SMA — A 股版指数加权算子
- [[factor-gtja191-all-formulas]] — GTJA-191 中 KDJ/RSI/MACD 因子
- [Whale-Quant ch03](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/_github_source/docs/) — 教学
- [Python 量化交易实战 ch5 / ch7.1.2](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — Talib + 国内版重写
