---
name: index-02-05-technical-indicators
description: 二级分类 2.5_技术指标 的索引 —— 经典指标 / 布林带 BOLL / Talib K 线 / RSRS / 波动率与其他 / 成交量情绪 / 趋势动量补充
category: 02_因子库/2.5_技术指标
tags: [技术指标, 索引, MACD, RSI, KDJ, BOLL, 布林带, RSRS, 波动率, Talib, 成交量, 情绪, Aroon, PLRC]
created: 2026-05-17
updated: 2026-05-29
status: stable
---

# 2.5 技术指标 · 索引

## 一句话定位

A 股技术指标的完整方法论——从经典 MACD/RSI/KDJ 国内版到布林带 BOLL、Talib 45 个 K 线形态、**A 股招牌择时因子 RSRS**，再到波动率与其他指标。**核心 A 股化结论**：所有"指数加权"指标必须用 **SMA_CN**（不是国际 EMA）；A 股最强技术因子是 **RSRS（择时）+ -IVOL（特质波动率）+ -TVR_1（换手率反转）**。布林带适合作为波动通道、%B/带宽特征和 ETF 择时辅助模块，不应无脑单独交易。

## 文件清单

| 文件 | 描述 | 状态 |
|---|---|---|
| [经典技术指标_MA_RSI_MACD_KDJ.md](经典技术指标_MA_RSI_MACD_KDJ.md) | 趋势型（MA/EMA/Bollinger/**BIAS 乖离率**）+ 动量型（MACD/MACD_CN）+ 摆动型（RSI/KDJ/CCI）+ 成交量型（OBV/VR/MFI）+ **国内版 SMA_CN 完整对比** | with-jq-impl |
| [布林带BOLL_波动通道.md](布林带BOLL_波动通道.md) | BOLL 中轨/上下轨/%B/带宽公式 + 均值回归与突破双模式 + Qlib 表达式 + A 股 ETF/QDII 适配 | draft |
| [Talib_K线形态.md](Talib_K线形态.md) | **Talib 45 个 CDL 函数完整清单**（单根/双根/三根 K 线 + 持续形态）+ A 股实证（整体不显著）+ 聚宽实现 | with-jq-impl |
| [RSRS_四版本_A股招牌择时.md](RSRS_四版本_A股招牌择时.md) | RSRS 阻力支撑相对强度 4 版本（标准/标准分/修正/右偏）+ 光大证券原研报数据 + **完整可跑择时策略** | with-jq-impl |
| [波动率与其他.md](波动率与其他.md) | 波动率（HV/Beta/IVOL/GARCH/**3 窗口 Skew/Kurt/Sharpe/Var**）+ 量价（OBV/VR/MFI）+ 波幅（ATR/CCI）+ **A 股最强技术 alpha 排行** | with-jq-impl |
| [成交量与量价情绪因子.md](成交量与量价情绪因子.md) | **PSY 心理线 / AR-BR 买卖力道 / VMACD / DAVOL 放量异常 / VROC / WVAD / VSTD / VOSC / Money Flow** + 全部 Qlib 表达式 | with-jq-impl |
| [趋势与动量因子_补充.md](趋势与动量因子_补充.md) | **ROC 多窗口 / Price 动量比 / Aroon / PLRC 线性回归斜率 / TRIX / Bull-Bear Power** + 全部 Qlib 表达式 | with-jq-impl |

## 阅读路径建议

### 新用户：从经典到 A 股特色

1. [经典技术指标_MA_RSI_MACD_KDJ.md](经典技术指标_MA_RSI_MACD_KDJ.md) —— **必读**：理解 SMA_CN 与国际 EMA 的差异
2. [波动率与其他.md](波动率与其他.md) —— A 股**最强技术因子**（-IVOL / -HV）
3. [RSRS_四版本_A股招牌择时.md](RSRS_四版本_A股招牌择时.md) —— A 股招牌择时
4. [Talib_K线形态.md](Talib_K线形态.md) —— 仅作参考（A 股弱）

### 老用户：查具体问题

- **"为什么国内 MACD 与国际版不同"** → [经典技术指标_MA_RSI_MACD_KDJ.md § 2.2 MACD_CN](经典技术指标_MA_RSI_MACD_KDJ.md)
- **"SMA_CN 公式是什么"** → [经典技术指标_MA_RSI_MACD_KDJ.md § 1.3 SMA_CN](经典技术指标_MA_RSI_MACD_KDJ.md)
- **"KDJ 国内版怎么算"** → [经典技术指标_MA_RSI_MACD_KDJ.md § 3.2 KDJ](经典技术指标_MA_RSI_MACD_KDJ.md)
- **"BIAS 乖离率怎么用"** → [经典技术指标_MA_RSI_MACD_KDJ.md § 1.5 BIAS](经典技术指标_MA_RSI_MACD_KDJ.md)
- **"RSRS 怎么用"** → [RSRS_四版本_A股招牌择时.md § 完整策略框架](RSRS_四版本_A股招牌择时.md)
- **"布林带怎么做 Qlib 特征 / ETF 择时"** → [布林带BOLL_波动通道.md](布林带BOLL_波动通道.md)
- **"A 股最强技术因子是什么"** → [波动率与其他.md § 4 A 股技术指标实证总结](波动率与其他.md)
- **"IVOL 怎么算"** → [波动率与其他.md § 1.5 IVOL](波动率与其他.md)
- **"3 窗口 Skew/Kurt/Sharpe 怎么写 Qlib 表达式"** → [波动率与其他.md § 1.6 风险统计矩](波动率与其他.md)
- **"K 线形态在 A 股有效吗"** → [Talib_K线形态.md § 3 A 股实证有效性](Talib_K线形态.md)
- **"PSY/AR/BR/VMACD 怎么写 Qlib 表达式"** → [成交量与量价情绪因子.md](成交量与量价情绪因子.md)
- **"DAVOL 放量异常怎么定义"** → [成交量与量价情绪因子.md § 4 DAVOL](成交量与量价情绪因子.md)
- **"WVAD 威廉变异离散量怎么算"** → [成交量与量价情绪因子.md § 6 WVAD](成交量与量价情绪因子.md)
- **"Aroon/PLRC/TRIX/Bull-Bear Power 怎么用"** → [趋势与动量因子_补充.md](趋势与动量因子_补充.md)
- **"ROC 多窗口怎么写"** → [趋势与动量因子_补充.md § 1 ROC 多窗口动量](趋势与动量因子_补充.md)
- **"PLRC 线性回归斜率 Qlib 怎么实现"** → [趋势与动量因子_补充.md § 4 PLRC](趋势与动量因子_补充.md)

## A 股技术因子核心结论速查

### A 股最强技术 alpha 因子（按实证显著性排序）

| 因子 | 类型 | t 值 | 实务用途 |
|---|---|---|---|
| **-TVR_1**（换手率反转）| 流动性 | **4.2** | 选股 |
| **STOM_barra**（流动性）| 流动性 | **4.0+** | 选股 |
| **-IVOL**（特质波动率取负）| 波动率 | **3.5+** | 选股 |
| **-HV_21**（21 日历史波动率取负）| 波动率 | 3.0+ | 选股 |
| **-Beta**（市场敏感度取负）| 波动率 | 3.0 | 选股 |
| **RSRS_v3**（修正 RSRS）| 趋势 | 年化超额 ~15% | 大盘择时 |

### 弱信号 / 失效因子

| 因子 | 备注 |
|---|---|
| RSI/KDJ 金叉死叉 | 单独使用弱，反转触发可（RSI<30 / KDJ<20）|
| MACD 金叉死叉 | 单独使用弱，趋势市有效 |
| MA 金叉死叉 | 整体不显著 |
| BOLL 裸均值回归 | 趋势市容易越跌越买，必须加趋势过滤 |
| **Talib K 线形态** | **整体不显著**——多数学术未实证 |
| OBV 单独使用 | 量价背离信号有效 |

### 国内版 vs 国际版对照

| 指标 | 国际版 | 国内版 | 差异 |
|---|---|---|---|
| 移动平均 | EMA(n)，α=2/(n+1) | **SMA_CN(n, m)**，α=m/n | 加权方式不同 |
| MACD | EMA(12)/(26)/(9) | **SMA_CN(13,2)/(27,2)/(10,2)** | 参数 + 加权不同 |
| RSI | 简单平均 UP/DOWN | **SMA_CN 加权** UP/DOWN | 加权方式不同 |
| KDJ | 同 | **SMA_CN 加权** RSV | 加权方式不同 |

**实务**：国内行情软件（通达信 / 东方财富 / 同花顺）显示的指标**都是国内版**——必须用 SMA_CN。

## 关键 A 股化要点（必读）

- **所有指数加权指标用 SMA_CN**，而非国际 EMA —— 与通达信 / 东方财富等行情软件一致
- **A 股反转占优**：RSI/KDJ 的超买卖反转信号 > 动量延续信号
- **K 线形态 A 股弱**：Talib 45 个 CDL 函数实证整体不显著
- **RSRS 是 A 股招牌择时**：年化超额 ~15%，适用指数 / ETF 不适用个股
- **BOLL 要先分市场状态**：震荡市用均值回归，趋势市用突破跟踪，%B/带宽更适合作为特征或辅助过滤
- **A 股最稳健技术 alpha** = -IVOL（低特质波动率取负）+ -TVR_1（低换手率取负）+ STOM_barra（流动性）
- **RSRS 大盘择时 + 多因子选股** = 完整 A 股策略

## 与其他二级的关系

| 二级 | 关系 |
|---|---|
| [[index-02-01-operator-dictionary]] 2.1 算子词典 | SMA_CN 等 A 股算子来源 |
| [[index-02-02-price-volume-factors]] 2.2 价量因子库 | GTJA-191 中 KDJ/RSI/MACD 国内版的对应（Alpha57/63/79/89 等） |
| [[index-02-03-barra-factors]] 2.3 Barra 风格因子 | DASTD / HSIGMA / Beta 是 Barra 波动率细类 |
| [[index-02-04-fundamental-factors]] 2.4 基本面因子 | 换手率反转 -TVR_1 在 2.4 已详述 |
| [[index-03-02-timing]] 3.2 择时策略（待建）| **RSRS 是核心** |
| [[index-03-04-ml-strategies]] 3.4 ML 策略（待建）| 45 个 K 线形态可作 ML 特征 |

---

[← 返回 02_因子库 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
