---
name: rsrs-four-versions
description: RSRS 阻力支撑相对强度因子四个版本完整推导 —— 标准 / 标准分 / 修正 / 右偏 + A 股择时招牌 + 聚宽完整实现
category: 02_因子库/2.5_技术指标
tags: [RSRS, 阻力支撑, 择时, A股招牌, OLS, 光大证券]
created: 2026-05-17
updated: 2026-05-17
source: 原始资料文件/Python量化交易实战/Python量化交易实战.md (ch7.2)
status: with-jq-impl
---

# RSRS 阻力支撑相对强度因子（四版本）

## TL;DR

**RSRS（Resistance Support Relative Strength）** 是光大证券提出的 A 股招牌择时因子——**用过去 N 日最高价对最低价做 OLS 回归取斜率作为信号**。本文给出**四个版本**（标准 / 标准分 / 修正 / 右偏）的完整推导 + A 股择时含义 + 聚宽实现 + 实证经验。**RSRS 是 A 股中文资料中最系统、最有独立价值的择时因子**。

## 来源

- **Python 实战 ch7.2**：[Python量化交易实战.md](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — RSRS 四版本系统推导
- **原始研报**：光大证券《再探技术分析与量化交易：RSRS 择时》（2017）

---

## 1. RSRS 基础原理

### 1.1 核心思想

**用最近 N 日的"高价对低价"做 OLS 回归**：

$$\text{HIGH}_t = \alpha + \beta \cdot \text{LOW}_t + \varepsilon_t$$

**斜率 $\beta$ 就是 RSRS 因子**。

### 1.2 直觉

- **β > 1**：高价上升幅度 > 低价上升幅度 → 阻力转化为支撑（**看多**）
- **β < 1**：高价上升幅度 < 低价上升幅度 → 支撑被突破（**看空**）
- **β ≈ 1**：均衡

### 1.3 为什么"高价对低价回归"

不像"价格对时间"或"价格对成交量"——RSRS 用的是**两个价格本身**的关系：

- HIGH 和 LOW 是日内的极值——反映**多空双方的极致表现**
- 它们的相对变化速度 → 多空力量强弱

---

## 2. 版本 1：标准 RSRS

### 公式

```
β_t = OLS(HIGH, LOW, N)
```

即对过去 N 日的 (LOW, HIGH) 做回归，取斜率。

### 参数

| 参数 | 推荐值 |
|---|---|
| **N**（回归窗口） | **18** |

### 阈值（择时信号）

```
β > 1：看多（满仓）
β < 1：看空（空仓 / 减仓）
```

### 聚宽实现

```python
import numpy as np
import pandas as pd


def rsrs_v1(high: pd.Series, low: pd.Series, N: int = 18) -> pd.Series:
    """标准 RSRS
    
    Returns: pd.Series, 每日 RSRS 值
    """
    rsrs = pd.Series(np.nan, index=high.index)
    
    for i in range(N, len(high)):
        x = low.iloc[i - N:i].values
        y = high.iloc[i - N:i].values
        # OLS: β = Cov(x, y) / Var(x)
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var = np.sum((x - x_mean) ** 2)
        if var > 0:
            rsrs.iloc[i] = cov / var
    
    return rsrs
```

### 实证

- **单独使用 RSRS_v1** 已有显著择时能力（光大证券原研报）
- **2008-2017 沪深 300 实证**：年化超额 ~15%（vs 买入持有 ~5%）
- **缺点**：β 绝对值受 N 影响大，跨市场 / 跨标的可比性差

---

## 3. 版本 2：标准分 RSRS（Z-score）

### 公式

```
β_t = OLS(HIGH, LOW, N)
Z_t = (β_t - mean(β, M)) / std(β, M)
```

把 RSRS 标准化为 **Z-score**，跨时间可比。

### 参数

| 参数 | 推荐值 |
|---|---|
| **N**（回归窗口） | 18 |
| **M**（标准化窗口） | **600**（约 2.5 年）|

### 阈值

```
Z > +0.7：看多（满仓）
Z < -0.7：看空（空仓）
```

### 聚宽实现

```python
def rsrs_v2(high: pd.Series, low: pd.Series, N: int = 18, M: int = 600) -> pd.Series:
    """标准分 RSRS（Z-score）"""
    rsrs_raw = rsrs_v1(high, low, N)
    
    # 滚动 M 期 Z-score
    rolling_mean = rsrs_raw.rolling(M).mean()
    rolling_std = rsrs_raw.rolling(M).std()
    z = (rsrs_raw - rolling_mean) / rolling_std
    
    return z
```

### 实证

- **改进**：Z-score 让信号在 2010 / 2015 / 2018 不同市场环境下都可比
- **缺点**：M=600 期需要约 2.5 年数据，**长期 warmup**

---

## 4. 版本 3：修正 RSRS（加入 R²）

### 直觉

**β 高但拟合不好**（R² 低）—— **不应该作为强信号**。**修正版用 R² 加权**：

```
Z_corrected = Z × R²
```

### 公式

```
β_t = OLS(HIGH, LOW, N)
R²_t = 拟合优度 = 1 - SS_res / SS_tot
Z_t = (β_t - mean(β, M)) / std(β, M)
Z_corrected_t = Z_t × R²_t
```

### 参数

同 RSRS_v2，加上 R² 计算。

### 阈值

```
Z_corrected > +0.7：看多
Z_corrected < -0.7：看空
```

### 聚宽实现

```python
def rsrs_v3(high: pd.Series, low: pd.Series, N: int = 18, M: int = 600) -> pd.Series:
    """修正 RSRS（含 R²）"""
    rsrs = pd.Series(np.nan, index=high.index)
    r2 = pd.Series(np.nan, index=high.index)
    
    for i in range(N, len(high)):
        x = low.iloc[i - N:i].values
        y = high.iloc[i - N:i].values
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var_x = np.sum((x - x_mean) ** 2)
        var_y = np.sum((y - y_mean) ** 2)
        
        if var_x > 0 and var_y > 0:
            beta = cov / var_x
            rsrs.iloc[i] = beta
            # R² = (Cov^2) / (Var_x × Var_y)
            r2.iloc[i] = (cov ** 2) / (var_x * var_y)
    
    # 标准化
    rolling_mean = rsrs.rolling(M).mean()
    rolling_std = rsrs.rolling(M).std()
    z = (rsrs - rolling_mean) / rolling_std
    
    return z * r2
```

### 实证

- **改进**：剔除"虚假强 β 信号"（R² 低时不发信号）
- **实务效果**：相对 v2 的稳定性提升

---

## 5. 版本 4：右偏 RSRS

### 直觉

**"右偏"= 强调正向极端信号**：

```
Z_skewed = Z_corrected × |β| × sign(β)
```

或更精确地：

```
Z_skewed = Z_corrected × β
```

强调"既 Z 高（极端），β 又高（强）"的情况。

### 聚宽实现

```python
def rsrs_v4(high: pd.Series, low: pd.Series, N: int = 18, M: int = 600) -> pd.Series:
    """右偏 RSRS"""
    rsrs = pd.Series(np.nan, index=high.index)
    r2 = pd.Series(np.nan, index=high.index)
    
    for i in range(N, len(high)):
        x = low.iloc[i - N:i].values
        y = high.iloc[i - N:i].values
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var_x = np.sum((x - x_mean) ** 2)
        var_y = np.sum((y - y_mean) ** 2)
        
        if var_x > 0 and var_y > 0:
            beta = cov / var_x
            rsrs.iloc[i] = beta
            r2.iloc[i] = (cov ** 2) / (var_x * var_y)
    
    rolling_mean = rsrs.rolling(M).mean()
    rolling_std = rsrs.rolling(M).std()
    z = (rsrs - rolling_mean) / rolling_std
    
    # 右偏：乘以 β
    return z * r2 * rsrs  # = z * r2 * β
```

### 实证

- **优点**：强信号被进一步放大
- **缺点**：信号波动加大、回撤可能加深
- **实务**：**v3 修正版 vs v4 右偏版**视策略风险偏好选择

---

## 6. 四版本对比

| 版本 | 公式 | 推荐 N / M | 阈值 | 优势 | 劣势 |
|---|---|---|---|---|---|
| **v1 标准** | β | 18 / - | β > 1 / < 1 | 最简 | 跨时不可比 |
| **v2 标准分** | Z = (β - μ) / σ | 18 / 600 | ±0.7 | 跨时可比 | 长 warmup |
| **v3 修正** | Z × R² | 18 / 600 | ±0.7 | 剔除虚假信号 | 计算复杂度+ |
| **v4 右偏** | Z × R² × β | 18 / 600 | ±0.7 | 强化极端信号 | 回撤可能加深 |

### 业界推荐

**v3 修正 RSRS 是业界最常用版本**——稳定性与有效性平衡最好。

---

## 7. RSRS 完整策略框架

```python
"""
基于 RSRS 的沪深 300 择时策略
完整可跑示例
"""
from jqdata import *
import pandas as pd
import numpy as np


def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.00025,
                  close_commission=0.00025, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    g.benchmark = '000300.XSHG'
    g.etf = '510300.XSHG'  # 沪深 300 ETF
    g.N = 18      # RSRS 回归窗口
    g.M = 600     # 标准化窗口
    g.threshold_buy = 0.7    # 买入阈值
    g.threshold_sell = -0.7  # 卖出阈值
    
    run_daily(rebalance, time='14:55')  # 收盘前 5 分钟决策


def compute_rsrs_v3(prices):
    """计算修正 RSRS"""
    high = prices['high']
    low = prices['low']
    
    if len(high) < g.N + g.M:
        return np.nan
    
    rsrs_raw = []
    r2_raw = []
    
    for i in range(g.N, len(high)):
        x = low.iloc[i - g.N:i].values
        y = high.iloc[i - g.N:i].values
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var_x = np.sum((x - x_mean) ** 2)
        var_y = np.sum((y - y_mean) ** 2)
        
        if var_x > 0 and var_y > 0:
            rsrs_raw.append(cov / var_x)
            r2_raw.append((cov ** 2) / (var_x * var_y))
        else:
            rsrs_raw.append(np.nan)
            r2_raw.append(np.nan)
    
    rsrs_series = pd.Series(rsrs_raw)
    rolling_mean = rsrs_series.rolling(g.M).mean()
    rolling_std = rsrs_series.rolling(g.M).std()
    z = (rsrs_series - rolling_mean) / rolling_std
    
    # 修正版：z × R²
    final = z * pd.Series(r2_raw)
    
    return final.iloc[-1] if not final.empty else np.nan


def rebalance(context):
    """每日 14:55 决策"""
    # 取沪深 300 历史数据
    prices = attribute_history(g.benchmark, count=g.N + g.M + 50,
                               unit='1d', fields=['high', 'low'])
    
    rsrs_value = compute_rsrs_v3(prices)
    log.info(f'RSRS = {rsrs_value:.3f}')
    
    if np.isnan(rsrs_value):
        return
    
    # 决策
    current_position = context.portfolio.positions.get(g.etf)
    current_amount = current_position.total_amount if current_position else 0
    
    if rsrs_value > g.threshold_buy and current_amount == 0:
        # 满仓买入 ETF
        order_target_percent(g.etf, 1.0)
        log.info(f'RSRS={rsrs_value:.3f} > {g.threshold_buy}, 满仓买入')
    
    elif rsrs_value < g.threshold_sell and current_amount > 0:
        # 清仓
        order_target_percent(g.etf, 0)
        log.info(f'RSRS={rsrs_value:.3f} < {g.threshold_sell}, 清仓')


def after_trading_end(context):
    total = context.portfolio.total_value
    starting = context.portfolio.starting_cash
    returns_pct = (total / starting - 1) * 100
    log.info(f'{context.current_dt.date()}: 累计 {returns_pct:+.2f}%')
```

---

## 8. RSRS 在 A 股的实证表现

### 8.1 光大证券原研报数据

**2008-2017 沪深 300**：

| 指标 | 买入持有 | RSRS v3 择时 |
|---|---|---|
| 年化收益 | 5.5% | **15.8%** |
| 最大回撤 | 71% | **20%** |
| 夏普 | 0.27 | **0.85** |
| 信息比率 | - | 0.65 |

### 8.2 跨市场验证

光大研报对 RSRS 在 **沪深 300 / 中证 500 / 创业板指 / 上证 50** 等多个 A 股指数测试——**均有效**。

### 8.3 海外验证

**RSRS 在美股 S&P 500 / 日股日经 225 也有效**——但 A 股效果更显著。

### 8.4 失效期

- **2015 年股灾**：RSRS 提前减仓有效
- **2018 年熊市**：RSRS 整体跑赢
- **2021-2022 抱团股回调**：RSRS 表现一般
- **2024-Q1 微盘股危机**：RSRS 不适用（DMA 加杠杆问题）

---

## 9. 实务注意事项

### 9.1 调仓时点

**收盘前 5 分钟（14:55）决策**——因为 RSRS 用当日 high/low：

- 14:55 时 high / low 基本固定（除非剧烈波动）
- 14:57 集合竞价后下单——按收盘价撮合

### 9.2 选择标的

RSRS **不适合个股**——单只股票的 high/low 噪声大，回归不稳。**用于指数 / ETF**：

- 沪深 300 ETF (510300)
- 中证 500 ETF (510500)
- 中证 1000 ETF (512100)
- 创业板 ETF (159915)

### 9.3 多指数组合

```python
# 用 RSRS 决定多个 ETF 的仓位
etfs = ['510300.XSHG', '510500.XSHG', '512100.XSHG']

for etf in etfs:
    rsrs = compute_rsrs_v3_for_etf(etf)
    if rsrs > 0.7:
        order_target_percent(etf, 1.0 / len(etfs))
    elif rsrs < -0.7:
        order_target_percent(etf, 0)
```

### 9.4 与多因子选股结合

**RSRS 作为大盘择时 + 多因子作为选股**：

```python
# 1. 检测大盘 RSRS
market_rsrs = compute_rsrs_v3(hs300_prices)

if market_rsrs > 0.7:
    # 多头：用多因子选股
    target_stocks = multi_factor_selection(...)
    for s in target_stocks:
        order_target_percent(s, 1.0 / 30)
elif market_rsrs < -0.7:
    # 空头：清仓
    for s in context.portfolio.positions:
        order_target_percent(s, 0)
```

---

## 综合观察

- **RSRS 是 A 股中文资料中最系统的择时因子**——四版本完整推导
- **核心公式**：β = OLS(HIGH, LOW, N=18) —— 多空力量比
- **v3 修正版**是业界最常用——平衡稳定性和有效性
- **A 股实证**：年化超额 ~10-15%（vs 买入持有），最大回撤显著降低
- **适用范围**：**指数 / ETF**，不适合个股（单股噪声大）
- **调仓时点**：14:55 收盘前 5 分钟
- **与多因子结合**：RSRS 大盘择时 + 多因子选股 = 完整 A 股策略
- **失效场景**：极端市场（如 2024-Q1 DMA 危机）—— 任何技术指标都失效

## 参考与延伸

- [[classical-technical-indicators]] — 经典技术指标
- [[talib-k-line-patterns]] — Talib K 线形态
- [[volatility-and-other-indicators]] — 波动率因子
- [[multi-factor-jq-strategy]] — 多因子选股（与 RSRS 结合）
- [[index-03-02-timing]] — 择时策略（待建，RSRS 是核心）
- [Python 量化交易实战 ch7.2](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — RSRS 完整推导原文
- 光大证券《再探技术分析与量化交易：RSRS 择时》(2017) — 原始研报
