---
name: factor-alpha101-all-formulas
description: Alpha-101 论文附录 A.1 全部 101 个 alpha 因子公式 + delay-0 与 indneutralize 标注 + OCR 整体说明
category: 02_因子库/2.2_价量公式因子库
tags: [alpha101, 因子公式, worldquant, kakushadze, 价量因子, delay-0, 行业中性]
created: 2026-05-16
updated: 2026-05-16
source: 原始资料文件/Alpha-101-GTJA-191/主知识文件.md (附录 A.1 第 200-733 行)
status: draft
---

# Alpha-101 全 101 公式（附录 A.1）

## TL;DR

WorldQuant 论文《101 Formulaic Alphas》附录 A.1 的**全部 101 个 alpha 公式**完整入库。算子语义见 [[operator-alpha101-definition]]，聚宽实现见 [[operator-jq-implementation]]，10 个样板因子的完整可跑代码见 [[factor-jq-impl-samples]]。

## 来源

- **主资料**：[主知识文件.md 第 200-733 行](../../../原始资料文件/Alpha-101-GTJA-191/主知识文件.md)（附录 A.1）
- **配套**：[101 Formulaic Alphas_origin.pdf 第 8-15 页](../../../原始资料文件/Alpha-101-GTJA-191/101%20Formulaic%20Alphas_origin.pdf)

## OCR 整体说明

附录 A.1 部分的 OCR 输出**质量很好**，101 个公式表达式基本无损（与 [[factor-gtja191-all-formulas]] 形成鲜明对比）。
唯一需要注意：论文中部分 alpha 在原 PDF 中以**截图形式嵌入**（OCR 时被识别为图片），但 `主知识文件.md` 版本对这些 alpha 也保留了文字版（来自论文另一处复制粘贴）。**所有 101 公式可以直接使用**。

## 关键标注

### delay-0 alphas（必须在 close 附近交易，回测要小心）

论文 Section 4 明确指出 4 个 alpha 为 delay-0（即使用当日收盘价时点的信号）：

- **Alpha#42**、**Alpha#48**、**Alpha#53**、**Alpha#54**

其余 97 个均为 delay-1（昨日信号决定今日操作）。**delay-0 回测时若按 delay-1 处理会偏乐观**——必须在仿真中按 close 撮合或在 close 前几分钟下单。

### 涉及行业中性化（indneutralize / IndNeutralize）的 alphas

含 `indneutralize(...)` 或 `IndNeutralize(...)` 算子的 alpha 需要行业分类输入（A 股用申万一级 / 中信一级）。**共 20 个**：

`#48, #58, #59, #63, #67, #69, #70, #76, #79, #80, #82, #87, #89, #90, #91, #93, #97, #100`（含上下文中的多次 `IndNeutralize`）

详见 [[operator-jq-implementation]] § `indneutralize`。

---

## 全 101 公式表

> 公式表达式按论文原文照搬。算子语义见 [[operator-alpha101-definition]]。

### Alpha #1 ~ #10

| # | 公式 | 备注 |
|---|---|---|
| 1 | `(rank(Ts_ArgMax(SignedPower(((returns < 0) ? stddev(returns, 20) : close), 2.), 5)) - 0.5)` | 复合模式：条件 + signedpower + ts_argmax + rank |
| 2 | `(-1 * correlation(rank(delta(log(volume), 2)), rank(((close - open) / open)), 6))` | 量价背离：成交量变化 vs 日内收益 |
| 3 | `(-1 * correlation(rank(open), rank(volume), 10))` | 开盘价与成交量的截面 rank 相关 |
| 4 | `(-1 * Ts_Rank(rank(low), 9))` | 最低价 rank 的时序排位反转 |
| 5 | `(rank((open - (sum(vwap, 10) / 10))) * (-1 * abs(rank((close - vwap)))))` | 价格相对均价偏离 |
| 6 | `(-1 * correlation(open, volume, 10))` | 经典量价背离 |
| 7 | `((adv20 < volume) ? ((-1 * ts_rank(abs(delta(close, 7)), 60)) * sign(delta(close, 7))) : (-1 * 1))` | 高换手日的反转信号 |
| 8 | `(-1 * rank(((sum(open, 5) * sum(returns, 5)) - delay((sum(open, 5) * sum(returns, 5)), 10))))` | 价格×收益变化 |
| 9 | `((0 < ts_min(delta(close, 1), 5)) ? delta(close, 1) : ((ts_max(delta(close, 1), 5) < 0) ? delta(close, 1) : (-1 * delta(close, 1))))` | 趋势/反转切换 |
| 10 | `rank(((0 < ts_min(delta(close, 1), 4)) ? delta(close, 1) : ((ts_max(delta(close, 1), 4) < 0) ? delta(close, 1) : (-1 * delta(close, 1)))))` | 与 #9 类似，加 rank |

### Alpha #11 ~ #20

| # | 公式 | 备注 |
|---|---|---|
| 11 | `((rank(ts_max((vwap - close), 3)) + rank(ts_min((vwap - close), 3))) * rank(delta(volume, 3)))` | |
| 12 | `(sign(delta(volume, 1)) * (-1 * delta(close, 1)))` | 量价方向背离 |
| 13 | `(-1 * rank(covariance(rank(close), rank(volume), 5)))` | 量价 rank 协方差 |
| 14 | `((-1 * rank(delta(returns, 3))) * correlation(open, volume, 10))` | |
| 15 | `(-1 * sum(rank(correlation(rank(high), rank(volume), 3)), 3))` | |
| 16 | `(-1 * rank(covariance(rank(high), rank(volume), 5)))` | |
| 17 | `(((-1 * rank(ts_rank(close, 10))) * rank(delta(delta(close, 1), 1))) * rank(ts_rank((volume / adv20), 5)))` | |
| 18 | `(-1 * rank(((stddev(abs((close - open)), 5) + (close - open)) + correlation(close, open, 10))))` | |
| 19 | `((-1 * sign(((close - delay(close, 7)) + delta(close, 7)))) * (1 + rank((1 + sum(returns, 250)))))` | |
| 20 | `(((-1 * rank((open - delay(high, 1)))) * rank((open - delay(close, 1)))) * rank((open - delay(low, 1))))` | 开盘跳空模式 |

### Alpha #21 ~ #30

| # | 公式 | 备注 |
|---|---|---|
| 21 | `((((sum(close, 8) / 8) + stddev(close, 8)) < (sum(close, 2) / 2)) ? (-1 * 1) : (((sum(close, 2) / 2) < ((sum(close, 8) / 8) - stddev(close, 8))) ? 1 : (((1 < (volume / adv20)) \|\| ((volume / adv20) == 1)) ? 1 : (-1 * 1))))` | 布林带式条件分支 |
| 22 | `(-1 * (delta(correlation(high, volume, 5), 5) * rank(stddev(close, 20))))` | |
| 23 | `(((sum(high, 20) / 20) < high) ? (-1 * delta(high, 2)) : 0)` | 突破触发 |
| 24 | `((((delta((sum(close, 100) / 100), 100) / delay(close, 100)) < 0.05) \|\| ((delta((sum(close, 100) / 100), 100) / delay(close, 100)) == 0.05)) ? (-1 * (close - ts_min(close, 100))) : (-1 * delta(close, 3)))` | |
| 25 | `rank(((((-1 * returns) * adv20) * vwap) * (high - close)))` | |
| 26 | `(-1 * ts_max(correlation(ts_rank(volume, 5), ts_rank(high, 5), 5), 3))` | |
| 27 | `((0.5 < rank((sum(correlation(rank(volume), rank(vwap), 6), 2) / 2.0))) ? (-1 * 1) : 1)` | |
| 28 | `scale(((correlation(adv20, low, 5) + ((high + low) / 2)) - close))` | |
| 29 | `(min(product(rank(rank(scale(log(sum(ts_min(rank(rank((-1 * rank(delta((close - 1), 5))))), 2), 1))))), 1), 5) + ts_rank(delay((-1 * returns), 6), 5))` | 嵌套极深 |
| 30 | `(((1.0 - rank(((sign((close - delay(close, 1))) + sign((delay(close, 1) - delay(close, 2)))) + sign((delay(close, 2) - delay(close, 3)))))) * sum(volume, 5)) / sum(volume, 20))` | |

### Alpha #31 ~ #40

| # | 公式 | 备注 |
|---|---|---|
| 31 | `((rank(rank(rank(decay_linear((-1 * rank(rank(delta(close, 10)))), 10)))) + rank((-1 * delta(close, 3)))) + sign(scale(correlation(adv20, low, 12))))` | |
| 32 | `(scale(((sum(close, 7) / 7) - close)) + (20 * scale(correlation(vwap, delay(close, 5), 230))))` | 长窗口 |
| 33 | `rank((-1 * ((1 - (open / close))^1)))` | |
| 34 | `rank(((1 - rank((stddev(returns, 2) / stddev(returns, 5)))) + (1 - rank(delta(close, 1)))))` | |
| 35 | `((Ts_Rank(volume, 32) * (1 - Ts_Rank(((close + high) - low), 16))) * (1 - Ts_Rank(returns, 32)))` | |
| 36 | `(((((2.21 * rank(correlation((close - open), delay(volume, 1), 15))) + (0.7 * rank((open - close)))) + (0.73 * rank(Ts_Rank(delay((-1 * returns), 6), 5)))) + rank(abs(correlation(vwap, adv20, 6)))) + (0.6 * rank((((sum(close, 200) / 200) - open) * (close - open)))))` | 五项线性组合 |
| 37 | `(rank(correlation(delay((open - close), 1), close, 200)) + rank((open - close)))` | |
| 38 | `((-1 * rank(Ts_Rank(close, 10))) * rank((close / open)))` | |
| 39 | `((-1 * rank((delta(close, 7) * (1 - rank(decay_linear((volume / adv20), 9)))))) * (1 + rank(sum(returns, 250))))` | |
| 40 | `((-1 * rank(stddev(high, 10))) * correlation(high, volume, 10))` | |

### Alpha #41 ~ #50

| # | 公式 | 备注 |
|---|---|---|
| 41 | `(((high * low)^0.5) - vwap)` | 简洁公式 |
| **42** | `(rank((vwap - close)) / rank((vwap + close)))` | **delay-0**——必须在 close 附近交易 |
| 43 | `(ts_rank((volume / adv20), 20) * ts_rank((-1 * delta(close, 7)), 8))` | |
| 44 | `(-1 * correlation(high, rank(volume), 5))` | |
| 45 | `(-1 * ((rank((sum(delay(close, 5), 20) / 20)) * correlation(close, volume, 2)) * rank(correlation(sum(close, 5), sum(close, 20), 2))))` | |
| 46 | `((0.25 < (((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10))) ? (-1 * 1) : (((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < 0) ? 1 : ((-1 * 1) * (close - delay(close, 1)))))` | |
| 47 | `((((rank((1 / close)) * volume) / adv20) * ((high * rank((high - close))) / (sum(high, 5) / 5))) - rank((vwap - delay(vwap, 5))))` | |
| **48** | `(indneutralize(((correlation(delta(close, 1), delta(delay(close, 1), 1), 250) * delta(close, 1)) / close), IndClass.subindustry) / sum(((delta(close, 1) / delay(close, 1))^2), 250))` | **delay-0** + **indneutralize 子行业**；长窗口 250 |
| 49 | `(((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < (-1 * 0.1)) ? 1 : ((-1 * 1) * (close - delay(close, 1))))` | 与 #46 类似 |
| 50 | `(-1 * ts_max(rank(correlation(rank(volume), rank(vwap), 5)), 5))` | |

### Alpha #51 ~ #60

| # | 公式 | 备注 |
|---|---|---|
| 51 | `(((((delay(close, 20) - delay(close, 10)) / 10) - ((delay(close, 10) - close) / 10)) < (-1 * 0.05)) ? 1 : ((-1 * 1) * (close - delay(close, 1))))` | 与 #49 类似 |
| 52 | `((((-1 * ts_min(low, 5)) + delay(ts_min(low, 5), 5)) * rank(((sum(returns, 240) - sum(returns, 20)) / 220))) * ts_rank(volume, 5))` | 长窗口 240 |
| **53** | `(-1 * delta((((close - low) - (high - close)) / (close - low)), 9))` | **delay-0**——OBV-like |
| **54** | `((-1 * ((low - close) * (open^5))) / ((low - high) * (close^5)))` | **delay-0**——5 次幂 |
| 55 | `(-1 * correlation(rank(((close - ts_min(low, 12)) / (ts_max(high, 12) - ts_min(low, 12)))), rank(volume), 6))` | 类 Stochastic |
| 56 | `(0 - (1 * (rank((sum(returns, 10) / sum(sum(returns, 2), 3))) * rank((returns * cap)))))` | 用 `cap` 市值 |
| 57 | `(0 - (1 * ((close - vwap) / decay_linear(rank(ts_argmax(close, 30)), 2))))` | |
| 58 | `(-1 * Ts_Rank(decay_linear(correlation(IndNeutralize(vwap, IndClass.sector), volume, 3.92795), 7.89291), 5.50322))` | **IndNeutralize sector** + 非整数窗口 |
| 59 | `(-1 * Ts_Rank(decay_linear(correlation(IndNeutralize(((vwap * 0.728317) + (vwap * (1 - 0.728317))), IndClass.industry), volume, 4.25197), 16.2289), 8.19648))` | **IndNeutralize industry**（vwap × 0.728317 + vwap × 0.271683 化简为 vwap） |
| 60 | `(0 - (1 * ((2 * scale(rank(((((close - low) - (high - close)) / (high - low)) * volume)))) - scale(rank(ts_argmax(close, 10))))))` | |

### Alpha #61 ~ #70

| # | 公式 | 备注 |
|---|---|---|
| 61 | `(rank((vwap - ts_min(vwap, 16.1219))) < rank(correlation(vwap, adv180, 17.9282)))` | 返回布尔（< 输出） |
| 62 | `((rank(correlation(vwap, sum(adv20, 22.4101), 9.91009)) < rank(((rank(open) + rank(open)) < (rank(((high + low) / 2)) + rank(high))))) * -1)` | 布尔嵌套 |
| 63 | `((rank(decay_linear(delta(IndNeutralize(close, IndClass.industry), 2.25164), 8.22237)) - rank(decay_linear(correlation(((vwap * 0.318108) + (open * (1 - 0.318108))), sum(adv180, 37.2467), 13.557), 12.2883))) * -1)` | **IndNeutralize industry** |
| 64 | `((rank(correlation(sum(((open * 0.178404) + (low * (1 - 0.178404))), 12.7054), sum(adv120, 12.7054), 16.6208)) < rank(delta(((((high + low) / 2) * 0.178404) + (vwap * (1 - 0.178404))), 3.69741))) * -1)` | |
| 65 | `((rank(correlation(((open * 0.00817205) + (vwap * (1 - 0.00817205))), sum(adv60, 8.6911), 6.40374)) < rank((open - ts_min(open, 13.635)))) * -1)` | |
| 66 | `((rank(decay_linear(delta(vwap, 3.51013), 7.23052)) + Ts_Rank(decay_linear(((((low * 0.96633) + (low * (1 - 0.96633))) - vwap) / (open - ((high + low) / 2))), 11.4157), 6.72611)) * -1)` | |
| 67 | `((rank((high - ts_min(high, 2.14593)))^rank(correlation(IndNeutralize(vwap, IndClass.sector), IndNeutralize(adv20, IndClass.subindustry), 6.02936))) * -1)` | **双重 IndNeutralize（sector + subindustry）** |
| 68 | `((Ts_Rank(correlation(rank(high), rank(adv15), 8.91644), 13.9333) < rank(delta(((close * 0.518371) + (low * (1 - 0.518371))), 1.06157))) * -1)` | |
| 69 | `((rank(ts_max(delta(IndNeutralize(vwap, IndClass.industry), 2.72412), 4.79344))^Ts_Rank(correlation(((close * 0.490655) + (vwap * (1 - 0.490655))), adv20, 4.92416), 9.0615)) * -1)` | **IndNeutralize industry** |
| 70 | `((rank(delta(vwap, 1.29456))^Ts_Rank(correlation(IndNeutralize(close, IndClass.industry), adv50, 17.8256), 17.9171)) * -1)` | **IndNeutralize industry** |

### Alpha #71 ~ #80

| # | 公式 | 备注 |
|---|---|---|
| 71 | `max(Ts_Rank(decay_linear(correlation(Ts_Rank(close, 3.43976), Ts_Rank(adv180, 12.0647), 18.0175), 4.20501), 15.6948), Ts_Rank(decay_linear((rank(((low + open) - (vwap + vwap)))^2), 16.4662), 4.4388))` | 双分支 max |
| 72 | `(rank(decay_linear(correlation(((high + low) / 2), adv40, 8.93345), 10.1519)) / rank(decay_linear(correlation(Ts_Rank(vwap, 3.72469), Ts_Rank(volume, 18.5188), 6.86671), 2.95011)))` | 比值结构 |
| 73 | `(max(rank(decay_linear(delta(vwap, 4.72775), 2.91864)), Ts_Rank(decay_linear(((delta(((open * 0.147155) + (low * (1 - 0.147155))), 2.03608) / ((open * 0.147155) + (low * (1 - 0.147155)))) * -1), 3.33829), 16.7411)) * -1)` | |
| 74 | `((rank(correlation(close, sum(adv30, 37.4843), 15.1365)) < rank(correlation(rank(((high * 0.0261661) + (vwap * (1 - 0.0261661)))), rank(volume), 11.4791))) * -1)` | |
| 75 | `(rank(correlation(vwap, volume, 4.24304)) < rank(correlation(rank(low), rank(adv50), 12.4413)))` | |
| 76 | `(max(rank(decay_linear(delta(vwap, 1.24383), 11.8259)), Ts_Rank(decay_linear(Ts_Rank(correlation(IndNeutralize(low, IndClass.sector), adv81, 8.14941), 19.569), 17.1543), 19.383)) * -1)` | **IndNeutralize sector** |
| 77 | `min(rank(decay_linear(((((high + low) / 2) + high) - (vwap + high)), 20.0451)), rank(decay_linear(correlation(((high + low) / 2), adv40, 3.1614), 5.64125)))` | 双分支 min |
| 78 | `(rank(correlation(sum(((low * 0.352233) + (vwap * (1 - 0.352233))), 19.7428), sum(adv40, 19.7428), 6.83313))^rank(correlation(rank(vwap), rank(volume), 5.77492)))` | |
| 79 | `(rank(delta(IndNeutralize(((close * 0.60733) + (open * (1 - 0.60733))), IndClass.sector), 1.23438)) < rank(correlation(Ts_Rank(vwap, 3.60973), Ts_Rank(adv150, 9.18637), 14.6644)))` | **IndNeutralize sector** |
| 80 | `((rank(Sign(delta(IndNeutralize(((open * 0.868128) + (high * (1 - 0.868128))), IndClass.industry), 4.04545)))^Ts_Rank(correlation(high, adv10, 5.11456), 5.53756)) * -1)` | **IndNeutralize industry** |

### Alpha #81 ~ #90

| # | 公式 | 备注 |
|---|---|---|
| 81 | `((rank(Log(product(rank((rank(correlation(vwap, sum(adv10, 49.6054), 8.47743))^4)), 14.9655))) < rank(correlation(rank(vwap), rank(volume), 5.07914))) * -1)` | 四次幂嵌套 |
| 82 | `(min(rank(decay_linear(delta(open, 1.46063), 14.8717)), Ts_Rank(decay_linear(correlation(IndNeutralize(volume, IndClass.sector), ((open * 0.634196) + (open * (1 - 0.634196))), 17.4842), 6.92131), 13.4283)) * -1)` | **IndNeutralize sector** |
| 83 | `((rank(delay(((high - low) / (sum(close, 5) / 5)), 2)) * rank(rank(volume))) / (((high - low) / (sum(close, 5) / 5)) / (vwap - close)))` | |
| 84 | `SignedPower(Ts_Rank((vwap - ts_max(vwap, 15.3217)), 20.7127), delta(close, 4.96796))` | **signedpower** |
| 85 | `(rank(correlation(((high * 0.876703) + (close * (1 - 0.876703))), adv30, 9.61331))^rank(correlation(Ts_Rank(((high + low) / 2), 3.70596), Ts_Rank(volume, 10.1595), 7.11408)))` | |
| 86 | `((Ts_Rank(correlation(close, sum(adv20, 14.7444), 6.00049), 20.4195) < rank(((open + close) - (vwap + open)))) * -1)` | |
| 87 | `(max(rank(decay_linear(delta(((close * 0.369701) + (vwap * (1 - 0.369701))), 1.91233), 2.65461)), Ts_Rank(decay_linear(abs(correlation(IndNeutralize(adv81, IndClass.industry), close, 13.4132)), 4.89768), 14.4535)) * -1)` | **IndNeutralize industry** |
| 88 | `min(rank(decay_linear(((rank(open) + rank(low)) - (rank(high) + rank(close))), 8.06882)), Ts_Rank(decay_linear(correlation(Ts_Rank(close, 8.44728), Ts_Rank(adv60, 20.6966), 8.01266), 6.65053), 2.61957))` | |
| 89 | `(Ts_Rank(decay_linear(correlation(((low * 0.967285) + (low * (1 - 0.967285))), adv10, 6.94279), 5.51607), 3.79744) - Ts_Rank(decay_linear(delta(IndNeutralize(vwap, IndClass.industry), 3.48158), 10.1466), 15.3012))` | **IndNeutralize industry** |
| 90 | `((rank((close - ts_max(close, 4.66719)))^Ts_Rank(correlation(IndNeutralize(adv40, IndClass.subindustry), low, 5.38375), 3.21856)) * -1)` | **IndNeutralize subindustry** |

### Alpha #91 ~ #101

| # | 公式 | 备注 |
|---|---|---|
| 91 | `((Ts_Rank(decay_linear(decay_linear(correlation(IndNeutralize(close, IndClass.industry), volume, 9.74928), 16.398), 3.83219), 4.8667) - rank(decay_linear(correlation(vwap, adv30, 4.01303), 2.6809))) * -1)` | **IndNeutralize industry** + 双 decay_linear |
| 92 | `min(Ts_Rank(decay_linear(((((high + low) / 2) + close) < (low + open)), 14.7221), 18.8683), Ts_Rank(decay_linear(correlation(rank(low), rank(adv30), 7.58555), 6.94024), 6.80584))` | |
| 93 | `(Ts_Rank(decay_linear(correlation(IndNeutralize(vwap, IndClass.industry), adv81, 17.4193), 19.848), 7.54455) / rank(decay_linear(delta(((close * 0.524434) + (vwap * (1 - 0.524434))), 2.77377), 16.2664)))` | **IndNeutralize industry** |
| 94 | `((rank((vwap - ts_min(vwap, 11.5783)))^Ts_Rank(correlation(Ts_Rank(vwap, 19.6462), Ts_Rank(adv60, 4.02992), 18.0926), 2.70756)) * -1)` | |
| 95 | `(rank((open - ts_min(open, 12.4105))) < Ts_Rank((rank(correlation(sum(((high + low) / 2), 19.1351), sum(adv40, 19.1351), 12.8742))^5), 11.7584))` | |
| 96 | `(max(Ts_Rank(decay_linear(correlation(rank(vwap), rank(volume), 3.83878), 4.16783), 8.38151), Ts_Rank(decay_linear(Ts_ArgMax(correlation(Ts_Rank(close, 7.45404), Ts_Rank(adv60, 4.13242), 3.65459), 12.6556), 14.0365), 13.4143)) * -1)` | |
| 97 | `((rank(decay_linear(delta(IndNeutralize(((low * 0.721001) + (vwap * (1 - 0.721001))), IndClass.industry), 3.3705), 20.4523)) - Ts_Rank(decay_linear(Ts_Rank(correlation(Ts_Rank(low, 7.87871), Ts_Rank(adv60, 17.255), 4.97547), 18.5925), 15.7152), 6.71659)) * -1)` | **IndNeutralize industry** |
| 98 | `(rank(decay_linear(correlation(vwap, sum(adv5, 26.4719), 4.58418), 7.18088)) - rank(decay_linear(Ts_Rank(Ts_ArgMin(correlation(rank(open), rank(adv15), 20.8187), 8.62571), 6.95668), 8.07206)))` | |
| 99 | `((rank(correlation(sum(((high + low) / 2), 19.8975), sum(adv60, 19.8975), 8.8136)) < rank(correlation(low, volume, 6.28259))) * -1)` | |
| 100 | `(0 - (1 * (((1.5 * scale(indneutralize(indneutralize(rank(((((close - low) - (high - close)) / (high - low)) * volume)), IndClass.subindustry), IndClass.subindustry))) - scale(indneutralize((correlation(close, rank(adv20), 5) - rank(ts_argmin(close, 30))), IndClass.subindustry))) * (volume / adv20))))` | **三重 indneutralize subindustry** |
| 101 | `((close - open) / ((high - low) + .001))` | 最简——日内动量 |

---

## A 股化注记

### 输入数据映射

| 论文变量 | A 股聚宽实现 |
|---|---|
| `returns` | `close.pct_change()` 或 `np.log(close / close.shift(1))` |
| `open / close / high / low / volume` | `get_price(fq='pre')` 前复权 |
| `vwap` | `get_price(... fields=['avg'])` 或 `(money / volume)` |
| `cap` | `get_valuation` 字段 `market_cap` 或 `circulating_market_cap` |
| `adv5` / `adv10` / `adv20` / `adv30` / `adv40` / `adv50` / `adv60` / `adv81` / `adv120` / `adv150` / `adv180` | `money.rolling(d).mean()`（注意是**金额**不是股数） |
| `IndClass.sector` / `IndClass.industry` / `IndClass.subindustry` | A 股映射为申万一级 / 申万二级 / 申万三级（或中信对应级） |

### 非整数窗口处理

Alpha-101 中很多窗口参数是非整数（如 `8.93345`、`17.9282`），论文 A.2 § ts_{O}(x, d) 明确规定 "**non-integer number of days d is converted to floor(d)**"——**全部取下整**。

### 涨跌停 / 停复牌处理

- 涨跌停时 vwap 计算可能除零（volume → 0）：用 `vwap = np.where(volume > 0, money / volume, close)` 兜底
- 停复牌当日数据缺失：`rolling` 算子需配 `min_periods` 控制；不主动 dropna，让上层组合器处理
- 复牌后跳价较大：长窗口因子（如 #32 的 `230`、#48 的 `250`、#52 的 `240`）会受 single-day 跳价影响

### 长窗口因子（≥ 200 天）

`#19 (sum(returns, 250))`, `#24 (sum(close, 100) / 100)`, `#32 (correlation(vwap, ..., 230))`, `#37 (correlation(..., 200))`, `#48 (sum(..., 250))`, `#52 (sum(returns, 240))`, `#56 (sum(returns, 10) / sum(sum(returns, 2), 3))`——**需要至少 1 年的历史数据**才能开始产出值，回测窗口要预留 warmup 期。

---

## 综合观察

- **复杂度极不均匀**：最简的 #101 只有 `(close-open)/((high-low)+0.001)`，最复杂的 #29、#100 嵌套深达 8 层
- **`decay_linear` 与 `Ts_Rank` 的组合是后半段的主流模式**（Alpha #58-#97 大量使用）
- **`IndNeutralize` 在 20 个 alpha 中出现，全部使用 sector / industry / subindustry 三级之一**
- **非整数窗口（如 8.93345, 17.9282）在论文 A.2 中明确规定取 floor**，但许多公开实现忽略这点
- **4 个 delay-0 alpha (#42, #48, #53, #54)** 必须特别处理时点——可考虑改为 `delay(...)` 形式做 delay-1 化以适配 T+1 回测
- 部分 alpha 公式中的"伪冗余项"如 `(vwap * 0.728317) + (vwap * (1 - 0.728317))` = `vwap` 是 WorldQuant alpha 库的命名混淆做法（防止公式被快速识别），可化简

## 参考与延伸

- [[operator-alpha101-definition]] — 算子定义
- [[operator-naming-mapping]] — Alpha-101 ↔ GTJA-191 命名映射
- [[operator-jq-implementation]] — 算子的聚宽 / pandas 实现
- [[factor-gtja191-all-formulas]] — 姊妹篇：GTJA-191 全 191 公式（A 股版）
- [[factor-jq-impl-samples]] — 10 个 alpha 的完整聚宽样板实现
- [101 Formulaic Alphas_origin.pdf 第 8-15 页](../../../原始资料文件/Alpha-101-GTJA-191/101%20Formulaic%20Alphas_origin.pdf) — 原文 PDF
