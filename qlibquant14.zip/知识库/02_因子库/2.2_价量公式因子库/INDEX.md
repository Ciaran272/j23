---
name: index-02-02-price-volume-factors
description: 二级分类 2.2_价量公式因子库 的索引 —— Alpha-101 全 101 公式 + GTJA-191 全 191 公式 + 10 个聚宽样板
category: 02_因子库/2.2_价量公式因子库
tags: [因子库, alpha101, gtja191, 公式, 聚宽样板, 索引]
created: 2026-05-16
updated: 2026-05-16
status: stable
---

# 2.2 价量公式因子库 · 索引

## 一句话定位

收录 Alpha-101 全 101 条 + GTJA-191 全 191 条因子表达式（共 **292 条公式**），其中 10 条配套完整的聚宽 Python 实现样板。算子语义查 [[index-02-01-operator-dictionary]]，因子实证数字查 [[index-02-06-empirical-benchmark]]（待建）。

## 文件清单

| 文件 | 描述 | 状态 |
|---|---|---|
| [alpha101_全部公式.md](alpha101_全部公式.md) | Alpha-101 论文附录 A.1 的全部 101 个公式，标注 4 个 delay-0 + 20 个含 indneutralize 的 alpha；OCR 整体可用 | draft |
| [gtja191_全部公式.md](gtja191_全部公式.md) | GTJA-191 研报 ch3.3 表 6 的全部 191 个公式，**4 级 OCR 状态标注**（✓ ⚠ ⚡ ❌）；6 个 alpha 完全缺失需回 PDF | draft |
| [公式_聚宽样板实现.md](公式_聚宽样板实现.md) | 10 个代表性因子（Alpha-101 5 个 + GTJA-191 5 个）的完整聚宽 / jqdatasdk Python 实现 | with-jq-impl |

## 因子库覆盖度

| 来源 | 总数 | 公式入库 | 聚宽实现 | 备注 |
|---|---|---|---|---|
| Alpha-101 | 101 | 101/101 ✓ | 5/101 | OCR 完整；4 个 delay-0 已标注 |
| GTJA-191 | 191 | 185/191（**6 个缺失需回 PDF**） | 5/191 | OCR 损坏密集；6 个完全缺失 |
| 合计 | 292 | 286/292 | 10/292 | 后续按需扩展聚宽实现 |

## 使用流程建议

1. **查公式语义**：在 `alpha101_全部公式.md` / `gtja191_全部公式.md` 按 Alpha 编号定位
2. **抄代码用**：先看 `公式_聚宽样板实现.md` 是否有该因子的完整实现；若有直接用，若无看算子层 [[operator-jq-implementation]] 自组合
3. **互译公式**：查 [[operator-naming-mapping]] 看 GTJA ↔ Alpha-101 对应关系（有 12 个直接等价）
4. **遇到 OCR 损坏的 GTJA 因子**：先看 `gtja191_全部公式.md` 的"修复提示"列，若标 ⚡ 或 ❌ 状态，**必须回 origin.pdf 重抄**

## 关键 A 股化要点（必读）

- **delay-0 因子**：Alpha-101 的 #42 / #48 / #53 / #54 必须在 close 附近交易，回测要用 close 撮合或临近收盘下单（详见 [公式_聚宽样板实现.md § 样板 7-8](公式_聚宽样板实现.md)）
- **indneutralize**：Alpha-101 中 20 个 alpha 使用，A 股映射为申万一级 / 二级 / 三级
- **非整数窗口**：Alpha-101 中如 `8.93345` 这种参数取 floor（论文 A.2 明确规定）
- **SELF 变量**：GTJA Alpha143 是唯一使用 SELF（前一日同一 alpha 值）的因子，需要状态化实现
- **基准指数**：GTJA Alpha75/149/181/182 使用 BANCHMARKINDEXCLOSE/OPEN（OCR 拼写笔误，实为 BENCHMARK），通常映射为沪深 300
- **Fama-French 三因子**：GTJA Alpha30 使用 MKT/SMB/HML（OCR 中 MKE → MKT）

## GTJA-191 OCR 4 级状态分布

| 状态 | 数量 | 处理 |
|---|---|---|
| ✓ 完整 | ~110 | 直接抄用 |
| ⚠ 轻度 | ~50 | 配修复提示用 |
| ⚡ 重度 | ~25（Alpha49/50/51/55/128/137/146/152/156/157/165/166/172/186/190 等） | 回 origin.pdf 第 11-16 页校对 |
| ❌ 完全缺失 | 6（**Alpha159, 161, 162, 167, 168, 169**） | 必须从 origin.pdf 重新提取 |

## 重复 / 等价因子（GTJA ↔ Alpha-101）

GTJA-191 中至少有 12 个因子与 Alpha-101 完全等价或近似（详见 [gtja191_全部公式.md § 重复因子](gtja191_全部公式.md)）：

| GTJA | Alpha-101 |
|---|---|
| Alpha13 | #41 |
| Alpha42 | #40 |
| Alpha98 | #24 |
| Alpha105 | #3 |
| Alpha117 | #35 |
| Alpha120 | #42 |
| Alpha139 | #6 |
| Alpha142 | #17 |
| Alpha163 | #25 |
| Alpha171 | #54（变种） |
| Alpha180 | #7 |
| Alpha184 | #37 |

复现时**优先使用 Alpha-101 版本**（OCR 完整、命名小写更易追溯），GTJA 重复版本作为校对。

---

[← 返回 02_因子库 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
