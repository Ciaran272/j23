---
name: operator-alpha101-definition
description: Alpha-101 论文附录 A.2 的 21 个核心算子与 A.3 输入数据定义，含中文释义、A 股化注记、与 GTJA-191 算子的对照入口
category: 02_因子库/2.1_算子词典
tags: [alpha101, 算子, 截面, 时序, rank, ts_rank, decay_linear, indneutralize]
created: 2026-05-16
updated: 2026-05-16
source: 原始资料文件/Alpha-101-GTJA-191/主知识文件.md (附录 A.2 第 735-773 行)
status: draft
---

# Alpha-101 算子定义（附录 A.2 + A.3）

## TL;DR

WorldQuant 论文《101 Formulaic Alphas》附录 A.2 定义了构造全部 101 个 alpha 所需的 **21 个原子算子**，附录 A.3 定义了 **9 类输入数据变量**。本文档是 [[operator-gtja191-definition]] 与 [[operator-naming-mapping]] 的源头之一，并通过 [[operator-jq-implementation]] 落地到聚宽。

## 来源

- **主资料**：[主知识文件.md 第 735-773 行](../../../原始资料文件/Alpha-101-GTJA-191/主知识文件.md)（附录 A.2 + A.3）
- **配套**：[101 Formulaic Alphas_origin.pdf 第 15-16 页](../../../原始资料文件/Alpha-101-GTJA-191/101%20Formulaic%20Alphas_origin.pdf)

## OCR 整体说明

附录 A.2 与 A.3 部分的 OCR 输出**完整无损**，所有算子定义与输入数据定义可以直接使用，无需回 PDF 校对。

---

## 一、标准算子（无需特殊解释）

> 原文（附录 A.2 第 739 行）：
> `abs(x), log(x), sign(x)` = standard definitions; same for the operators `+`, `-`, `*`, `/`, `>`, `<`, `==`, `||`, `x ? y : z`

| 算子 | 中文释义 | 备注 |
|---|---|---|
| `abs(x)` | 绝对值 | 与 numpy/pandas 一致 |
| `log(x)` | 自然对数 | 输入 ≤ 0 时未定义；用前需保证 x > 0 |
| `sign(x)` | 符号函数 | 返回 -1/0/1 |
| `+`、`-`、`*`、`/` | 四则运算 | 元素级 |
| `>`、`<`、`==` | 比较运算 | 返回布尔 |
| `\|\|` | 逻辑或 | 注意：原文用 `\|\|` 而非 `\|` |
| `x ? y : z` | 三元条件 | C 风格，Python 写 `np.where(x, y, z)` |

---

## 二、截面算子（cross-sectional）

### `rank(x)`

> **原文**：cross-sectional rank

**中文释义**：截面排序——同一时点对所有股票的 x 值做升序排序，输出归一化到 [0, 1] 区间的分位数（百分比 rank）。

**A 股化注记**：
- 每日有效股票池会变动（停牌 / 新股 / 退市 / ST），rank **必须在当日有效池内做**，否则会引入未来函数或污染
- 涨跌停股票当日"价格被锁定"但 rank 上仍参与（这是合理的）
- 行业内 rank 时需先做 [[operator-jq-implementation#行业内-rank]] 处理

**聚宽实现**：详见 [[operator-jq-implementation]] § `rank`

### `scale(x, a)`

> **原文**：rescaled x such that sum(abs(x)) = a (the default is a = 1)

**中文释义**：截面归一化——把 x 缩放使所有股票绝对值之和等于 a（默认 1）。常用于把因子值变成"权重向量"。

**A 股化注记**：
- 输出的"权重"通常用作仓位分配前的中间量，配 04_组合与风控的优化器
- 默认 a=1 时若 x 全正则输出就是直接的权重分布

**聚宽实现**：详见 [[operator-jq-implementation]] § `scale`

### `indneutralize(x, g)`

> **原文**：x cross-sectionally neutralized against groups g (subindustries, industries, sectors, etc.), i.e., x is cross-sectionally demeaned within each group g

**中文释义**：行业中性化——同一时点把 x 按行业分组，每个分组内做去均值处理（demean）。

**A 股化注记（重要）**：
- **`g` 参数在 A 股需要选择行业分类标准**：常用中信一级 / 申万一级 / 申万二级
- 同一个 alpha 公式中**不同位置的 `IndClass` 可以采用不同分类**（论文 A.3 节明确说明 "Multiple IndClass in the same alpha need not correspond to the same industry classification"）
- 聚宽 API：`get_industry(security, date)` 获取个股行业；`finance.run_query(query(industries.industry_code))` 获取行业全集
- 停牌股票要从分组中排除，否则会污染该行业均值

**聚宽实现**：详见 [[operator-jq-implementation]] § `indneutralize`

---

## 三、时序算子（time-series）

### `delay(x, d)`

> **原文**：value of x d days ago

**中文释义**：把 x 向后挪 d 天（取 d 天前的值）。

**聚宽实现**：`df.shift(d)`

### `delta(x, d)`

> **原文**：today's value of x minus the value of x d days ago

**中文释义**：今天的 x 减去 d 天前的 x，即 `x_t - x_{t-d}`。

**聚宽实现**：`df - df.shift(d)` 或 `df.diff(d)`

### `correlation(x, y, d)`

> **原文**：time-serial correlation of x and y for the past d days

**中文释义**：x 和 y 在过去 d 天的**时间序列 Pearson 相关系数**（每个股票各自一个值）。

**A 股化注记**：
- d 天窗口内若有停牌缺失值，相关系数会有偏。建议在 rolling 前做 `dropna` 或 `fillna(method='ffill')`
- 滚动相关用 pandas `rolling.corr` 实现

**聚宽实现**：详见 [[operator-jq-implementation]] § `correlation`

### `covariance(x, y, d)`

> **原文**：time-serial covariance of x and y for the past d days

**中文释义**：x 和 y 在过去 d 天的时间序列协方差。

**聚宽实现**：`x.rolling(d).cov(y)`

### `stddev(x, d)`

> **原文**：moving time-series standard deviation over the past d days

**中文释义**：过去 d 天的 x 的滚动标准差。

**聚宽实现**：`x.rolling(d).std()`

### `sum(x, d)`

> **原文**：time-series sum over the past d days

**中文释义**：过去 d 天的 x 求和。

**聚宽实现**：`x.rolling(d).sum()`

### `product(x, d)`

> **原文**：time-series product over the past d days

**中文释义**：过去 d 天的 x 求积。

**聚宽实现**：`x.rolling(d).apply(np.prod, raw=True)` 或 `np.exp(np.log(x).rolling(d).sum())`（数值更稳）

### `ts_min(x, d)` / `min(x, d)`

> **原文**：time-series min over the past d days；`min(x, d) = ts_min(x, d)`

**中文释义**：过去 d 天的 x 最小值。注意 `min(x, d)` 是 Alpha-101 论文中的简写，**不等于** numpy 的元素级 min。

**聚宽实现**：`x.rolling(d).min()`

### `ts_max(x, d)` / `max(x, d)`

> **原文**：time-series max over the past d days；`max(x, d) = ts_max(x, d)`

**聚宽实现**：`x.rolling(d).max()`

### `ts_argmax(x, d)`

> **原文**：which day ts_max(x, d) occurred on

**中文释义**：过去 d 天内 x 最大值发生在第几天。返回的是相对位置（0 到 d-1，或 1 到 d，**论文未明确，需统一约定**）。

**A 股化注记**：约定**返回 1 到 d**（即"最近 d 天里第几天"，最近一天为 1），与 GTJA-191 的 HIGHDAY 一致。

**聚宽实现**：详见 [[operator-jq-implementation]] § `ts_argmax`

### `ts_argmin(x, d)`

> **原文**：which day ts_min(x, d) occurred on

**中文释义**：过去 d 天内 x 最小值发生在第几天。约定同 `ts_argmax`。

**聚宽实现**：详见 [[operator-jq-implementation]] § `ts_argmin`

### `ts_rank(x, d)`

> **原文**：time-series rank in the past d days

**中文释义**：x 当日在过去 d 天序列中的排位（每个股票各自一个值），与截面 `rank` 不同——`ts_rank` 是**对自己的过去做排序**。

**聚宽实现**：详见 [[operator-jq-implementation]] § `ts_rank`

### `ts_{O}(x, d)`（通用时序算子）

> **原文**：operator O applied across the time-series for the past d days; non-integer number of days d is converted to floor(d)

**中文释义**：泛指任何时序算子。**非整数 d 取下取整**——这是 Alpha-101 实现细节。

---

## 四、工具算子

### `signedpower(x, a)`

> **原文**：x^a

**中文释义**：x 的 a 次幂。**注意**：a 可能是小数（如 0.5、2），且 x 可能为负——直接 `x**a` 在 x<0 且 a 不是整数时会产生复数或 NaN。论文的实际语义是 `sign(x) * abs(x)^a`（带符号的幂运算）。

**聚宽实现**：`np.sign(x) * np.abs(x) ** a`

### `decay_linear(x, d)`

> **原文**：weighted moving average over the past d days with linearly decaying weights d, d – 1, …, 1 (rescaled to sum up to 1)

**中文释义**：过去 d 天的 x 的线性衰减加权移动平均，权重为 d, d-1, ..., 1（最近的权重最大），归一化使和为 1。

**对照**：与 GTJA-191 的 `DECAYLINEAR(A, d)` **完全相同**。

**聚宽实现**：详见 [[operator-jq-implementation]] § `decay_linear`

---

## 五、输入数据（附录 A.3）

> 原文（第 768-773 行）：

| 变量 | 原文释义 | A 股对应 / 注记 |
|---|---|---|
| `returns` | daily close-to-close returns | 收盘到收盘对数收益（或简单收益，论文未明确，常用对数）；聚宽 `get_price` 输出后自算 |
| `open / close / high / low / volume` | standard daily price/volume | 聚宽 `get_price(fq='pre')` 取前复权；停牌日数据缺失需 `fillna(method='ffill')` 或剔除 |
| `vwap` | daily volume-weighted average price | A 股聚宽用 `get_price(... fields=['avg'])` 或 `(money/volume)` 计算；注意涨跌停板时成交量为 0 会除零 |
| `cap` | market cap | A 股市值：总市值 vs 流通市值视使用场景而定（多因子中性化常用流通市值）；聚宽 `get_valuation` 字段 `market_cap` / `circulating_market_cap` |
| `adv{d}` | average daily dollar volume for the past d days | 过去 d 天平均日成交额（**dollar volume**，即"金额"而非"股数"，对应 A 股的 `money` 字段）。常见 `adv5`, `adv10`, `adv20`, `adv60` |
| `IndClass` | a generic placeholder for a binary industry classification (GICS / BICS / NAICS / SIC), 在 `indneutralize(x, IndClass.level)` 中使用，level = sector / industry / subindustry | A 股映射为中信一级 / 申万一级 / 申万二级 / 申万三级；聚宽 `get_industry(security, date)`；**同一 alpha 中可使用不同分类**（论文允许） |

---

## 六、综合观察

- **21 个算子完全足够构造全部 101 个 alpha**——这是论文体系的简洁性所在
- 算子分两大类：**截面**（同一时点跨股票）和**时序**（同一股票跨时间），少数算子（如 `decay_linear`）只作用于时序但语义上是加权聚合
- 与 GTJA-191 命名差异较大（`ts_rank` ↔ `TSRANK`、`decay_linear` ↔ `DECAYLINEAR`、`indneutralize` ↔ "风格中性预处理"），互译细节见 [[operator-naming-mapping]]
- 实际落地到聚宽时，**截面算子用 `axis=1`，时序算子用 `rolling()` 或 `shift()`**，详见 [[operator-jq-implementation]]
- **`min/max` 的歧义**：论文中 `min(x, d)` 是 `ts_min(x, d)` 的别名，**不是**元素级 `min(x, y)`。看到 `min(close, 10)` 这种用法要识别为时序 min

## 参考与延伸

- [[operator-gtja191-definition]] — GTJA-191 算子定义（中文 A 股版）
- [[operator-naming-mapping]] — Alpha-101 ↔ GTJA-191 命名映射
- [[operator-jq-implementation]] — 算子的聚宽 / pandas / jqdatasdk 实现
- [101 Formulaic Alphas_origin.pdf 第 15-16 页](../../../原始资料文件/Alpha-101-GTJA-191/101%20Formulaic%20Alphas_origin.pdf) — OCR 真值源
