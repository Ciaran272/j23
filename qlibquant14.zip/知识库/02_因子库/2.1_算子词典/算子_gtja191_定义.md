---
name: operator-gtja191-definition
description: GTJA-191 国泰君安研报附录 2 的 30+ 算子函数与数据变量定义，含中文释义、A 股化注记、三处 OCR/笔误校对
category: 02_因子库/2.1_算子词典
tags: [gtja191, 算子, 数据变量, RANK, TSRANK, SMA, WMA, DECAYLINEAR, REGBETA]
created: 2026-05-16
updated: 2026-05-16
source: 原始资料文件/国泰君安－基于短周期价量特征的多因子选股体系/国泰君安基于短周期价量特征的多因子选股体系.md (附录 2 表 15，第 799-802 行)
status: draft
---

# GTJA-191 算子定义（附录 2 表 15）

## TL;DR

国泰君安《基于短周期价量特征的多因子选股体系》附录 2 表 15，定义了构造全部 191 个 A 股价量 alpha 因子所需的 **19 个数据变量** + **30+ 算子函数**。本文档是 [[operator-alpha101-definition]] 的姊妹篇（A 股版），通过 [[operator-naming-mapping]] 与之互译，并由 [[operator-jq-implementation]] 落地到聚宽。

## 来源

- **主资料**：[国泰君安基于短周期价量特征的多因子选股体系.md 第 799-802 行](../../../原始资料文件/国泰君安－基于短周期价量特征的多因子选股体系/国泰君安基于短周期价量特征的多因子选股体系.md)（附录 2 表 15）
- **配套**：[国泰君安..._origin.pdf 第 29-30 页](../../../原始资料文件/国泰君安－基于短周期价量特征的多因子选股体系/国泰君安基于短周期价量特征的多因子选股体系_origin.pdf)（真值源）

## OCR / 笔误整体说明（重要，引用前必读）

附录 2 表 15 的 OCR 输出整体可用，但存在 **3 处明确错误**：

| 位置 | OCR / 原文输出 | 修正 | 性质 |
|---|---|---|---|
| 数据变量"Fama French 三因子" | `HML SMB MKE` | `HML SMB MKT` | **作者笔误 + OCR 错**（MKE 不存在，应为 MKT = 市场因子 Market） |
| 算子 `COVIANCE(A, B, n)` | `COVIANCE` | `COVARIANCE` | **作者笔误**（少了一个 A 字母）；现实使用中常见拼写为 COVARIANCE |
| 算子 `LOWDAY(A, n)` 定义 | "计算 A 前 n 期时间序列中**最大值**距离当前时点的间隔" | "计算 A 前 n 期时间序列中**最小值**距离当前时点的间隔" | **作者笔误**：复制了 HIGHDAY 的定义没改；与算子名"LOW"day 矛盾 |

引用 / 入库时**应使用修正后版本**，并在原文出现错误处加注 `<!-- OCR: 原为 X, 应为 Y -->` 备查。

---

## 一、数据变量（19 个）

> 原文（附录 2 表 15 上半部分）：

### 量价基础变量（与 Alpha-101 A.3 对应）

| 变量 | 原文定义 | A 股聚宽对应 |
|---|---|---|
| `OPEN` | 开盘价 | `get_price(... fields=['open'])` |
| `HIGH` | 最高价 | `... fields=['high']` |
| `LOW` | 最低价 | `... fields=['low']` |
| `CLOSE` | 收盘价 | `... fields=['close']` |
| `VWAP` | 均价 | A 股聚宽用 `... fields=['avg']` 或 `money / volume` 计算；涨跌停板成交量 0 时除零需特殊处理 |
| `VOLUME` | 成交量 | `... fields=['volume']`（**股数**） |
| `AMOUNT` | 成交额 | `... fields=['money']`（**金额**，对应 Alpha-101 的 `adv{d}` 计算基础） |

### 基准指数（A 股特有）

| 变量 | 原文定义 | 备注 |
|---|---|---|
| `BANCHMARKINDEXCLOSE` | 基准指数的开盘价 | **原文定义有错**——名为 CLOSE 但定义说是"开盘价"。按变量名应是**基准指数收盘价**；GTJA 报告中通常以**沪深 300 收盘价**为基准 |
| `BANCHMARKINDEXOPEN` | 基准指数的收盘价 | 同理。按变量名应是**基准指数开盘价** |

**注**：上述两个变量名拼写为 `BANCHMARK`（应为 `BENCHMARK`），属作者笔误，沿用至今。

### 收益与衍生变量

| 变量 | 原文定义 | 公式 |
|---|---|---|
| `RET` | 每日收益率（收盘/前收盘 - 1） | `CLOSE / DELAY(CLOSE, 1) - 1` |
| `DTM` | A 股 ATR 体系变量 | `(OPEN <= DELAY(OPEN, 1)) ? 0 : MAX((HIGH - OPEN), (OPEN - DELAY(OPEN, 1)))` |
| `DBM` | A 股 ATR 体系变量 | `(OPEN >= DELAY(OPEN, 1)) ? 0 : MAX((OPEN - LOW), (OPEN - DELAY(OPEN, 1)))` |
| `TR` | 真实波幅 True Range | `MAX(MAX(HIGH - LOW, ABS(HIGH - DELAY(CLOSE, 1))), ABS(LOW - DELAY(CLOSE, 1)))` |
| `HD` | 当日高点相对昨日高点的差 | `HIGH - DELAY(HIGH, 1)` |
| `LD` | 昨日低点相对当日低点的差 | `DELAY(LOW, 1) - LOW` |

### 因子模型变量

| 变量 | 原文定义 | 备注 |
|---|---|---|
| `HML` | Fama-French 价值因子 High Minus Low | 高账面市值比组合 - 低账面市值比组合 |
| `SMB` | Fama-French 规模因子 Small Minus Big | 小市值组合 - 大市值组合 |
| `MKT` | Fama-French 市场因子（**原文 OCR/笔误为 MKE**） | 沪深 300 等市场基准收益减无风险利率 |

### 特殊变量

| 变量 | 原文定义 | 备注 |
|---|---|---|
| `SELF` | 出现在 Alpha143 中，表示 t-1 日的 Alpha143 因子计算结果 | **递归引用**——Alpha143 是少数有时间依赖性的因子，实现时需要保留状态。详见 [[operator-jq-implementation]] § `SELF` |

---

## 二、算子函数（30+）

### 截面算子

#### `RANK(A)`

> **原文**：向量 A 升序排序

**中文释义**：截面排序——同一时点对所有股票的 A 值做升序排序。**原文未说是否归一化到 [0,1]**，GTJA-191 实务中通常归一化（与 Alpha-101 `rank` 一致）。

**A 股化注记**：与 [[operator-alpha101-definition]] § `rank` 相同：
- 每日有效池处理（剔除停牌 / 新股 / 退市 / ST）
- 行业内 rank 需先按行业分组

### 时序聚合算子

#### `STD(A, n)`
> **原文**：序列 A 过去 n 天标准差。聚宽：`A.rolling(n).std()`

#### `SUM(A, n)`
> **原文**：序列 A 过去 n 天求和。聚宽：`A.rolling(n).sum()`

#### `MEAN(A, n)`
> **原文**：序列 A 过去 n 天均值。聚宽：`A.rolling(n).mean()`

#### `PROD(A, n)`
> **原文**：序列 A 过去 n 天累乘。聚宽：`A.rolling(n).apply(np.prod, raw=True)` 或 `np.exp(np.log(A).rolling(n).sum())`（数值稳定版）

#### `TSMIN(A, n)`
> **原文**：序列 A 过去 n 天的最小值。聚宽：`A.rolling(n).min()`

#### `TSMAX(A, n)`
> **原文**：序列 A 过去 n 天的最大值。聚宽：`A.rolling(n).max()`

#### `TSRANK(A, n)`
> **原文**：序列 A 的末位值在过去 n 天的顺序排位

**中文释义**：A 当日在过去 n 天序列中的排位。与 Alpha-101 `ts_rank` 等价。

**聚宽实现**：详见 [[operator-jq-implementation]] § `TSRANK`

#### `HIGHDAY(A, n)`
> **原文**：计算 A 前 n 期时间序列中最大值距离当前时点的间隔

**中文释义**：过去 n 天 A 最大值发生在第几天前。与 Alpha-101 `ts_argmax` 等价（约定返回 1 到 n）。

#### `LOWDAY(A, n)`
> **原文（已修正）**：计算 A 前 n 期时间序列中**最小值**距离当前时点的间隔
> <!-- OCR/笔误: 原文写"最大值"，应为"最小值"。LOWDAY 与 HIGHDAY 互补 -->

**中文释义**：过去 n 天 A 最小值发生在第几天前。与 Alpha-101 `ts_argmin` 等价。

#### `SUMAC(A, n)`
> **原文**：计算 A 的前 n 项的累加（cumulative sum）

**中文释义**：A 序列前 n 项的**累计和**（不是滚动和）。注意这是**从序列起点到 n 处的逐项累加**，而 `SUM(A, n)` 是过去 n 天的滚动和——两者**不同**。

### 时序变换算子

#### `DELTA(A, n)`
> **原文**：A - A（OCR 输出残缺，实际为 `A_t - A_{t-n}`）

**中文释义**：A 当前值减去 n 期前的值。与 Alpha-101 `delta(x, d)` 等价。聚宽：`A - A.shift(n)`。

#### `DELAY(A, n)`
> **原文**：A_{t-n}（OCR 输出残缺为单字母 A）

**中文释义**：A 在 n 期前的值。与 Alpha-101 `delay(x, d)` 等价。聚宽：`A.shift(n)`。

#### `LOG(A)`
> **原文**：自然对数函数

#### `ABS(A)`
> **原文**：绝对值函数

#### `SIGN(A)`
> **原文**：符号函数（1 if A > 0, 0 if A = 0, -1 if A < 0）

#### `MAX(A, B)` / `MIN(A, B)`
> **原文**：在 A、B 中选择最大 / 最小的数

**中文释义**：**元素级**两者取大 / 取小。**注意**与 `TSMAX/TSMIN` 区别：`MAX(A, B)` 输入是两个相同长度的序列，输出元素级最大；`TSMAX(A, n)` 输入是序列 A 和窗口长度 n。

### 相关性算子

#### `CORR(A, B, n)`
> **原文**：序列 A、B 过去 n 天相关系数

**中文释义**：A 与 B 在过去 n 天的 Pearson 相关。与 Alpha-101 `correlation(x, y, d)` 等价。聚宽：`A.rolling(n).corr(B)`。

#### `COVARIANCE(A, B, n)`（**原文 OCR/笔误为 COVIANCE**）
> **原文（已修正）**：序列 A、B 过去 n 天协方差
> <!-- OCR/笔误: 原文写 COVIANCE, 应为 COVARIANCE -->

**聚宽实现**：`A.rolling(n).cov(B)`

### 加权平均算子

#### `SMA(A, n, m)`
> **原文**：Y_{i+1} = (A_i × m + Y_i × (n - m)) / n，其中 Y 表示最终结果

**中文释义**：A 股版**指数加权移动平均**（与通达信、东方财富等行情软件的 SMA 一致），**不同于** Alpha-101 没有此算子。递推形式为：

```
Y_t = (m / n) * A_t + ((n - m) / n) * Y_{t-1}
```

即新值权重 m/n、旧值权重 (n-m)/n。**实际效果**：m=1 时是经典指数加权（衰减系数 1/n）；m=2 时是 KDJ 中常用的"半衰期约 n/2 的 EMA"。

**A 股化注记（重要）**：
- 这是 A 股技术指标体系（KDJ、RSI、MACD 国内版）的核心算子，**不是国际通用 SMA**（国际上 SMA = simple moving average，对应 GTJA-191 的 `MEAN`）
- 起始值 Y_0 的处理：常见做法是 Y_0 = A_0，或用前 m 期的简单均值。**GTJA-191 原报告未明确**，实务以 Y_0 = A_0 居多
- Whale-Quant ch03 与 Python 量化实战 ch5.1.5 都有此算子的"国内版"实现

**聚宽实现**：详见 [[operator-jq-implementation]] § `SMA`

#### `WMA(A, n)`
> **原文**：计算 A 前 n 期样本加权平均值，权重为 0.9^i（i 表示样本距离当前时点的间隔）

**中文释义**：**指数衰减加权移动平均**，权重为 0.9, 0.9², 0.9³, ..., 0.9^(n-1)（最近一天权重为 0.9⁰=1，最早一天权重为 0.9^(n-1)）。归一化使权重和为 1。

**注意**：与 Alpha-101 的 `decay_linear`**不同**——`decay_linear` 是**线性**衰减权重 (d, d-1, ..., 1)，`WMA` 是**几何**衰减权重 (0.9⁰, 0.9¹, ...)。

**聚宽实现**：详见 [[operator-jq-implementation]] § `WMA`

#### `DECAYLINEAR(A, d)`
> **原文**：对 A 序列计算移动平均加权，其中权重对应 d, d-1, ..., 1（权重和为 1）

**中文释义**：与 Alpha-101 `decay_linear(x, d)` **完全相同**。

### 回归算子

#### `REGBETA(A, B, n)`
> **原文**：前 n 期样本 A 对 B 做回归所得回归系数

**中文释义**：A 对 B 做 OLS 回归（A 是被解释变量，B 是解释变量），返回斜率系数 β。**截距未输出**。

**A 股化注记**：实际公式 `A_t = α + β * B_t + ε_t` 的 β。常见用法：算个股 Beta（A=个股收益, B=市场收益）、计算 RSRS 因子（A=最高价, B=最低价）。

**聚宽实现**：详见 [[operator-jq-implementation]] § `REGBETA`

#### `REGRESI(A, B, n)`
> **原文**：前 n 期样本 A 对 B 做回归所得的残差

**中文释义**：A 对 B 回归后**当期的残差**（不是序列）。即 `A_t - (α + β * B_t)` 在 t 为当前时点的值。

**聚宽实现**：详见 [[operator-jq-implementation]] § `REGRESI`

### 条件 / 筛选算子

#### `COUNT(condition, n)`
> **原文**：计算前 n 期满足条件 condition 的样本个数

**中文释义**：前 n 期内，布尔条件 condition 为真的次数。聚宽：`condition.rolling(n).sum()`（condition 为布尔序列）。

#### `SUMIF(A, n, condition)`
> **原文**：对 A 前 n 项条件求和，其中 condition 表示选择条件

**中文释义**：前 n 期 A，只对 condition 为真的位置求和。聚宽：`(A * condition).rolling(n).sum()`（condition 是 0/1 布尔）。

#### `FILTER(A, condition)`
> **原文**：对 A 筛选出符合选择条件 condition 的样本

**中文释义**：保留 A 中 condition 为真的位置，其他位置常用 NaN / 0 / 不变（**原文未明确**）。**实务约定**：常用 0 替代（与 `A * condition` 等价）。

### 工具算子

#### `SEQUENCE(n)`
> **原文**：生成 1 ~ n 的等差序列

**中文释义**：`[1, 2, 3, ..., n]`。常用于 `REGBETA` 中给"时间"作为自变量回归。

#### 逻辑运算
- `&` — 与（and）
- `|` — 或（or）
- `A ? B : C` — 三元条件：若 A 成立则为 B，否则为 C（与 Alpha-101 三元条件等价）

---

## 三、综合观察

- **30+ 算子比 Alpha-101 的 21 个多**：GTJA-191 多出 `SMA`（A 股版指数加权）、`WMA`（几何衰减加权）、`REGBETA / REGRESI`（回归类）、`COUNT / SUMIF / FILTER`（条件类）、`SEQUENCE`（等差序列）、`SUMAC`（累加）等
- 多出的算子大多源自 **A 股技术指标体系**（KDJ、RSI、MACD 国内版需要 SMA；RSRS 需要 REGBETA）和 **条件因子**（如 Alpha 中用 `MEAN(IF(condition, X, 0), n)` 这种结构）
- 命名风格全大写（A 股研报传统），与 Alpha-101 小写形成鲜明对比；映射详见 [[operator-naming-mapping]]
- **3 处 OCR / 笔误**（COVIANCE → COVARIANCE、LOWDAY 定义错为"最大值"、MKE → MKT）在原文中长期保留，**抄写时务必修正**
- **`SELF` 变量是 Alpha143 独有**——表示前一日同一 alpha 的值，意味着 Alpha143 实现时需保留状态（不能纯函数式）；这是 GTJA-191 体系中**唯一**有显式时间依赖性的因子

## 参考与延伸

- [[operator-alpha101-definition]] — Alpha-101 论文附录 A.2 算子定义（英文 / 美股版）
- [[operator-naming-mapping]] — Alpha-101 ↔ GTJA-191 命名映射
- [[operator-jq-implementation]] — 算子的聚宽 / pandas / jqdatasdk 实现
- [国泰君安..._origin.pdf 第 29-30 页](../../../原始资料文件/国泰君安－基于短周期价量特征的多因子选股体系/国泰君安基于短周期价量特征的多因子选股体系_origin.pdf) — OCR 真值源
