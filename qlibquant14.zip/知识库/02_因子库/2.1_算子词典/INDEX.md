---
name: index-02-01-operator-dictionary
description: 二级分类 2.1_算子词典 的索引 —— Alpha-101 与 GTJA-191 全部算子的定义、映射、聚宽实现
category: 02_因子库/2.1_算子词典
tags: [算子, alpha101, gtja191, 命名映射, 聚宽实现, 索引]
created: 2026-05-16
updated: 2026-05-16
status: stable
---

# 2.1 算子词典 · 索引

## 一句话定位

把 Alpha-101 与 GTJA-191 用到的全部 30+ 个原子算子（rank / ts_rank / delay / correlation / decay_linear / indneutralize / SMA / WMA / REGBETA / ...）的语义、命名映射、聚宽 / pandas / jqdatasdk 实现集中归档，作为 [[index-02-02-price-volume-factors]] 价量公式因子库的解码字典。

## 文件清单

| 文件 | 描述 | 状态 |
|---|---|---|
| [算子_alpha101_定义.md](算子_alpha101_定义.md) | Alpha-101 论文附录 A.2 的 21 个算子 + A.3 的 9 类输入数据，含中文释义与 A 股化注记 | draft |
| [算子_gtja191_定义.md](算子_gtja191_定义.md) | GTJA-191 研报附录 2 表 15 的 19 个数据变量 + 30+ 算子函数，含 3 处 OCR/笔误修正 | draft |
| [算子_命名映射.md](算子_命名映射.md) | Alpha-101 ↔ GTJA-191 命名映射表（完全等价 / 近似 / 各自独有三类） | draft |
| [算子_聚宽实现.md](算子_聚宽实现.md) | 全部算子的 pandas / jqdatasdk 实现，含 A 股有效池构造、行业中性化、回归算子、Alpha143 状态化等 | with-jq-impl |

## 使用流程建议

1. **新读者**：先读 `算子_alpha101_定义.md` 建立"算子"心智模型 → 读 `算子_命名映射.md` 看 GTJA-191 风格差异 → 用 `算子_聚宽实现.md` 查具体代码
2. **复现 Alpha-101 因子**：查 `算子_alpha101_定义.md` 看语义 → 在 `算子_聚宽实现.md` 找对应函数 → 组合调用
3. **复现 GTJA-191 因子**：查 `算子_gtja191_定义.md` 看语义（注意 3 处 OCR 修正） → 在 `算子_聚宽实现.md` 找对应函数 → 组合调用
4. **互译公式**：查 `算子_命名映射.md`，注意 `indneutralize / scale / signedpower` 在 GTJA-191 中无直接对应

## 关键 A 股化要点（必读）

- **截面算子（rank / scale / indneutralize）必须在每日有效池内做**——剔除停牌 / 新股 / ST / 退市
- **`indneutralize` 在 A 股选申万一级（28 个行业）做行业中性化**，聚宽 API 是 `get_industry(security, date)`
- **GTJA-191 的 `SMA(A, n, m)` 不是国际通用 SMA**——是 A 股版指数加权（KDJ / RSI / MACD 国内版核心），等价于 `pandas.ewm(alpha=m/n, adjust=False)`
- **`decay_linear`（线性衰减）vs `WMA`（几何 0.9^i 衰减）容易混淆**——两者不同
- **Alpha143 的 `SELF` 变量需要状态化实现**——是 GTJA-191 体系中唯一有显式时间依赖性的因子

## 关键 OCR/笔误修正（必读）

引用 GTJA-191 算子时务必使用修正后版本：

| 原文 | 修正 |
|---|---|
| `COVIANCE` | `COVARIANCE` |
| `LOWDAY` 定义中"最大值" | "最小值" |
| 数据变量 `MKE` | `MKT`（Fama-French 市场因子） |

详见 [算子_gtja191_定义.md § OCR / 笔误整体说明](算子_gtja191_定义.md)。

---

[← 返回 02_因子库 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
