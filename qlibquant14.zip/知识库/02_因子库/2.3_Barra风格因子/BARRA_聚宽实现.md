---
name: barra-jq-implementation
description: Barra 10 大风格因子的聚宽 Python 完整实现 —— 含半衰指数加权 / 标准化 / 行业中性化 / CNE5 求解器框架
category: 02_因子库/2.3_Barra风格因子
tags: [Barra, 聚宽, 实现, BETA, RSTR, DASTD, STOM_barra, CNE5, WLS]
created: 2026-05-17
updated: 2026-05-17
status: with-jq-impl
---

# Barra 风格因子的聚宽实现

## TL;DR

把 [[barra-9-style-factors]] 的 9 大类风格因子 + [[barra-a-stock-roster]] 的 41 个技术因子落地到聚宽。本文给出：**每个因子的 Python 实现** + **半衰指数加权工具** + **CNE5 模型求解器框架**（求纯因子组合权重 + 因子收益率）。

## 工具函数

### 半衰指数加权

Barra 多个因子使用"**半衰指数加权**"——最近的权重大，半衰期 $H$ 表示"权重衰减一半所需的期数"。

```python
import numpy as np
import pandas as pd


def half_life_weights(n: int, half_life: int) -> np.ndarray:
    """半衰指数加权数组
    
    Args:
        n: 数据长度
        half_life: 半衰期
    
    Returns:
        (n,) 权重数组，时间倒序（最近权重最大），和为 1
    """
    lambda_ = 0.5 ** (1.0 / half_life)
    weights = np.array([lambda_ ** (n - 1 - i) for i in range(n)])
    return weights / weights.sum()


# 验证：n=10, half_life=3
w = half_life_weights(10, 3)
print(w)  # 应该是 [..., 0.063, 0.125, 0.25, 0.5] 风格的递增数组（最末为最近）
```

### 截面标准化

```python
def cs_standardize(factor: pd.Series, market_cap: pd.Series) -> pd.Series:
    """Barra 截面标准化：去市值加权均值 + 截面除以标准差
    
    Args:
        factor: (N,) 因子原始值
        market_cap: (N,) 市值
    
    Returns:
        (N,) 标准化后因子值
    """
    # 1. 去市值加权均值
    weights = market_cap / market_cap.sum()
    weighted_mean = (factor * weights).sum()
    centered = factor - weighted_mean
    
    # 2. 除以截面标准差
    return centered / centered.std()
```

### Winsorize

```python
def winsorize(factor: pd.Series, lower=0.01, upper=0.99) -> pd.Series:
    """截面 winsorize"""
    q_low, q_up = factor.quantile(lower), factor.quantile(upper)
    return factor.clip(q_low, q_up)
```

---

## 10 大风格因子聚宽实现

### 1. Beta

```python
def compute_beta(security_returns: pd.Series, benchmark_returns: pd.Series,
                 T=252, half_life=63) -> float:
    """计算 BETA
    
    r_i = α + β · r_m + ε，半衰指数加权 WLS
    
    Args:
        security_returns: (T,) 个股日收益序列
        benchmark_returns: (T,) 沪深 300 日收益序列
    """
    weights = half_life_weights(T, half_life)
    
    sec = security_returns.tail(T).values
    bench = benchmark_returns.tail(T).values
    
    if len(sec) < T // 2 or len(bench) < T // 2:
        return np.nan
    
    # 加权回归 (WLS)
    sec_mean = (sec * weights).sum()
    bench_mean = (bench * weights).sum()
    
    cov = ((sec - sec_mean) * (bench - bench_mean) * weights).sum()
    var = ((bench - bench_mean) ** 2 * weights).sum()
    
    return cov / var if var > 0 else np.nan
```

### 2. Momentum (RSTR)

```python
def compute_rstr(returns: pd.Series, T=504, L=21, half_life=126) -> float:
    """计算 RSTR（Carhart 动量，剔除最近 L 期）
    
    RSTR = Σ_{t=L}^{T+L} w_t · ln(1 + r_t)
    """
    # 取过去 T+L 期收益（剔除最近 L 期）
    history = returns.iloc[-(T + L):-L]
    if len(history) < T:
        return np.nan
    
    log_returns = np.log(1 + history.values)
    weights = half_life_weights(T, half_life)
    
    return (log_returns * weights).sum()
```

### 3. Size (LNCAP)

```python
def compute_lncap(total_market_cap: float) -> float:
    """log(总市值)"""
    return np.log(total_market_cap) if total_market_cap > 0 else np.nan
```

### 4. Earnings Yield

```python
def compute_etop(earnings_ttm: float, market_cap: float) -> float:
    """ETOP = 历史 TTM EP（PE_TTM 的倒数）"""
    return earnings_ttm / market_cap if market_cap > 0 else np.nan


def compute_cetop(cash_earnings: float, price: float) -> float:
    """CETOP = 现金收益 / 股价"""
    return cash_earnings / price if price > 0 else np.nan


def compute_epibs(est_eps: float, price: float) -> float:
    """EPIBS = 一致预期 EPS / 股价
    
    需要 jqfactor 的 consensus_data
    """
    return est_eps / price if price > 0 else np.nan
```

### 5. Volatility

```python
def compute_dastd(returns: pd.Series, T=252, half_life=42) -> float:
    """DASTD = 加权日收益率标准差"""
    history = returns.tail(T).values
    if len(history) < T // 2:
        return np.nan
    weights = half_life_weights(T, half_life)
    mean = (history * weights).sum()
    return np.sqrt(((history - mean) ** 2 * weights).sum())


def compute_cmra(monthly_returns: pd.Series, T=12) -> float:
    """CMRA = 过去 T 月累计对数收益的"最大-最小"
    
    Args:
        monthly_returns: 月度收益率序列
    """
    history = monthly_returns.tail(T).values
    if len(history) < T // 2:
        return np.nan
    cum_log = np.cumsum(np.log(1 + history))
    return np.log(1 + cum_log.max()) - np.log(1 + cum_log.min())


def compute_hsigma(security_returns: pd.Series, benchmark_returns: pd.Series,
                   T=252, half_life=63) -> float:
    """HSIGMA = BETA 回归残差的标准差"""
    beta = compute_beta(security_returns, benchmark_returns, T, half_life)
    if np.isnan(beta):
        return np.nan
    
    sec = security_returns.tail(T).values
    bench = benchmark_returns.tail(T).values
    
    # 简化：用历史均值算截距
    weights = half_life_weights(T, half_life)
    sec_mean = (sec * weights).sum()
    bench_mean = (bench * weights).sum()
    alpha = sec_mean - beta * bench_mean
    
    residuals = sec - (alpha + beta * bench)
    return np.sqrt(((residuals - residuals.mean()) ** 2 * weights).sum())
```

### 6. Growth

```python
def compute_sgro(revenues_5y: pd.Series) -> float:
    """SGRO = 过去 5 年营收复合增长率
    
    Args:
        revenues_5y: (5,) 过去 5 个年度的营业收入
    """
    if len(revenues_5y) < 5 or revenues_5y.iloc[0] <= 0:
        return np.nan
    return (revenues_5y.iloc[-1] / revenues_5y.iloc[0]) ** (1/5) - 1


def compute_egro(net_profits_5y: pd.Series) -> float:
    """EGRO = 过去 5 年净利润复合增长率"""
    if len(net_profits_5y) < 5 or net_profits_5y.iloc[0] <= 0:
        return np.nan
    return (net_profits_5y.iloc[-1] / net_profits_5y.iloc[0]) ** (1/5) - 1
```

### 7. Value (BTOP)

```python
def compute_btop(common_equity: float, market_cap: float) -> float:
    """BTOP = 账面权益 / 市值 = 1/PB"""
    return common_equity / market_cap if market_cap > 0 else np.nan


# 简便：直接从 PB 反推
def compute_btop_from_pb(pb_ratio: float) -> float:
    return 1.0 / pb_ratio if pb_ratio > 0 else np.nan
```

### 8. Leverage

```python
def compute_mlev(market_equity, long_debt):
    """MLEV = (ME + LD) / ME"""
    return (market_equity + long_debt) / market_equity if market_equity > 0 else np.nan


def compute_dtoa(total_debt, total_assets):
    """DTOA = TD / TA"""
    return total_debt / total_assets if total_assets > 0 else np.nan


def compute_blev(book_equity, long_debt):
    """BLEV = (BE + LD) / BE"""
    return (book_equity + long_debt) / book_equity if book_equity > 0 else np.nan
```

### 9. Liquidity

```python
def compute_stom_barra(volumes_amount: pd.Series, mkt_caps: pd.Series, T=21) -> float:
    """STOM_barra = ln(过去 21 日累计换手金额率)
    
    公式：ln(Σ V_t / S_t)，V=日成交金额，S=日流通市值
    """
    if len(volumes_amount) < T or len(mkt_caps) < T:
        return np.nan
    ratios = volumes_amount.tail(T).values / mkt_caps.tail(T).values
    s = ratios.sum()
    return np.log(s) if s > 0 else np.nan


def compute_stoq_barra(stom_series: pd.Series, T=63) -> float:
    """STOQ_barra = ln((1/T) Σ exp(STOM_t))"""
    history = stom_series.tail(T).values
    if len(history) < T // 2:
        return np.nan
    return np.log(np.mean(np.exp(history)))


def compute_stoa_barra(stom_series: pd.Series, T=252) -> float:
    """STOA_barra = ln((1/T) Σ exp(STOM_t)), T=252"""
    return compute_stoq_barra(stom_series, T=T)
```

---

## 批量计算所有 Barra 因子

```python
"""
对一只股票，计算全部 10 大风格因子的当期值
"""
from jqdatasdk import get_price, get_valuation, get_fundamentals
from jqdata import *
import pandas as pd
import numpy as np


def compute_all_barra_factors(security: str, date: str) -> dict:
    """计算所有 Barra 风格因子（当期值）
    
    Args:
        security: 股票代码（如 '000001.XSHE'）
        date: 日期（如 '2024-06-30'）
    
    Returns: {factor_name: value}
    """
    # 加载历史数据
    history = attribute_history(
        security, 500, '1d',
        fields=['close', 'volume', 'money', 'high', 'low'],
        df=True,
    )
    
    # 加载基准
    bench = attribute_history(
        '000300.XSHG', 500, '1d',
        fields=['close'], df=True,
    )
    
    # 日收益率
    returns = history['close'].pct_change().dropna()
    bench_returns = bench['close'].pct_change().dropna()
    
    # 月度收益率（用于 CMRA）
    monthly_close = history['close'].resample('M').last()
    monthly_returns = monthly_close.pct_change().dropna()
    
    # 流通市值（用于 STOM_barra）
    valuation = get_valuation(security, end_date=date, count=500,
                              fields=['code', 'circulating_market_cap', 'market_cap',
                                      'pb_ratio', 'pe_ratio'])
    mkt_caps = valuation['circulating_market_cap'] * 1e8  # 亿元 → 元
    total_mkt = valuation['market_cap'].iloc[-1] * 1e8
    
    # 财报数据（PIT 处理已默认）
    q = query(income.code, income.operating_revenue,
              income.np_parent_company_owners,
              balance.total_assets, balance.total_liability,
              balance.equities_parent_company_owners,
              cash_flow.net_operate_cash_flow).filter(
        income.code == security
    )
    fund = get_fundamentals(q, statDate=date.split('-')[0])
    
    # === 计算各因子 ===
    factors = {}
    
    factors['BETA'] = compute_beta(returns, bench_returns, T=252, half_life=63)
    factors['RSTR'] = compute_rstr(returns, T=504, L=21, half_life=126)
    factors['LNCAP'] = compute_lncap(total_mkt)
    factors['BTOP'] = compute_btop_from_pb(valuation['pb_ratio'].iloc[-1])
    factors['DASTD'] = compute_dastd(returns, T=252, half_life=42)
    factors['CMRA'] = compute_cmra(monthly_returns, T=12)
    factors['HSIGMA'] = compute_hsigma(returns, bench_returns, T=252, half_life=63)
    
    # ETOP = 1 / PE_TTM
    pe_ttm = valuation['pe_ratio'].iloc[-1]
    factors['ETOP'] = 1.0 / pe_ttm if pe_ttm > 0 else np.nan
    
    # STOM_barra（金额 / 流通市值）
    if 'money' in history.columns:
        factors['STOM_barra'] = compute_stom_barra(
            history['money'], mkt_caps.reindex(history.index, method='ffill'),
            T=21,
        )
    
    return factors


# 用法
factors = compute_all_barra_factors('000001.XSHE', '2024-06-30')
print(factors)
```

---

## 批量截面计算 + 标准化

```python
def compute_barra_panel(securities: list, date: str) -> pd.DataFrame:
    """对股票池在 date 时点计算 Barra 因子，返回标准化后的因子矩阵
    
    Returns:
        DataFrame: (N, K) 行=股票，列=因子
    """
    # 1. 逐股票计算原始值
    raw_data = {}
    for sec in securities:
        try:
            raw_data[sec] = compute_all_barra_factors(sec, date)
        except Exception as e:
            log.warning(f'{sec} 计算失败: {e}')
            continue
    
    df = pd.DataFrame(raw_data).T
    
    # 2. 加载市值（用于标准化）
    valuation = get_fundamentals(
        query(valuation.code, valuation.market_cap).filter(
            valuation.code.in_(df.index.tolist())
        ),
        date=date,
    ).set_index('code')
    market_cap = valuation['market_cap']
    
    # 3. 对每个因子做截面标准化
    standardized = pd.DataFrame(index=df.index)
    for factor_name in df.columns:
        try:
            wins = winsorize(df[factor_name], 0.01, 0.99)
            std = cs_standardize(wins, market_cap.loc[df.index])
            standardized[factor_name] = std
        except Exception as e:
            log.warning(f'{factor_name} 标准化失败: {e}')
    
    return standardized
```

---

## CNE5 模型求解器（完整框架）

集成 [[barra-cne5-model]] § 7 的实现：

```python
def cne5_estimate(
    universe: list,
    date: str,
    industry_level='sw_l1',
):
    """完整 CNE5 模型求解：返回因子收益率向量 + 纯因子组合权重
    
    Returns:
        dict:
            'lambda_C': 国家因子收益率
            'lambda_I': pd.Series 行业因子收益率
            'lambda_S': pd.Series 10 个风格因子收益率
            'omega': K×N 纯因子组合权重矩阵
            'u': N 维特质性收益率
    """
    # 1. 加载 t 期超额收益（用 t+1 的 1 日 / 21 日 / 60 日收益）
    returns_today = get_returns_today(universe, date)  # 假设已实现
    
    # 2. 加载 t-1 时点的因子暴露
    industry = get_industry_panel(universe, [date], level=industry_level).iloc[0]
    style_factors = compute_barra_panel(universe, prev_date(date))  # 用 t-1
    
    # 3. 加载市值
    valuation = get_fundamentals(
        query(valuation.code, valuation.market_cap).filter(
            valuation.code.in_(universe)
        ),
        date=prev_date(date),
    ).set_index('code')
    market_cap = valuation['market_cap']
    
    # 4. 对齐
    common = returns_today.index.intersection(style_factors.index).intersection(market_cap.index)
    returns_today = returns_today.loc[common]
    industry = industry.loc[common]
    style_factors = style_factors.loc[common]
    market_cap = market_cap.loc[common]
    
    # 5. 调用求解器（来自 [[barra-cne5-model]]）
    from cne5_solver import cne5_solve  # 假设已实现
    result = cne5_solve(returns_today, industry, style_factors, market_cap)
    
    return result
```

---

## 性能优化建议

### 缓存

```python
# 在 g.cache 中缓存中间结果
def get_barra_cached(security, date):
    key = f'{security}_{date}'
    if key in g.barra_cache:
        return g.barra_cache[key]
    result = compute_all_barra_factors(security, date)
    g.barra_cache[key] = result
    return result
```

### 用聚宽 jqfactor 平台预算

聚宽提供 `jqfactor` 平台预算的 Barra 因子：

```python
from jqfactor import get_factor_values

# 直接取预算的 Barra 风格因子（仅部分平台版本支持）
factors = get_factor_values(
    securities=['000001.XSHE'],
    factors=['size', 'beta', 'momentum', 'value', 'leverage'],
    start_date='2024-01-01',
    end_date='2024-06-30',
)
```

**优势**：聚宽已做标准化、行业中性化、PIT 处理——直接可用。

---

## 综合观察

- **10 大风格因子的聚宽实现**已给出——但**完整实现需要**：基本面 PIT 数据 / 分析师一致预期数据
- **关键工具**：`half_life_weights`（半衰指数加权）+ `cs_standardize`（截面标准化）+ `winsorize`（极值处理）
- **STOM_barra 是 A 股最重要的 alpha**——单独实现并 IC 检验
- **聚宽 jqfactor 平台预算 Barra 因子**——直接用比自己实现快很多
- **完整 CNE5 求解器**需要：对齐数据 + 构造约束 + WLS 求解 + 输出纯因子组合权重

## 参考与延伸

- [[barra-cne5-model]] — CNE5 模型推导（含 cne5_solve 完整代码）
- [[barra-9-style-factors]] — Barra 10 大风格因子细类定义（文件名保留 "9-style" 兼容旧引用，实际为 10 大）
- [[barra-a-stock-roster]] — Python 实战表 7-1 的 41 个因子名录
- [[operator-jq-implementation]] — 通用算子（与本节实现思路一致）
- [[neutralization-practice]] — 截面标准化的方法论
- [聚宽 jqfactor 文档](https://www.joinquant.com/help/api/help#JQfactor) — 预算因子接口
