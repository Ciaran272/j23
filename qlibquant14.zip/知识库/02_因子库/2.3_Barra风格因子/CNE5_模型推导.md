---
name: barra-cne5-model
description: Barra CNE5 多因子风险模型完整推导 —— 国家因子 + 行业因子 + Q 个风格因子 + WLS 估计 + 纯因子组合 + 协方差矩阵调整
category: 02_因子库/2.3_Barra风格因子
tags: [Barra, CNE5, 风险模型, WLS, 纯因子组合, 协方差矩阵, 因子投资]
created: 2026-05-17
updated: 2026-05-17
source: 原始资料文件/因子投资方法与实践/因子投资方法与实践.md (ch7.2)
status: draft
---

# Barra CNE5 多因子风险模型推导

## TL;DR

**Barra CNE5** 是 MSCI 针对 A 股市场的多因子风险模型——包含 **1 国家因子 + 28 个行业因子 + 10 个风格因子**（共 K = 39 个因子）。其核心目的不是预测预期收益，而是**通过多因子结构估计个股的协方差矩阵 $\Sigma$**，用于风险管理与组合优化。本文整合因子投资 ch7.2 的完整推导：模型设定 + WLS 估计 + 纯因子组合性质 + 协方差矩阵调整。

## 来源

- **因子投资 ch7.2**：[因子投资方法与实践.md ch7.2 第 4791-5045 行](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) —— **完整推导**
- **配套 PDF**：[因子投资方法与实践_origin.pdf](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践_origin.pdf) —— OCR 重灾区，矩阵公式必须回 PDF 校对
- **MSCI 官方文档**：CNE5 模型白皮书（私有，作者可申请试用）

---

## OCR 整体说明（重要）

ch7.2 的矩阵公式 OCR **损坏严重**：

| 损坏位置 | 现象 | 处理 |
|---|---|---|
| 式 (7.19) 大矩阵展开 | 下标乱码（如 $\beta_{1t}^{D_1}$ 应为 $\beta_{1t}^{I_1}$）| **必须回 origin.pdf 第 7 章核对** |
| 式 (7.20)-(7.21) | 部分下标 $s_{I_p}$ 显示错乱 | 同上 |
| 式 (7.25) 权重矩阵 W | 整体可读 | 不需修正 |
| 式 (7.26) 约束矩阵 C | 部分上下标错位 | 回 PDF |
| 式 (7.29)-(7.30) Ω·β 性质 | 子矩阵 $D_{(1+P)\times(1+P)}$ 数值表整体可读 | 不需修正 |
| 式 (7.34)-(7.45) 协方差调整 | 公式编号错乱 | 配合上下文判断 |

**抄写公式前必须回 origin.pdf**。本文呈现的是清洗后的版本。

---

## 1. CNE5 模型设定

### 因子组成

CNE5 模型在 t 时刻把每只股票的超额收益分解为：

$$R_{it}^e = \lambda_{Ct} + \sum_{p=1}^{P} \beta_{i,t-1}^{I_p} \lambda_{I_p t} + \sum_{q=1}^{Q} \beta_{i,t-1}^{S_q} \lambda_{S_q t} + u_{it} \tag{7.19}$$

其中：

- $R_{it}^e$ = t 时刻股票 i 的超额收益（相对无风险利率）
- $\lambda_{Ct}$ = 国家因子的因子收益率
- $\beta_{i,t-1}^{I_p}$ = t-1 时刻股票 i 在行业 $I_p$ 上的因子暴露（**0 或 1**，因为一个公司任意时刻只属于一个行业）
- $\lambda_{I_p t}$ = 行业 $I_p$ 在 t 时刻的因子收益率
- $\beta_{i,t-1}^{S_q}$ = t-1 时刻股票 i 在风格因子 $S_q$ 上的因子暴露
- $\lambda_{S_q t}$ = 风格因子 $S_q$ 在 t 时刻的因子收益率
- $u_{it}$ = t 时刻股票 i 的特质性收益率（idiosyncratic return）

**注**：所有股票在国家因子上的暴露都是 1——国家因子起到截距项的作用。

### A 股具体配置

| 因子类型 | 数量 | 含义 |
|---|---|---|
| **国家因子** | 1 | 全市场基准（近似市场组合） |
| **行业因子** | P = 28（申万一级）/ 31（2021 修订后） | 行业暴露 |
| **风格因子** | Q = 10 | Beta / Momentum / Size / Non-linear Size / Earnings Yield / Residual Volatility / Growth / Value / Leverage / Liquidity |
| **K 合计** | 39 / 42 | 总因子数 |

详细的 10 大风格因子见 [[barra-9-style-factors]]（文件名保留 "9-style" 兼容旧引用，实际为 10 大）。

---

## 2. 风格因子暴露的标准化

### 直接使用公司特征

CNE5 与 Fama-MacBeth 类多因子模型的关键差异：

| 模型类型 | 因子暴露 |
|---|---|
| Fama-MacBeth（FF3 等） | **时序回归系数**（如个股对市场 / SMB / HML 的 beta） |
| **Barra CNE5** | **直接用公司特征值** ——如 BM 比率直接作为价值因子的原始暴露 |

这是 Barra 的特色——**特征即暴露**，避免了 FM 框架下时序回归的不稳定性。

### 标准化两步

对每个风格因子的原始暴露，做两步标准化：

#### Step 1: 去市值加权均值

$$\sum_{i=1}^{N} s_i \beta_{i,t-1}^{S_q} = 0, \quad q = 1, \ldots, Q \tag{7.21}$$

其中 $s_i$ 是股票 i 的市值权重。

**含义**：风格因子在**市值加权的市场组合**上暴露为 0——这是 CNE5 的关键假设（市场组合应当中性）。

**实现**：

$$\beta_{i,t-1}^{S_q,\text{centered}} = \beta_{i,t-1}^{S_q,\text{raw}} - \sum_{j=1}^{N} s_j \beta_{j,t-1}^{S_q,\text{raw}}$$

#### Step 2: 截面除以标准差

$$\beta_{i,t-1}^{S_q,\text{standardized}} = \frac{\beta_{i,t-1}^{S_q,\text{centered}}}{\text{std}_{\text{cs}}(\beta^{S_q,\text{centered}})}$$

经过两步后，所有风格因子暴露**截面均值 = 0、截面标准差 = 1**。

---

## 3. 行业约束（避免多重共线性）

### 问题

国家因子的因子暴露向量（全 1）= P 个行业因子暴露向量的和（每只股票恰好属于一个行业）。这导致回归矩阵**共线**——解不唯一。

### 解决：行业收益率加权和为 0

$$s_{I_1} \lambda_{I_1 t} + s_{I_2} \lambda_{I_2 t} + \cdots + s_{I_P} \lambda_{I_P t} = 0 \tag{7.20}$$

其中 $s_{I_p}$ 是行业 $I_p$ 内所有股票按市值的权重之和。

**含义**：所有行业的因子收益率（按行业市值加权）总和为 0——避免与国家因子混淆。

### 国家因子 = 市场组合

代入式 (7.21) 和式 (7.20) 可证明：

$$R_{Mt}^e = \lambda_{Ct} + 0 + 0 + \sum_{i=1}^{N} s_i u_i \approx \lambda_{Ct} \tag{7.22}$$

即**国家因子收益率 ≈ 市值加权市场组合的超额收益**——这就是国家因子的本质。

---

## 4. WLS 估计（加权最小二乘）

### 权重设定

Barra 假设个股特质性收益率方差与市值平方根成反比——**大市值股票的权重更高**：

$$W = \text{diag}\left(\frac{\sqrt{s_1}}{\sum_j \sqrt{s_j}}, \frac{\sqrt{s_2}}{\sum_j \sqrt{s_j}}, \ldots, \frac{\sqrt{s_N}}{\sum_j \sqrt{s_j}}\right) \tag{7.25}$$

**直观**：小市值股票特质波动大，估计噪声大，WLS 给低权重。

### 约束矩阵 C

把行业收益率加权和为 0 的约束（式 7.20）写成矩阵形式：

$$\boldsymbol{\lambda} = \mathbf{C} \boldsymbol{\lambda}^{(\text{free})}$$

其中 $\mathbf{C}$ 是 $K \times (K-1)$ 矩阵——把 $\lambda_{I_P}$ 用其他 P-1 个行业收益率的线性组合表达。

### 纯因子组合权重矩阵

最终通过带约束的 WLS 解得**纯因子投资组合权重矩阵**：

$$\boxed{\Omega = \mathbf{C} (\mathbf{C}^T \boldsymbol{\beta}^T \mathbf{W} \boldsymbol{\beta} \mathbf{C})^{-1} \mathbf{C}^T \boldsymbol{\beta}^T \mathbf{W}} \tag{7.27}$$

其中：
- $\Omega$ 是 $K \times N$ 矩阵
- **第 k 行**是**因子 k 的纯因子投资组合中所有 N 支股票的权重**

### 因子收益率

$$\lambda_{kt} = \sum_{i=1}^{N} \omega_{ki} R_{it}^e, \quad k = 1, \ldots, K \tag{7.28}$$

即每个因子的纯因子组合在 t 期的收益。

---

## 5. 纯因子投资组合的性质

### $\Omega \beta$ 的分块结构

$$\Omega \boldsymbol{\beta} = \begin{bmatrix} D_{(1+P) \times (1+P)} & \mathbf{0}_{(1+P) \times Q} \\ \mathbf{0}_{Q \times (1+P)} & I_{Q \times Q} \end{bmatrix} \tag{7.29}$$

### 解读

| 块 | 含义 |
|---|---|
| **右上 $\mathbf{0}_{(1+P) \times Q}$** | 国家 + 行业纯因子组合在所有 Q 个风格因子上**暴露 = 0** |
| **左下 $\mathbf{0}_{Q \times (1+P)}$** | Q 个风格纯因子组合在国家 + 行业因子上**暴露 = 0** |
| **右下 $I_{Q \times Q}$** | 每个风格纯因子组合**仅在该因子上有 1 个单位暴露**，对其他风格因子**暴露 = 0** |
| **左上 $D_{(1+P) \times (1+P)}$** | 国家 + 行业纯因子组合在国家 + 行业因子上的暴露（详见下文） |

### 三类纯因子组合的特征

#### 国家因子的纯因子组合

- **是纯多头组合**（不做空）
- 在国家因子上暴露为 1
- 在所有行业上有正的暴露（自然包含所有行业）
- **在所有风格因子上暴露为 0**
- **≈ 市值加权市场组合**

#### 行业因子的纯因子组合

- **是资金中性的**（多空相抵）
- 100% 做多该行业，**100% 做空国家因子组合**
- 在所有其他行业上暴露为 0
- 在所有风格因子上暴露为 0
- **反映该行业相对市场组合的超额收益**

#### 风格因子的纯因子组合

- **是资金中性的**
- 仅在该风格因子上有 1 个单位暴露
- 在国家、行业、其他风格因子上**全部暴露为 0**
- **干净的"风格 alpha"**——剥离了行业与其他风格的影响

### 实务意义

纯因子组合**是 Barra 的核心价值**：

- **因子收益率 = 纯因子组合的实际收益**——可直接计算
- **风险归因**：把投资组合的收益分解到每个因子的贡献——见 [[index-04-03-risk-attribution]] 待建
- **风险预算**：组合在各因子上的暴露可控

---

## 6. 协方差矩阵

### 核心公式

$$\boxed{\Sigma = \boldsymbol{\beta} \Sigma_\lambda \boldsymbol{\beta}^T + \Sigma_\varepsilon} \tag{7.18}$$

其中：

| 矩阵 | 维度 | 含义 |
|---|---|---|
| $\Sigma$ | $N \times N$ | 个股收益率协方差矩阵 |
| $\boldsymbol{\beta}$ | $N \times K$ | 因子暴露矩阵 |
| $\Sigma_\lambda$ | $K \times K$ | **因子收益率协方差矩阵** |
| $\Sigma_\varepsilon$ | $N \times N$（对角） | **特质性收益率协方差矩阵**（假设互相独立） |

**核心思想**：把 N 维个股协方差矩阵分解为 K 维因子协方差 + N 维特质方差——**实现降维**。

### 估计困难

- $\Sigma$ 直接估计需要 $N(N+1)/2$ 个参数（N=3000 时约 450 万）
- $\Sigma_\lambda$ 只需 $K(K+1)/2$（K=38 时仅 741）

但**$\Sigma_\lambda$ 和 $\Sigma_\varepsilon$ 的样本估计本身不准确**——Barra 提出两种调整：

### 调整 1：特征因子调整法（修正 $\Sigma_\lambda$）

**问题**：样本因子协方差矩阵 $\hat{\Sigma}_\lambda$ 的特征因子组合的事前方差估计不准确——**方差越小的特征因子，事后偏差统计量越大**（低估了风险）。

**方法**（Menchero et al. 2011）：

1. 对 $\hat{\Sigma}_\lambda$ 做特征分解 $\hat{\Sigma}_\lambda = UDU^T$
2. 假设特征因子收益率服从 $N(0, D(k))$，**模拟生成 M 次样本**
3. 计算每次模拟的 $\tilde{D}_m$ 与"真实" $D_m$ 的偏差
4. 取平均偏差作为修正系数 $\nu_s(k)$
5. 修正后的因子协方差矩阵：$\hat{\Sigma}_{\lambda 0} = U (\nu^2 D) U^T$

**核心思想**：用 bootstrap 方法估计样本估计本身的偏差，反向修正。

### 调整 2：贝叶斯收缩（修正 $\Sigma_\varepsilon$）

**问题**：特质性波动率在样本外的持续性很差——**样本中波动率小的股票被低估、波动率大的股票被高估**。

**方法**：

1. 把全部股票按市值分成 10 档
2. 计算每档市值加权的平均样本特质性波动率 $\hat{\sigma}^i_g$（作为先验）
3. 用贝叶斯框架把样本估计和先验线性组合：

$$\hat{\sigma}^{i,\text{posterior}}_i = \alpha_i \hat{\sigma}^{i,\text{prior}}_g + (1 - \alpha_i) \hat{\sigma}^{i,\text{sample}}_i$$

其中 $\alpha_i$ 是收缩系数（**样本估计越不可靠，收缩越多**）。

---

## 7. 工程实现注记

### 复杂度

```
Step 1: 加载 t 期数据
  - 个股收益率：O(N)
  - 行业分类：O(N)
  - 风格特征：O(NQ)
Step 2: 求解 Ω
  - 构造 β: O(NK)
  - 构造 W: O(N)
  - 矩阵求逆 (C' β' W β C)^{-1}: O((K-1)^3) ≈ O(K^3)
  - 总: O(NK^2 + K^3)
Step 3: 计算因子收益率
  - O(NK)

A 股 N≈4000, K≈38, 单期总复杂度 O(NK^2) ≈ 5.8M 次浮点运算
```

### Python 实现框架

```python
import numpy as np
import pandas as pd
from numpy.linalg import inv


def cne5_solve(
    returns: pd.Series,      # (N,) t 期个股超额收益
    industry: pd.Series,     # (N,) t-1 时点的行业分类
    style_factors: pd.DataFrame,  # (N, Q) t-1 时点的风格因子标准化暴露
    market_cap: pd.Series,    # (N,) t-1 时点的市值
):
    """求解 CNE5 模型，返回因子收益率向量 lambda
    
    Returns:
        lambda_C: 国家因子收益率
        lambda_I: P 维行业因子收益率向量
        lambda_S: Q 维风格因子收益率向量
        u: N 维特质性收益率向量
        omega: K×N 纯因子组合权重矩阵
    """
    N = len(returns)
    
    # 1. 构造因子暴露矩阵 β
    industries = sorted(industry.unique())
    P = len(industries)
    Q = style_factors.shape[1]
    K = 1 + P + Q
    
    beta = np.zeros((N, K))
    beta[:, 0] = 1  # 国家因子
    for j, ind in enumerate(industries):
        beta[:, 1 + j] = (industry == ind).values.astype(float)
    beta[:, 1 + P:] = style_factors.values
    
    # 2. 构造 W 矩阵（按 √市值 加权）
    sqrt_cap = np.sqrt(market_cap.values)
    w_diag = sqrt_cap / sqrt_cap.sum()
    W = np.diag(w_diag)
    
    # 3. 构造约束矩阵 C
    # 约束：sum_p s_{I_p} * λ_{I_p} = 0
    # 把 λ_{I_P} 用前 P-1 个表达
    s_industries = np.array([market_cap[industry == ind].sum() for ind in industries])
    s_total = s_industries.sum()
    
    C = np.eye(K)
    # 删除 λ_{I_P} 列（用其他 P-1 个表达）
    # C 是 K×(K-1)
    C_compact = np.zeros((K, K - 1))
    # 国家因子
    C_compact[0, 0] = 1
    # 行业因子 1..P-1
    for j in range(P - 1):
        C_compact[1 + j, 1 + j] = 1
    # 行业因子 P（用其他行业线性组合）
    for j in range(P - 1):
        C_compact[1 + P - 1, 1 + j] = -s_industries[j] / s_industries[-1]
    # 风格因子
    for q in range(Q):
        C_compact[1 + P + q, 1 + (P - 1) + q] = 1
    C = C_compact
    
    # 4. 求解 Ω = C (C' β' W β C)^{-1} C' β' W
    inner = C.T @ beta.T @ W @ beta @ C
    omega = C @ inv(inner) @ C.T @ beta.T @ W
    
    # 5. 因子收益率 λ = Ω · R^e
    lambda_full = omega @ returns.values
    lambda_C = lambda_full[0]
    lambda_I = lambda_full[1:1 + P]
    lambda_S = lambda_full[1 + P:]
    
    # 6. 特质性收益率
    u = returns.values - beta @ lambda_full
    
    return {
        'lambda_C': lambda_C,
        'lambda_I': pd.Series(lambda_I, index=industries),
        'lambda_S': pd.Series(lambda_S, index=style_factors.columns),
        'u': pd.Series(u, index=returns.index),
        'omega': omega,
    }
```

详细实现见 [[barra-jq-implementation]]。

---

## 综合观察

- **CNE5 = 1 + 28(P) + 9(Q) = 38 个因子**（A 股）
- **核心差异**：CNE5 用**公司特征作为因子暴露**（直接、稳定），不像 FM 用时序回归 beta
- **国家因子 ≈ 市场组合**——通过式 (7.22) 可证明
- **纯因子组合的三个性质**：
  - 国家因子组合是市场组合（纯多头）
  - 行业因子组合 = 多该行业 + 空市场（资金中性）
  - 风格因子组合 = 干净 alpha（资金中性 + 其他暴露为 0）
- **协方差矩阵 $\Sigma = \beta \Sigma_\lambda \beta^T + \Sigma_\varepsilon$ 是 CNE5 的核心产出**
- **两大调整**：特征因子法（修 $\Sigma_\lambda$）+ 贝叶斯收缩（修 $\Sigma_\varepsilon$）
- **OCR 警示**：所有矩阵公式必须回 origin.pdf 第 7 章核对

## 参考与延伸

- [[barra-9-style-factors]] — Barra 10 大风格因子的细类定义（文件名保留 "9-style" 兼容旧引用，实际为 10 大）
- [[barra-a-stock-roster]] — Python 实战表 7-1 的 40+ Barra 因子名录
- [[barra-jq-implementation]] — Barra 因子的聚宽 Python 实现
- [因子投资 ch7.2](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — 完整原文（OCR 重灾区）
- [因子投资_origin.pdf 第 7 章](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践_origin.pdf) — 矩阵公式真值源
- [[index-04-03-risk-attribution]] 4.3 风险归因（待建） — Barra 的应用
- [[risk-based-optimization]] 4.1 — 用 Barra 协方差做组合优化
