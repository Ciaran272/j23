---
name: index-02-03-barra-factors
description: 二级分类 2.3_Barra风格因子 的索引 —— CNE5 模型推导 / 10 大风格因子 / A 股 41 因子名录 / 聚宽实现
category: 02_因子库/2.3_Barra风格因子
tags: [Barra, CNE5, 风格因子, 索引]
created: 2026-05-17
updated: 2026-05-17
status: stable
---

# 2.3 Barra 风格因子 · 索引

## 一句话定位

整合因子投资 ch7.2（CNE5 完整推导）+ GTJA-191 附录 1（10 大风格因子细类）+ Python 实战表 7-1（A 股 41 个 Barra 因子名录），给出 Barra 风险模型的**理论 + 因子 + 实现**完整闭环——**为 4.3 风险归因和 4.1 风险型组合优化提供基础**。

## 文件清单

| 文件 | 描述 | 状态 |
|---|---|---|
| [CNE5_模型推导.md](CNE5_模型推导.md) | Barra CNE5 模型完整推导：国家 + 28 行业 + 10 风格 + WLS + 纯因子组合 + 协方差矩阵调整（特征因子调整 + 贝叶斯收缩）| draft |
| [九大风格因子_定义.md](九大风格因子_定义.md) | 10 大类风格因子的细类定义（文件名保留 "9-style" 兼容旧引用）：Beta / RSTR / LNCAP / NLSIZE / EPIBS-ETOP-CETOP / DASTD-CMRA-HSIGMA / SGRO-EGRO-EGIB / BTOP / MLEV-DTOA-BLEV / STOM-STOQ-STOA | draft |
| [BARRA_A股因子名录.md](BARRA_A股因子名录.md) | Python 实战表 7-1 的 **41 个 A 股 Barra 因子完整名录**（流动性 15 + 动量 11 + 波动率 15）+ OCR 校对 + 实证显著性 | draft |
| [BARRA_聚宽实现.md](BARRA_聚宽实现.md) | 10 大风格因子的聚宽 Python 实现 + 半衰指数加权工具 + 截面标准化 + 批量计算 + CNE5 求解器框架 | with-jq-impl |

## 阅读路径建议

### 新用户：从理论到实现

1. [CNE5_模型推导.md](CNE5_模型推导.md) —— 理解为什么用多因子模型 + 求解逻辑
2. [九大风格因子_定义.md](九大风格因子_定义.md) —— 理解 10 大类风格的具体含义（文件名保留兼容性）
3. [BARRA_A股因子名录.md](BARRA_A股因子名录.md) —— 理解 A 股具体有哪些可用因子
4. [BARRA_聚宽实现.md](BARRA_聚宽实现.md) —— 复制可跑代码

### 老用户：查具体问题

- **"CNE5 模型公式怎么写"** → [CNE5_模型推导.md § 1. CNE5 模型设定](CNE5_模型推导.md)
- **"纯因子组合是什么"** → [CNE5_模型推导.md § 5. 纯因子投资组合的性质](CNE5_模型推导.md)
- **"DASTD 怎么算"** → [九大风格因子_定义.md § 5. Volatility](九大风格因子_定义.md)
- **"A 股最有效的 Barra 因子有哪些"** → [BARRA_A股因子名录.md § A 股因子实证显著性](BARRA_A股因子名录.md)
- **"半衰指数加权怎么实现"** → [BARRA_聚宽实现.md § 工具函数](BARRA_聚宽实现.md)
- **"Beta 怎么计算"** → [BARRA_聚宽实现.md § 1. Beta](BARRA_聚宽实现.md)
- **"批量计算 Barra 因子怎么做"** → [BARRA_聚宽实现.md § 批量计算](BARRA_聚宽实现.md)

## 关键 A 股化要点（必读）

### 10 大风格因子

| 大类 | A 股有效性 | 备注 |
|---|---|---|
| **Beta** | 弱 | A 股低 β 异象（高 β 反带低收益） |
| **Momentum (RSTR)** | **失效** | A 股短期反转占优 |
| **Size (LNCAP)** | 强（2017 前）/ **失效（2017 后）** | 监管打击壳价值 |
| **Non-linear Size (NLSIZE)** | 弱-中 | 中市值溢价；2017 后大盘股普遍较强 |
| **Earnings Yield (ETOP)** | **强** | CH-3 三因子用此替代 BM |
| **Residual Volatility (DASTD)** | **强** | 低波异象 |
| **Growth** | 中 | 数据获取难（需分析师一致预期）|
| **Value (BTOP)** | 中等 | A 股 BM 因子显著但 EP 更强 |
| **Leverage** | 弱 | A 股不显著 |
| **Liquidity (STOM)** | **极强** | **A 股最重要 alpha 之一** |

**A 股 Barra 实证最重要发现**（因子投资 ch6.8）：**交易摩擦类因子（DASTD / STOM）是 A 股最有效的**——与美股以基本面 alpha 为主形成鲜明对比。

### A 股 41 个 Barra 因子（表 7-1）

- **流动性 15 个**：STOM/STOQ/STOS/STOA + 3 个 Barra 版 + Ins/Ins_c + Size/non-linear-size/Market_cap + MSM/MSQ/MSS
- **动量 11 个**：RSTR_barra + 5 个不同周期 RSTR + 4 个 RS + Alpha
- **波动率 15 个**：DASTD/CMRA/HSIGMA/Beta + 3 个 Yieldvol + 4 个 High_low + 4 个 VOL

**实务**：从 41 个中**选 10-20 个低相关因子**即可。

## 关键 OCR 校对（必读）

### 因子投资 ch7.2（CNE5 推导）

**所有矩阵公式 OCR 损坏严重**，特别是：
- 式 (7.19) 大矩阵展开
- 式 (7.26) 约束矩阵 C
- 式 (7.29)-(7.30) 纯因子组合性质

**抄写时务必回 origin.pdf 第 7 章核对**。

### Python 实战表 7-1

- `lns` → `Ins`（机构持股，institution 缩写）
- `Yieldvol_3` 出现两次 → 第二个应为 `Yieldvol_6`
- `STOA_barra` T=244 → 应为 **252**（一年交易日数）
- `RSTR_m12` 半衰期 → 应为 60 日（原文与 RSTR_m24 重复，疑似笔误）

## 与其他二级的关系

| 二级 | 关系 |
|---|---|
| [[index-02-01-operator-dictionary]] 2.1 算子词典 | 部分算子（如半衰加权）在 Barra 实现中复用 |
| [[index-02-02-price-volume-factors]] 2.2 价量因子库 | Alpha-101 / GTJA-191 因子与 Barra 风格因子的关系（多个 Barra 因子可用 GTJA-191 算子表达） |
| [[index-04-01-portfolio-optimization]] 4.1 组合优化方法 | Barra 协方差矩阵 $\Sigma$ 是 4.1 优化的关键输入 |
| [[index-04-03-risk-attribution]] 4.3 风险归因（待建） | **本节是 4.3 的直接基础**——风险归因依赖纯因子组合 |
| [[index-03-01-multi-factor-selection]] 3.1 多因子选股 | 风格中性化使用 Barra 10 大风格因子 |
| [[neutralization-practice]] | 风格中性化的实务（与本节配套） |

---

[← 返回 02_因子库 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
