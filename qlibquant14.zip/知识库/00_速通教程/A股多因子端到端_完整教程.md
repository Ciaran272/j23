---
name: end-to-end-tutorial-a-share
description: A 股多因子端到端完整教程 —— 11 章串联整库 27 板块（含 00 综合层）+ 端到端可跑策略（-TVR_1 / STOM / EP 三因子等权选股）
category: 00_速通教程
tags: [端到端教程, 多因子, A股, 知识地图, alpha, 实战, 聚宽]
created: 2026-05-17
updated: 2026-05-17
status: stable
---

# A 股多因子端到端：从世界观到上线

> **整库 27 板块（含 00 综合层）的串联导览** + **可复制运行的多因子策略示例**。
>
> 围绕 A 股最强 3 因子（-TVR_1 / STOM / EP）等权选股的端到端实现，串起 01 方法论 → 05 工程化的完整链路。

---

## 0. 阅读指南

### 0.1 这篇教程是什么 / 不是什么

| 是 | 不是 |
|---|---|
| ✅ 整库 27 板块（含 00 综合层）的**串联导览** | ❌ 从零讲量化（量化基础 → 看 [Whale-Quant ch01](../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/)）|
| ✅ 端到端**可跑**的多因子策略 | ❌ 高级 ML 量化（→ 1.5 + 3.4）|
| ✅ 每章都引导到对应深度板块 | ❌ 替代深度板块的"详细推导"（→ 各章 `[[name]]` 链接的板块）|
| ✅ A 股化注记贯穿全程 | ❌ 美股 / 港股策略（A 股专用）|
| ✅ 聚宽优先实现（jqdatasdk + 在线 IDE）| ❌ 多平台并行（其他平台 → 5.2 横向对比）|

### 0.2 推荐阅读路径

**第一遍**：通读 11 章，建立全局认识（**约 3-5 小时**）。  
**第二遍**：复制策略代码到聚宽在线 IDE 跑通（**约 1-2 天**）。  
**第三遍**：每章末尾的 `[[name]]` 链接进入对应板块深度阅读（**约 2-4 周**）。

### 0.3 前置准备

- **Python 基础**：能看懂 pandas / numpy
- **聚宽账号**：注册聚宽 https://www.joinquant.com（**试用账号 1 年免费 + 100 万条/天**）
- **可选**：本地 Python 环境 + jqdatasdk（`pip install jqdatasdk`）

### 0.4 整库 27 板块速查（核心 5 一级 + 00 综合层 + 99 入口）

| 一级 | 二级 | 板块入口 |
|---|---|---|
| 01 方法论与世界观 | 1.1-1.5 | [[index-01-methodology]] |
| 02 因子库 | 2.1-2.7 | [[index-02-factor-library]] |
| 03 策略原型 | 3.1-3.5 | [[index-03-strategy-prototypes]] |
| 04 组合与风控 | 4.1-4.4 | [[index-04-portfolio-risk]] |
| 05 工程与回测 | 5.1-5.5 | [[index-05-engineering-backtest]] |
| 99 skill 入口 | 触发 / 路由 / 引用规范 | [[index-99-skill-entry]] |

---

## 1. 量化的"心智地基"（01 方法论与世界观）

> 在写一行代码之前，先理解**量化在哲学上是什么**。心智不对，越写越偏。
>
> **串联板块**：[[index-01-methodology]] 1.1-1.5 全 5 板块

### 1.1 因子投资的统一公式

**核心公式**（[[unified-view-formula]]）：

$$E[R_i] = \alpha_i + \beta_i' \lambda$$

- $\alpha_i$：**纯 alpha**（无法被任何已知因子解释的超额收益）—— 我们要赚的
- $\beta_i'$：个股对**因子**的暴露
- $\lambda$：**因子收益**（市场的"风险溢价"）

**含义**：所有量化策略都在做两件事——**找新 alpha**（未被识别的）+ **承担因子暴露**（承担风险换收益）。

**A 股化注记**：A 股**风险溢价**和美股不同——A 股的"价值"主要来自交易摩擦（流动性 / 反转 / 波动）而非基本面（[[empirical-single-factor-table]]）。

### 1.2 检验方法：什么样的因子算"真"

**核心问题**：发现一个"看起来 t > 2 的因子"——它真的是 alpha 吗？

**5 大检验工具**（[[index-01-02-test-methods]]）：

1. **截面 t 检验**（最简单）
2. **Fama-MacBeth 两步回归**（控制其他因子）
3. **GRS 检验**（联合 α=0）
4. **Newey-West 调整**（处理序列相关）—— A 股月频用 lag=6
5. **PSR / 数据窥探修正**（防 p-hacking）

**关键阈值**（[[anomaly-test-and-model-comparison]]）：

| 检验类型 | 阈值 | 说明 |
|---|---|---|
| 单因子 t | **> 3.0** | 修正因子动物园后（旧标准 t>2 已不够）|
| 月频 NW lag | **6** | 半年自相关 |
| Fama-MacBeth t | > 2.5 | 多因子环境 |
| GRS p-value | < 0.05 | 联合显著 |

### 1.3 独立交易员视角

**Chan 7 条避坑**（[[quant-as-small-business]]）：

1. **找你能解释的策略**（黑箱 ≠ alpha）
2. **样本外回测必须严格**（**1 次**用 test set）
3. **关注最大回撤而非夏普**（A 股 > 30% 回撤应停）
4. **凯利仓位 / 仓位 = m / s²**（[[kelly-single-strategy]]）
5. **拥挤陷阱**（2007 量化危机示例）
6. **数据迁就比前视更隐蔽**（[[backtest-pitfalls-statistical]]）
7. **存活偏差是杀手**（[[backtest-data-pitfalls]]）

### 1.4 行为金融：A 股 alpha 来自哪里

**因子动物园问题**（[[factor-zoo-p-hacking-data-snooping]]）：300+ 美股因子被发表，但**绝大多数样本外失效**。

**A 股 alpha 来源**（[[behavioral-finance-and-investor-sentiment]]）：
- 行为偏差（散户 70%+ 占比）→ **PEAD / 短期反转 / 春节效应**
- 流动性 / 摩擦 → **STOM / -TVR_1 / -IVOL**
- **错误定价**（A 股市场效率较低）→ **EP / -AG / GP**

### 1.5 ML 与因子的协同

**ML 在量化中的角色**（[[index-01-05-ml-and-factors]]）：**预测 + 特征选择**——不是替代经典多因子。

**Gu-Kelly-Xiu 2020 美股实证**：神经网络 > 树模型 > 弹性网 > OLS

**A 股 ML 性价比清单**（[[a-share-ml-practice-and-pitfalls]]）：

| 复杂度 | 方法 | A 股推荐 |
|---|---|---|
| 极低 | **IC 加权 5 因子** | **首选**（80% alpha 来自这里）|
| 中 | LightGBM / XGBoost | 业界主流 |
| 高 | LSTM / Transformer / RL | **不推荐**（A 股信噪比低）|

**本教程的多因子策略 = 起点（IC 加权 3 因子）**——简单但有效。

---

## 2. 示例策略蓝图

### 2.1 为什么选 -TVR_1 / STOM / EP 三因子等权

**来源**：[[empirical-single-factor-table]] § A 股最强 5 alpha

| 因子 | 类别 | A 股 t 值 | 含义 |
|---|---|---|---|
| **-TVR_1** | 流动性反转 | 4.2 | 短期换手率倒数（缩量者后续反弹）|
| **STOM_barra** | 流动性 | ~4.0+ | 1 个月对数累计换手率（[[barra-9-style-factors]] § Liquidity）|
| **EP** | 价值 | 3.0 | 盈利收益率 = 1/PE |

**为什么是 3 个 / 不是 5 个**：
- 3 个已覆盖 A 股**两大主导效应**（交易摩擦 + 价值）
- 等权 + 简单合成 = 80% alpha 用 20% 复杂度获取
- 3 个因子的**截面相关性低**（[[empirical-multi-factor-portfolio]]）

**为什么等权 / 不是 IC 加权**：
- 教程目的是"端到端跑通"，简单 > 复杂
- 进阶版可用 IC 加权（→ 第 6 章末 / [[ic-test-and-combination]]）

### 2.2 策略蓝图

| 维度 | 选择 | 来源板块 |
|---|---|---|
| **股票池** | 沪深 300（动态成分股）| [[backtest-data-pitfalls]] § 指数成分变动 |
| **回测周期** | 2020-2024（5 年）| - |
| **频率** | 月度调仓（每月第一个交易日）| [[jq-skeleton-main-flow]] |
| **持仓数** | 30 只 | [[index-03-01-multi-factor-selection]] |
| **配置** | 等权 | [[portfolio-optimization-overview]] |
| **手续费** | 印花税 0.05%（卖出端）+ 佣金 0.03% + 滑点 0.2% | [[cost-four-components]] |
| **基准** | 沪深 300（`000300.XSHG`） | - |
| **撮合** | 次日开盘价 | [[backtest-frameworks-comparison]] § 撮合假设陷阱 |
| **A 股化** | 过滤涨跌停 / 停牌 / ST / 新股次新股（180 日内） | [[backtest-trading-rules]] + [[backtest-data-pitfalls]] |

---

## 3. 数据接入（5.1 + 5.4）

> **数据是地基，地基不牢一切都是噪声**。
>
> **串联板块**：[[index-05-01-data-access]] + [[index-05-04-backtest-pitfalls]]

### 3.1 聚宽 jqdatasdk 速通

**认证 + 第一次调用**（[[jqdatasdk-practice]] § 1）：

```python
from jqdatasdk import auth, get_price, get_index_stocks, get_fundamentals, query, valuation, indicator
from jqdatasdk import get_query_count, get_extras, get_security_info
import pandas as pd
import numpy as np

# 认证（聚宽试用账号 1 年 / 每天 100 万条数据）
auth('your_phone', 'your_password')
print(f'剩余配额: {get_query_count()["spare"]:,} / {get_query_count()["total"]:,} 条')
```

**5 类核心数据**（[[data-api-comparison]] § 3）：量价 / 基本面 / 宏观 / 市场情报 / 替代数据。本教程只用前两类。

### 3.2 A 股数据 9 大陷阱（必读）

| 陷阱 | 处理 | 详见 |
|---|---|---|
| **PIT 财务** | 聚宽 `get_fundamentals(date=)` 默认 PIT | [[financial-data-pit]] |
| **复权方式** | 全部用 `fq='pre'`（前复权）| [[backtest-data-pitfalls]] § 2 |
| **存活偏差** | `get_all_securities(date=历史日期)` | [[backtest-data-pitfalls]] § 5 |
| **指数成分历史** | `get_index_stocks(index, date=历史日期)` | [[backtest-data-pitfalls]] § 7 |
| **ST 历史状态** | `get_extras('is_st', ..., end_date=历史日期)` | [[backtest-data-pitfalls]] § 3 |
| **新股次新股** | `get_security_info` 取上市日，过滤 < 180 日 | [[backtest-data-pitfalls]] § 4 |
| **涨跌停** | `get_current_data().high_limit / low_limit` | [[backtest-trading-rules]] § 1 |
| **停牌** | `get_current_data().paused` | [[backtest-trading-rules]] § 2 |
| **T+1** | 聚宽自动处理 `closeable_amount` | [[backtest-trading-rules]] § 3 |

### 3.3 代码 1：数据拉取（端到端示例 Part 1）

```python
"""端到端示例 - Part 1: 数据拉取
拉取沪深 300 在 2024-06-30 时点的成分股 + 6 个月行情数据。
"""

# 1. 取 2024-06-30 时点的沪深 300 成分（避免存活偏差）
TRADE_DATE = '2024-06-30'
universe = get_index_stocks('000300.XSHG', date=TRADE_DATE)
print(f'沪深 300 成分股: {len(universe)} 只')

# 2. 过滤新股次新股（上市 < 180 天）
def filter_new_stocks(stocks, end_date, min_days=180):
    result = []
    for s in stocks:
        info = get_security_info(s)
        if info is None:
            continue
        days = (pd.Timestamp(end_date) - pd.Timestamp(info.start_date)).days
        if days >= min_days:
            result.append(s)
    return result

universe = filter_new_stocks(universe, TRADE_DATE, min_days=180)
print(f'过滤新股后: {len(universe)} 只')

# 3. 过滤当日 ST（用历史 ST 状态）
st_df = get_extras('is_st', universe, end_date=TRADE_DATE, count=1)
is_st_today = st_df.iloc[-1] if not st_df.empty else pd.Series([False] * len(universe), index=universe)
universe = [s for s in universe if not is_st_today.get(s, False)]
print(f'过滤 ST 后: {len(universe)} 只')

# 4. 一次性拉取近 6 个月行情（批量 200 只 / 次）
def batch_get_price(securities, start, end, fields, fq='pre', batch=200):
    dfs = []
    for i in range(0, len(securities), batch):
        chunk = securities[i:i+batch]
        df = get_price(chunk, start_date=start, end_date=end,
                       fields=fields, fq=fq, panel=False)
        dfs.append(df)
    return pd.concat(dfs)

START = '2024-01-01'
END = TRADE_DATE
price_df = batch_get_price(
    universe, start=START, end=END,
    fields=['open', 'close', 'volume', 'money', 'high_limit', 'low_limit'],
    fq='pre',
)
print(f'行情数据 shape: {price_df.shape}')
# 例：~70000 行 = 280 只股票 × 250 个交易日

# 5. 拉取基本面（用于 EP 因子）
fund_df = get_fundamentals(
    query(valuation.code, valuation.pe_ratio, valuation.circulating_market_cap)
    .filter(valuation.code.in_(universe)),
    date=TRADE_DATE,
)
print(f'基本面数据: {len(fund_df)} 只')

print(f'\n剩余配额: {get_query_count()["spare"]:,} 条')
```

**关键设计**（[[jqdatasdk-practice]] § 2.3）：

- **批量调用**：200 只股票 1 次而非 280 次
- **PIT 严守**：所有 `date=` 对齐 `TRADE_DATE`
- **过滤顺序**：成分股 → 新股 → ST → 数据拉取（每步缩小池子，节省配额）

---

## 4. 因子构造（2.1 + 2.2 + 2.3 + 2.4 + 2.5）

> 从原始数据计算我们的 3 个因子。
>
> **串联板块**：[[index-02-01-operator-dictionary]] + [[index-02-02-price-volume-factors]] + [[index-02-04-fundamental-factors]] + [[index-02-05-technical-indicators]]

### 4.1 算子词典基础

**Alpha-101 / GTJA-191 共 30+ 算子**（[[operator-alpha101-definition]] + [[operator-gtja191-definition]]）：

| 算子 | 含义 | pandas / 聚宽实现 |
|---|---|---|
| `rank(x)` | 截面 pct 排名 | `df.rank(axis=1, pct=True)` |
| `delta(x, d)` | $x_t - x_{t-d}$ | `df.diff(d)` |
| `ts_mean(x, d)` | 时序 d 期均值 | `df.rolling(d).mean()` |
| `correlation(x, y, d)` | 时序 d 期相关 | `x.rolling(d).corr(y)` |
| `signedpower(x, a)` | $\text{sign}(x) \cdot |x|^a$ | `np.sign(df) * np.abs(df) ** a` |
| `decay_linear(x, d)` | 线性衰减加权均值 | 详见 [[operator-jq-implementation]] |

### 4.2 因子 1：-TVR_1（流动性反转）

**含义**：当日成交额倒数 → **缩量者后续反弹**（A 股短期反转的核心）

**公式**：

$$\text{-TVR\_1}_t = -\frac{1}{\text{turnover}_t}$$

其中 turnover = 成交额 / 流通市值

**实现**（聚宽）：

```python
def compute_tvr_neg(price_df, fund_df, date):
    """-TVR_1 因子：当日换手率的负倒数"""
    # 取当日 close 和 money
    day_data = price_df.xs(pd.Timestamp(date), level='time')  # 取该日切片
    money = day_data['money']
    
    # 流通市值（亿元转元）
    circ_cap = fund_df.set_index('code')['circulating_market_cap'] * 1e8
    
    # 换手率 = 成交额 / 流通市值
    turnover = money / circ_cap
    
    # -1 / 换手率
    tvr_neg = -1 / (turnover + 1e-6)
    return tvr_neg
```

### 4.3 因子 2：STOM（1 个月对数累计换手率）

**含义**：来自 Barra CNE5 Liquidity 因子（[[barra-9-style-factors]] § 10. Liquidity）

**公式**：

$$\text{STOM} = \ln\left(\sum_{t=1}^{21} \frac{V_t}{S_t}\right)$$

其中 $V_t$ = 当日成交量，$S_t$ = 流通股本

**实现**：

```python
def compute_stom(price_df, fund_df, date, window=21):
    """STOM = ln(过去 21 个交易日累计换手率)"""
    end = pd.Timestamp(date)
    
    # 取过去 21 个交易日的成交额
    money_panel = price_df['money'].unstack('code')
    recent_money = money_panel.loc[:end].tail(window)
    
    # 流通市值
    circ_cap = fund_df.set_index('code')['circulating_market_cap'] * 1e8
    
    # 每日换手率 + 累加 + log
    daily_turn = recent_money.div(circ_cap, axis=1)
    stom = np.log(daily_turn.sum(axis=0) + 1e-10)
    return stom
```

### 4.4 因子 3：EP（盈利收益率）

**含义**：经典价值因子 = 1 / PE_TTM（[[value-and-profitability-factors]]）

**公式**：

$$\text{EP} = \frac{1}{\text{PE\_TTM}}$$

**实现**：

```python
def compute_ep(fund_df):
    """EP = 1 / PE_TTM"""
    pe = fund_df.set_index('code')['pe_ratio']
    # 过滤负 PE（亏损公司）
    pe = pe.where(pe > 0)
    ep = 1 / pe
    return ep
```

### 4.5 代码 2：三因子计算（端到端示例 Part 2）

```python
"""端到端示例 - Part 2: 三因子计算"""

# 1. 计算 -TVR_1
tvr_neg = compute_tvr_neg(price_df, fund_df, TRADE_DATE)
print(f'-TVR_1 因子分布:\n{tvr_neg.describe()}')

# 2. 计算 STOM
stom = compute_stom(price_df, fund_df, TRADE_DATE)
print(f'STOM 因子分布:\n{stom.describe()}')

# 3. 计算 EP
ep = compute_ep(fund_df)
print(f'EP 因子分布:\n{ep.describe()}')

# 4. 合并到一张表
factor_df = pd.DataFrame({
    'tvr_neg': tvr_neg,
    'stom': stom,
    'ep': ep,
}).dropna()  # 去掉任一因子缺失的股票
print(f'有效因子覆盖: {len(factor_df)} 只 / 共 {len(universe)} 只')
```

**A 股化注记**：
- 这 3 个因子全部来自 [[empirical-single-factor-table]] 实证基准
- **TVR / STOM 是 A 股本土特色**——美股没有同等强度的流动性 alpha
- EP 在 A 股是 CH-3 三因子模型（Liu et al. 2019）的核心因子（CH-3 用 EP 替代 BM）

---

## 5. 因子检验（1.2 + 2.6）

> **任何因子用于实盘前都必须经过检验**——光看历史回测的"漂亮收益"会被骗。
>
> **串联板块**：[[index-01-02-test-methods]] + [[index-02-06-empirical-benchmark]]

### 5.1 IC（信息系数）

**定义**（[[ic-test-and-combination]]）：

$$IC_t = \text{Spearman}(\text{factor}_t, \text{return}_{t+1 \to t+T})$$

- $T$：预测期（如 20 交易日）
- 截面 Spearman 秩相关 = **rank IC**（推荐）vs **Pearson IC**（不稳健）

**A 股阈值**（[[empirical-single-factor-table]]）：

| IC 均值 | 评级 |
|---|---|
| > 0.05 | **优秀**（A 股顶级） |
| 0.03-0.05 | **良好**（A 股可用） |
| 0.01-0.03 | 一般 |
| < 0.01 | 弱 |

### 5.2 ICIR（IC 的信息比率）

$$ICIR = \frac{\overline{IC}}{\sigma(IC)} \cdot \sqrt{N}$$

| ICIR | 评级 |
|---|---|
| > 0.5 | **A 股优秀**（凤毛麟角）|
| 0.3-0.5 | 良好 |
| < 0.1 | 弱 |

### 5.3 代码 3：单因子检验（端到端示例 Part 3）

> 注：本步骤需要"未来收益"，仅用于因子的事后验证。**生产中不能这么做**——生产中只用"截面排序选股"。

```python
"""端到端示例 - Part 3: 单因子事后检验
拉取 2020-2024 全段，逐月计算每个因子的 IC + 累积分层收益。
"""
from scipy import stats

def calc_factor_ic_history(factor_history, return_history, period=20):
    """逐期计算 IC"""
    ic_list = []
    for date in factor_history.index:
        try:
            f = factor_history.loc[date].dropna()
            r = return_history.loc[date].dropna()
            common = f.index.intersection(r.index)
            if len(common) >= 30:
                ic, _ = stats.spearmanr(f.loc[common], r.loc[common])
                ic_list.append({'date': date, 'ic': ic})
        except Exception:
            pass
    return pd.DataFrame(ic_list).set_index('date')

# (此处省略时序循环计算因子 + 未来收益的代码框架)
# 关键点：
#   1. 每月初计算 -TVR_1 / STOM / EP
#   2. 计算未来 20 日的收益（next 20 days return）
#   3. 截面 Spearman IC
#   4. 全期统计 IC 均值 / 标准差 / ICIR / 正 IC 比例 / t 值

# 假设我们已经算出 ic_history，那么：
def evaluate_ic(ic_history):
    return {
        'ic_mean': ic_history['ic'].mean(),
        'ic_std': ic_history['ic'].std(),
        'ic_ir': ic_history['ic'].mean() / ic_history['ic'].std() * np.sqrt(len(ic_history)),
        'positive_ratio': (ic_history['ic'] > 0).mean(),
        't_stat': ic_history['ic'].mean() / (ic_history['ic'].std() / np.sqrt(len(ic_history))),
    }

# 预期 A 股 5 年实证结果（参考值，[[empirical-single-factor-table]]）：
# -TVR_1: IC ≈ 0.06, ICIR ≈ 0.65, t ≈ 4.2
# STOM:   IC ≈ 0.05, ICIR ≈ 0.55, t ≈ 4.0
# EP:     IC ≈ 0.04, ICIR ≈ 0.42, t ≈ 3.0
```

### 5.4 Fama-MacBeth 多因子检验

**问题**：单因子 IC 都好——但 3 个因子放一起，还有几个是"独立 alpha"？

**Fama-MacBeth 两步流程**（[[portfolio-sort-and-regression]] § 2.5）：

1. **截面回归**（每月一次）：$r_{i,t} = \gamma_0 + \gamma_1 \cdot f_{1,i,t-1} + \gamma_2 \cdot f_{2,i,t-1} + \gamma_3 \cdot f_{3,i,t-1} + \epsilon$
2. **时序均值**：$\hat{\gamma}_k = \frac{1}{T} \sum_t \gamma_{k,t}$
3. **NW 调整 t**：$t_k = \frac{\hat{\gamma}_k}{\sigma_{NW}(\hat{\gamma}_k)}$ （月频 lag = 6）

**A 股阈值**：每个 $\hat{\gamma}_k$ 的 t > 2.5 → 因子独立显著。

### 5.5 实证基准对照

**A 股因子 t 值参考**（[[empirical-single-factor-table]]）：

| 因子 | A 股 t 值（2000-2019）| 评级 |
|---|---|---|
| **-TVR_1** | 4.2 | 极强 |
| **STOM_barra** | ~4.0+ | 极强 |
| **-IVOL** | 3.5+ | 强 |
| **F-Score × BM** | 3.8 | 强 |
| **EP** | 3.0 | 强 |
| **-AG** | -2.8 | 中等 |
| **GP** | 2.3 | 中等 |
| **ROE** | 1.5 | **不显著** |

我们选的 3 个因子（-TVR_1 / STOM / EP）都在前 5 位 —— **三个独立 t > 3 的因子，组合后的合成 IC 大概率 > 单因子**。

---

## 6. 多因子合成与选股（3.1）

> 把 3 个因子合成一个综合得分，按截面排序选 30 只。
>
> **串联板块**：[[index-03-01-multi-factor-selection]] 多因子选股全 5 文件

### 6.1 截面 rank 等权合成

**为什么 rank 而非原始值**（[[multi-factor-methodology-overview]]）：

- 原始值**截面尺度不同**（PE 一般 5-100，TVR 一般 0.001-0.1）→ 直接平均会让某一因子主导
- rank 后所有因子**等距分布在 [0, 1]**，等权合成才有意义

**实现**：

```python
def combine_factors_equal_weight(factor_df, factor_names):
    """等权合成多因子"""
    ranked = factor_df[factor_names].rank(pct=True)
    combined = ranked.mean(axis=1)
    return combined
```

### 6.2 风格中性（可选进阶）

**问题**：3 个因子可能与 Barra 风格（市值 / 行业 / 波动）有暴露 → 选出来的股票可能集中在小盘 / 高波动

**做法**（[[neutralization-practice]]）：

1. 对每个因子做截面回归，剔除市值 + 行业暴露
2. 用残差作为"中性化后的因子值"
3. 再合成 + 选股

**代码框架**：

```python
def neutralize_against_size_industry(factor_series, size_series, industry_series):
    """因子市值 + 行业中性化"""
    # 1. 构造哑变量
    industry_dummies = pd.get_dummies(industry_series, prefix='ind')
    
    # 2. 截面回归
    from sklearn.linear_model import LinearRegression
    X = pd.concat([size_series, industry_dummies], axis=1).dropna()
    y = factor_series.reindex(X.index)
    mask = ~y.isna()
    
    reg = LinearRegression().fit(X[mask], y[mask])
    pred = pd.Series(reg.predict(X), index=X.index)
    residual = (y - pred).reindex(factor_series.index)
    return residual
```

**A 股化注记**：本教程为简化**不做中性化**，进阶版强推（[[multi-factor-jq-strategy]]）。

### 6.3 代码 4：选股（端到端示例 Part 4）

```python
"""端到端示例 - Part 4: 多因子合成 + 选股"""

# 1. 等权合成
factor_df['combined'] = combine_factors_equal_weight(
    factor_df, ['tvr_neg', 'stom', 'ep']
)

# 2. 选前 30 只
TOP_N = 30
top_stocks = factor_df['combined'].nlargest(TOP_N).index.tolist()
print(f'选股结果（前 5）：')
for s in top_stocks[:5]:
    info = get_security_info(s)
    print(f'  {s} - {info.display_name}: combined={factor_df.loc[s, "combined"]:.4f}')
```

---

## 7. 组合优化与仓位（4.1 + 4.2）

> 选出来 30 只——如何决定每只占多少？
>
> **串联板块**：[[index-04-01-portfolio-optimization]] + [[index-04-02-kelly-position]]

### 7.1 6 种组合优化方法对比

[[portfolio-optimization-overview]] 完整对比：

| 方法 | 一句话 | 适用 |
|---|---|---|
| **等权** | 每只 1/N | **本教程 / 因子明确时** |
| **市值加权** | 按市值比例 | 跟踪指数 / 大盘策略 |
| **最小方差** | 优化目标 = 协方差最小 | 低波策略 |
| **最大分散度** | 多样化最大 | 资产配置 |
| **风险平价** | 风险贡献平衡 | 多资产组合 |
| **Black-Litterman** | 贝叶斯结合预期 + 协方差 | 机构 |

**为什么本教程选等权**：
- 简单，无需估计协方差矩阵
- 在因子已经做了"选股"环节后，等权效果通常不差
- A 股个人量化的实务首选

### 7.2 凯利公式与仓位

**单策略凯利**（[[kelly-single-strategy]]）：

$$f^* = \frac{m}{s^2}$$

**A 股个人量化的实务**（[[kelly-risk-tail]]）：
- A 股不能加杠杆 → 单策略 f* 通常 < 1，**满仓即可**
- **半凯利 / 1/4 凯利更稳健**（[[kelly-risk-tail]] § Thorp 回撤公式）

**整体仓位决策**：本教程**默认满仓 100%**——选 30 只等权 = 每只 3.33%。

### 7.3 代码 5：等权配置（端到端示例 Part 5）

```python
"""端到端示例 - Part 5: 等权配置"""

# 等权 = 每只目标仓位 = 1 / N
target_weights = {s: 1.0 / TOP_N for s in top_stocks}

for s, w in list(target_weights.items())[:5]:
    print(f'  {s}: {w:.4%}')
print(f'  ... (共 {len(target_weights)} 只)')
```

---

## 8. 风险归因（4.3 + 2.3 Barra）

> 跑出收益后**必须做归因**——你赚的钱是 alpha 还是 beta？
>
> **串联板块**：[[index-04-03-risk-attribution]] + [[index-02-03-barra-factors]]

### 8.1 Brinson 归因（行业层）

**核心问题**：超额收益来自**选股能力**还是**行业配置**？

**Brinson 三件套**（[[risk-attribution-three-factor]]）：

1. **配置效应** = $\sum (w_i^P - w_i^B) \cdot r_i^B$
2. **选股效应** = $\sum w_i^B \cdot (r_i^P - r_i^B)$
3. **交互效应** = $\sum (w_i^P - w_i^B) \cdot (r_i^P - r_i^B)$

### 8.2 Barra 风格归因

**问题**：组合在 Barra 10 大风格（[[barra-9-style-factors]]）上有多少暴露？

**步骤**：
1. 计算组合在每个 Barra 因子上的**加权暴露**（持仓权重 × 个股暴露）
2. 与基准对比
3. 把超额收益拆分到风格因子 + 残差（特质性收益）

**实现**：[[multi-factor-risk-attribution-jq]]

### 8.3 A 股归因关键观察

**典型问题诊断**（[[risk-attribution-three-factor]]）：
- 高 Beta + 高 STOM → "高波 / 高流动性"风格暴露过多 → 牛市赢、熊市输
- 低 Size → "小盘"暴露 → 2017 后大概率失效
- 高 NLSIZE → "中盘"暴露 → 长期跑输

---

## 9. 回测与评估（5.2 + 5.4）

> 跑通策略 → 评估 → 找陷阱。**这一步决定策略是否能上线**。
>
> **串联板块**：[[index-05-02-backtest-frameworks]] + [[index-05-04-backtest-pitfalls]]

### 9.1 12 个核心评估指标

详见 [[backtest-metrics-full]] 的完整公式 + pandas 实现：

| 类别 | 指标 | A 股个人量化警戒线 |
|---|---|---|
| **收益** | 年化收益、累计收益 | > 基准 |
| **风险** | 年化波动、最大回撤 | 回撤 < 25% |
| **风险调整** | **夏普 / 索提诺 / 卡玛** | 夏普 > 1.0 |
| **基准对比** | Alpha / Beta / **信息比率** | IR > 0.5 |
| **因子专用** | IC / ICIR / 胜率 / 盈亏比 | IC > 0.03 |

### 9.2 A 股 30 条回测陷阱自检

[[backtest-checklist]] 完整清单，最高优先级 10 条：

1. ✅ 用历史日期取股票池（避免存活偏差）
2. ✅ 财务数据走 PIT（聚宽 `get_fundamentals(date=)` 默认 ✓）
3. ✅ 全部用前复权（`fq='pre'`）
4. ✅ 过滤当日涨跌停（不下单）
5. ✅ 过滤当日停牌
6. ✅ 过滤 ST / *ST（按历史状态）
7. ✅ 过滤新股次新股（180 日）
8. ✅ 印花税 + 佣金 + 滑点（聚宽 `set_order_cost`）
9. ✅ 撮合用次日开盘（不是当日收盘——避免前视）
10. ✅ 月频用日 K + 日收益（不用周收益算夏普）

### 9.3 代码 6：完整回测（聚宽在线 IDE 版）

下面是**完整的聚宽策略代码**，可以**直接复制到聚宽在线 IDE 跑通**。

```python
"""
端到端示例 - Part 6/7: 完整聚宽策略
A 股三因子（-TVR_1 / STOM / EP）等权月度调仓
直接复制到 https://www.joinquant.com/algorithm/index/edit 运行
"""
from jqdata import *
import pandas as pd
import numpy as np


def initialize(context):
    # === A 股标准配置（[[jq-config-universe]]）===
    set_benchmark('000300.XSHG')              # 沪深 300 基准
    set_option('use_real_price', True)         # 用真实价格
    set_option('avoid_future_data', True)      # 防未来函数
    log.info('策略初始化')
    
    # 交易成本（[[cost-jq-modeling]]）
    set_order_cost(
        OrderCost(
            close_tax=0.0005,               # 印花税 0.05%（卖出，2023.8.28 减半后）
            open_commission=0.0003,         # 买入佣金
            close_commission=0.0003,        # 卖出佣金
            min_commission=5                 # 最低 5 元
        ),
        type='stock'
    )
    set_slippage(FixedSlippage(0.002))      # 固定滑点 0.2%
    
    # 全局参数
    g.hold_count = 30
    g.universe_index = '000300.XSHG'
    g.stom_window = 21
    g.new_stock_filter_days = 180
    
    # 每月第一个交易日调仓
    run_monthly(rebalance, 1, time='open')


def before_trading_start(context):
    """盘前用 T-1 数据准备"""
    g.calc_date = context.previous_date


def get_universe(context):
    """T-1 时点的股票池"""
    # 1. 沪深 300 历史成分
    stocks = list(get_index_stocks(g.universe_index, g.calc_date))
    
    # 2. 过滤新股次新股
    stocks = [
        s for s in stocks
        if (g.calc_date - get_security_info(s).start_date).days >= g.new_stock_filter_days
    ]
    
    # 3. 过滤当日 ST
    current_data = get_current_data()
    stocks = [s for s in stocks if not current_data[s].is_st]
    
    # 4. 过滤当日涨跌停 / 停牌
    stocks = [
        s for s in stocks
        if not current_data[s].paused
        and current_data[s].last_price != current_data[s].high_limit
        and current_data[s].last_price != current_data[s].low_limit
    ]
    
    return stocks


def compute_factors(universe, calc_date):
    """计算 -TVR_1 / STOM / EP 三因子"""
    
    # === 因子 1: -TVR_1（当日换手率的负倒数）===
    # 取 T-1 当日成交额 + 流通市值
    today_data = get_price(
        universe, end_date=calc_date, count=1,
        fields=['money'], fq='pre', panel=False,
    )
    money_today = today_data.set_index('code')['money']
    
    fund = get_fundamentals(
        query(valuation.code, valuation.pe_ratio, valuation.circulating_market_cap)
        .filter(valuation.code.in_(universe)),
        date=calc_date,
    )
    fund = fund.set_index('code')
    circ_cap = fund['circulating_market_cap'] * 1e8  # 亿 → 元
    
    turnover_today = money_today / circ_cap
    tvr_neg = -1 / (turnover_today + 1e-6)
    
    # === 因子 2: STOM（21 日累计换手率的 log）===
    money_panel = get_price(
        universe, end_date=calc_date, count=g.stom_window,
        fields=['money'], fq='pre', panel=False,
    )
    money_pivot = money_panel.pivot(index='time', columns='code', values='money')
    
    # 每日换手率
    daily_turn = money_pivot.div(circ_cap, axis=1)
    stom = np.log(daily_turn.sum(axis=0) + 1e-10)
    
    # === 因子 3: EP（1/PE_TTM，过滤负 PE）===
    pe = fund['pe_ratio']
    pe = pe.where(pe > 0)
    ep = 1 / pe
    
    # === 合并 + 删缺失 ===
    factor_df = pd.DataFrame({
        'tvr_neg': tvr_neg,
        'stom': stom,
        'ep': ep,
    }).dropna()
    
    # === 截面 rank 等权合成 ===
    ranked = factor_df.rank(pct=True)
    factor_df['combined'] = ranked.mean(axis=1)
    
    return factor_df


def rebalance(context):
    """每月调仓"""
    # 1. 获取股票池
    universe = get_universe(context)
    log.info(f'股票池: {len(universe)} 只')
    
    # 2. 计算因子
    factor_df = compute_factors(universe, g.calc_date)
    log.info(f'有效因子覆盖: {len(factor_df)} 只')
    
    # 3. 选前 30 只
    target_stocks = factor_df.nlargest(g.hold_count, 'combined').index.tolist()
    log.info(f'目标持仓: {target_stocks[:5]}... (共 {len(target_stocks)} 只)')
    
    # 4. 卖出不在目标的持仓
    for security in list(context.portfolio.positions.keys()):
        if security not in target_stocks:
            order_target(security, 0)
    
    # 5. 等权买入新持仓（避开涨停 / 停牌）
    if not target_stocks:
        log.warning('目标持仓为空')
        return
    
    target_value = context.portfolio.total_value / len(target_stocks)
    current_data = get_current_data()
    
    for security in target_stocks:
        info = current_data[security]
        # 避开涨停（无法买入）
        if info.last_price == info.high_limit or info.paused:
            log.warning(f'{security} 涨停或停牌，跳过')
            continue
        order_target_value(security, target_value)
    
    log.info('调仓完成')


def after_trading_end(context):
    """盘后记录"""
    record(总持仓数=len(context.portfolio.positions))
```

**回测设置**（聚宽 IDE 内）：

- 起始资金：1,000,000
- 起止日期：2020-01-01 到 2024-12-31
- 频率：天（日级）
- 数据源：聚宽默认

**预期结果**（参考；实际结果可能因数据更新有变化）：

| 指标 | 策略 | 基准（沪深 300）|
|---|---|---|
| 年化收益 | 12-18% | 0-5% |
| 年化波动 | 22-25% | 17-19% |
| 最大回撤 | 20-25% | 30%+ |
| 夏普 | 0.6-0.8 | 0.0-0.3 |
| Alpha（年化） | 8-12% | - |
| Beta | 0.85-0.95 | 1.0 |
| 信息比率 | 0.5-0.8 | - |
| 月度换手 | 40-60% | - |

---

## 10. 工程化与上线（5.3 + 5.5）

> 跑通回测 → 进入模拟盘 / 实盘 + 长期监控。
>
> **串联板块**：[[index-05-03-jq-sdk-template]] + [[index-05-05-mlops]]

### 10.1 聚宽策略骨架五段式

[[jq-skeleton-main-flow]] 完整说明。本教程上面的代码已经是标准骨架：

```
initialize          ← 全局配置
   ↓
before_trading_start ← T-1 数据准备
   ↓
rebalance / handle_data ← 主策略逻辑
   ↓
after_trading_end    ← 盘后记录
```

### 10.2 上线流程

| 阶段 | 时长 | 内容 |
|---|---|---|
| **回测** | 立刻 | 聚宽 IDE 选"回测"运行 |
| **模拟盘** | 1-3 个月 | "模拟交易" → 等同实盘环境（除资金外）|
| **小资金实盘** | 3-6 个月 | 5-10 万试水，观察实际滑点 / 印花税 |
| **正式实盘** | 持续 | 满意后扩大资金 |

### 10.3 轻量 MLOps 三件套

[[mlops-engineering]] § 个人量化 95% 不需要完整 MLOps。三件套足够：

```
1. MLflow（实验追踪）—— pip install mlflow / mlflow ui
2. DVC（数据版本）  —— pip install dvc / dvc add data/*.parquet
3. parquet + git    —— 本地缓存 + 代码版本
```

**A 股个人量化的"持续监控"**（[[mlops-engineering]] § 4）：

- **每月**：实盘 vs 回测的 IC / 收益对比
- **每季**：因子失效检查 + Barra 风格暴露体检
- **每年**：滚动重训因子参数 + checklist 完整自检

### 10.4 实盘部署

**聚宽实盘**：
1. 模拟盘充分跑通后，点击"实盘"
2. 绑定证券账户（聚宽支持多家券商）
3. 自动每日运行，无需服务器

**特别注意**（[[backtest-trading-rules]]）：
- 实盘**滑点通常比回测高**（设置时给到 0.3-0.5%）
- 实盘**会遇到部分成交 / 撤单**（聚宽自动处理但建议日志）
- 实盘**资金占用**比回测高（涨停未成交 → 资金冻结）

---

## 11. 进阶路径（03 其余 + 2.7 + 99）

> 本教程的多因子选股只是 03 策略原型 5 大类的 1 个——其余 4 大类等你探索。
>
> **串联板块**：[[index-03-strategy-prototypes]] + [[index-02-07-alternative-data]] + [[index-99-skill-entry]]

### 11.1 03 策略原型全图

| 板块 | 一句话 | 推荐学习时机 |
|---|---|---|
| [[index-03-01-multi-factor-selection]] 3.1 多因子选股 | 本教程主线 | **已学** ✓ |
| [[index-03-02-timing]] 3.2 择时策略 | RSRS / 双均线 / 风险预算 | 本教程进阶（加择时滤镜）|
| [[index-03-03-statistical-arbitrage]] 3.3 统计套利与配对 | 协整 / 配对（A 股仅做多版）| 高阶 |
| [[index-03-04-ml-strategies]] 3.4 ML 策略 | LightGBM / XGBoost | 进阶（替换 6.1 等权合成）|
| [[index-03-05-seasonality-events]] 3.5 季节性与事件 | 春节效应 / PEAD | 高阶（A 股本土特色）|

### 11.2 推荐进阶路径

**Step 1**：跑通本教程的 3 因子（**已做**）→ 跑出真实 IC / Alpha

**Step 2**：加择时滤镜（[[rsrs-four-versions]]）
- RSRS_v3 是 A 股招牌择时（夏普 0.85）
- 在本教程的 `rebalance` 上层加 `if RSRS_signal > 0` 判断

**Step 3**：扩到 5 因子（加 -IVOL + -AG）
- IC 加权合成（替代等权）
- 期望年化超额 +2-3%

**Step 4**：加事件驱动（[[event-driven-pead]]）
- 业绩预告 → PEAD（A 股比美股显著）
- 期望持有期 60 日 / 超额 5-12%

**Step 5**：加 ML 模型（[[lightgbm-stock-selection-implementation]]）
- LightGBM 替代等权合成
- A 股个人量化推荐天花板

**Step 6**：加 MLOps 工程化（[[mlops-engineering]]）
- MLflow + DVC + git 三件套

### 11.3 替代数据扩展（[[index-02-07-alternative-data]]）

A 股可获取的替代数据（[[alternative-data-30-categories]]）：

- 🟢 **易获取**：龙虎榜、北向资金、融资融券、业绩预告（聚宽 `finance.*`）
- 🟡 **中等**：新闻 NLP、雪球热度（需爬虫 / 第三方 API）
- 🔴 **难**：卫星、信用卡、地理位置（个人不推荐）

### 11.4 整库 27 板块全图（核心 5 一级 + 00 综合层 + 99 入口）

```
┌────────────────────────────────────────────────────────────┐
│  心智骨架（01 锚定 5 板块）                                │
│  1.1 统一视角 → 1.2 检验方法 → 1.3 独立交易员            │
│  → 1.4 行为金融 → 1.5 ML 协同                             │
└────────────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────────────┐
│  具体工具（02 因子库 7 板块）                              │
│  2.1 算子 ↔ 2.2 公式 → 2.3 Barra / 2.4 基本面 / 2.5 技术  │
│  → 2.6 实证基准 + 2.7 另类数据                            │
└────────────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────────────┐
│  策略落地（03 全 5 + 04 全 4）                             │
│  3.x 五大策略原型 → 4.1-4.4 配权风控成本                  │
└────────────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────────────┐
│  工程闭环（05 全 5）                                       │
│  5.1 数据 → 5.2 框架 → 5.3 聚宽 SDK                       │
│  → 5.4 回测陷阱 → 5.5 MLOps                               │
└────────────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────────────┐
│  反向索引（99 skill 入口）                                 │
│  触发关键词 + 整库路由 + 引用规范                          │
└────────────────────────────────────────────────────────────┘
```

---

## 12. 综合观察 + A 股化关键结论

### 12.1 本教程的"端到端串联"价值

11 章对应整库 27 板块（01-05 共 26 二级 + 00 综合层 + 99 入口）的覆盖率：

- **直接覆盖**：01 全 5 + 02 全 7 + 03.1 + 04 全 4 + 05 全 5 + 99 = **22 板块**
- **进阶链接**：03.2-3.5 (4 板块) = 通过第 11 章引导
- **总覆盖**：**直接 22 + 进阶 4 + 00 自身 + 99 入口 = 27 板块 / 27 = 100%**

### 12.2 A 股化关键结论速查（贯穿全教程）

| 主题 | 核心结论 | 在哪一章 |
|---|---|---|
| **A 股最强 5 alpha** | -TVR_1 / STOM / -IVOL / EP / -AG | 第 2 章 |
| **A 股动量** | 整体失效，反转占优 | 第 1.4 章 |
| **A 股小市值** | 2017 后崩塌 | 第 1.4 章 |
| **A 股 ML 性价比** | IC 加权 5 因子 > LightGBM >> LSTM | 第 1.5 章 |
| **A 股因子 t 阈值** | t > 3.0（修正因子动物园后）| 第 5.4 章 |
| **NW lag 月频** | 6（半年自相关） | 第 5.4 章 |
| **复权选择** | 全部用 `fq='pre'`（回测/因子）+ `use_real_price` ✓（下单）| 第 3.2 章 |
| **A 股 5 大约束** | T+1 / 涨跌停 / 停复牌 / 做空受限 / 印花税 | 第 9.2 章 |
| **印花税** | 卖出端 0.05%（2023.8.28 减半后）| 第 9.3 章 |
| **主板 ST** | ±5%（2026.7.6 起 ±10%）| 第 9.2 章 |
| **聚宽配额** | 试用账号 1 年 100 万条/天 | 第 3.1 章 |
| **A 股 PEAD** | 比美股更显著 | 第 11.2 章 |
| **MLOps** | 95% 不需要完整 MLOps；MLflow + DVC + git 足够 | 第 10.3 章 |

### 12.3 单独阅读建议

如果你**只读 1 章**：第 9 章（回测与评估 + 30 条陷阱）—— **回测可信度 > 任何模型复杂度**

如果你**只读 3 章**：第 1（心智）+ 第 9（陷阱）+ 第 11（进阶）—— 建立**框架**

如果你**只复制 1 段代码**：第 9.3 完整聚宽策略 —— **就是端到端实现**

### 12.4 维护提醒（动态信息）

| 日期 | 关注点 |
|---|---|
| **2026-07-06** | 主板 ST 涨跌幅 ±5% → ±10% 切换日（[[backtest-trading-rules]] 已加注）|
| **聚宽试用账号到期** | 1 年后续期或升级正式版 |
| **每月** | 实盘 vs 回测 IC 监控 |
| **每季** | 因子失效检查 + Barra 风格暴露体检 |
| **每年** | 完整自检（[[backtest-checklist]] 30 条）|

---

## 13. 参考与延伸

### 13.1 27 板块完整引用

详见 [99 触发与路由](../99_skill入口/触发与路由.md) § 整库 27 板块完整路由

### 13.2 原始资料

本教程引用的原始资料（7 份）：

- **因子投资方法与实践**（石川等）—— 方法论密度最高
- **Alpha-101 论文**（Kakushadze 2015）—— 算子与公式
- **GTJA-191 研报**（国泰君安 2017）—— A 股版价量因子
- **Whale-Quant 开源课**（datawhale）—— 工具与代码层
- **Python 量化交易实战**（王晓华）—— 实战代码
- **量化交易事业**（Chan）—— 独立交易员视角
- **从数据到交易**（Marti 综述）—— ML 视角

详细速览见 `原始资料文件/` 下各子目录的 `速览_*.md`。

### 13.3 外部学习资源

- **聚宽社区**：https://www.joinquant.com/community
- **量化研究博客**：[Chan's Blog](http://epchan.blogspot.com/) / [因子动物园](http://factorzoo.com/)
- **GitHub 资源**：
  - [Alpha-101-GTJA-191](https://github.com/wpwpwpwpwpwpwpwpwp/Alpha-101-GTJA-191)
  - [jqdatasdk](https://github.com/JoinQuant/jqdatasdk)
  - [Barra-CNE5](https://github.com/xinyue6688/Barra-CNE5)

---

**🎯 教程完成。**

完成本教程后建议的下一步（按优先级）：

1. **复制第 9.3 的聚宽策略代码到聚宽 IDE 跑一遍**——亲手得到回测结果
2. **进入 [[index-05-04-backtest-pitfalls]] 5.4 用 30 条 checklist 自检自己的策略**
3. **按第 11.2 的进阶路径逐步扩展**（加择时 → 加因子 → 加 ML → 加 MLOps）
4. **建立"每月 IC 监控"工作流**（[[mlops-engineering]] § 持续监控）

**有问题随时查 [[index-99-skill-entry]] 99 → 触发关键词 + 整库路由速查表**。
