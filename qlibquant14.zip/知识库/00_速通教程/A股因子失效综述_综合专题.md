---
name: a-share-factor-decay-comprehensive
description: A 股因子失效完全综述 —— 4 个典型失效案例 + 失效原理 + 预警信号 + 防御策略（跨 1.4/2.6/3.x/5.4 综合）
category: 00_速通教程
tags: [A股, 因子失效, p-hacking, 拥挤, 小市值, 动量, 白马股, DMA, 综合专题]
created: 2026-05-17
updated: 2026-05-17
status: stable
---

# A 股因子失效完全综述

> **跨板块综合专题（阶段 2）**——把 1.4 因子动物园 / 2.6 实证基准 / 3.x 各类策略 / 5.4 回测陷阱 中关于"因子失效"的散点，整合为一篇完整专题。
>
> **回答的问题**：A 股历史上哪些因子曾经强大但后来失效？失效的根因是什么？怎么提前预警？防御策略是什么？

---

## TL;DR

A 股因子**失效不是偶然现象，而是规律性现象**。本文系统化梳理：

- **4 个典型失效案例**：小市值 2017 / 动量长期 / 白马股 2021 / DMA 2024
- **3 大失效根因**：监管 / 拥挤 / 行为偏差变化
- **5 类预警信号**：IC 衰减 / 拥挤度上升 / 估值溢价过高 / 政策方向 / 多元相关上升
- **4 种防御策略**：多元因子 / 滚动监控 / 滚动重训 / 失效切换

**核心 takeaway**：**任何 alpha 都会失效**——区别只在于"失效的速度"和"是否能及时识别"。**实战中"识别失效的能力" > "找到新 alpha 的能力"**。

---

## 1. 4 个 A 股典型失效案例

> 来源：[[empirical-factor-decay-cases]] 2.6 § A 股 4 个典型失效案例

### 1.1 小市值 2017（壳价值陷阱）

**失效前的辉煌**（2010-2016 / 7 年）：

| 因子 | 年化超额 | 夏普 |
|---|---|---|
| 小市值 LNCAP 反向 | **20-30%** | **1.5-2.0** |
| 中小盘指数 | 远超大盘 | - |

**根因**：A 股"壳价值"经济学
- 借壳上市常见 → 小市值股票有"被借壳期权"价值
- 散户追小炒新偏好 → 持续抬高估值

**失效的导火索**：**2017 年 IPO 加速 + 监管打击炒小**
- 证监会加速 IPO（年新增上市 ~400+ 家）→ 壳价值大幅下降
- 监管打击"妖股 / 炒小炒新" → 流动性折价崩塌

**失效后的表现**：

| 期间 | 小市值因子年化超额 |
|---|---|
| 2010-2016 | **+22%**（极强） |
| 2017 | **-25%**（崩塌）|
| 2018-2021 | -2% 到 0%（基本失效）|
| 2022-2024 | 中性偏弱 |

**实战教训**：
- **政策风险是 A 股因子失效的最大驱动**（不是市场波动）
- 监管方向**可以预测**——壳价值消失是 IPO 改革的必然
- **任何依赖"市场机制 + 散户行为"的 alpha 都可能被政策一锤定音**

### 1.2 动量长期失效（散户结构主导）

**失效不是"突然"而是"一直"**：A 股 12M-1M 动量因子从 2005 至今**长期不显著**（IC 在 0 附近波动）。

**根因**：A 股散户结构（70%+ 个人投资者交易额）→ 短期反转主导
- 散户追高 → 高点抛售 → 反弹
- 长期动量被短期反转**淹没**

**美股对比**：
- 美股动量 1996-2024 t > 4.0（持续显著）
- 美股机构占 75%+ → 信息扩散慢 + 行为持续性强

**A 股的"动量替代品"**：
- **残差动量**（剔除行业 + 市值暴露后）——稍有效，但 t 仅 2.5 左右
- **短期反转**（-TVR_1）—— A 股最强 alpha 之一（t = 4.2）

**实战教训**：
- **海外经典因子不能直接搬到 A 股**
- **必须本地实证**（[[empirical-single-factor-table]] 的存在意义）
- "动量在 A 股不显著"是结构性现象，不是策略 bug

### 1.3 白马股 2021（外资抱团破裂）

**失效前的辉煌**（2017-2020 / 4 年）：

| 标的 | 累计涨幅 |
|---|---|
| 贵州茅台 | +450% |
| 中国中免 | +700% |
| 海天味业 | +500% |
| 五粮液 | +350% |

**"白马股策略"**：高 ROE + 大市值 + 稳定增长 + 行业龙头 → 持有不动

**根因**：外资 + 公募抱团
- 2017 后陆股通 / QFII 大量流入 → 偏好"中国白马"
- 公募基金"押宝"龙头 → 互相强化
- 估值从 PE 20-30 推到 60-80 倍

**失效的导火索**：**2021 年 2 月 - 2024 年**
- 春节后白马股集体下跌
- "核心资产 30 强"指数 2021.2 至 2024.6 跌 **50%+**
- 茅台从 2600 → 1500

**根因分析**（事后）：
- **抱团 + 估值过高 = 不稳定均衡**
- 任何信息冲击都会引发踩踏（如 2021 年消费回落）
- 公募散户化 + 外资流出共振

**实战教训**：
- **"故事 + 估值溢价"组合极危险**——白马股的高 ROE 没失效，但**估值溢价反转**了
- 任何因子的"超额收益"如果是估值驱动而非基本面改善 → **预警**
- 单纯"高 ROE"不是 alpha，**"高 ROE + 合理估值"才是**

### 1.4 DMA 2024（量化策略集体回撤）

**事件**：2024 年 2 月 5 日开始的"量化雪崩"
- 中证 500 在 2024.2.5-2.8 三天跌 **15%+**
- 大量 DMA 产品（**多空策略 / 100% 多 + 100% 空对冲**）集中爆仓
- 量化机构 7 天蒸发 1 万亿管理规模

**根因**：拥挤交易 + 流动性踩踏
- 量化机构 2020-2023 急速扩张到管理规模 1.5 万亿+
- 选股策略**高度同质化**（都用类似 alpha）
- 2024.2 春节前流动性紧张 → 第一波爆仓 → 强制平仓 → 第二波 → ...

**失效的特点**：
- **不是因子失效，是流动性事件**
- A 股最强的几个因子（TVR / STOM / IVOL）在 2024.2.5-2.8 同时回撤
- 但 2 月底 - 3 月迅速反弹（基本面没坏）

**实战教训**：
- **拥挤是量化的最大风险**（[[kelly-risk-tail]] § 风险传染）
- 个人量化的"小资金优势"在这里体现——**不容易引发自身的踩踏**
- **流动性管理 > 因子选择**（极端时刻所有因子都失效）
- 容量管理（[[capacity-analysis-gtja]]）—— 个人在 ~100 万规模时安全边际大

---

## 2. 失效的 3 大根因（系统化）

> 综合 [[factor-zoo-p-hacking-data-snooping]] 1.4 + [[backtest-factor-decay]] 5.4

### 2.1 政策 / 监管驱动

**特征**：
- 失效**突然且彻底**（一个政策一次性消除 alpha）
- 不可预测（除非有信息优势）
- 影响**结构性**（不是临时波动）

**历史例子**：
- 小市值 2017（IPO 改革 + 监管打击炒小）
- 老雷曼套利（2008 之前美股 IB 套利 → 2008 后消失）
- 中国融券标的扩容（短期反转 alpha 部分被对冲机构吃掉）

**预警**：
- 政策方向（如"加大 IPO 力度 / 推进退市常态化"等）
- 监管会议精神
- 阅读券商研报对政策预测的"集中度"

### 2.2 拥挤驱动

**特征**：
- 失效**渐进**（IC 缓慢衰减）
- 偶尔伴随**踩踏事件**（如 DMA 2024）
- 与管理规模正相关

**历史例子**：
- 量化雪崩 2007 美股（Long-Term Capital + 多家对冲基金）
- DMA 2024 A 股
- 任何"超过容量 5 倍"的策略

**预警**：
- 因子 IC 衰减（用滚动 IC 比较：当前 12M IC vs 历史 36M IC）
- 管理规模过快增长（如同类策略基金规模 3 年 10 倍）
- 出现"很多人在讨论这个因子"的现象

### 2.3 行为偏差变化驱动

**特征**：
- 失效**最慢但最隐蔽**
- 与市场结构变化相关
- 难以单独识别（混杂其他根因）

**历史例子**：
- 散户占比下降 → 部分"散户偏差"alpha 弱化
- 机构化（公募 / 私募 / 北向）→ A 股估值因子的"效率提升"
- ETF 大发展 → 指数权重股的"被动买入"

**预警**：
- 市场参与者结构数据（如个人投资者 / 机构投资者 / 北向占比）
- 中国证监会 / 中证报的定期报告
- 长期趋势性变化（5+ 年）

---

## 3. 5 类预警信号

> 综合 [[backtest-factor-decay]] 5.4 + [[ic-test-and-combination]] 1.2

### 3.1 IC 衰减信号

**计算**：滚动 12M IC vs 历史 36M IC

```python
def detect_ic_decay(ic_series, recent_window=12, historical_window=36):
    """检测因子 IC 衰减"""
    recent_ic = ic_series.tail(recent_window).mean()
    historical_ic = ic_series.tail(historical_window).mean()
    
    if historical_ic == 0:
        return None
    
    decay_ratio = (historical_ic - recent_ic) / abs(historical_ic)
    
    return {
        'recent_ic': recent_ic,
        'historical_ic': historical_ic,
        'decay_ratio': decay_ratio,
        'warning': decay_ratio > 0.3,  # > 30% 衰减
    }
```

**阈值**：
- 衰减率 > 30% → **警告**
- 衰减率 > 50% → **建议停用**
- 连续 3 个月 IC < 0 → **该因子可能已失效**

### 3.2 拥挤度信号

**指标 1**：因子组合的市值集中度
- 选出的股票**市值越集中**（如均集中在小盘）→ 拥挤
- 计算：组合内股票市值分布 std

**指标 2**：与同行业基金持仓重合度
- 通过 Wind / 公开持仓 计算策略选股 vs 主流量化基金重合度
- 重合度 > 40% → 拥挤

**指标 3**：成分股的 turnover 异常
- 选出股票的换手率突然**远高于历史均值**
- 可能是其他套利者也在做同样策略

### 3.3 估值溢价信号

**计算**：策略组合 PE / 基准 PE 的比值

```python
def detect_valuation_premium(strategy_pe, benchmark_pe, history_quantile=0.8):
    """检测策略估值溢价过高"""
    current_ratio = strategy_pe / benchmark_pe
    historical_ratios = ...  # 历史比值序列
    
    if current_ratio > np.quantile(historical_ratios, history_quantile):
        return 'WARNING: 策略估值溢价处于历史 80% 分位以上'
    return 'OK'
```

**阈值**：
- 估值溢价 > 历史 80% 分位 → 警告
- 估值溢价 > 历史 95% 分位 → 高危
- 例：白马股 2020 末 PE 50+ × 基准 PE 15 = 比值 > 3.3 → 历史 99% 分位

### 3.4 政策方向信号

**关注点**：
- 证监会的"五年规划"或"年度工作要点"
- 重大监管事件（如全面注册制 / 退市常态化）
- 政策报告中的"高频词汇"变化

**实务建议**：
- 每季度做一次政策方向梳理
- 因子选择需考虑"政策容忍度"——例如重组套利在监管严的时期可能失效

### 3.5 多元相关上升

**信号**：原本独立的因子，相关性突然上升

```python
def detect_factor_correlation_spike(factor_returns_df, window=60):
    """检测因子间相关性的异常上升"""
    recent_corr = factor_returns_df.tail(window).corr().abs().mean().mean()
    historical_corr = factor_returns_df.iloc[:-window].corr().abs().mean().mean()
    
    spike_ratio = recent_corr / historical_corr if historical_corr > 0 else 0
    
    if spike_ratio > 1.5:
        return 'WARNING: 因子相关性异常上升 → 拥挤迹象'
    return 'OK'
```

**阈值**：
- 平均相关性上升 > 50% → 警告
- 极端情况（如 DMA 2024）：相关性接近 1（所有因子同方向）

---

## 4. 4 种防御策略

### 4.1 多元因子组合

**原理**：单因子失效 ≠ 多因子组合失效
- A 股 5 因子（-TVR_1 / STOM / -IVOL / EP / -AG）通常**任意时刻只有 1-2 个同时失效**
- 等权组合自动降低单因子失效风险

**实务**：
- 至少 5 个因子（不要 < 3）
- 不同类别因子混合（流动性 + 价值 + 质量 + 行为）
- 等权或 IC 加权（避免市值加权，因为某些股票市值大时容易被市值加权吃掉）

### 4.2 滚动监控

**频率**：
- 每月：IC 监控 + 失效预警
- 每季：拥挤度 + 估值溢价检查
- 每年：完整 30 条 checklist（[[backtest-checklist]]）

**工具链**（轻量 MLOps）：
- MLflow 追踪每月回测
- 简单 Python 脚本计算预警指标
- 邮件 / Slack 告警

详见 [[mlops-engineering]] § 持续监控。

### 4.3 滚动重训

**原理**：因子参数不应静态固定，应随市场结构变化滚动更新

**实务**：
- IC 加权权重每 3-6 个月重训
- ML 模型每 6-12 个月重训
- 不要"一次性回测出参数永远不变"

**A 股特殊性**：
- A 股市场结构变化快 → 重训频率比美股高
- 每年至少一次完整重训 + 每季度小调

### 4.4 失效切换

**原理**：检测到失效信号后，主动停用因子

**实务**：

```python
def factor_lifecycle_management(ic_history, threshold=0.3):
    """因子生命周期管理"""
    decay = detect_ic_decay(ic_history)
    
    if decay['decay_ratio'] > 0.5:
        action = 'STOP'   # 停用
    elif decay['decay_ratio'] > threshold:
        action = 'REDUCE'  # 降权
    else:
        action = 'KEEP'   # 保持
    
    return action
```

**完整流程**：
1. 每月 IC 监控
2. 衰减 > 30% → 降权（权重 × 0.5）
3. 衰减 > 50% → 停用（权重 = 0）
4. 连续 3 个月 IC < 0 → 完全剔除
5. 替补因子（保持 5 因子组合不变）

---

## 5. 实战：构建"防失效"的多因子框架

### 5.1 框架核心组件

```
┌────────────────────────────────────────────┐
│  数据接入（5.1 + 5.4）                     │
│  PIT 财务 / 复权 / 存活偏差防护           │
└─────────────────┬──────────────────────────┘
                  ↓
┌────────────────────────────────────────────┐
│  因子计算（2.x）                           │
│  -TVR_1 / STOM / -IVOL / EP / -AG 等       │
└─────────────────┬──────────────────────────┘
                  ↓
┌────────────────────────────────────────────┐
│  ⭐ 失效预警层（新加）                      │
│  - IC 衰减检测                             │
│  - 拥挤度监控                              │
│  - 估值溢价检测                            │
│  - 因子相关性变化                          │
└─────────────────┬──────────────────────────┘
                  ↓
┌────────────────────────────────────────────┐
│  因子组合（3.1 + 4.1）                     │
│  IC 加权（动态权重）+ 滚动重训             │
└─────────────────┬──────────────────────────┘
                  ↓
┌────────────────────────────────────────────┐
│  选股 + 调仓（5.3）                        │
└────────────────────────────────────────────┘
```

### 5.2 关键代码片段（防失效组件）

```python
"""防失效多因子框架的核心组件"""

class FactorLifecycleManager:
    """因子生命周期管理"""
    
    def __init__(self, factor_names, decay_threshold=0.3):
        self.factors = {name: {'status': 'KEEP', 'weight': 1.0} for name in factor_names}
        self.threshold = decay_threshold
        self.ic_history = {name: [] for name in factor_names}
    
    def update_ic(self, factor_name, ic_value):
        """每月调用：更新因子 IC"""
        self.ic_history[factor_name].append(ic_value)
        
        if len(self.ic_history[factor_name]) >= 12:
            self.check_decay(factor_name)
    
    def check_decay(self, factor_name):
        """检测因子衰减"""
        recent_ic = np.mean(self.ic_history[factor_name][-12:])
        historical_ic = np.mean(self.ic_history[factor_name][-36:])
        
        if historical_ic == 0:
            return
        
        decay = (historical_ic - recent_ic) / abs(historical_ic)
        
        if decay > 0.5:
            self.factors[factor_name]['status'] = 'STOP'
            self.factors[factor_name]['weight'] = 0
            print(f'⚠ {factor_name} 停用 (decay={decay:.2%})')
        elif decay > self.threshold:
            self.factors[factor_name]['status'] = 'REDUCE'
            self.factors[factor_name]['weight'] = 0.5
            print(f'⚠ {factor_name} 降权 (decay={decay:.2%})')
        else:
            self.factors[factor_name]['status'] = 'KEEP'
            self.factors[factor_name]['weight'] = 1.0
    
    def get_active_factors(self):
        """获取当前有效因子 + 权重"""
        return {
            name: meta['weight']
            for name, meta in self.factors.items()
            if meta['status'] != 'STOP'
        }


# 使用示例
mgr = FactorLifecycleManager(['tvr_neg', 'stom', 'ep', 'ivol_neg', 'ag_neg'])

# 每月更新（伪代码）
for month_end_date in monthly_dates:
    for factor in mgr.factors:
        ic = calculate_ic(factor, month_end_date)
        mgr.update_ic(factor, ic)
    
    active_factors = mgr.get_active_factors()
    print(f'{month_end_date}: 活跃因子 {len(active_factors)}/{5}')
```

---

## 6. 失效检测的"信噪比"问题

> 这一节是本文的"反思"——失效检测本身有局限性

### 6.1 假阳性问题

**问题**：IC 短期波动 → 误判为失效 → 错杀好因子

**对策**：
- 至少 12 个月衰减信号 + 连续 3 个月 IC < 0 才停用
- 不要 1-2 个月的回撤就停用
- 区分"周期性回撤"（如熊市初期）vs"结构性失效"

### 6.2 假阴性问题

**问题**：失效信号滞后 → 错过最佳止损时机

**对策**：
- 结合**领先指标**（政策方向 / 估值溢价 / 拥挤度）而非仅 IC
- IC 是后视的，预警信号应该是前视的

### 6.3 "上帝视角"陷阱

**问题**：事后看 2017 小市值崩塌"明显可预测"——但事前真的能预测吗？

**残酷真相**：
- 2017 年 1 月几乎没人预测到小市值会崩
- 即使到 2017 年 6 月衰减已经明显，仍有大量基金"等反弹"
- 真正能止损的是有**纪律性**的，不是"聪明"的

**对策**：
- **事先定义清晰的止损规则**（如"衰减 > 50% 立刻停用"）
- **不要靠"判断"**——靠**系统**
- 这本质是 Chan 7 条避坑的第 6 条（[[quant-as-small-business]]）

---

## 7. 跨板块引用密度

| 板块 | 用到的内容 |
|---|---|
| [[index-01-04-behavioral-finance]] 1.4 | 因子动物园 / p-hacking / 数据窥探 |
| [[index-02-06-empirical-benchmark]] 2.6 | A 股因子实证 / 4 个失效案例 |
| [[index-05-04-backtest-pitfalls]] 5.4 | 30 条回测陷阱清单 |
| [[index-03-04-ml-strategies]] 3.4 | ML 防过拟合 |
| [[index-04-02-kelly-position]] 4.2 | 拥挤 / 风险传染 |

具体文献：

- [[empirical-factor-decay-cases]] —— A 股 4 个典型失效案例
- [[factor-zoo-p-hacking-data-snooping]] —— 因子动物园理论
- [[backtest-factor-decay]] —— 失效预警 / 防御策略
- [[ic-test-and-combination]] —— IC 检验
- [[backtest-checklist]] —— 30 条 checklist
- [[kelly-risk-tail]] —— 风险传染 / 2007 量化危机
- [[capacity-analysis-gtja]] —— 容量分析

---

## 8. 综合观察 + 一图速记

```
A 股因子失效的"三层防御":

外层（前视）：
├── 政策方向监控
├── 估值溢价检测
├── 拥挤度跟踪
└── 因子相关性

中层（后视）：
├── 滚动 IC 监控
└── 历史 IC vs 当前 IC 对比

内层（执行）：
├── 衰减 > 30% → 降权
├── 衰减 > 50% → 停用
└── 连续 3 月 IC<0 → 剔除
```

**核心 takeaway**：
- **失效是 A 股因子的"常态"而非"异常"**
- **检测失效 > 找新 alpha**——纪律性的执行比"聪明的判断"更重要
- **4 大案例的根因不同**：监管（小市值）/ 行为（动量）/ 估值（白马股）/ 拥挤（DMA）
- **多元因子 + 滚动监控 + 滚动重训 + 失效切换** = 实战可用的防御组合
- **个人量化的优势**：小资金 → 不容易引发自身踩踏 + 灵活切换

## 9. 后续阅读路径

| 想深入哪个方向 | 推荐 |
|---|---|
| **A 股 alpha 的本质** | [[a-share-alpha-essence]] 综合专题（第 1 篇）|
| **凯利 + A 股仓位** | [[a-share-kelly-position-comprehensive]] 综合专题（第 3 篇）|
| **跑通端到端策略** | [[end-to-end-tutorial-a-share]] 教程主线 |
| **完整 30 条 checklist** | [[backtest-checklist]] |
| **因子动物园原理** | [[factor-zoo-p-hacking-data-snooping]] |
| **凯利风险传染** | [[kelly-risk-tail]] § 2007 量化危机 |
| **A 股容量分析** | [[capacity-analysis-gtja]] |
