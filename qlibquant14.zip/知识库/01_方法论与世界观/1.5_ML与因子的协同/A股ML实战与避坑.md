---
name: a-share-ml-practice-and-pitfalls
description: A 股 ML 实战与避坑 —— 性价比清单 + Whale-Quant 时序模型（ARIMA/GARCH/LSTM）+ Marti 综述索引 + 实操避坑
category: 01_方法论与世界观/1.5_ML与因子的协同
tags: [A股ML, LightGBM, XGBoost, LSTM, 时序模型, GARCH, ARIMA, MLOps, 避坑]
created: 2026-05-17
updated: 2026-05-17
source: Whale-Quant ch08 + Marti 综述 ch2 + A 股业界经验
status: stable
---

# A 股 ML 实战与避坑

## TL;DR

承接 [因子投资中的ML综述.md](因子投资中的ML综述.md) 的学术综述，本文聚焦 **A 股个人量化的 ML 实战**：

- **A 股 ML 性价比清单**：从"零成本"到"高复杂度"的 7 个层级
- **Whale-Quant ch08 时序模型**：ARIMA / GARCH / LSTM / GRU 在 A 股的适用边界
- **Marti 综述 ch2 算法清单索引**：监督 / 无监督 / 强化学习全景
- **6 个实操避坑**：时序划分 / 标签噪声 / 特征泄漏 / 拥挤度 / 过拟合 / 部署陷阱

**核心 A 股化结论**：

- **A 股 ML 最强工业级方案 = 5-10 因子 + XGBoost / LightGBM + 严格 OOS**
- **Transformer / RL 在 A 股几乎无效**——信噪比太低 + 样本短
- **特征工程 > 模型选择**——A 股的"垃圾进 → 垃圾出"更严重
- **MLOps 是 A 股个人最大的工程缺口**——业界用 mlflow / DVC / Airflow

## 来源

- **Whale-Quant 开源量化课程 ch08**：[速览_whale_quant.md](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/速览_whale_quant.md)
  - ch08.1 小波分析原理
  - ch08.2 LightGBM 原理（核心实战）
  - ch08.3 时序模型（ARIMA / GARCH / RNN / LSTM / GRU）
- **Marti 综述 ch2**：监督/无监督/强化学习算法清单
- **A 股业界 ML 经验**（综合）

**OCR 注记**：Whale-Quant 是开源 Markdown 教材，**OCR 良好**。Marti 综述 ch2 仅作目录索引——不展开数学推导。

---

## 1. A 股 ML 的"性价比清单"（最重要）

### 1.1 7 个层级（从零成本到高复杂度）

| 层级 | 方法 | A 股有效性 | 适合资金 | 备注 |
|---|---|---|---|---|
| **L0** | **5 因子 IC 加权**（A 股最强 5） | **强** | 任意 | **80% 个人量化由此起步** |
| L1 | 5-15 因子 + Logistic 回归 | 强 | 50 万+ | A 股可解释，工业可用 |
| L2 | **15-50 因子 + 弹性网络** | **强** | 100 万+ | 业界量化标配 |
| **L3** | **50-100 因子 + GBDT/LightGBM** | **强** | 500 万+ | **业界主流**——A 股 sweet spot |
| L4 | 50-200 因子 + XGBoost 集成 | 中-强 | 1000 万+ | 头部私募用 |
| L5 | 100+ 特征 + DFN（3-5 层）| 中 | 5000 万+ | 学术 + 部分私募 |
| L6 | 1000+ 特征 + LSTM / Transformer | **弱** | 1 亿+ | **A 股几乎无效** |
| L7 | 强化学习 / GAN | **极弱** | - | **研究阶段，不可用** |

### 1.2 推荐起点

**对 A 股个人量化（资金 50-500 万）**：

- **从 L0 开始**——5 因子 IC 加权（参见 [[ic-test-and-combination]] 和 [[empirical-single-factor-table]]）
- **6-12 个月后升级 L2-L3**——弹性网络 + GBDT
- **不必上 L5+**——边际效用极低 + 过拟合风险极高

### 1.3 为什么 A 股 ML 复杂度有上限

| 限制 | 内容 |
|---|---|
| **样本短** | A 股自 1990 年开始——30+ 年月度数据 = ~ 360 月 |
| **状态转换频繁** | 2017 / 2021 / 2024——每 4-7 年一次状态转换 |
| **信噪比极低** | 金融数据 SNR < 1（vs 图像识别 SNR > 100）|
| **拥挤竞争** | 私募规模 1.5 万亿——同质化策略多 |
| **散户主导** | 散户行为非理性——ML 难以建模 |

---

## 2. Whale-Quant ch08 时序模型概览

### 2.1 ch08 的 3 大主题

> 来源：Whale-Quant 速览：

```
ch08 机器学习与时序预测
├── ch08.1 小波分析（信号处理）
├── ch08.2 LightGBM（监督学习核心）
└── ch08.3 时序模型
    ├── ARIMA（线性时序）
    ├── GARCH（波动率建模）
    ├── RNN（循环神经网络）
    ├── LSTM（长短期记忆）
    └── GRU（门控循环单元）
```

### 2.2 小波分析（ch08.1）

#### 概念

> **小波分析**（Wavelet Analysis）= 把时序信号分解为不同频率的成分。

**直觉**（与 FFT 对比）：

| 维度 | FFT（傅里叶变换）| 小波变换 |
|---|---|---|
| **基函数** | 正弦 / 余弦（全局）| 小波（局部）|
| **时间局部性** | 无 | **有**（能定位"信号出现的时刻"）|
| **适合** | 平稳信号 | **非平稳信号**（金融数据典型）|

#### 在 A 股的应用

| 应用 | 内容 |
|---|---|
| **去噪** | 把价格分解为"低频趋势 + 高频噪声" → 去掉噪声 |
| **多尺度分析** | 同时看日线 / 周线 / 月线 |
| **特征工程** | 把小波系数作为 ML 特征 |

#### 实务建议

- **小波分析 ≠ alpha**——它是工具，不是策略
- **A 股 ML 中作为特征工程的一步**
- 库：`PyWavelets`（Python）

```python
import pywt
import numpy as np

def wavelet_decompose(prices, wavelet='db4', level=4):
    """小波分解价格"""
    coeffs = pywt.wavedec(prices, wavelet, level=level)
    # coeffs[0] = 低频（趋势）
    # coeffs[1:] = 高频（细节，从粗到细）
    return coeffs

def denoise_via_wavelet(prices, wavelet='db4', threshold=0.5):
    """小波去噪"""
    coeffs = pywt.wavedec(prices, wavelet, level=4)
    # 阈值化高频系数
    coeffs_thresh = [coeffs[0]] + [pywt.threshold(c, threshold, mode='soft') for c in coeffs[1:]]
    return pywt.waverec(coeffs_thresh, wavelet)
```

### 2.3 LightGBM（ch08.2 - **核心实战**）

#### LightGBM 是什么

> **LightGBM** = 微软开源的 GBDT 实现——**比 XGBoost 快 3-5 倍**，**内存占用更少**。

**与 GBDT / XGBoost 的对比**：

| 维度 | GBDT | XGBoost | **LightGBM** |
|---|---|---|---|
| **算法** | 标准 GBDT | GBDT + 正则化 | **GBDT + Leaf-wise + Histogram** |
| **速度** | 慢 | 中 | **快**（3-5 倍）|
| **内存** | 高 | 中 | **低** |
| **特征处理** | 一般 | 好 | **优秀**（自动处理类别变量）|
| **业界普及** | 较少 | **广泛**（Kaggle 主流）| **业界量化首选** |

#### A 股 LightGBM 实战

```python
import lightgbm as lgb
import pandas as pd
from sklearn.preprocessing import StandardScaler

def a_share_lightgbm_pipeline(stocks, features, target, periods):
    """A 股 LightGBM 因子合成 pipeline"""
    
    # 1. 数据准备
    X = features  # shape: (N_samples, N_features)
    y = target    # shape: (N_samples,) - 下期收益率
    
    # 2. 时序切分（不能用随机切分）
    train_idx = periods <= '2020-12-31'
    val_idx = (periods > '2020-12-31') & (periods <= '2022-12-31')
    test_idx = periods > '2022-12-31'
    
    # 3. 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X[train_idx])
    X_val_scaled = scaler.transform(X[val_idx])
    X_test_scaled = scaler.transform(X[test_idx])
    
    # 4. LightGBM 训练
    train_data = lgb.Dataset(X_train_scaled, label=y[train_idx])
    val_data = lgb.Dataset(X_val_scaled, label=y[val_idx])
    
    params = {
        'objective': 'regression',
        'metric': 'rmse',
        'num_leaves': 31,           # 控制复杂度
        'learning_rate': 0.05,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1,
        'min_data_in_leaf': 20,     # 防止过拟合
        'lambda_l1': 0.1,           # L1 正则
        'lambda_l2': 0.1,           # L2 正则
    }
    
    model = lgb.train(
        params,
        train_data,
        num_boost_round=500,
        valid_sets=[train_data, val_data],
        callbacks=[lgb.early_stopping(50)],  # early stopping
    )
    
    # 5. 特征重要性
    feature_importance = pd.DataFrame({
        'feature': X.columns,
        'importance': model.feature_importance('gain'),
    }).sort_values('importance', ascending=False)
    
    # 6. 测试集评估
    test_pred = model.predict(X_test_scaled)
    test_ic = pd.Series(test_pred).corr(pd.Series(y[test_idx]))
    
    return {
        'model': model,
        'feature_importance': feature_importance,
        'test_ic': test_ic,
        'best_iteration': model.best_iteration,
    }
```

#### LightGBM 超参调优清单

| 超参 | 推荐范围 | A 股调优建议 |
|---|---|---|
| **num_leaves** | 31-127 | A 股建议 31（不要太复杂）|
| **learning_rate** | 0.01-0.1 | 0.05（保守）|
| **min_data_in_leaf** | 10-100 | **20+**（防过拟合）|
| **feature_fraction** | 0.6-1.0 | 0.8 |
| **bagging_fraction** | 0.6-1.0 | 0.8 |
| **lambda_l1 / l2** | 0-1.0 | **0.1+**（A 股需要更强正则）|

### 2.4 时序模型（ch08.3）

#### ARIMA（自回归 + 积分 + 滑动平均）

**模型**：

$$ARIMA(p, d, q): (1 - \phi_1 L - ... - \phi_p L^p)(1-L)^d X_t = (1 + \theta_1 L + ... + \theta_q L^q)\varepsilon_t$$

- **p**：自回归阶数
- **d**：差分次数（让序列平稳）
- **q**：滑动平均阶数

**A 股应用**：

| 用途 | 推荐 |
|---|---|
| **个股收益率预测** | **不推荐**——A 股个股近似随机游走 |
| **波动率预测** | 不直接用，用 GARCH 替代 |
| **宏观经济指标** | 可用（如 GDP 增长率）|
| **指数（沪深 300）短期预测** | 边缘有效 |

**结论**：**ARIMA 在 A 股个股层面几乎无效**——金融数据近似随机游走 → ARIMA 退化为均值预测。

#### GARCH（广义自回归条件异方差）

**核心创新**：建模**条件方差**（波动率）。

**模型**（GARCH(1,1)）：

$$\sigma_t^2 = \omega + \alpha \cdot r_{t-1}^2 + \beta \cdot \sigma_{t-1}^2$$

**直觉**：

- 当前波动率 = **长期均值 + 上期收益冲击 + 上期波动率持续性**
- **波动率聚集**（volatility clustering）：高波动后跟随高波动

**A 股应用**：

| 用途 | 推荐 |
|---|---|
| **波动率预测** | **强**——比简单 std 更准确 |
| **VaR 计算** | 强——风险管理标配 |
| **期权定价** | 强 |
| **个股 alpha 预测** | 弱（波动率不预测收益）|

**实务实现**：

```python
from arch import arch_model

def fit_garch(returns):
    """拟合 GARCH(1,1)"""
    model = arch_model(returns * 100, vol='Garch', p=1, q=1)
    result = model.fit(disp='off')
    return result

# 预测未来 5 期波动率
forecast = result.forecast(horizon=5)
volatility_forecast = np.sqrt(forecast.variance.values[-1, :])
```

详见 [[volatility-and-other-indicators]] § GARCH 波动率。

#### RNN / LSTM / GRU

##### RNN（最基础）

**问题**：长序列梯度消失。

##### LSTM（长短期记忆）

**结构**：

```
LSTM 单元
├── 遗忘门（forget gate）：决定保留多少前期信息
├── 输入门（input gate）：决定加入多少新信息
└── 输出门（output gate）：决定输出多少
```

**优势**：处理长序列时序信号。

##### GRU（门控循环单元）

**LSTM 的简化版**：

- 合并遗忘门 + 输入门 = 更新门
- 更少参数 → 训练更快
- 性能与 LSTM 相近

#### 在 A 股的应用

**LSTM / GRU 在 A 股的实际有效性**：

| 用途 | A 股有效性 |
|---|---|
| **单股票收益预测** | **极弱**——SNR 太低 |
| **市场指数预测** | 弱 |
| **NLP（财经新闻）** | **中**——但需要大量标注数据 |
| **波动率预测** | **弱**——不如 GARCH |
| **替代数据**（卫星 / 量价微观）| **中-强** |

**A 股化结论**：

- **LSTM / GRU 在 A 股个股层面几乎无效**
- **业界没有"LSTM 强 alpha 策略"成功案例**
- **现代趋势 = LSTM + 注意力机制 + 替代数据**——但工程成本极高

**A 股个人量化建议**：

- **不要花时间研究 LSTM 选股**
- 集中在**特征工程 + GBDT**

---

## 3. Marti 综述 ch2 索引

> 来源：Marti 综述 ch2 监督/无监督/强化学习算法清单——本节**仅作目录索引**，不展开。

### 3.1 监督学习清单

| 算法类型 | 代表 | A 股有效性 |
|---|---|---|
| 线性 | OLS / Ridge / Lasso / Elastic Net | **强**（基础工具）|
| **树模型** | **GBDT / XGBoost / LightGBM / RF** | **强**（业界主流）|
| 邻近 | KNN | 弱 |
| 朴素贝叶斯 | NB | 弱 |
| **SVM** | 线性 / RBF / 多项式 | 中 |
| **神经网络** | MLP / DFN / CNN / RNN / LSTM | 谨慎 |

### 3.2 无监督学习清单

| 算法类型 | 代表 | A 股应用 |
|---|---|---|
| **降维** | **PCA / IPCA / RP-PCA / t-SNE / UMAP** | **隐性因子提取** |
| 聚类 | K-Means / DBSCAN / HDBSCAN | **股票聚类**（行业内分组）|
| 异常检测 | Isolation Forest / LOF | **风控**（极端事件检测）|
| 关联规则 | Apriori / FP-Growth | **跨股票关联** |

### 3.3 强化学习（不推荐）

| 算法 | 在 A 股 |
|---|---|
| Q-Learning / DQN | **几乎无效**（信噪比低）|
| Policy Gradient / PPO | 同上 |
| Actor-Critic / SAC | 同上 |
| AlphaGo 类（MCTS）| 不适用 |

**A 股化建议**：

- **RL 在 A 股是"研究项目"，不是"赚钱工具"**
- **不建议个人量化投入 RL**
- 业界仅头部 1-2 家私募在研究 RL 仓位管理

---

## 4. A 股 ML 实战避坑（6 类核心陷阱）

### 4.1 陷阱 1：时序数据用随机切分（**最常见**）

**错误**：

```python
# 错误！时序数据不能这样切分
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
```

**为什么错**：

- 训练集可能包含**比测试集更晚的数据**
- 等价于"未来函数" → 必过拟合

**正确**：

```python
# 时序切分：按时间顺序
train_end = '2020-12-31'
val_end = '2022-12-31'

train = data[data.date <= train_end]
val   = data[(data.date > train_end) & (data.date <= val_end)]
test  = data[data.date > val_end]
```

### 4.2 陷阱 2：标签噪声 + 数据不平衡

#### 标签噪声

**A 股收益率的肥尾**：

- 月度收益率 mean ≈ 1% / std ≈ 8%
- 但有极端值（如涨停 10% / 跌停 -10% / 重大事件 +30%）

**应对**：

```python
# Winsorize 极端收益率
from scipy.stats.mstats import winsorize

y_winsorized = winsorize(y, limits=[0.01, 0.01])  # 上下各 1%
```

#### 数据不平衡（分类问题）

```python
# 二分类：股票下期是否跑赢市场
y_binary = (returns > market_returns).astype(int)

# 处理类别不平衡
from sklearn.utils.class_weight import compute_class_weight
class_weights = compute_class_weight('balanced', classes=[0, 1], y=y_binary)
```

### 4.3 陷阱 3：特征泄漏（**致命陷阱**）

**典型例子**：

| 错误 | 内容 |
|---|---|
| **未来基本面** | 用 2024-Q3 财报预测 2024-Q3 月初收益（财报在月末才公布）|
| **未来标签** | 用 t+1 期数据预测 t 期 |
| **整体标准化** | 用整个样本（含未来）的均值标准化训练集 |
| **时间泄漏** | 训练集和测试集中的样本时间交叉 |

**正确**：

```python
def proper_feature_engineering(stocks, date):
    """A 股特征工程的 PIT 处理"""
    # 1. 财务数据 PIT
    fundamentals = get_fundamentals_at(stocks, date)  # 只取 date 时点可见的最新报告
    
    # 2. 量价特征用 t-1 之前的数据
    price_features = compute_price_features(
        stocks, 
        start=date - timedelta(days=252),
        end=date - timedelta(days=1),  # 注意 -1
    )
    
    # 3. 标签是 t+1 期收益（不是 t 期）
    label = compute_next_period_return(stocks, date)
    
    return fundamentals, price_features, label
```

### 4.4 陷阱 4：拥挤度未考虑（**A 股特有**）

**问题**：

- 你的 ML 模型样本内表现好
- 但**业界同质化策略多**（聚宽社区 + 公众号已普及）
- **样本外被套利消除**

**A 股 4 个典型拥挤崩塌**（参见 [[empirical-factor-decay-cases]]）：

| 案例 | 时期 |
|---|---|
| 小市值崩塌 | 2017 |
| 白马股崩塌 | 2021 |
| **DMA / 量化指增危机** | 2024 Q1 |

**应对**：

```python
def check_strategy_crowding(factor_returns, factor_universe):
    """评估策略拥挤度"""
    metrics = {
        # 1. 估值价差
        'valuation_spread': compute_pb_spread(factor_universe),
        
        # 2. 配对相关性
        'pair_correlation': compute_holdings_correlation(factor_universe),
        
        # 3. 因子滚动 std
        'rolling_volatility': factor_returns.rolling(60).std().iloc[-1],
        
        # 4. 行业拥挤度（公募 / 私募的相对持仓）
        'institutional_holding': get_inst_holding_pct(factor_universe),
    }
    
    if metrics['valuation_spread'] > 0.6 or metrics['pair_correlation'] > 0.7:
        return "高度拥挤——预期短期表现差"
    return "可接受"
```

### 4.5 陷阱 5：过拟合的"伪信号"

**典型表现**：

| 信号 | 风险 |
|---|---|
| 样本内 IC = 0.10 / 样本外 IC = 0.02 | **过拟合** |
| 样本内夏普 = 3 / 样本外夏普 = 0.5 | **过拟合** |
| 样本内 100% 正收益月 / 样本外 50% | **过拟合** |
| 大量超参微调 → 样本内极好 | **过拟合** |

**应对**：

```python
def detect_overfitting(model, X_train, y_train, X_test, y_test):
    """检测过拟合"""
    train_ic = pd.Series(model.predict(X_train)).corr(pd.Series(y_train))
    test_ic = pd.Series(model.predict(X_test)).corr(pd.Series(y_test))
    
    ratio = test_ic / train_ic
    
    if ratio < 0.5:
        return f"过拟合警告：test_ic / train_ic = {ratio:.2f} < 0.5"
    return f"可接受：test_ic / train_ic = {ratio:.2f}"
```

### 4.6 陷阱 6：部署陷阱（"实盘 vs 回测"差距）

**典型差异**：

| 维度 | 回测 | 实盘 |
|---|---|---|
| **交易成本** | 用历史平均 | **实际更高**（特别是小流动性股票）|
| **滑点** | 假设无 | **实际有**（0.1-0.5%）|
| **冲击成本** | 假设无 | **大单时显著** |
| **流动性** | 假设充足 | **小盘 / 微盘股不足** |
| **执行延迟** | 即时 | **几秒到几分钟** |
| **股票池变化** | 假设稳定 | **新增 / 退市 / ST 变动** |

**应对**：

```python
# 1. 模拟实盘成本
def simulate_realistic_costs(returns, turnover):
    """加入真实交易成本"""
    commission = 0.0003  # 万分之 3
    stamp_tax = 0.001    # 千分之 1（仅卖方）
    slippage = 0.002     # 0.2%
    
    total_cost = (commission * 2 + stamp_tax + slippage) * turnover
    return returns - total_cost

# 2. 容量评估
def estimate_capacity(strategy, max_market_share=0.05):
    """评估策略容量（不超过日成交 5%）"""
    daily_volume = compute_daily_volume(strategy.universe)
    return daily_volume.median() * max_market_share
```

---

## 5. A 股 ML 实战的"端到端"流程

### 5.1 完整 Pipeline

```python
def a_share_ml_pipeline(start_date='2010-01-01', end_date='2024-12-31'):
    """A 股 ML 因子合成完整 pipeline"""
    
    # ============================================================
    # 步骤 1：数据准备
    # ============================================================
    from jqdata import *
    
    stocks = get_index_stocks('000300.XSHG')  # 沪深 300
    
    # ============================================================
    # 步骤 2：特征工程（25 个因子）
    # ============================================================
    features = pd.DataFrame()
    
    # 2.1 趋势 / 反转类（5）
    features['ret_1m']  = compute_return(stocks, n=21)
    features['ret_3m']  = compute_return(stocks, n=63)
    features['ret_12m'] = compute_return(stocks, n=252)
    features['rsrs']    = compute_rsrs(stocks)
    features['ts_max']  = compute_max_close(stocks, n=21)
    
    # 2.2 交易摩擦类（5）—— A 股最强
    features['tvr_1m']     = compute_turnover(stocks, n=21)
    features['tvr_6m']     = compute_turnover(stocks, n=126)
    features['amihud']     = compute_amihud_illiquidity(stocks)
    features['stom_barra'] = compute_stom_barra(stocks)
    features['mom_reversal_1m'] = -compute_return(stocks, n=21)
    
    # 2.3 风险类（5）
    features['ivol']       = compute_ivol(stocks)
    features['beta']       = compute_beta(stocks)
    features['hv_21']      = compute_historical_vol(stocks, n=21)
    features['dastd']      = compute_dastd(stocks)
    features['high_low_1m'] = compute_high_low_range(stocks, n=21)
    
    # 2.4 基本面类（5）
    features['ep']  = 1 / get_pe_ttm(stocks)
    features['gp']  = compute_gross_profit_ratio(stocks)
    features['roe'] = compute_roe(stocks)
    features['roa'] = compute_roa(stocks)
    features['ag']  = compute_asset_growth(stocks)
    
    # 2.5 质量类（5）
    features['f_score']    = compute_f_score(stocks)
    features['debt_ratio'] = compute_debt_ratio(stocks)
    features['cfo_ni']     = compute_cfo_to_net_income(stocks)
    features['quality']    = compute_quality_score(stocks)
    features['mom_1m_industry_neutral'] = compute_industry_neutral_mom(stocks)
    
    # ============================================================
    # 步骤 3：标签（t+1 期收益率）
    # ============================================================
    y = compute_next_month_return(stocks)
    
    # 处理标签异常值
    from scipy.stats.mstats import winsorize
    y = pd.Series(winsorize(y, limits=[0.01, 0.01]), index=y.index)
    
    # ============================================================
    # 步骤 4：时序切分
    # ============================================================
    train_mask = features.index <= '2020-12-31'
    val_mask   = (features.index > '2020-12-31') & (features.index <= '2022-12-31')
    test_mask  = features.index > '2022-12-31'
    
    # ============================================================
    # 步骤 5：训练 LightGBM
    # ============================================================
    import lightgbm as lgb
    
    train_data = lgb.Dataset(features[train_mask], label=y[train_mask])
    val_data   = lgb.Dataset(features[val_mask],   label=y[val_mask])
    
    params = {
        'objective': 'regression',
        'metric': 'rmse',
        'num_leaves': 31,
        'learning_rate': 0.05,
        'feature_fraction': 0.8,
        'min_data_in_leaf': 20,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'verbose': -1,
    }
    
    model = lgb.train(
        params,
        train_data,
        num_boost_round=500,
        valid_sets=[train_data, val_data],
        callbacks=[lgb.early_stopping(50)],
    )
    
    # ============================================================
    # 步骤 6：评估
    # ============================================================
    test_pred = model.predict(features[test_mask])
    test_ic = pd.Series(test_pred).corr(pd.Series(y[test_mask]))
    
    # R²_OOS（用 0 作基准）
    test_residuals = y[test_mask] - test_pred
    r2_oos = 1 - np.sum(test_residuals ** 2) / np.sum(y[test_mask] ** 2)
    
    print(f"Test IC: {test_ic:.4f}")
    print(f"R²_OOS: {r2_oos:.4f}")
    
    # 检测过拟合
    train_pred = model.predict(features[train_mask])
    train_ic = pd.Series(train_pred).corr(pd.Series(y[train_mask]))
    print(f"Train IC: {train_ic:.4f}")
    print(f"OOS / IS ratio: {test_ic / train_ic:.2f}")  # 应 > 0.5
    
    # ============================================================
    # 步骤 7：特征重要性
    # ============================================================
    importance = pd.DataFrame({
        'feature': features.columns,
        'importance': model.feature_importance('gain'),
    }).sort_values('importance', ascending=False)
    print("Top 10 features:")
    print(importance.head(10))
    
    # ============================================================
    # 步骤 8：构建组合
    # ============================================================
    # 每月用预测排序，做多 top 20，等权
    rankings = pd.Series(test_pred).rank(pct=True)
    long_pool = rankings[rankings > 0.95]  # top 5%
    
    # ============================================================
    # 步骤 9：实盘成本调整
    # ============================================================
    portfolio_return = compute_portfolio_return(long_pool, stocks)
    
    realistic_return = simulate_realistic_costs(
        portfolio_return,
        turnover=compute_turnover_rate(long_pool),
    )
    
    return {
        'model': model,
        'feature_importance': importance,
        'test_ic': test_ic,
        'r2_oos': r2_oos,
        'realistic_return': realistic_return,
    }
```

### 5.2 预期结果（A 股现代基准）

| 指标 | 合理区间 | 备注 |
|---|---|---|
| **Train IC** | 0.10-0.15 | 太高（>0.2）= 过拟合 |
| **Test IC** | **0.05-0.10** | **A 股现代水平** |
| **OOS/IS ratio** | **> 0.5** | 过拟合阈值 |
| **R²_OOS（0 基准）** | **0.5-1.5%** | Gu-Kelly-Xiu 阈值 |
| **年化超额（扣成本）** | **5-12%** | 现代沪深 300 增强基准 |
| **夏普** | **0.5-1.0** | |
| **IR** | **0.3-0.8** | |

详见 [[empirical-multi-factor-portfolio]] § 3.1 工业级策略。

---

## 6. MLOps 与特征存储（5.5 待建预告）

### 6.1 A 股 ML 的"工程缺口"

**业界状态**：

- **数据**：jqdatasdk / tushare / Wind / 优矿（多源）
- **特征工程**：自己维护 vs **第三方因子库**（聚宽社区）
- **模型训练**：本地 / 云服务器
- **MLOps**：**A 股个人量化几乎缺失**

### 6.2 推荐工具栈（A 股个人量化）

| 阶段 | 工具 |
|---|---|
| **数据版本控制** | `DVC` / `git-lfs` |
| **特征存储** | `Feast`（开源）/ 自建 Parquet |
| **实验跟踪** | `MLflow`（必装！）|
| **调度** | `Airflow` / `cron` |
| **模型部署** | `joblib`（pickle）/ `ONNX` |

### 6.3 简化版 MLOps 配置

```python
# 用 MLflow 跟踪实验
import mlflow
import mlflow.lightgbm

mlflow.set_experiment("A_share_alpha_v2")

with mlflow.start_run():
    # 记录超参
    mlflow.log_params(params)
    
    # 训练
    model = lgb.train(params, train_data, valid_sets=[val_data])
    
    # 记录指标
    mlflow.log_metric('test_ic', test_ic)
    mlflow.log_metric('r2_oos', r2_oos)
    
    # 记录模型
    mlflow.lightgbm.log_model(model, "model")
```

详见 [[index-05-05-mlops]]（待建）。

---

## 7. A 股 ML 的"绝不"清单

| 绝不 | 原因 |
|---|---|
| **绝不**用随机切分时序数据 | 未来函数 → 必过拟合 |
| **绝不**在测试集上调超参 | 该数据集报废 |
| **绝不**用 LSTM / Transformer 选股 | 信噪比太低，浪费时间 |
| **绝不**忽略 PIT（point-in-time）| 财务数据未来函数最隐蔽 |
| **绝不**用 R²_OOS（历史均值基准）| 美化所有模型 ~3% |
| **绝不**忽略实盘交易成本 | 回测夏普 = 实盘夏普 / 1.5-2 |
| **绝不**单一窗口验证 | 必多窗口（2010-2018 / 2019-2021 / 2022-2024）|
| **绝不**100+ 特征 + 单模型 | 必过拟合 |
| **绝不**忽略拥挤度 | A 股 5 年崩 3 次（小市值 / 白马 / DMA）|
| **绝不**单押 ML 模型 | 必与经典因子集成 |

---

## 8. ML 在 A 股个人量化的"最佳实践"

### 8.1 学习路径

```
M1-M3：基础
  ↓ 学 Python + pandas + 聚宽
M4-M6：经典多因子
  ↓ 5 因子 IC 加权（无 ML）
M7-M12：进阶
  ↓ 添加弹性网络 + GBDT
Y2-Y3：专业
  ↓ XGBoost + 集成 + 严格 OOS
Y3+：研究
  ↓ 可尝试 IPCA / RP-PCA
```

### 8.2 资金规模与 ML 复杂度

| 资金规模 | 推荐复杂度 |
|---|---|
| < 50 万 | L0（5 因子 IC 加权）|
| 50-200 万 | L0-L2（+ 弹性网络）|
| 200-1000 万 | L2-L3（+ GBDT/LightGBM）|
| 1000 万-1 亿 | L3-L4（+ XGBoost 集成）|
| > 1 亿 | L4-L5（+ DFN 谨慎）|

### 8.3 时间投入

| 时间 | 推荐内容 |
|---|---|
| **20%** | 特征工程（最关键）|
| 30% | 模型训练 |
| **30%** | **样本外验证 + 严格回测** |
| 10% | 实盘部署 |
| 10% | 监控 + 拥挤度分析 |

---

## 综合观察

- **A 股 ML 的"最佳路径"**：5 因子 IC 加权（L0）→ 弹性网络（L2）→ GBDT/LightGBM（L3）
- **不要追求复杂模型**：A 股样本短 + 信噪比低 → 过拟合风险极高
- **A 股最重要特征 = 交易摩擦类**（vs 美股的趋势类）
- **LSTM / Transformer / RL 在 A 股几乎无效**——别浪费时间
- **特征工程 > 模型选择**——"垃圾进 → 垃圾出"
- **时序切分 + PIT 处理 + Shanken 修正**是 A 股 ML 的"3 大底线"
- **A 股拥挤崩塌频繁**（5 年崩 3 次）——必须监控拥挤度
- **MLOps 是 A 股个人量化的最大工程缺口**——用 MLflow + DVC 弥补
- **ML 不取代经典多因子**——**集成是最佳路径**
- **真正的 A 股 ML alpha 来自严格的工程纪律**，不是复杂的算法

## 美股 ETF 案例补充：LightGBM 单标的择时的失败

> 来源：[XLK→161128 LOF 项目 Phase 3 F.1](../../03_策略原型/3.2_择时策略/XLK_161128_研究结论汇总.md)（2026-05）

### 背景

测试 LightGBM 监督学习能否超越简单线性合成（PA Champion v1）作为 161128 LOF 择时信号。
- 标的：单一 LOF（161128，跟踪标普 500 IT 指数）
- 特征：12 个因果特征（XLK 多 MA 偏离、Top4 股偏离、波动率、动量、VIX）
- 目标：未来 5 日累计 LOF 收益（连续回归）
- 模型：LightGBM Regressor，max_depth=4, n_est=100, min_child_samples=20（抗过拟合）

### 结果（3 种 position 映射 × walk-forward 4 splits）

| 模式 | Mean Sharpe | vs baseline (Sharpe 1.317) |
|---|---|---|
| sign（>0 满仓）| 0.054 | -1.263 |
| tertile（三分）| 0.211 | -1.107 |
| **continuous (sigmoid)** | **0.694** | **-0.624** |

**3/3 模式全失败**。最优 continuous 仍弱于简单 50/50 PosAvg 0.62 Sharpe。

### 失败原因（与 A 股 ML 案例一致）

1. **样本太小**：1500 天 × 12 特征 → 模型容量超过信息容量
   - A 股 ML sweet spot 是 50-100 因子 × 几千股票 × N 天
   - 单标的择时只有 6-12 候选特征 → **GBDT 无法发挥**

2. **标签噪声大**：5 日 forward 收益方差极大（COVID 单周可 ±10%）

3. **PA Champion 信号已最优**：F.4 风险归因显示 PA 80% alpha 来自"空仓避险"
   - 二元决策用 GBDT 反而引入噪声
   - 简单线性合成已捕获核心 alpha

4. **Regime shift**：2023 AI 大涨与之前 3 年差异极大
   - LightGBM 用"全期数据"训练，难以适应
   - 简单状态机 + EMA 平滑反而自然抗 regime shift

### 重要发现：特征重要性指出意外信号

LightGBM 最看重的特征排名：

| 排名 | 特征 | importance |
|---|---|---|
| 1 | **xlk_vol_ratio (20d/60d 波动率比)** | **146** |
| 2 | xlk_vol_20d | 103 |
| 3 | xlk_close_vs_ma60 | 89 |
| 4 | vix_level | 78 |
| 5 | avgo_close_vs_ma13 | 70 |

**反直觉发现**：LightGBM 最看重的是**波动率比率**，不是任何 MA 偏离/动量。

这个发现**间接帮助**了后续的策略改进 — Phase 4 H.3 用 vol_ratio < 0.7 作为"低噪声加仓"信号，成功改善 PA Champion v2 → v2.1（详见 [反应式风控的失败.md](../../05_工程与回测/5.4_回测陷阱清单/反应式风控的失败.md) 案例 5）。

→ **LightGBM 本身失败，但作为"特征探索工具"有价值**。

### 跨市场教训：A 股 ML 经验直接迁移 XLK 失败

| A 股 ML 推荐 | 美股 ETF 实测 |
|---|---|
| 50-100 因子 sweet spot | 12 因子根本不够（单标的的固有限制）|
| 5d forward return target | 噪音过大，标签 t < 1.0 |
| L3 GBDT 通常优于 L1 线性 | **GBDT 反而比简单 50/50 PosAvg 差** |
| ML 取代经典多因子 | **简单合成 + EMA + 状态机已是数学最优** |

**核心结论**：A 股 ML 推荐**不能直接迁移到单标的择时场景**。模型选择不是关键，**特征数量 × 标签信噪比**才是。

### 实践指南

- 单标的（ETF / 指数）择时：**用简单状态机 + 多因子线性合成**，**不要用 GBDT/LSTM/Transformer**
- ML 适用：**多股票横截面 / 因子选股** —— 50+ 候选特征 × 几千股票
- ML 失败时不要继续尝试 LSTM/Transformer（容量更大，过拟合更严重）

> **完整对比 → [趋势策略的风控边界.md](../../03_策略原型/3.2_择时策略/趋势策略的风控边界.md)**

## 参考与延伸

- [INDEX.md](INDEX.md) — 1.5 板块索引
- [因子投资中的ML综述.md](因子投资中的ML综述.md) — Gu-Kelly-Xiu 综述
- [[empirical-single-factor-table]] — A 股最强 5 alpha（交易摩擦类）
- [[empirical-multi-factor-portfolio]] — A 股 ML 现代基准
- [[empirical-factor-decay-cases]] — A 股 4 个失效案例（含 DMA 2024）
- [[ic-test-and-combination]] — IC 加权（ML 的 baseline）
- [[backtest-data-pitfalls]] — A 股数据陷阱（含 PIT）
- [[backtest-factor-decay]] — 因子衰减与拥挤
- [[independent-vs-institution-capacity-constraints]] — Chan 容量论与 ML 的关系
- [[behavioral-finance-and-investor-sentiment]] § PLS 合成 — ML 在情绪上的应用
- [[index-04-04-trading-cost-capacity]] — 实盘成本与回测调整
- [[volatility-and-other-indicators]] § GARCH — 波动率建模
- [Whale-Quant ch08](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/速览_whale_quant.md) — 时序模型详解
- [因子投资 ch6.8](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — Gu-Kelly-Xiu 原文综述
- [反应式风控的失败.md](../../05_工程与回测/5.4_回测陷阱清单/反应式风控的失败.md) — 美股 ETF 完整 4 案例（含 LightGBM）
- [趋势策略的风控边界.md](../../03_策略原型/3.2_择时策略/趋势策略的风控边界.md) — 元结论

[← 返回 1.5 索引](INDEX.md)
