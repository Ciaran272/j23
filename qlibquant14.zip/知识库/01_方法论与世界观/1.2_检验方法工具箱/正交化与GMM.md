---
name: orthogonalization-and-gmm
description: 因子正交化（施密特过程 + 几何意义）+ 广义矩估计 GMM（三部分框架 + 通用资产定价工具）
category: 01_方法论与世界观/1.2_检验方法工具箱
tags: [因子正交化, 施密特正交化, 几何意义, GMM, 广义矩估计, Hansen, 通用框架]
created: 2026-05-17
updated: 2026-05-17
source: 原始资料文件/因子投资方法与实践/因子投资方法与实践.md (ch2.6 + ch2.7)
status: stable
---

# 因子正交化与 GMM

## TL;DR

**两个高级方法**：

1. **因子正交化**（ch2.6）：用施密特正交化过程**剔除已知因子的影响**，让新因子的"增量贡献"显化
2. **广义矩估计（GMM）**（ch2.7）：**所有资产定价检验的"母体"** —— Hansen (1982) 诺奖工作

**核心 A 股化建议**：

- **正交化是业界常用工具**：因子 A 对因子 B 正交后，残差才是 A 的"真实独立信号"
- **GMM 是研究级工具**：实务中很少直接用，但理解它能更深入理解 GRS / Fama-MacBeth / Newey-West 的本质
- **OCR 警告**：ch2.7 是**全书 OCR 损坏第二严重**的章节（仅次于 ch7.2 Barra 推导）—— **任何 GMM 公式抄写必须回原文 PDF**

## 来源

- **因子投资 ch2.6 因子正交化**（行 1286-1428）
- **因子投资 ch2.7 广义矩估计**（行 1429-1773）—— **数学密度最高 / OCR 损坏最严重**

**OCR 校对警告（重要）**：

> 因子投资 ch2.7 是全书数学最复杂的一节，OCR 在以下位置严重损坏：
> - 矩条件（moment conditions）的求和符号
> - 协方差矩阵的下标错位
> - 三部分框架（2.7.2 / 第二部分 GMM）的矩阵公式
>
> **本文档不展开完整 GMM 推导**——抄公式必须回 [因子投资_origin.pdf 第 2.7 节](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践_origin.pdf)。

---

## 1. 因子正交化（ch2.6）

### 1.1 为什么需要正交化

**核心问题**：

```
因子 A（如 BM）→ 显著
因子 B（如 EP）→ 显著
但 A 和 B 高度相关
   ↓
A 是否在 B 之外有"增量贡献"？
   ↓
正交化：把 B 的影响从 A 中剔除，看残差是否显著
```

**典型场景**：

| 场景 | 正交化的作用 |
|---|---|
| BM 因子 vs EP 因子 | 看 BM 是否在 EP 之外有独立价值 |
| 动量因子 vs 短期反转 | 看 12 月动量是否独立于 1 月反转 |
| 残差动量 | 剥离行业 / 市值后的动量 |
| 多因子合成的去重 | 避免因子高度共线 |

### 1.2 施密特正交化（Gram-Schmidt orthogonalization）

**核心思想**：把一组**线性相关的因子**变成**两两正交的因子**。

**步骤**（K 个因子 $f_1, f_2, ..., f_K$）：

```
1. 取 f_1 作为基底 e_1 = f_1
2. 把 f_2 投影到 e_1 → 投影部分 = β_{2,1} e_1
   残差 = f_2 - β_{2,1} e_1 = e_2（与 e_1 正交）
3. 把 f_3 投影到 e_1, e_2 → 投影部分
   残差 = f_3 - β_{3,1} e_1 - β_{3,2} e_2 = e_3（与 e_1, e_2 正交）
4. ... 一直到 f_K
   ↓
得到 e_1, e_2, ..., e_K（两两正交，但保持线性张成空间不变）
```

### 1.3 回归的几何意义

> 因子投资 ch2.6.2 的关键洞察：

**多元回归 $y = X b + \varepsilon$ 的几何含义**：

```
y = b_1 x_1 + b_2 x_2 + ... + b_K x_K + ε

几何上：
- y 是 T 维空间的一个向量
- {x_1, ..., x_K} 张成一个 K 维子空间
- 回归 = 把 y 投影到这个子空间
- 投影向量 = b_1 x_1 + b_2 x_2 + ... + b_K x_K
- 残差 ε = y - 投影向量（与子空间正交）
```

**关键性质**：

- **残差 ε 与所有 x_i 正交**（这就是 OLS 一阶条件）
- 残差代表 y 中**无法被 X 解释的部分**

### 1.4 用正交化求解多元回归

**等价做法（数值稳定）**：

```
不直接求解 y = X b + ε
   ↓
先对 X 做施密特正交化得 e_1, ..., e_K
   ↓
对每个 e_k 单独做一元回归（因为它们两两正交）
   y = c_1 e_1 + c_2 e_2 + ... + c_K e_K + ε
   ↓
再把 c 转回 b
```

**实务意义**：

- **数值稳定**：避免共线性导致的矩阵 ill-conditioning
- **直观解释**：每个 e_k 的系数 c_k 就是该正交化后因子的"纯独立贡献"
- **多因子合成的核心工具**

### 1.5 A 股中的正交化应用

**典型用法**：

#### 1.5.1 残差动量（去掉行业 / 风格影响）

```python
def residual_momentum(returns, industry_dummies, size_factor):
    """残差动量 = 个股收益率剔除行业 + 市值后的动量"""
    # 1. 个股收益率 vs 行业 / 市值回归
    X = pd.concat([industry_dummies, size_factor], axis=1)
    residuals = ols(returns, X).resid  # 残差

    # 2. 用残差算动量
    rsi_residual = residuals.rolling(252).mean() / residuals.rolling(252).std()
    return rsi_residual
```

**A 股实证**：

- **原始动量** 12 月：A 股 t ≈ 1（不显著）
- **残差动量** 12 月：A 股 t > 2（边缘显著）
- 详见 [[index-02-04-fundamental-factors]] § 动量因子

#### 1.5.2 因子合成的去重

```python
def orthogonalize_factors(factors_df):
    """把高度相关的因子做正交化"""
    from sklearn.preprocessing import StandardScaler
    import numpy as np

    # Z-score
    scaled = StandardScaler().fit_transform(factors_df)

    # QR 分解（等价于施密特正交化）
    Q, R = np.linalg.qr(scaled)

    return pd.DataFrame(Q, index=factors_df.index, columns=factors_df.columns)
```

#### 1.5.3 Barra 风险归因（详见 [[risk-attribution-three-factor]]）

**Barra 模型的核心**：

```
个股收益率 = 国家因子 + 行业因子 + 风格因子 + 残差
        ↑          ↑          ↑         ↑
        所有股票      多个       9 个     特质
        共暴露 1     行业       风格      α 候选
```

**因子之间需要正交化**——避免协方差矩阵的奇异性。

详见 [[barra-cne5-model]] § 因子正交化。

### 1.6 正交化的实务建议

| 应用 | 推荐 |
|---|---|
| 检验新因子的独立性 | **对已知因子做正交化**——看残差 α t 值 |
| 多因子合成 | **不必正交化**——直接 IC 加权（详见 [[ic-test-and-combination]]）|
| Barra 风格因子 | **必须正交化**——避免共线 |
| 残差动量 / 残差波动率 | **必须正交化**——剔除已知风险 |

---

## 2. 广义矩估计 GMM（ch2.7）

### 2.1 历史地位

**Hansen (1982)** 提出 **GMM（Generalized Method of Moments）** —— **2013 年诺贝尔经济学奖**（与 Fama / Shiller 同年）。

**GMM 的地位**：

> "**Cochrane (2005) Asset Pricing** 把 GMM 推为资产定价的"通用语言"——所有具体方法（OLS / IV / Fama-MacBeth / GRS / 卡尔曼滤波）都是 GMM 的特例。"

### 2.2 GMM 的核心思想

**直觉**：

```
任何资产定价模型都可写成"矩条件（moment conditions）"形式：
   E[g(x_t, θ)] = 0
   
   其中：
   - x_t 是数据
   - θ 是未知参数
   - g(.) 是从模型推出的函数

GMM 的目标：找到 θ̂ 使得样本矩 ḡ(θ̂) 尽可能接近 0
   ↓
具体做法：最小化 ḡ(θ̂)' W ḡ(θ̂)（W 是加权矩阵）
```

### 2.3 GMM 的三部分分析框架（因子投资 ch2.7.2）

**Hansen (1982) 的三部分框架**：

| 部分 | 内容 |
|---|---|
| **矩条件**（moment conditions）| 从理论模型推出的 E[g(x, θ)] = 0 |
| **加权矩阵**（weighting matrix）| 决定如何"加权"不同矩条件——影响估计效率 |
| **检验**（overidentifying test）| Hansen J 统计量——检验所有矩条件是否同时为 0 |

### 2.4 GMM 的特例（重要）

**GMM 的强大之处**：所有经典方法都是它的特例。

| 经典方法 | GMM 的特例 |
|---|---|
| **OLS** | 矩条件 $E[X'\varepsilon] = 0$ + 单位加权 |
| **IV**（工具变量）| 矩条件 $E[Z'\varepsilon] = 0$ + 单位加权 |
| **Fama-MacBeth** | 矩条件 + 两步 GMM |
| **GRS 检验** | 假设正态 + 有限样本 → F 分布 |
| **Newey-West** | GMM 的协方差矩阵估计 |
| **CCAPM** | 矩条件 $E[m_t R_t] = 1$（m 是 SDF）|

**学这一个 → 理解所有**。

### 2.5 GMM 的优势

| 优势 | 含义 |
|---|---|
| **不需要分布假设**（无需正态）| 比 GRS 适用更广 |
| **大样本性质好** | 一致性 + 渐进正态性 |
| **支持过度识别检验**（Hansen J）| 检验所有矩条件是否兼容 |
| **统一框架** | OLS / IV / FM / Newey-West 都是 GMM |

### 2.6 GMM 的应用：检验 CCAPM

**Consumption-based CAPM**：

$$E[m_t R_t^e] = 0, \quad m_t = \delta \left(\frac{C_{t+1}}{C_t}\right)^{-\gamma}$$

- $m_t$：随机贴现因子（SDF），基于消费的相对增长率
- $\delta$：折现率
- $\gamma$：相对风险厌恶系数

**Hansen (1982) 用 GMM 检验**：

- 矩条件：$E[m_t R_t^e] = 0$
- 参数：$(\delta, \gamma)$
- **结果**：实证拒绝 CCAPM——这是"消费基础资产定价的拒绝"

**意义**：GMM 不只检验线性多因子模型，还能检验**非线性 SDF 模型**——因此比 GRS 更通用。

### 2.7 GMM 在因子投资中的角色

#### 2.7.1 检验因子是否被定价

```
factor_t 被定价 ⟺ E[m_t × factor_t] = λ
                        ↑
                   用 GMM 估计
```

#### 2.7.2 与 FF 时序回归 / 截面回归的关系

- **FF 时序回归**：是 GMM 的特例（特定矩条件）
- **截面回归 + Shanken 修正**：可以用 GMM 自然推出
- **Newey-West 估计量**：是 GMM 协方差矩阵估计的应用

#### 2.7.3 当 OLS 假设失败时

- **OLS 失败原因**：异方差 / 自相关 / IV 内生性 / 非线性
- **GMM 全部能处理**

### 2.8 GMM 在 A 股研究中的应用

**学术 A 股研究**：

- **Liu et al. (2019) CH-3 模型**：用 GMM 估计因子收益率
- **国内顶刊（管理科学）**：FM 回归 + GMM 标准做法

**业界**：

- **业界几乎不用 GMM**——计算复杂、不直观、需要专业训练
- 业界用 OLS + NW 调整 = "GMM 的简化"

### 2.9 GMM 不应成为黑箱（ch2.7.5）

**因子投资 ch2.7.5 的警告**：

> "**GMM 不应成为黑箱**——任何严肃的因子检验研究员都应理解 GMM 框架。"

**为什么**：

- 看到论文用"GMM 检验" → **能判断作者是否真的懂**
- 自己用 GMM 时 → 能正确选择矩条件 + 加权矩阵
- 看到 NW 调整 → **理解它是 GMM 的协方差估计的应用**

### 2.10 学习建议

| 难度 | 推荐资料 |
|---|---|
| **入门**（理解 GMM 是什么）| 因子投资 ch2.7（精读 + 回原文校对）|
| **进阶**（自己实现 GMM）| **Cochrane (2005) Asset Pricing** 全书 |
| **顶级**（GMM 顶刊应用）| Hansen (1982) 原文 + Greene (2017) Econometric Analysis |
| **国内** | **管理科学**期刊的资产定价类论文 |

---

## 3. 实务结合：正交化 + GMM

### 3.1 工业级因子合成的工作流

```
1. 取候选因子 {f_1, f_2, ..., f_K}
   ↓
2. 计算两两相关性
   ↓
3. 高相关组（|ρ| > 0.5）做正交化（施密特 / QR 分解）
   ↓
4. 每个正交化后的因子单独做 NW 调整时序回归
   ↓
5. IC 加权合成
   ↓
6. 用 GRS 检验合成因子是否独立于已知因子（如 FF3 / CH-3）
   ↓
7. 若独立 + α t 值 > 3 → 真正的新 alpha
   否则 → 与已知共线，丢弃
```

### 3.2 残差动量的完整实现

```python
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


def residual_momentum_a_share(returns, industry_dummies, market_cap, lookback=252):
    """A 股残差动量
    
    剥离行业 + 市值后的动量信号。
    """
    # 1. 在每个时点做时序回归：returns = β_industry × industry + β_size × size + ε
    residuals = pd.DataFrame(index=returns.index, columns=returns.columns)

    for date in returns.index:
        for stock in returns.columns:
            recent_returns = returns.loc[:date, stock].tail(lookback)
            recent_industry = industry_dummies.loc[:date].tail(lookback)
            recent_size = market_cap.loc[:date, stock].tail(lookback)

            X = pd.concat([recent_industry, recent_size], axis=1)
            model = LinearRegression().fit(X, recent_returns)
            residuals.loc[date, stock] = recent_returns - model.predict(X)

    # 2. 残差动量
    momentum = residuals.rolling(252).mean() / residuals.rolling(252).std()
    return momentum


# 检验
def test_residual_momentum_vs_raw():
    """对比原始动量 vs 残差动量"""
    # 假设已有数据
    raw_momentum_t = compute_factor_nw_t(raw_momentum)
    res_momentum_t = compute_factor_nw_t(residual_momentum)

    print(f"原始 12 月动量 t = {raw_momentum_t:.2f}")    # 通常 < 1
    print(f"残差 12 月动量 t = {res_momentum_t:.2f}")    # 通常 > 2

    # A 股实证：残差动量恢复显著性
```

### 3.3 GMM 在 A 股的"实操级"建议

**对一般的 A 股因子研究员**：

| 任务 | 推荐工具 |
|---|---|
| 单因子检验 | **OLS + NW 调整** |
| 多因子合成 | **正交化 + IC 加权** |
| 模型比较 | **GRS + α 检验** |
| 异象检验 | **时序回归 + NW** |
| **GMM** | **理解原理即可——实务用 OLS + NW 替代** |

**只有以下情况才需要直接用 GMM**：

1. 非线性 SDF 模型（如 CCAPM）
2. 工具变量（IV）问题
3. 同时检验线性 + 非线性矩条件
4. 学术发表（严肃论文标配）

---

## 4. A 股化注记

### 4.1 正交化的常见场景

| 场景 | 推荐 |
|---|---|
| 价值因子 BM / EP / SP 共线 | **PCA 或正交化**——只保留 1-2 个 |
| Barra 10 大风格 | **必须正交化**——否则协方差不可逆 |
| 行业中性化 | **回归正交化**——残差作 alpha |
| 动量 + 反转 | **残差动量** vs 原始动量 |
| 高相关因子组 | **PCA 合成** 或 **施密特正交化** |

### 4.2 OCR 损坏的处理

**因子投资 ch2.7 GMM 推导是全书 OCR 第二严重**：

| 损坏类型 | 处理 |
|---|---|
| 矩条件求和符号 | **回 PDF 第 2.7 节核对** |
| 加权矩阵下标 | **回 PDF 第 2.7.2 节** |
| Hansen J 统计量 | **回 PDF 第 2.7.4 节** |
| 概念理解 | **用本文档的概念性描述足够** |

**建议工作流**：

1. **先读本文档** → 理解 GMM 是什么、能做什么
2. **再读因子投资 ch2.7** → 看公式但**先不抄**
3. **如果需要抄公式** → **必须打开 origin.pdf 第 2.7 节核对**

### 4.3 与 Cochrane (2005) 的对应

**Cochrane Asset Pricing** 是 GMM 的"圣经"：

| 因子投资 ch2.7 | Cochrane ch10-11 |
|---|---|
| 2.7.1 样本均值的方差 | Cochrane ch10.1 |
| 2.7.2 分析框架 | **Cochrane ch10.2 / 11**（最完整）|
| 2.7.3 数学基础 | Cochrane ch11 |
| 2.7.4 有效性 | Cochrane ch11.4 |

**严肃研究者建议**：**直接读 Cochrane**——更全、更严谨。

---

## 5. 综合实务工作流

### 5.1 严肃论文的因子研究

```
1. 排序法 + t 检验（初筛）
2. 时序回归 + NW 调整（基础检验）
3. Fama-MacBeth + Shanken 修正（截面）
4. 正交化（剔除已知因子）
5. GRS / α 检验（联合 / 单独检验）
6. GMM（顶刊标配，可用 Cochrane 代码）
7. 因子持久性检验（不同窗口）
8. 拥挤度监控（详见 [[empirical-factor-decay-cases]]）
```

### 5.2 业界量化的简化版

```
1. 单变量排序（初筛）
2. NW 调整时序回归（信号验证）
3. 正交化（去重）
4. IC 加权合成
5. 与基准对比（α 检验）
6. 拥挤度监控
```

---

## 综合观察

- **正交化是业界 + 学术共用工具**——剔除已知因子的影响
- **施密特正交化 = 多元回归的几何本质**——把多元回归变成 K 个一元回归
- **GMM = 所有方法的"母体"**——OLS / IV / FM / GRS / NW 都是它的特例
- **GMM 不应成为黑箱**——研究员应理解原理（但实务可用 NW 替代）
- **A 股的残差动量** vs 原始动量是经典正交化应用——能让动量"复活"
- **ch2.7 GMM 推导 OCR 极重**——抄公式必须回 PDF
- **业界简化版工作流**：排序 + NW + 正交化 + IC 合成 + 拥挤度监控

## 参考与延伸

- [INDEX.md](INDEX.md) — 1.2 板块索引
- [排序法与回归检验.md](排序法与回归检验.md) — 排序 + 三种回归
- [异象检验与模型比较.md](异象检验与模型比较.md) — NW / GRS / 张成检验
- [[index-01-01-unified-view]] — 统一视角公式（GMM 是公式检验的母体）
- [[barra-cne5-model]] — Barra 模型的正交化应用
- [[risk-attribution-three-factor]] — 业绩归因 + 正交化
- [[ic-test-and-combination]] — IC 加权合成 + 正交化
- [[empirical-factor-decay-cases]] — 因子衰减 + 拥挤度
- [因子投资 ch2.6-2.7](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — 完整原文
- **Cochrane (2005) Asset Pricing** — GMM 的圣经

[← 返回 1.2 索引](INDEX.md)
