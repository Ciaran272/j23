---
name: ic-test-and-combination
description: 单因子 IC 检验 + 因子合成 4 种方法（等权 / IC 加权 / IR 加权 / PCA / Logistic 监督学习）+ Python 实战 ch6.2 的 4 步法
category: 03_策略原型/3.1_多因子选股
tags: [IC, IR, 单因子检验, 因子合成, Python实战, jqfactor_analyzer]
created: 2026-05-16
updated: 2026-05-16
status: draft
---

# 单因子 IC 检验与多因子合成

## TL;DR

**单因子 IC 检验**回答"这个因子有没有预测力"；**多因子合成**回答"多个因子怎么组合成一个最终信号"。本文给出 IC 的 4 种定义 + 单因子检验完整流程 + 4 种合成方法（等权 / IC 加权 / IR 加权 / PCA / 监督学习），含聚宽 / jqfactor_analyzer 实现。

## 来源

- **因子投资 ch2.2-2.5**：[因子投资方法与实践.md](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) —— 学术严谨方法论
- **Python 实战 ch6.2**：[Python量化交易实战.md](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) —— **IC 合成 4 步法**（实操，OCR 已校对）
- **聚宽 jqfactor_analyzer**：https://github.com/JoinQuant/jqfactor_analyzer —— 业界工具
- 详细方法论见 [[index-01-methodology]] 1.2

---

## IC 的 4 种定义

**IC = Information Coefficient = 因子值与未来收益的相关系数**。但具体计算有 4 种变体：

### 1. 截面 Pearson IC

$$IC_t = \text{Pearson Corr}(f_{i,t}, R_{i,t+1})$$

- 同一时点，跨所有股票，**因子值与下一期收益的 Pearson 相关**
- 输出一个时间序列：每个时点一个 IC 值

### 2. 截面 Rank IC（Spearman IC）

$$IC^{rank}_t = \text{Spearman Corr}(f_{i,t}, R_{i,t+1}) = \text{Pearson Corr}(\text{rank}(f_{i,t}), \text{rank}(R_{i,t+1}))$$

- 用排位做相关，**对极值不敏感**
- **A 股实务首选**（因为收益分布右偏明显）

### 3. 时序 IC（按股票）

$$IC^{ts}_i = \text{Corr}(f_{i,t}, R_{i,t+1})$$

- 同一只股票，跨时间，因子值与下期收益的相关
- 不常用 —— 信号量级随股票而异，可比性差

### 4. 加权 IC

$$IC^w_t = \frac{\sum_i w_i \cdot (f_{i,t} - \bar{f}_t)(R_{i,t+1} - \bar{R}_{t+1})}{\sqrt{\sum_i w_i (f_{i,t} - \bar{f}_t)^2} \sqrt{\sum_i w_i (R_{i,t+1} - \bar{R}_{t+1})^2}}$$

- 权重 $w_i$ 可用市值的平方根（与 Barra 一致）
- 抑制小市值股票的噪声

**实务建议**：用 **Rank IC**。

### IC 实现（聚宽）

```python
import pandas as pd
import numpy as np

def cross_section_ic(factor: pd.DataFrame, returns: pd.DataFrame, method='spearman') -> pd.Series:
    """计算截面 IC 序列
    
    factor: (date, code) 宽表，因子值
    returns: (date, code) 宽表，下期收益（已 shift(-1)）
    method: 'spearman' (Rank IC) / 'pearson'
    """
    ics = []
    for date in factor.index:
        f = factor.loc[date]
        r = returns.loc[date]
        common = f.index.intersection(r.index)
        f, r = f.loc[common], r.loc[common]
        valid = f.notna() & r.notna()
        if valid.sum() < 30:
            ics.append(np.nan)
            continue
        if method == 'spearman':
            ic = f[valid].rank().corr(r[valid].rank())
        else:
            ic = f[valid].corr(r[valid])
        ics.append(ic)
    return pd.Series(ics, index=factor.index)
```

---

## 单因子检验关键指标

```python
ic_series = cross_section_ic(factor, returns_next, method='spearman')

# 1. IC 均值
ic_mean = ic_series.mean()

# 2. IC 标准差
ic_std = ic_series.std()

# 3. ICIR = IC 信息比率（核心指标）
icir = ic_mean / ic_std

# 4. IC t 值（显著性）
ic_tstat = ic_mean / (ic_std / np.sqrt(len(ic_series)))

# 5. IC 胜率
ic_winrate = (ic_series > 0).mean()  # 正向因子的话

# 6. IC 偏度（极端值多不多）
ic_skew = ic_series.skew()
```

**经验阈值**（学术 / 实务参考）：

| 指标 | 经验阈值 | 含义 |
|---|---|---|
| `\|IC 均值\|` | > 0.02 | 因子有微弱预测力 |
| `\|IC 均值\|` | > 0.05 | 因子较好 |
| `ICIR` | > 0.5 | 因子稳健 |
| `ICIR` | > 1.0 | 因子优秀 |
| `IC t 值` | > 2 | 显著 |
| `IC 胜率` | > 55% | 方向稳定 |

**注意**：单一指标不可独立看。一个 IC 均值 0.10 但 ICIR 0.3 的因子不如 IC 均值 0.04 但 ICIR 1.0 的因子稳健。

---

## Python 实战 ch6.2 的 IC 合成 4 步法

王晓华《Python 量化交易实战》ch6.2 给出实操版的 IC 合成 4 步法（OCR 校对版）：

### 第 1 步：计算因子与收益率的回归系数

对每个因子 $k$，每期 $t$，做截面回归：

$$R_{i,t+1} = \beta_{k,t} \cdot f_{k,i,t} + \varepsilon_{i,t+1}$$

得到该因子在 t 期的"截面回归系数" $\beta_{k,t}$。

```python
def factor_return(factor_k: pd.DataFrame, returns_next: pd.DataFrame) -> pd.Series:
    """计算因子 k 的因子收益率序列"""
    from sklearn.linear_model import LinearRegression
    fr = []
    for date in factor_k.index:
        f = factor_k.loc[date].dropna()
        r = returns_next.loc[date].loc[f.index].dropna()
        common = f.index.intersection(r.index)
        if len(common) < 30:
            fr.append(np.nan)
            continue
        reg = LinearRegression().fit(f.loc[common].values.reshape(-1, 1), r.loc[common].values)
        fr.append(reg.coef_[0])
    return pd.Series(fr, index=factor_k.index)
```

### 第 2 步：计算下一期股票收益率

简单：`returns_next = close.pct_change().shift(-1)`，即用未来一期的收益。

### 第 3 步：计算预期与真实收益率的相关系数（IC 值）

对每个因子，每期：

$$IC_{k,t} = \text{Corr}(\hat{R}_{k,i,t+1}, R_{i,t+1})$$

其中 $\hat{R}_{k,i,t+1} = \beta_{k,t} \cdot f_{k,i,t}$ 是用因子 k 单独预测的下期收益。

实际中由于 $\hat{R}_{k,i,t+1}$ 与 $f_{k,i,t}$ 同方向（只差常数 $\beta_{k,t}$），$IC_{k,t}$ 直接等价于因子值与下期收益的相关——回到上文的"截面 IC"。

### 第 4 步：等权法合成

把 N 个有效因子等权合成：

```python
def equal_weight_combine(factors: dict, returns_next: pd.DataFrame) -> pd.DataFrame:
    """等权合成多因子
    
    factors: {factor_name: pd.DataFrame}
    """
    standardized = {}
    for name, f in factors.items():
        # 截面 z-score
        standardized[name] = f.sub(f.mean(axis=1), axis=0).div(f.std(axis=1), axis=0)
    
    # 等权平均
    combined = sum(standardized.values()) / len(standardized)
    return combined
```

**说明**：Python 实战 ch6.2 这一步是"等权"，但实务中通常会再加权重——见下文 4 种合成方法。

---

## 4 种合成方法

### 方法 1：等权（最朴素）

```python
combined = (f1.rank(axis=1, pct=True) + 
            f2.rank(axis=1, pct=True) + 
            f3.rank(axis=1, pct=True)) / 3
```

**适用**：因子之间相关性低 + 都有效；快速 prototype。

**问题**：忽略因子的预测力差异。

---

### 方法 2：IC 加权

按每个因子的历史 IC 均值加权：

```python
def ic_weighted_combine(factors: dict, ic_series: dict, lookback: int = 60) -> pd.DataFrame:
    """IC 加权合成（用过去 lookback 期 IC 均值作权重）"""
    # 每期权重 = 过去 60 期的 IC 均值
    weights = pd.DataFrame({
        name: ic_series[name].rolling(lookback).mean()
        for name in factors
    })
    
    # 归一化权重（绝对值和为 1）
    weights = weights.div(weights.abs().sum(axis=1), axis=0)
    
    # 因子标准化
    standardized = {
        name: f.sub(f.mean(axis=1), axis=0).div(f.std(axis=1), axis=0)
        for name, f in factors.items()
    }
    
    # 加权合成
    combined = sum(standardized[name].mul(weights[name], axis=0) for name in factors)
    return combined
```

**适用**：因子之间相关性低，每个因子的 IC 序列稳定。

**问题**：IC 高但 IC 波动大的因子被高估。

---

### 方法 3：IR 加权（推荐）

按 ICIR 加权（IC 均值 / IC 标准差）：

```python
def ir_weighted_combine(factors: dict, ic_series: dict, lookback: int = 60) -> pd.DataFrame:
    """IR 加权合成（用过去 lookback 期 ICIR 作权重）"""
    ir = pd.DataFrame({
        name: ic_series[name].rolling(lookback).mean() / 
              ic_series[name].rolling(lookback).std()
        for name in factors
    })
    
    # 归一化
    weights = ir.div(ir.abs().sum(axis=1), axis=0)
    
    standardized = {
        name: f.sub(f.mean(axis=1), axis=0).div(f.std(axis=1), axis=0)
        for name, f in factors.items()
    }
    
    combined = sum(standardized[name].mul(weights[name], axis=0) for name in factors)
    return combined
```

**适用**：**实务首选**——同时考虑预测力和稳定性。

---

### 方法 4：PCA / IPCA

用主成分分析降维，把高度相关的因子合并：

```python
from sklearn.decomposition import PCA

def pca_combine(factors: dict, n_components: int = 3) -> pd.DataFrame:
    """PCA 合成"""
    # 把所有因子拼成大矩阵 (n_dates * n_stocks, n_factors)
    stacked = pd.concat({name: f.stack() for name, f in factors.items()}, axis=1)
    
    # PCA
    pca = PCA(n_components=n_components)
    transformed = pca.fit_transform(stacked.fillna(0))
    
    # 取第一主成分
    first_pc = pd.Series(transformed[:, 0], index=stacked.index)
    return first_pc.unstack()
```

**适用**：因子之间相关性高（如多个动量因子），可去冗余。

**问题**：可解释性差——第一主成分可能没有明显含义。

---

### 方法 5：Logistic 回归（监督学习）

把"未来一期是否上涨 > 5%"作为二分类标签，用 Logistic 回归学习因子权重：

```python
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

def logistic_combine(factors: dict, returns_next: pd.DataFrame, threshold: float = 0.05):
    """Logistic 回归合成
    
    标签：未来一期收益 > threshold 为 1，否则 0
    """
    # 准备 X, y
    X_list = []
    y_list = []
    for date in returns_next.index:
        if date not in factors[list(factors)[0]].index:
            continue
        row_x = pd.DataFrame({name: factors[name].loc[date] for name in factors})
        row_y = (returns_next.loc[date] > threshold).astype(int)
        common = row_x.index.intersection(row_y.index)
        X_list.append(row_x.loc[common])
        y_list.append(row_y.loc[common])
    
    X = pd.concat(X_list).dropna()
    y = pd.concat(y_list).loc[X.index]
    
    # 训练
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    clf = LogisticRegression(class_weight='balanced').fit(X_scaled, y)
    
    # 返回每个因子的权重
    return dict(zip(X.columns, clf.coef_[0]))
```

**适用**：因子很多（> 10 个）+ 想做 ML 选股。

**问题**：容易过拟合，**必须分样本内 / 样本外**。

---

## jqfactor_analyzer 实现

聚宽提供 [jqfactor_analyzer](https://github.com/JoinQuant/jqfactor_analyzer) 库，封装了上述全部流程：

```python
# pip install jqfactor_analyzer
import jqfactor_analyzer as ja

# 准备数据：factor_value 是 (date, code) 宽表
fa = ja.analyze_factor(
    factor=factor_value,  # 因子值
    quantiles=10,  # 分组数
    periods=(1, 5, 21),  # 检验持有期：1日 / 5日 / 21日
    industry='jq_l1',  # 行业分类
    weight_method='avg',  # 加权方式
)

# 输出 IC 报告
fa.create_summary_tear_sheet()

# 输出收益分析报告
fa.create_returns_tear_sheet()

# 输出 IC 时序图
fa.create_information_tear_sheet()

# 输出换手率分析
fa.create_turnover_tear_sheet()
```

**优势**：
- 自动按 quantile 分组（10 组）
- 自动算 IC / IR / 多空收益 / 单调性
- 内置行业 / 市值中性
- 输出 alphalens-style 报告

**详见**：[聚宽 jqfactor_analyzer 文档](https://www.joinquant.com/help/api/help#JQfactor_analyzer)

---

## A 股化注记

### 时滞处理（最容易掉的坑）

**单因子检验的核心约束**：因子值 $f_{i,t}$ **必须用 t 期之前的数据计算**，下期收益 $R_{i,t+1}$ **必须用 t 之后的实际收益**。

**典型错误**：

```python
# ❌ 错误：用 today 的 close 计算的因子，对 today 的收益做 IC
factor = compute_factor(close)  # 含 today close
returns = close.pct_change()  # today 的收益
ic = factor.corrwith(returns)  # 这是"看着今天涨预测今天涨"，毫无意义
```

```python
# ✓ 正确：因子用 t-1 数据，收益用 t 数据
factor = compute_factor(close).shift(1)  # 用昨日因子
returns = close.pct_change()  # 今日收益
ic = ...  # 这才是真正的 IC
```

聚宽 jqfactor_analyzer 已自动处理这个 shift——但**自己实现时务必检查**。

### 中性化先于合成

合成之前必须做行业 / 市值中性化，否则合成结果会被"行业暴露"主导。详见 [[neutralization-practice]]。

### 检验周期与持有期匹配

**关键**：IC 的"下期"含义要与策略的调仓频率匹配——
- 月度调仓策略 → 用 21 日 IC
- 周度调仓策略 → 用 5 日 IC
- 日频策略 → 用 1 日 IC

**不要**用日 IC 选月度策略的因子——日 IC 高的因子可能在月度上失效。

### IC 衰减分析

好因子的 IC 在不同持有期上应该稳定衰减，而非突然消失：

```python
# 计算 1/5/10/21 日 IC
for period in [1, 5, 10, 21]:
    returns_n = close.pct_change(period).shift(-period)
    ic = cross_section_ic(factor, returns_n)
    print(f'IC {period}d: mean={ic.mean():.4f}, IR={ic.mean()/ic.std():.2f}')
```

**好因子**：IC 从短期到长期单调或平缓衰减。**坏因子**（可能是数据窥探）：IC 在某个特定持有期突然峰值，其他期低。

---

## 综合观察

- **Rank IC 是 A 股实务首选**（抗极值、对收益分布右偏稳健）
- **ICIR / IC t 值比 IC 均值更重要**——稳健性是基础
- **IR 加权合成是 4 种方法中的工业级选择**
- **PCA 适合冗余因子组**（如 10 个动量因子合一个），但可解释性差
- **Logistic 回归监督学习** 要严格分样本内 / 样本外，避免过拟合
- **jqfactor_analyzer 是聚宽生态最易用的工具**——研究阶段直接用，无需自己实现

## 参考与延伸

- [[multi-factor-methodology-overview]] — 多因子选股完整方法论
- [[neutralization-practice]] — 行业 / 市值 / 风格中性化
- [[multi-factor-jq-strategy]] — 工业级聚宽策略实现
- [[index-01-methodology]] 1.2 — Fama-MacBeth 回归 / GRS 检验等学术工具
- [因子投资方法与实践 ch2](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — 方法论原书
- [Python量化交易实战 ch6.2](../../../原始资料文件/Python量化交易实战/Python量化交易实战.md) — IC 合成 4 步法
- [jqfactor_analyzer 文档](https://www.joinquant.com/help/api/help#JQfactor_analyzer)
