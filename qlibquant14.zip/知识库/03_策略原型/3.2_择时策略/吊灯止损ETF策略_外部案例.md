---
name: chandelier-exit-etf-external-case
description: MyInvestPilot 美股2号吊灯止损 ETF 外部案例 —— QQQ/XLK/ARKK 等成长 ETF 独立 ATR trailing stop，含公开数据结构、Qlib 复现路线和 A 股/QDII 适配注记
category: 03_策略原型/3.2_择时策略
tags: [吊灯止损, ChandelierExit, ATR, trailing_stop, ETF择时, 趋势跟踪, Qlib, A股化]
created: 2026-05-29
updated: 2026-05-29
source: MyInvestPilot chandelier-exit 策略文档与 myinvestpilot_us_2 公开组合页/公开数据文件
status: draft
---

# 吊灯止损 ETF 策略 · 外部案例

## TL;DR

这是一个**ATR 动态追踪止损**案例：组合资产池包含 `QQQ / XLK / XLY / VIG / ARKK / ICLN / FTEC / ESGU` 等美股成长 ETF，每个 ETF 独立判断趋势与止损位置；趋势明确时持有，跌破 Chandelier stop 或趋势反转时退出。

对我们最有价值的不是直接照抄美股2号参数，而是把 **Chandelier Exit 拆成一个可复用的退出/风控模块**：

```text
入场：由均线、RSRS、动量、基本面或人工筛选决定
持仓：每日更新 ATR trailing stop
出场：价格跌破只上不下的止损线，或趋势确认条件失效
```

它和 [[dual-moving-average-global-etf-external-case]] 的区别是：双均线是“趋势入场 + 趋势出场”的完整门控；吊灯止损更像“已经入场后的保护利润工具”。它和 [[momentum-rotation-external-case]] 的区别是：不比较谁最强，而是对每个资产独立控制下行风险。

## 来源

- 策略文档：`https://www.myinvestpilot.com/docs/strategies/chandelier-exit`
- 组合案例：`https://www.myinvestpilot.com/portfolios/myinvestpilot_us_2`
- 公开状态文件：`https://media.i365.tech/myinvestpilot/portfolios/myinvestpilot_us_2/state_summary.json`
- 公开 AI 周报文件：`https://media.i365.tech/myinvestpilot/portfolios/myinvestpilot_us_2/insight.json`
- 公开 SQLite 文件：`https://media.i365.tech/myinvestpilot/portfolios/myinvestpilot_us_2/myinvestpilot_us_2_portfolio.db`
- 本次读取日期：2026-05-29

## 来源 1 · 吊灯止损通用规则

策略文档给出的核心公式：

```text
止损价 = 最近 N 日最高价 - ATR(N) * multiplier
```

常用参数：

| 参数 | 文档默认 | 含义 |
|---|---:|---|
| `N` | `22` | 最近 22 个交易日最高价与 ATR 窗口 |
| `multiplier` | `3` | ATR 倍数，越大止损越宽 |
| 低倍数 | `2` | 止损更紧，容易被震出 |
| 高倍数 | `4` | 止损更松，单次亏损可能更大 |

关键执行规则：

1. Chandelier Exit 主要是**止损/出场系统**，不是完整买入信号。
2. 买入后建立初始止损线。
3. 每日收盘后重新计算候选止损价。
4. 止损线只能上调，不能下调。
5. 一旦价格跌破止损线，卖出该资产。

这条“只能上调”的路径依赖规则很重要。单纯计算 `Max(high, 22) - ATR * 3` 只是候选止损价，不等于真实可执行的 trailing stop。

## 来源 2 · 美股2号组合资产池

组合页描述该案例为美股科技、消费、清洁能源等成长 ETF 组合，通过 Chandelier 止损策略捕捉趋势机会。页面显示标的：

| 标的 | 暴露方向 |
|---|---|
| `QQQ` | 纳斯达克 100 / 美国大型科技成长 |
| `XLK` | 美国科技板块 |
| `XLY` | 美国可选消费板块 |
| `VIG` | 美国股息增长 ETF |
| `ARKK` | 创新成长主题 |
| `ICLN` | 全球清洁能源 |
| `FTEC` | Fidelity 信息技术 ETF |
| `ESGU` | 美国 ESG 宽基 ETF |

组合页写明的策略逻辑：

- 使用 ATR 的 Chandelier 止损点确定趋势方向和止损位置。
- 配合移动平均线确认趋势。
- 多个 ETF 分别判断。
- 趋势明确时持有，趋势反转时退出。

**研究注记**：

- 页面和公开 SQLite 交易库确认到 8 个交易标的。
- `state_summary.json` 中 `total_symbols = 9`，与公开页面/交易库不一致；暂不猜测第 9 个标的。
- 平台没有公开该组合的完整后台参数，例如具体均线周期、成交价规则、是否有最小仓位/最小交易额等。

## 公开数据文件结构

本次读取公开 SQLite 文件时看到：

| 表 | 行数 | 用途 |
|---|---:|---|
| `net_values` | 2112 | 净值序列 |
| `trade_records` | 332 | 交易记录 |
| `position_records` | 10755 | 每日持仓 |
| `capital_records` | 338 | 现金与资产变化 |
| `portfolio_status` | 1 | 汇总指标 |
| `benchmark_index` | 3069 | 全球指数基准 |
| `equal_weight_benchmark` | 1 | 等权买入持有基准 |
| `return_attribution_assets` | 8 | 资产收益归因 |
| `return_attribution_annual` | 9 | 年度归因 |

公开样本摘要：

| 项目 | 数值 |
|---|---:|
| 净值日期范围 | `2018-01-02` 到 `2026-05-28` |
| 净值记录数 | `2112` |
| 交易记录数 | `332` |
| 交易标的数 | `8` |
| 最新净值 | `2.7075` |
| CAGR | `12.59%` |
| Sharpe | `0.4958` |
| 最大回撤 | `-34.49%` |
| 当前回撤 | `0.00%` |
| 胜率 | `35.67%` |
| 盈亏比 | `4.272` |
| Calmar | `0.365` |
| 年化波动 | `16.04%` |

截至公开数据最新日，持仓为 7 个 ETF：

| 标的 | 持仓状态 |
|---|---|
| `ICLN` | 持有 |
| `XLK` | 持有 |
| `FTEC` | 持有 |
| `QQQ` | 持有 |
| `ESGU` | 持有 |
| `VIG` | 持有 |
| `XLY` | 持有 |
| `ARKK` | 未持有 |

`insight.json` 给出的风格描述：

- 信号以持有为主：`H = 68%`
- 退出信号：`E = 29.7%`
- 买入信号：`B = 1.2%`
- 低频风格：约 `3.4` 次交易/月
- 历史持仓中位数：`34` 天
- 年均交易：约 `39.7` 次

**研究注记**：

- 胜率只有 `35.67%`，但盈亏比 `4.272`，符合趋势跟踪常见的“低胜率、高盈亏比”结构。
- 策略年化波动低于等权买入持有基准，但收益和夏普不一定优于等权基准；更合理的定位是“降低暴露、控制回撤、保护利润”，不是天然增强收益。
- 公开数据库足够做反推研究，但不能证明已经完全复刻平台后台逻辑。

## Qlib 表达式与实现要点

### 候选 Chandelier stop

Qlib Expression Engine 可以表达候选止损线：

```python
highest_22 = "Max($high, 22)"

tr_22 = (
    "Mean("
    "If($high - $low > Abs($high - Ref($close, 1)), "
    "If($high - $low > Abs($low - Ref($close, 1)), $high - $low, Abs($low - Ref($close, 1))), "
    "If(Abs($high - Ref($close, 1)) > Abs($low - Ref($close, 1)), "
    "Abs($high - Ref($close, 1)), Abs($low - Ref($close, 1))))"
    ", 22)"
)

raw_chandelier_stop = f"({highest_22}) - 3 * ({tr_22})"
```

也可以先用更简单的 ATR 近似做研究：

```python
atr22_simple = "Mean($high - $low, 22)"
raw_chandelier_stop_simple = "Max($high, 22) - 3 * Mean($high - $low, 22)"
```

### 真实 trailing stop 需要状态机

Expression Engine 难以直接表达“自买入以来止损线只上不下、出场后重置”的完整状态。因此在 Qlib 中建议把它写在策略层：

```python
if not holding:
    if entry_signal:
        buy(asset, target_weight)
        stop[asset] = raw_chandelier_stop[asset]
else:
    stop[asset] = max(stop[asset], raw_chandelier_stop[asset])
    if close[asset] < stop[asset] or not trend_gate[asset]:
        sell(asset)
        stop[asset] = None
```

这里的 `entry_signal` 不应直接等同于 Chandelier stop。更稳妥的入场来源包括：

- `close > MA200`
- `MA50 > MA200`
- `RSRS_v3` 多头信号
- 中期动量为正
- 人工选定 ETF 篮子后仅做风险退出

### 与均线确认结合

美股2号页面提到“配合移动平均线确认趋势”，但未公开具体周期。研究初版可以设定为：

```python
trend_gate_ma200 = "$close > Mean($close, 200)"
trend_gate_ma50_200 = "Mean($close, 50) > Mean($close, 200)"
```

建议把均线确认与吊灯止损拆成两层：

```text
第一层：趋势过滤，决定能不能持有
第二层：ATR trailing stop，决定如何保护利润和退出
```

## 与其他择时案例的区别

| 维度 | 吊灯止损 ETF | 双均线全球 ETF | 动量轮动 | 目标权重趋势过滤 |
|---|---|---|---|---|
| 决策问题 | 已持有资产何时止损/止盈退出？ | 每个资产是否金叉？ | 哪个资产最强？ | 每个资产是否高于 MA200？ |
| 核心指标 | 最高价 + ATR | 短/长均线 | N 日相对动量 | MA200 月末门控 |
| 入场能力 | 弱，需外部信号 | 强 | 强 | 中等 |
| 出场特点 | trailing stop 保护利润 | 死叉退出 | 被更强资产替换 | 跌破 MA200 退出 |
| 风险来源 | 震荡市反复止损 | 均线附近假信号 | 追涨反转 | 长周期滞后 |
| 适用目标 | 风控模块 / 退出模块 | 多资产趋势门控 | 进攻轮动 | 中长期配置风控 |

**综合观察**：

- 吊灯止损最好不要单独使用，应该挂在已有入场逻辑之后。
- 它对趋势资产最有价值：指数 ETF、行业 ETF、商品 ETF、海外 ETF、趋势型基金。
- 它对横盘资产不友好，容易连续小止损。
- 它适合做“保护利润”的后半段，而不是预测大行情的前半段。

## A 股 / QDII 迁移候选

| 方向 | 候选池 | 研究重点 |
|---|---|---|
| A 股宽基 ETF | 沪深300 / 中证500 / 创业板 / 科创50 ETF | 回撤控制与 T+1 执行 |
| A 股行业 ETF | 半导体 / 人工智能 / 新能源车 / 消费 / 红利 ETF | 趋势持续性和拥挤交易 |
| 跨市场 QDII/LOF | 纳指 ETF / 日经 ETF / 印度基金 / 标普科技 LOF | 场内溢价、时差、底层指数确认 |
| 防守资产 | 黄金 ETF / 债券 ETF / 现金 | 作为出场后的资金去向 |

### A 股化注意事项

- **T+1**：买入后次日才能卖出，止损触发不能按美股日内逻辑处理。
- **涨跌停**：ETF 通常没有个股那么极端，但仍需考虑无法按理想价格成交。
- **停牌/折溢价**：QDII/LOF 场内价格可能与底层净值偏离，止损可能止在“溢价波动”上。
- **成交额**：小众行业 ETF 容量有限，ATR 止损触发时可能放大滑点。
- **交易日错位**：日经、纳指、印度等底层市场与 A 股交易日不同，信号确认要统一日历。

## 必做对照实验

| 对照组 | 用途 |
|---|---|
| 买入持有单资产 | 判断收益是否来自 beta |
| ETF 等权买入持有 | 判断策略是否优于静态分散 |
| 均线趋势过滤 | 对照普通趋势门控 |
| 均线趋势过滤 + Chandelier stop | 检验吊灯止损的边际贡献 |
| Chandelier stop 不同 ATR 窗口 | 检验 `14 / 22 / 50` 稳健性 |
| Chandelier stop 不同倍数 | 检验 `2 / 3 / 4` 风险收益差异 |
| 加入现金/债券/黄金去向 | 检验退出后的资金效率 |

## 参数反推路线

公开组合没有给出完整后台参数。若要复刻美股2号，可以这样反推：

1. 下载公开 `trade_records`。
2. 准备 8 个 ETF 的复权日线 OHLC 数据。
3. 网格搜索 ATR 窗口：`14, 22, 30, 50`。
4. 网格搜索 ATR 倍数：`2.0, 2.5, 3.0, 3.5, 4.0`。
5. 网格搜索趋势确认：`close > MA200`、`MA50 > MA200`、`close > MA100`、中期动量为正。
6. 比较交易日期匹配度、买卖方向匹配度、持仓天数误差、净值相关性。
7. 再比较成交规则：当日收盘成交、次日开盘成交、次日收盘成交。

不要只用最终净值拟合参数。更好的评分对象是交易序列和持仓序列，否则容易过拟合。

## 风险检查清单

- **横盘震荡**：价格反复跌破止损线，造成连续小亏。
- **跳空风险**：跌破止损线时实际成交价可能远低于止损价。
- **参数敏感**：倍数太小容易被震出，倍数太大又会放大回撤。
- **入场依赖**：Chandelier 本身不解决“什么时候买”的问题。
- **路径依赖**：回测必须维护每个资产的持仓状态和止损状态。
- **组合拥挤**：成长 ETF 之间相关性高，多个资产可能同时触发退出。
- **样本偏差**：美股成长 ETF 2018-2026 样本包含科技股强周期，不能直接外推。

## 结论

这个案例值得入库，但定位要准确：

- 它是**ATR trailing stop 风控模块**，不是完整 alpha 策略。
- 最值得吸收的是“最高价 - ATR 倍数”的动态止损框架，以及“止损线只上不下”的状态机实现。
- 与均线、RSRS、动量等入场信号组合后，适合用于 ETF、指数、QDII/LOF 和趋势型行业基金。
- 对我们后续 Qlib 研究，最优先的实验不是复制美股2号，而是检验：在已有 ETF 趋势策略上加入 Chandelier stop，是否能改善最大回撤、Calmar 和左尾风险。

## 参考与延伸

- [[index-03-02-timing]]
- [[timing-methodology-overview]]
- [[a-share-timing-implementation]]
- [[dual-moving-average-global-etf-external-case]]
- [[momentum-rotation-external-case]]
- [[target-weight-trend-filter-external-case]]
