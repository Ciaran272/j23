---
name: a-share-timing-implementation
description: A 股择时实现 —— 双均线（Granville 八大法则）+ MACD + RSRS 引用 + 多重确认 + A 股化避坑（T+1 / 涨跌停 / 停复牌）
category: 03_策略原型/3.2_择时策略
tags: [A股择时, 双均线, Granville, MACD, RSRS, 多重确认, 聚宽实现, T+1, 涨跌停]
created: 2026-05-17
updated: 2026-05-29
source: Whale-Quant ch05 + Python 实战 ch7.2 + 业界经验 + MyInvestPilot MACD Strategy
status: with-jq-impl
status: stable
---

# A 股择时实现

## TL;DR

承接 [择时方法论总览.md](择时方法论总览.md) 的方法论——本文聚焦 **A 股个人量化的可执行实现**：

```
3 个核心可实现的择时策略：
├── 1. 双均线（Granville 八大法则）
├── 2. MACD 择时（双线交叉 + 柱状图）
└── 3. RSRS_v3（引用 [[rsrs-four-versions]]）+ 多重确认

A 股化的 5 大避坑：
- T+1（当日买入次日才能卖）
- 涨跌停（停板无法成交）
- 停复牌（长期停牌后跌停连环）
- 交易成本（频繁切换累积）
- 做空受限（"空仓" = 转债券 / 货币基金）
```

**核心 A 股化建议**：

- **个人量化推荐组合 = RSRS_v3 + 双均线 + 北向资金**（多重确认）
- **不要单押 MACD**——A 股多假突破 / 易过拟合
- **聚焦大盘 / 板块 ETF 择时**——个股择时容量小 + 拥挤

## 来源

- **Whale-Quant ch05 量化择时策略**（双均线 + MACD）
- **Python 实战 ch7.2 RSRS**（已在 [[rsrs-four-versions]] 完整建好）
- **业界 A 股择时经验**

---

## 1. 双均线择时（Granville 八大法则）

### 1.1 Granville 八大法则（完整版）

> Joseph Granville（美国 1976）提出——A 股择时最简单经典的方法。

**核心规则**：用一个均线（通常 200 日 MA）作为"中长期趋势线"。

| # | 状态 | 行动 | 含义 |
|---|---|---|---|
| 1 | 均线由下降变成上升，**股价从下向上突破均线** | **买入** | 趋势反转向上 |
| 2 | 股价跌破均线但很快又上升回均线之上 | **买入** | 假跌破 / 洗盘 |
| 3 | 股价在均线之上下跌但未跌破均线 | **持有 / 加仓** | 牛市回调 |
| 4 | 股价急跌远离均线（向下乖离过大）| **反弹买入** | 超跌反弹 |
| 5 | 均线由上升变下降，**股价从上向下跌破均线** | **卖出** | 趋势反转向下 |
| 6 | 股价突破均线但很快又下跌回均线之下 | **卖出** | 假突破 |
| 7 | 股价在均线之下上涨但未突破均线 | **减仓** | 熊市反弹 |
| 8 | 股价急涨远离均线（向上乖离过大）| **回调卖出** | 超买调整 |

### 1.2 A 股化注记

| 法则 | A 股特殊性 |
|---|---|
| 法则 1-2（买入信号）| A 股**假突破多**——需配合成交量放大 |
| 法则 3（牛市回调）| **涨跌停限制**会延迟回调幅度判断 |
| 法则 5-6（卖出信号）| **A 股暴跌后涨停反弹常见**——单纯看均线易被套 |
| 法则 8（超买卖出）| A 股**主升浪可能远离均线很久**——过早卖出错过收益 |

### 1.3 聚宽实现

```python
"""
A 股双均线择时（Granville 八大法则）
直接复制到聚宽 IDE：https://www.joinquant.com/algorithm/index/edit
"""
from jqdata import *
import pandas as pd


def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.00025,
                  close_commission=0.00025, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    g.benchmark = '000300.XSHG'
    g.etf = '510300.XSHG'  # 沪深 300 ETF
    g.ma_short = 5    # 短均线（用于趋势判断）
    g.ma_long = 200   # 长均线（牛熊分界）
    g.deviation_threshold = 0.10  # 乖离率阈值（10%）
    
    run_daily(rebalance, time='14:55')  # 收盘前 5 分钟决策


def get_signal(close_series, ma_short_series, ma_long_series):
    """根据 Granville 八大法则生成信号"""
    if len(close_series) < 2 or len(ma_long_series) < 2:
        return 'neutral'
    
    close = close_series.iloc[-1]
    close_prev = close_series.iloc[-2]
    ma_long = ma_long_series.iloc[-1]
    ma_long_prev = ma_long_series.iloc[-2]
    
    # 均线方向
    ma_rising = ma_long > ma_long_prev
    
    # 价格相对均线位置
    price_above_ma = close > ma_long
    
    # 乖离率
    deviation = (close - ma_long) / ma_long
    
    # 法则 1：均线上升 + 价格从下向上突破
    if ma_rising and close_prev < ma_long_prev and close > ma_long:
        return 'strong_buy'
    
    # 法则 5：均线下降 + 价格从上向下跌破
    if not ma_rising and close_prev > ma_long_prev and close < ma_long:
        return 'strong_sell'
    
    # 法则 3：均线之上下跌未跌破（持有）
    if ma_rising and price_above_ma and close < close_prev:
        return 'hold'
    
    # 法则 4：急跌远离均线（反弹买入）
    if deviation < -g.deviation_threshold:
        return 'rebound_buy'
    
    # 法则 8：急涨远离均线（回调卖出）
    if deviation > g.deviation_threshold:
        return 'profit_take'
    
    # 默认：根据均线和价格位置
    if ma_rising and price_above_ma:
        return 'long'
    elif not ma_rising and not price_above_ma:
        return 'short'
    
    return 'neutral'


def rebalance(context):
    """每日 14:55 决策"""
    # 取沪深 300 数据
    prices = get_bars(
        g.benchmark,
        count=g.ma_long + 50,
        unit='1d',
        fields=['close'],
        df=True,
    )
    
    if len(prices) < g.ma_long:
        return
    
    close_series = prices['close']
    ma_short_series = close_series.rolling(g.ma_short).mean()
    ma_long_series = close_series.rolling(g.ma_long).mean()
    
    signal = get_signal(close_series, ma_short_series, ma_long_series)
    
    log.info(f'当前信号: {signal}')
    
    # 执行交易
    current_position = context.portfolio.positions
    current_value = context.portfolio.total_value
    
    if signal in ['strong_buy', 'long', 'rebound_buy']:
        # 满仓沪深 300 ETF
        target_value = current_value
        order_target_value(g.etf, target_value)
    elif signal in ['strong_sell', 'short']:
        # 空仓
        order_target_value(g.etf, 0)
    elif signal == 'profit_take':
        # 减仓 50%
        order_target_value(g.etf, current_value * 0.5)
    elif signal == 'hold':
        # 保持仓位
        pass
```

### 1.4 双均线择时的预期表现

| 指标 | 区间 | 备注 |
|---|---|---|
| 年化收益 | 7-12% | 受市场环境影响 |
| 最大回撤 | 15-25% | 比买入持有低 |
| 夏普 | 0.5-0.7 | 中等 |
| 调仓频率 | 月度 / 季度 | 取决于均线参数 |

**警告**：

- **震荡市频繁切换** → 收益打折
- **A 股牛市底部启动晚** → 错过最佳买点

---

## 2. MACD 择时

### 2.1 MACD 基础

**3 个核心组件**：

```
DIF = EMA(12) - EMA(26)      # 快线
DEA = EMA(DIF, 9)             # 慢线
MACD = (DIF - DEA) × 2        # 柱状图
```

### 2.2 经典 4 种交易信号

| # | 信号 | 含义 |
|---|---|---|
| 1 | **金叉**：DIF 上穿 DEA | 买入 |
| 2 | **死叉**：DIF 下穿 DEA | 卖出 |
| 3 | **底背离**：价格新低，DIF 不创新低 | 看多反转 |
| 4 | **顶背离**：价格新高，DIF 不创新高 | 看空反转 |
| 5 | **零轴过滤**：DIF / MACD 柱位于零轴上方 | 只做更强多头信号 |

MyInvestPilot MACD 策略文档给出一个可做参数网格的分层：

| 参数 | 风格 | 用途 |
|---|---|---|
| `(6, 12, 9)` | 短线 | 更敏感，但假信号更多 |
| `(12, 26, 9)` | 标准 | 默认研究起点 |
| `(19, 39, 9)` | 长线 | 更平滑，适合减少噪声 |

**策略化要点**：金叉 / 死叉只是触发条件，零轴、成交量、长期均线才是过滤条件。裸 MACD 金叉在 A 股震荡市非常容易反复打脸。

### 2.3 聚宽实现

```python
def macd_signal(close_series, fast=12, slow=26, signal=9):
    """计算 MACD 信号"""
    ema_fast = close_series.ewm(span=fast, adjust=False).mean()
    ema_slow = close_series.ewm(span=slow, adjust=False).mean()
    
    dif = ema_fast - ema_slow
    dea = dif.ewm(span=signal, adjust=False).mean()
    macd = (dif - dea) * 2
    
    return dif, dea, macd


def macd_strategy_signal(close_series):
    """MACD 策略信号生成"""
    dif, dea, macd = macd_signal(close_series)
    
    if len(dif) < 2:
        return 'neutral'
    
    dif_now = dif.iloc[-1]
    dif_prev = dif.iloc[-2]
    dea_now = dea.iloc[-1]
    dea_prev = dea.iloc[-2]
    
    # 金叉
    if dif_prev < dea_prev and dif_now > dea_now:
        return 'golden_cross'  # 买入
    
    # 死叉
    if dif_prev > dea_prev and dif_now < dea_now:
        return 'death_cross'  # 卖出
    
    # 趋势保持
    if dif_now > dea_now:
        return 'bullish'
    else:
        return 'bearish'
```

### 2.3.1 零轴过滤 + 成交量确认版本

更实用的 MACD 应该把“触发信号”和“过滤条件”分开：

```python
def macd_strategy_signal_filtered(close_series, volume_series=None, ma_long=200):
    """MACD 过滤版信号：金叉/死叉 + 零轴 + 长期趋势 + 成交量确认"""
    dif, dea, macd = macd_signal(close_series)
    if len(close_series) < max(ma_long, 35) or len(dif) < 2:
        return 'neutral'
    
    dif_now, dif_prev = dif.iloc[-1], dif.iloc[-2]
    dea_now, dea_prev = dea.iloc[-1], dea.iloc[-2]
    macd_now, macd_prev = macd.iloc[-1], macd.iloc[-2]
    
    golden_cross = dif_prev <= dea_prev and dif_now > dea_now
    death_cross = dif_prev >= dea_prev and dif_now < dea_now
    zero_axis_ok = dif_now > 0 and macd_now > 0
    hist_turn_positive = macd_prev <= 0 and macd_now > 0
    
    ma_filter = close_series.iloc[-1] > close_series.rolling(ma_long).mean().iloc[-1]
    
    volume_ok = True
    if volume_series is not None and len(volume_series) >= 20:
        volume_ok = volume_series.iloc[-1] > volume_series.rolling(20).mean().iloc[-1]
    
    if golden_cross and zero_axis_ok and ma_filter and volume_ok:
        return 'strong_buy'
    if hist_turn_positive and zero_axis_ok and ma_filter:
        return 'buy_watch'
    if death_cross or dif_now < 0:
        return 'sell'
    if dif_now > dea_now and ma_filter:
        return 'hold'
    return 'neutral'
```

**解释**：

- `golden_cross`：触发条件。
- `zero_axis_ok`：避免零轴下方弱反弹。
- `ma_filter`：只在长期趋势向上时做多。
- `volume_ok`：突破或金叉时要求成交量确认，降低无量假信号。

这不是“最优参数”，而是更符合实盘思维的研究基线。

### 2.4 MACD 的 A 股化局限

| 局限 | 内容 |
|---|---|
| **频繁假信号** | A 股震荡市 → 金叉 / 死叉频繁切换 → 亏损 |
| **滞后性** | MACD 是趋势指标 → 在拐点之后才发信号 |
| **背离判断主观** | "底背离 / 顶背离"难量化 |
| **单一指标不稳健** | 单独使用 t < 1.5（实证）|
| **参数敏感** | 短线参数容易过度交易，长线参数容易错过拐点 |

**A 股化建议**：

- **MACD 不要单押**——与 RSRS / 双均线组合使用
- **金叉 + 高 RSRS_v3 → 强买入信号**
- **死叉 + 低 RSRS_v3 → 强卖出信号**
- **零轴上方金叉 > 零轴下方金叉**——后者多数只是弱反弹
- **成交量确认优先于背离想象**——背离必须定义窗口后再量化

---

## 3. RSRS（引用 [[rsrs-four-versions]]）

### 3.1 简要回顾

> 详见 [[rsrs-four-versions]] —— 2.5 已完整建好。

**核心**：

$$\text{HIGH}_t = \alpha + \beta \cdot \text{LOW}_t + \varepsilon_t$$

- **β = OLS 斜率** = RSRS 信号
- **v3 修正版**：$Z \times R^2$（业界推荐）

### 3.2 实证

| 指标 | RSRS_v3（2008-2017）| 买入持有 |
|---|---|---|
| **年化收益** | **15.8%** | 5.5% |
| **最大回撤** | **20%** | 71% |
| **夏普** | **0.85** | 0.27 |
| **信息比率** | **0.65** | - |

### 3.3 完整聚宽代码

详见 [[rsrs-four-versions]] § 完整可跑示例。

```python
# 简要框架（完整代码见 [[rsrs-four-versions]]）
def rsrs_v3(high, low, N=18, M=600):
    """修正 RSRS"""
    rsrs = pd.Series(np.nan, index=high.index)
    r2 = pd.Series(np.nan, index=high.index)

    for i in range(N, len(high)):
        x = low.iloc[i - N:i].values
        y = high.iloc[i - N:i].values
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var_x = np.sum((x - x_mean) ** 2)
        var_y = np.sum((y - y_mean) ** 2)
        
        if var_x > 0 and var_y > 0:
            beta = cov / var_x
            rsrs.iloc[i] = beta
            r2.iloc[i] = (cov ** 2) / (var_x * var_y)

    # Z-score 标准化
    rolling_mean = rsrs.rolling(M).mean()
    rolling_std = rsrs.rolling(M).std()
    z = (rsrs - rolling_mean) / rolling_std

    return z * r2  # 修正版：Z × R²
```

### 3.4 阈值

```
Z_corrected > +0.7：满仓
Z_corrected < -0.7：空仓
中间值：保持现状
```

---

## 4. 多重确认择时（A 股个人推荐）

### 4.1 完整组合策略

```python
"""
A 股多重确认择时策略
=====================
信号 1：RSRS_v3 修正版
信号 2：250 日均线（牛熊线）
信号 3：北向资金净流入（资金面）

满仓：3 个信号都看多
半仓：2 个信号看多
空仓：3 个信号都看空 / 2 个看空

复制到聚宽 IDE 即可运行
"""
from jqdata import *
import pandas as pd
import numpy as np


def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.00025,
                  close_commission=0.00025, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    g.benchmark = '000300.XSHG'
    g.etf = '510300.XSHG'
    
    # RSRS 参数
    g.N = 18  # 回归窗口
    g.M = 600  # 标准化窗口
    g.threshold_buy = 0.7
    g.threshold_sell = -0.7
    
    # 均线参数
    g.ma_days = 250
    
    # 北向资金参数
    g.north_lookback = 5  # 看近 5 日北向资金
    
    run_daily(rebalance, time='14:55')


def compute_rsrs_v3(prices):
    """计算修正 RSRS"""
    high = prices['high']
    low = prices['low']
    
    if len(high) < g.N + g.M:
        return np.nan
    
    rsrs_raw = []
    r2_raw = []
    
    for i in range(g.N, len(high)):
        x = low.iloc[i - g.N:i].values
        y = high.iloc[i - g.N:i].values
        x_mean = x.mean()
        y_mean = y.mean()
        cov = np.sum((x - x_mean) * (y - y_mean))
        var_x = np.sum((x - x_mean) ** 2)
        var_y = np.sum((y - y_mean) ** 2)
        
        if var_x > 0 and var_y > 0:
            rsrs_raw.append(cov / var_x)
            r2_raw.append((cov ** 2) / (var_x * var_y))
        else:
            rsrs_raw.append(np.nan)
            r2_raw.append(np.nan)
    
    rsrs_series = pd.Series(rsrs_raw)
    rolling_mean = rsrs_series.rolling(g.M).mean()
    rolling_std = rsrs_series.rolling(g.M).std()
    z = (rsrs_series - rolling_mean) / rolling_std
    
    final = z * pd.Series(r2_raw)
    
    return final.iloc[-1] if not final.empty else np.nan


def compute_ma_signal(prices):
    """计算 250 日均线信号"""
    close = prices['close']
    if len(close) < g.ma_days:
        return 'unknown'
    
    ma_now = close.iloc[-g.ma_days:].mean()
    close_now = close.iloc[-1]
    
    # 均线方向
    ma_5d_ago = close.iloc[-g.ma_days - 5: -5].mean()
    ma_rising = ma_now > ma_5d_ago
    
    if close_now > ma_now and ma_rising:
        return 'long'
    elif close_now < ma_now and not ma_rising:
        return 'short'
    else:
        return 'neutral'


def compute_north_flow_signal():
    """计算北向资金信号"""
    # 取近 N 日北向资金净流入
    try:
        north_flow = get_north_flow(
            end_date=context.current_dt.date(),
            count=g.north_lookback,
        )
        if north_flow is None or len(north_flow) == 0:
            return 'unknown'
        
        total_inflow = north_flow['amount'].sum()
        
        if total_inflow > 0:
            return 'long'
        else:
            return 'short'
    except:
        return 'unknown'


def rebalance(context):
    """每日决策"""
    # 取沪深 300 历史数据
    prices = get_bars(
        g.benchmark,
        count=g.N + g.M + 100,  # 足够长
        unit='1d',
        fields=['high', 'low', 'close'],
        df=True,
    )
    
    if len(prices) < g.N + g.M:
        log.info('数据不足')
        return
    
    # 3 个信号
    rsrs_z = compute_rsrs_v3(prices)
    ma_signal = compute_ma_signal(prices)
    north_signal = compute_north_flow_signal()
    
    # RSRS 信号
    if rsrs_z > g.threshold_buy:
        rsrs_signal = 'long'
    elif rsrs_z < g.threshold_sell:
        rsrs_signal = 'short'
    else:
        rsrs_signal = 'neutral'
    
    signals = [rsrs_signal, ma_signal, north_signal]
    
    long_count = signals.count('long')
    short_count = signals.count('short')
    
    log.info(
        f'RSRS={rsrs_z:.2f}({rsrs_signal}), '
        f'MA={ma_signal}, '
        f'North={north_signal}, '
        f'Long count={long_count}, Short count={short_count}'
    )
    
    # 决策
    current_value = context.portfolio.total_value
    
    if long_count >= 2:
        # 满仓
        order_target_value(g.etf, current_value)
        log.info(f'满仓 ETF')
    elif long_count == 1 and short_count <= 1:
        # 半仓
        order_target_value(g.etf, current_value * 0.5)
        log.info(f'半仓 ETF')
    elif short_count >= 2:
        # 空仓
        order_target_value(g.etf, 0)
        log.info(f'空仓')
    else:
        # 默认保持
        pass
```

### 4.2 预期表现

| 指标 | 多重确认（估计）| RSRS_v3 单一 | 买入持有 |
|---|---|---|---|
| 年化收益 | **10-15%** | 15.8% | 5.5% |
| 最大回撤 | **15-25%** | 20% | 71% |
| 夏普 | **0.7-0.9** | 0.85 | 0.27 |
| 误信号率 | **低**（多确认）| 中 | - |
| 收益稳定性 | **高**（多确认）| 中 | 低 |

**核心权衡**：

- **多重确认**降低误信号 → 但**信号延迟**导致部分收益让渡
- **单一 RSRS**追求最大收益 → 但**误信号率高**

### 4.3 实务调优建议

```python
# 调优方向
1. 调整 RSRS 阈值（0.7 vs 0.5 vs 1.0）
2. 调整 MA 天数（200 vs 250 vs 360）
3. 调整北向看回天数（5 vs 10 vs 20）
4. 加入 MACD 作第 4 信号
5. 加入南华情绪指数作第 5 信号
6. 加入"信号一致度"权重（3/3 信号 vs 2/3 信号）

警告：
- 不要过度调参 → 必过拟合
- 推荐参数基础上 ±20% 测试稳健性
- 必须严格样本外验证
```

---

## 5. A 股 5 大避坑（核心）

### 5.1 避坑 1：T+1 限制

**问题**：

```python
# 错误
if signal == 'sell':
    order_target_value(etf, 0)  # 想立即清仓
    
# 但若是 T+1 限制：
# - 早上 9:31 信号 → 卖
# - 但当日买入的部分不能卖（需到次日）
```

**正确处理**：

```python
def safe_sell(stock):
    """T+1 安全卖出"""
    available_amount = context.portfolio.positions[stock].closeable_amount
    if available_amount > 0:
        order_target_value(stock, 0, ignore_amount=False)
```

### 5.2 避坑 2：涨跌停限制

**问题**：

```python
# 错误：在涨停 / 跌停时下单可能不成交
if signal == 'buy':
    order_target_value(etf, target_value)  # 但 ETF 涨停时不成交
```

**正确处理**：

```python
def is_limit_up(stock):
    """判断涨停"""
    last_close = get_close(stock, days=1)[-1]
    current_price = get_current_price(stock)
    return current_price >= last_close * 1.099  # 留余地


def safe_buy(stock):
    """检查涨跌停后买入"""
    if is_limit_up(stock):
        log.info(f'{stock} 涨停，无法买入')
        return False
    order_target_value(stock, target_value)
    return True
```

### 5.3 避坑 3：停复牌处理

**问题**：

```python
# 错误：长期停牌的股票仍按旧价计算
```

**正确处理**：

```python
def filter_suspended(stocks, date):
    """过滤停牌股票"""
    return [s for s in stocks if not is_suspended(s, date)]
```

### 5.4 避坑 4：交易成本累积

**A 股双边成本**：

- 佣金：万 2.5（双边）
- 印花税：千 1（卖方）
- 滑点：~0.2%
- 总成本：**双边约 30 bp**

**实务计算**：

```python
def estimate_cost(turnover_rate):
    """估算交易成本（按换手率）"""
    commission = 0.00025 * 2     # 双边
    stamp_tax = 0.001            # 仅卖方
    slippage = 0.002             # 单边
    
    cost_per_turn = commission + stamp_tax + slippage * 2  # ~30bp
    annual_cost = cost_per_turn * turnover_rate * 12  # 年化
    return annual_cost


# 例：月度调仓 200% 换手率 → 年化成本 0.30% * 12 = 3.6%
# 这是从年化收益里扣的
```

### 5.5 避坑 5：A 股做空受限

**美股**："空仓" = 真做空（融券 + 卖出）

**A 股**："空仓" = 换成债券 / 货币基金（无真正做空）

```python
def empty_position():
    """A 股的'空仓'"""
    # 选项 1：转换为货币基金（流动性强）
    order_target_value('511990.XSHG', context.portfolio.total_value)
    
    # 选项 2：转换为短债 ETF
    # order_target_value('159972.XSHE', context.portfolio.total_value)
```

---

## 6. 综合：A 股个人择时的"3 步起步"

### Step 1：用 RSRS_v3 单一信号（M1-M3）

```python
# 最简单版本
if rsrs_z > 0.7:
    full_position()
elif rsrs_z < -0.7:
    no_position()
```

### Step 2：加入双均线确认（M4-M6）

```python
# 多重确认 v1
if rsrs_z > 0.7 and hs300_above_ma250:
    full_position()
elif rsrs_z < -0.7 and hs300_below_ma250:
    no_position()
else:
    half_position()
```

### Step 3：加入北向资金 / 情绪（M6+）

```python
# 多重确认 v2（4 信号）
signals = [rsrs_signal, ma_signal, north_signal, sentiment_signal]
long_count = signals.count('long')

if long_count >= 3:
    full_position()
elif long_count >= 2:
    three_quarter_position()
elif long_count >= 1:
    half_position()
else:
    no_position()
```

---

## 综合观察

- **A 股个人择时推荐"3 步起步"**：RSRS_v3 → + 双均线 → + 北向资金
- **Granville 八大法则** 是双均线择时的经典 —— A 股仍适用，但需配合 RSRS
- **MACD 择时**易过拟合 + 假信号多 —— 不要单押
- **多重确认 + IR 加权** 是最稳健做法
- **A 股 5 大避坑**：T+1 / 涨跌停 / 停复牌 / 成本 / 做空受限
- **择时是风险管理工具**——不是超额收益工具
- **不要追求"完美择时"** —— 大多数都是过拟合

## 参考与延伸

- [INDEX.md](INDEX.md) — 3.2 板块索引
- [择时方法论总览.md](择时方法论总览.md) — 8 种 + 因子择时 5 种
- [[rsrs-four-versions]] — RSRS 四版本完整推导（2.5）
- [[classical-technical-indicators]] — MA / MACD / RSI / KDJ
- [[volatility-and-other-indicators]] — IVOL / Beta
- [[index-04-02-kelly-position]] — 凯利公式 + 杠杆（择时+仓位）
- [[multi-factor-jq-strategy]] — 工业级多因子（选股+择时结合）
- [[backtest-trading-rules]] — A 股交易制度陷阱
- [Whale-Quant ch05](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/速览_whale_quant.md) — 8 种择时方法

[← 返回 3.2 索引](INDEX.md)
