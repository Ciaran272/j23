---
name: a-share-single-side-pairs-implementation
description: A 股做空受限下的"单边版"配对交易实现 —— 同业股 / 可转债 / ETF 套利 + 完整聚宽代码 + 4 大陷阱
category: 03_策略原型/3.3_统计套利与配对
tags: [A股配对, 单边配对, 同业股, 可转债套利, ETF套利, 聚宽实现, 做空受限]
created: 2026-05-17
updated: 2026-05-17
source: Python 实战 ch11 + 业界 A 股配对经验
status: with-jq-impl
---

# A 股单边配对实现

## TL;DR

承接 [协整与配对方法论.md](协整与配对方法论.md)——本文聚焦 **A 股做空受限下的可执行方案**：

```
A 股做空受限 → 经典双边配对降级为以下 4 种方案：

方案 1：同业股"单边版"配对
方案 2：股指期货对冲（仅适合大盘股配对）
方案 3：可转债 vs 正股套利（A 股特有）
方案 4：ETF 跨市场套利（沪深 300 ETF 配对）
```

**核心 A 股化建议**：

- **A 股个人最现实 = 可转债 vs 正股套利**——无杠杆 / 无做空 / 持有 1-3 月
- **同业股单边配对**：仅做差价偏低的一边（如建行 vs 工行）
- **ETF 跨市场套利**：技术性套利——空间小但稳定
- **避坑 4 大陷阱**：协整断裂 / 单边暴雷 / 资金成本 / 流动性

## 来源

- **Python 实战 ch11 完整配对**：相关性 → 均值方差协方差 → ADF → OLS → 残差 ±3σ
- **业界 A 股配对经验**（综合）
- **A 股可转债 / ETF 市场特性**

---

## 1. 美股双边 vs A 股单边（核心差异）

### 1.1 经典美股双边配对

```
做多 GLD 1 份 + 做空 GDX 1.6766 份
        ↓
资金中性（市值相等）
        ↓
差价 z = GLD - 1.6766 × GDX 平稳
        ↓
z > +2σ → 做空 GLD / 做多 GDX
z < -2σ → 做多 GLD / 做空 GDX
```

### 1.2 A 股做空受限

| 限制 | 描述 |
|---|---|
| **个人融券难** | 50 万门槛 + 1:1 杠杆 |
| **券池小** | 可融券股票 < 1000 只 |
| **融券利率高** | **8-15%**（vs 美股 3-5%）|
| **可融券额度** | 部分券商可能限额 |
| **ST / 退市股不能融券** | 风险股做空更难 |

### 1.3 A 股的"降级方案"

| 方案 | 做法 | 适用场景 |
|---|---|---|
| **方案 1：单边多头** | 只做差价偏低一边 | **同业股推荐** |
| **方案 2：股指期货对冲** | 单一股票 + 股指期货空头 | 大盘股配对 |
| **方案 3：可转债 vs 正股** | 可转债折价时买入 | **A 股个人推荐** |
| **方案 4：ETF 跨市场** | 同标的不同 ETF | 技术性套利 |

---

## 2. 方案 1：同业股单边配对

### 2.1 适合配对的 A 股同业股

> **稳定同业垄断公司**（协整概率高）：

#### 银行业

| 配对 | 业务相似度 | 推荐度 |
|---|---|---|
| **建设银行 vs 工商银行** | 极高（四大行）| ⭐⭐⭐⭐ |
| **建设银行 vs 农业银行** | 极高 | ⭐⭐⭐⭐ |
| 工商银行 vs 农业银行 | 极高 | ⭐⭐⭐⭐ |
| 招商银行 vs 浦发银行 | 中（股份制）| ⭐⭐⭐ |

#### 白酒业

| 配对 | 业务相似度 | 推荐度 |
|---|---|---|
| **贵州茅台 vs 五粮液** | 中（不同档次）| ⭐⭐⭐ |
| 山西汾酒 vs 古井贡酒 | 中 | ⭐⭐ |

#### 港口业

| 配对 | 业务相似度 | 推荐度 |
|---|---|---|
| **上港集团 vs 宁波港** | 高 | ⭐⭐⭐ |
| 招商港口 vs 上港集团 | 高 | ⭐⭐⭐ |

#### 保险业

| 配对 | 业务相似度 | 推荐度 |
|---|---|---|
| **中国平安 vs 中国人寿** | 极高 | ⭐⭐⭐⭐ |

#### 券商业

| 配对 | 业务相似度 | 推荐度 |
|---|---|---|
| **中信证券 vs 海通证券** | 极高 | ⭐⭐⭐⭐ |

### 2.2 单边版逻辑

**经典版**：

```
z > +2σ → 做空 A / 做多 B
z < -2σ → 做多 A / 做空 B
```

**A 股单边版**：

```
z > +2σ（A 偏高，B 偏低）→ 只做多 B
z < -2σ（A 偏低，B 偏高）→ 只做多 A
```

**含义**：

- **不做空一边** → 风险降低（单边暴跌不至于亏空头）
- **alpha 降低** → 只能获取"价差回归的一半"
- **资金利用率高** → 不需要保证金做空

### 2.3 单边配对的预期表现

| 维度 | 经典双边 | A 股单边版 |
|---|---|---|
| 年化超额 | 8-15% | **3-8%** |
| 最大回撤 | 5-10% | **5-12%** |
| 夏普 | 1.0-1.5 | **0.5-1.0** |
| 容量 | 中（依做空容量）| **大** |
| 实现难度 | 高 | **低** |

### 2.4 完整聚宽实现

```python
"""
A 股同业股单边配对（建行 vs 工行）
复制到聚宽 IDE 即可运行
"""
from jqdata import *
import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller


def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.00025,
                  close_commission=0.00025, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    # 配对：建行 vs 工行
    g.stock_a = '601939.XSHG'  # 建设银行
    g.stock_b = '601398.XSHG'  # 工商银行
    
    # 参数
    g.lookback = 60         # 滚动窗口
    g.entry_z = 1.5         # 入场阈值（单边，比双边宽松）
    g.exit_z = 0.5          # 出场阈值
    g.adf_threshold = -2.86 # 单变量 ADF 5% 显著
    g.max_holding_days = 30 # 最长持有期
    
    g.position = 'flat'    # 当前持仓状态：flat / long_a / long_b
    g.entry_date = None
    
    run_daily(rebalance, time='14:55')


def compute_pair_signal(prices_a, prices_b):
    """计算配对信号"""
    if len(prices_a) < g.lookback or len(prices_b) < g.lookback:
        return None
    
    # 1. OLS 求对冲比率
    X = sm.add_constant(prices_b)
    model = sm.OLS(prices_a, X).fit()
    alpha = model.params[0]
    beta = model.params[1]
    residuals = model.resid
    
    # 2. ADF 检验残差平稳性
    adf_t = adfuller(residuals)[0]
    
    is_cointegrated = adf_t < g.adf_threshold
    
    # 3. 标准化残差
    z_score = (residuals.iloc[-1] - residuals.mean()) / residuals.std()
    
    return {
        'beta': beta,
        'z_score': z_score,
        'adf_t': adf_t,
        'is_cointegrated': is_cointegrated,
    }


def rebalance(context):
    """每日决策"""
    # 取价格历史
    prices_a = get_bars(
        g.stock_a, count=g.lookback + 50,
        unit='1d', fields=['close'], df=True,
    )['close']
    prices_b = get_bars(
        g.stock_b, count=g.lookback + 50,
        unit='1d', fields=['close'], df=True,
    )['close']
    
    if len(prices_a) < g.lookback or len(prices_b) < g.lookback:
        return
    
    signal = compute_pair_signal(prices_a, prices_b)
    if signal is None:
        return
    
    log.info(
        f'z={signal["z_score"]:.2f}, '
        f'ADF t={signal["adf_t"]:.2f}, '
        f'协整={signal["is_cointegrated"]}, '
        f'仓位={g.position}'
    )
    
    # 协整断裂保护
    if not signal['is_cointegrated']:
        if g.position != 'flat':
            # 协整断裂，立即清仓
            log.info('协整断裂，清仓')
            order_target_value(g.stock_a, 0)
            order_target_value(g.stock_b, 0)
            g.position = 'flat'
            g.entry_date = None
        return
    
    z = signal['z_score']
    current_value = context.portfolio.total_value
    
    # 出场逻辑
    if g.position != 'flat':
        # 持有期超限
        holding_days = (context.current_dt.date() - g.entry_date).days
        if holding_days > g.max_holding_days:
            log.info(f'持有 {holding_days} 天，清仓')
            order_target_value(g.stock_a, 0)
            order_target_value(g.stock_b, 0)
            g.position = 'flat'
            g.entry_date = None
            return
        
        # Z-score 回归到出场阈值
        if abs(z) < g.exit_z:
            log.info(f'z={z:.2f} 回归，清仓')
            order_target_value(g.stock_a, 0)
            order_target_value(g.stock_b, 0)
            g.position = 'flat'
            g.entry_date = None
            return
    
    # 入场逻辑（仅在空仓时）
    if g.position == 'flat':
        # z > entry_z：A 偏高，B 偏低 → 单边做多 B
        if z > g.entry_z:
            log.info(f'z={z:.2f} > {g.entry_z}，做多 B={g.stock_b}')
            order_target_value(g.stock_b, current_value * 0.95)
            g.position = 'long_b'
            g.entry_date = context.current_dt.date()
        
        # z < -entry_z：A 偏低，B 偏高 → 单边做多 A
        elif z < -g.entry_z:
            log.info(f'z={z:.2f} < {-g.entry_z}，做多 A={g.stock_a}')
            order_target_value(g.stock_a, current_value * 0.95)
            g.position = 'long_a'
            g.entry_date = context.current_dt.date()
```

---

## 3. 方案 2：股指期货对冲（中性策略）

### 3.1 适用场景

**单股 + 股指期货**：

- **做多大盘股 A + 做空 IF 股指期货** → 市场中性
- 适合**单股 alpha 显著**但担心系统性风险时

### 3.2 实施门槛

| 要求 | 内容 |
|---|---|
| **股指期货账户** | 50 万门槛 + 培训考试 |
| **保证金** | ~ 12% |
| **品种** | IF（沪深 300）/ IC（中证 500）/ IH（上证 50）|

### 3.3 单股 + 期货对冲示例

```python
def hedge_single_stock_with_futures(stock, position_value):
    """单股 + 股指期货对冲"""
    # 1. 计算股票 β
    stock_beta = compute_beta_to_hs300(stock)
    
    # 2. 计算需要的期货空头量
    hs300_price = get_current_price('IF2406.CCFX')  # 当月主力合约
    contract_value = hs300_price * 300  # 每手 300 倍乘数
    
    # 3. 对冲量
    hedge_value = position_value * stock_beta
    hedge_contracts = -int(hedge_value / contract_value)
    
    return hedge_contracts
```

**警告**：

- **股指期货保证金占资金 12%**——需要预留
- **基差风险**：升贴水会影响对冲效果
- **不适合个人小资金**（最少 50 万）

---

## 4. 方案 3：可转债 vs 正股套利（**A 股推荐**）

### 4.1 可转债基础

**可转债**：

- 公司发行的债券，**可按约定价格转换为该公司股票**
- 同时具有**债性 + 股性**
- A 股 + 港股都有

**关键术语**：

| 术语 | 含义 |
|---|---|
| **转股价** | 可转债转换为正股的价格 |
| **转股价值** | 100 × 正股价 / 转股价 |
| **转股溢价率** | (可转债价 - 转股价值) / 转股价值 |
| **强赎条款** | 正股价 > 130% 转股价持续 N 日 → 公司强制赎回 |

### 4.2 套利机会

#### 机会 1：折价转股套利

**机制**：

```
当转股溢价率 < 0（可转债折价）：
   买入可转债 → 转股 → 卖出正股
        ↓
   赚取折价 - 交易成本
```

**A 股化**：

- **空间小**（市场效率高，折价机会少）
- **常出现在小盘转债**

#### 机会 2：可转债 + 正股配对（持有套利）

**机制**：

```
可转债理论价格 ≈ 转股价值 + 期权价值
        ↓
当可转债被严重低估（如转股溢价率 < 5%）：
   买入可转债，等待价格回升
   不需要做空正股（A 股做空难）
        ↓
持有期 1-3 月 → 价差回归
```

#### 机会 3：强赎前的转股价值套利

**机制**：

```
正股价 > 130% 转股价持续多日 → 触发强赎
        ↓
公司提前赎回可转债（按 100 元 + 利息）
        ↓
此时持有可转债 → 选择转股（赚转股价值 - 100 + 利息）
```

### 4.3 A 股可转债套利的优势

| 优势 | 内容 |
|---|---|
| **不需要做空** | 全部多头操作 |
| **无杠杆** | 自有资金 |
| **流动性好** | 可转债日成交常 > 1 亿 |
| **持有期适中** | 1-3 月 |
| **A 股个人友好** | 普通账户即可参与 |

### 4.4 实务工作流

```python
def find_undervalued_convertible_bonds():
    """筛选低估可转债"""
    # 1. 取所有可转债
    bonds = get_all_securities(['convertible'])
    
    candidates = []
    for bond in bonds.index:
        # 2. 计算转股价值
        underlying = get_underlying_stock(bond)
        stock_price = get_current_price(underlying)
        conversion_price = get_conversion_price(bond)
        conversion_value = 100 * stock_price / conversion_price
        
        # 3. 当前可转债价格
        bond_price = get_current_price(bond)
        
        # 4. 转股溢价率
        premium = (bond_price - conversion_value) / conversion_value
        
        # 5. 筛选条件
        if (
            premium < 0.05         # 溢价 < 5%
            and bond_price < 110   # 价格合理
            and bond_price > 95    # 不是临近违约
        ):
            candidates.append({
                'bond': bond,
                'underlying': underlying,
                'price': bond_price,
                'conversion_value': conversion_value,
                'premium': premium,
            })
    
    return candidates


def convertible_bond_strategy():
    """可转债策略框架"""
    # 1. 筛选候选
    candidates = find_undervalued_convertible_bonds()
    
    # 2. 风险过滤（剔除违约风险高的）
    candidates = [c for c in candidates if check_credit_risk(c['bond']) == 'safe']
    
    # 3. 等权配置
    n = len(candidates)
    if n == 0:
        return
    
    weight_per_bond = 1.0 / n
    
    # 4. 下单
    for c in candidates:
        target_value = context.portfolio.total_value * weight_per_bond
        order_target_value(c['bond'], target_value)
```

### 4.5 历史实证

| 时期 | 可转债摸鱼策略 |
|---|---|
| **2017-2019**| 年化 15-25%（市场不饱和）|
| **2020-2021** | 年化 10-20%（饱和但仍有效）|
| **2022-2024** | 年化 5-15%（拥挤度上升）|
| **2024+** | **拥挤** → 预期降低 |

**警告**：可转债摸鱼已成为 A 股流行策略，**拥挤度上升 → alpha 衰减**。

---

## 5. 方案 4：ETF 跨市场套利

### 5.1 ETF 套利机制

**同标的不同 ETF**：

| 标的 | 不同发行人的 ETF |
|---|---|
| **沪深 300** | 510300（华泰柏瑞）/ 510310（易方达）/ 510330（华夏） |
| **中证 500** | 510500（华泰柏瑞）/ 510510（南方）|
| **创业板** | 159915（易方达）/ 159952（广发） |

**理论**：

- 跟踪同一指数，价格应**几乎相同**
- 跟踪误差通常 < 5 bp / 日
- **偶发短期偏离 → 套利机会**

### 5.2 套利方法

```python
def etf_arbitrage():
    """ETF 跨市场套利"""
    # 1. 同标的不同 ETF 对
    pairs = [
        ('510300.XSHG', '510310.XSHG'),  # 沪深 300
        ('510500.XSHG', '510510.XSHG'),  # 中证 500
    ]
    
    for etf_a, etf_b in pairs:
        # 2. 价格差异
        price_a = get_current_price(etf_a)
        price_b = get_current_price(etf_b)
        
        spread_pct = abs(price_a - price_b) / ((price_a + price_b) / 2) * 10000  # bp
        
        # 3. 套利信号
        if spread_pct > 30:  # 30 bp 以上偏离
            log.info(f'{etf_a} vs {etf_b}：偏离 {spread_pct:.1f} bp')
            # 买入便宜的 ETF
```

### 5.3 ETF 套利的局限

| 局限 | 内容 |
|---|---|
| **空间小** | 通常 < 30 bp |
| **执行速度要求高** | 需要快速下单 |
| **个人量化竞争** | 头部量化已布局 |
| **交易成本** | 双边 30 bp 已吃掉大部分 |

**结论**：

- **ETF 套利对 A 股个人意义有限**
- **机构 / 头部量化主导**
- 个人量化**作为辅助** ok，**不作为主策略**

---

## 6. 配对交易的 4 大陷阱（A 股化）

### 6.1 陷阱 1：协整断裂

> 详见 [协整与配对方法论.md](协整与配对方法论.md) § 协整断裂监控。

**A 股典型断裂**：

| 案例 | 时期 | 影响 |
|---|---|---|
| **银行业重组** | 2003 | 国有银行配对短期失效 |
| **2018 中美贸易战** | 2018 | 制造业配对断裂 |
| **2021 教育双减** | 2021 | 教育公司配对崩塌 |
| **2024 半导体国产替代** | 2020-2024 | 部分公司剧烈分化 |

**应对**：每月做滚动 ADF 检验，**协整断裂立即退出**。

### 6.2 陷阱 2：单边股票暴雷

**A 股版**：

| 案例 | 时期 |
|---|---|
| **乐视网** | 2016-2018 |
| **康得新** | 2019 财务造假 |
| **獐子岛** | 2018 扇贝事件 |

**应对**：

- **基本面风控**：剔除业绩持续恶化股
- **新闻监控**：商誉减值 / 财务造假预警 → 立即清仓
- **建立黑名单池** → 永久剔除高风险股

### 6.3 陷阱 3：资金成本

**A 股个人**：

- 融券利率 **8-15%** → 套利吃掉所有 alpha
- **解决方案**：用单边版（无做空），可转债策略

### 6.4 陷阱 4：流动性

**问题**：

- 小盘配对在回测中表现好
- 但**实际成交量小** → 滑点远超回测

**应对**：

- **要求日均成交额 > 5000 万**
- **持仓不超过日均成交 5%**
- **A 股最小流动性配对**：1 亿日均成交额以上的股票

---

## 7. A 股配对实务建议

### 7.1 起步推荐

| 阶段 | 推荐策略 |
|---|---|
| **入门**（< 50 万）| 可转债摸鱼 |
| **中级**（50-200 万）| 可转债 + 同业股单边配对 |
| **高级**（> 200 万）| 同业股单边 + 股指期货对冲 |
| **专业**（500 万+）| 多策略组合 + Barra 风险归因 |

### 7.2 实操检查清单

```python
def pre_trade_check(pair):
    """配对交易前检查清单"""
    checks = {
        # 1. 协整稳定性
        'cointegrated': check_cointegration(pair, multi_window=[60, 120, 250]),
        
        # 2. 半衰期合理
        'half_life_ok': 5 < compute_half_life(pair) < 60,
        
        # 3. 流动性
        'liquid_a': get_average_volume(pair[0], days=20) > 5e7,
        'liquid_b': get_average_volume(pair[1], days=20) > 5e7,
        
        # 4. 基本面健康
        'fundamentals_a': check_fundamentals(pair[0]),
        'fundamentals_b': check_fundamentals(pair[1]),
        
        # 5. 不在风险事件期
        'no_event': not has_pending_event(pair[0]) and not has_pending_event(pair[1]),
    }
    
    return all(checks.values()), checks
```

### 7.3 持续监控

```python
def monitor_active_pairs():
    """持续监控活跃配对"""
    for pair in active_pairs:
        # 1. 协整稳定性
        if not is_still_cointegrated(pair, lookback=60):
            close_position(pair, reason='cointegration_broken')
        
        # 2. 单边异常
        for stock in pair:
            if has_announcement_today(stock):  # 重大公告
                if assess_risk(stock) == 'high':
                    close_position(pair, reason='single_side_risk')
        
        # 3. 持有期超限
        if days_holding(pair) > max_holding_period:
            close_position(pair, reason='time_limit')
```

---

## 综合观察

- **A 股做空受限** → 经典双边配对**降级**为 4 种 A 股版方案
- **方案 1：同业股单边** —— 仅做差价偏低的一边，alpha 降低 50% 但风险降低
- **方案 2：股指期货对冲** —— 50 万门槛，仅适合大盘股
- **方案 3：可转债 vs 正股**（**A 股个人推荐**）—— 无杠杆 / 无做空 / 持有 1-3 月
- **方案 4：ETF 跨市场套利** —— 空间小，仅辅助
- **A 股稳定协整对**：四大行 / 保险双雄 / 头部券商
- **A 股断裂频繁**——监管 / 重组 / 黑天鹅，必须滚动监控
- **4 大陷阱**：协整断裂 / 单边暴雷 / 资金成本 / 流动性
- **可转债摸鱼策略已拥挤** —— 2024+ alpha 预期降低

## 参考与延伸

- [INDEX.md](INDEX.md) — 3.3 板块索引
- [协整与配对方法论.md](协整与配对方法论.md) — Chan ch7 完整方法论
- [[index-02-04-fundamental-factors]] — 基本面风控
- [[index-04-04-trading-cost-capacity]] — A 股交易成本与容量
- [[multi-factor-jq-strategy]] — 工业级策略
- [[empirical-factor-decay-cases]] — 4 个 A 股失效案例
- [[backtest-trading-rules]] — A 股交易制度陷阱
- [[independent-vs-institution-capacity-constraints]] — Chan 容量论
- [Chan ch7 + Python 实战 ch11](../../../原始资料文件/量化交易如何建立自己的算法交易事业/量化交易如何建立自己的算法交易事业-源文件.md)

[← 返回 3.3 索引](INDEX.md)
