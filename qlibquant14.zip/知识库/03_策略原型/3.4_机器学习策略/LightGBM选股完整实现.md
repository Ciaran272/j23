---
name: lightgbm-stock-selection-implementation
description: A 股 LightGBM 选股二分类完整实现 —— 标签设计 + 25 特征 + 训练 + 评估 + 聚宽端到端代码
category: 03_策略原型/3.4_机器学习策略
tags: [LightGBM, GBDT, A股选股, 二分类, 端到端实现, 聚宽, jqdatasdk]
created: 2026-05-17
updated: 2026-05-17
source: Whale-Quant ch08.2 + 1.5 ML 综述 + 业界 A 股经验
status: with-jq-impl
---

# LightGBM 选股完整实现

## TL;DR

**承接 Whale-Quant ch08.2**——但**完整改写为 A 股 jqdatasdk 版本**：

```
策略架构：
├── 1. 标签：未来 5 日"最高涨>5% 且最大跌>-3%" → 标 1
├── 2. 特征：25 个（5 大类，覆盖 [[empirical-single-factor-table]] A 股最强 5）
├── 3. 训练：LightGBM 二分类
├── 4. 预测：每月初对全市场预测"标 1 概率"
├── 5. 选股：取概率最高 top 30
├── 6. 风控：剔除 ST / 涨跌停 / 流动性差
└── 7. 配权：等权 / 风险平价
```

**核心 A 股化**：

- **原文 tushare → 改写 jqdatasdk**
- **特征改用 A 股最强 5 alpha**（-TVR_1 / STOM_barra / -IVOL / EP / -AG）
- **严格 OOS 验证**：6 / 2 / 2 切分（train / val / test）

**预期表现**（A 股 2022-2024）：

| 指标 | 区间 |
|---|---|
| **Test IC** | **0.05-0.10** |
| **R²_OOS** | **0.5-1.5%** |
| **年化超额（扣成本）** | **5-10%** |
| **夏普** | 0.5-1.0 |

## 来源

- **Whale-Quant ch08.2 LightGBM 选股**
- **[[ml-in-factor-investing-survey]] § Gu-Kelly-Xiu (2020) 综述**（树模型 > 线性）
- **[[a-share-ml-practice-and-pitfalls]] § 性价比清单 + 端到端 Pipeline**

---

## 1. Whale-Quant ch08.2 的核心创新

### 1.1 标签设计（关键）

> Whale-Quant ch08.2 的核心思路：

```
传统回归：预测下期具体收益率
   ↓
噪声大 / 受异常值影响

LightGBM 二分类（Whale-Quant 创新）：
   未来 5 日最高涨幅 > 5% 且最大跌幅 > -3% → 标 1（好股票）
   其他 → 标 0
   ↓
✓ 抗噪声（同 5%+ 涨幅都标 1）
✓ 业务可解释（"找到能涨且不大跌的股票"）
✓ 适合二分类（决策树天然处理）
```

**A 股化注记**：

- **5% / 3% 阈值可调**——A 股波动大，可放宽到 6% / -4%
- **持有期 5 日可调**——10 日 / 21 日都可尝试
- **标签平衡**：5% 阈值在 A 股约 15-20% 样本标 1（合理）

### 1.2 与回归方法对比

| 维度 | 二分类 | 回归 |
|---|---|---|
| 标签 | 0/1 | 具体收益率 |
| 受异常值影响 | **不敏感** | 敏感 |
| 业务解释 | **直观**（"好/差"）| 抽象 |
| 模型选择 | GBDT / 逻辑回归 | OLS / GBDT |
| A 股适用性 | **强** | 中 |

---

## 2. 25 个特征设计（基于 [[empirical-single-factor-table]]）

### 2.1 五大类特征

```python
# A 股最强 5 alpha + 增强特征（25 个）
features = {
    # 1. 趋势 / 反转类（5 个）
    'ret_1m':  'compute_return(stock, n=21)',
    'ret_3m':  'compute_return(stock, n=63)',
    'ret_12m': 'compute_return(stock, n=252)',
    'rsrs':    'compute_rsrs(stock)',
    'rsi_14':  'compute_rsi(stock, n=14)',
    
    # 2. 交易摩擦类（5 个 —— A 股最强）
    'tvr_1m':       'compute_turnover(stock, n=21)',
    'tvr_6m':       'compute_turnover(stock, n=126)',
    'amihud_illiq': 'compute_amihud(stock)',
    'stom_barra':   'compute_stom_barra(stock)',
    'mom_reversal_1m': '-compute_return(stock, n=21)',
    
    # 3. 风险类（5 个）
    'ivol':         'compute_ivol(stock)',
    'beta':         'compute_beta(stock)',
    'hv_21':        'compute_historical_vol(stock, n=21)',
    'dastd':        'compute_dastd(stock)',
    'high_low_1m':  'compute_high_low_range(stock, n=21)',
    
    # 4. 基本面类（5 个）
    'ep':  '1 / get_pe_ttm(stock)',
    'gp':  'compute_gross_profit_ratio(stock)',
    'roe': 'compute_roe(stock)',
    'roa': 'compute_roa(stock)',
    'ag':  'compute_asset_growth(stock)',
    
    # 5. 质量类（5 个）
    'f_score':       'compute_f_score(stock)',
    'debt_ratio':    'compute_debt_ratio(stock)',
    'cfo_to_ni':     'compute_cfo_to_net_income(stock)',
    'quality_score': 'compute_quality_score(stock)',
    'mom_industry_neutral': 'compute_industry_neutral_mom(stock)',
}
```

### 2.2 为什么选这 25 个

| 选择原因 | 内容 |
|---|---|
| **覆盖 5 类风险因子** | 趋势 / 流动性 / 风险 / 基本面 / 质量 |
| **A 股最强 5 alpha 全包含** | -TVR_1 / STOM_barra / -IVOL / EP / -AG |
| **数量适中** | 25 个 —— 既不过少也不过多（Whale-Quant ch08.2 建议 20-50）|
| **可解释** | 每个特征都有明确金融学含义 |
| **聚宽可获取** | 全部能从 jqdatasdk 计算 |

---

## 3. 完整端到端实现

### 3.1 训练阶段（独立运行）

```python
"""
A 股 LightGBM 选股训练
====================
独立运行（不在聚宽中）
保存模型 → 后续聚宽策略调用
"""
import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.preprocessing import StandardScaler
from jqdatasdk import *

auth('your_jq_username', 'your_password')


def compute_features(stocks, date):
    """计算 25 个特征"""
    features = pd.DataFrame(index=stocks)
    
    # 1. 趋势类（5）
    for n, name in [(21, 'ret_1m'), (63, 'ret_3m'), (252, 'ret_12m')]:
        prices_now = get_price(stocks, end_date=date, count=1, fields='close')['close']
        prices_n_ago = get_price(stocks, end_date=date, count=n+1, fields='close')['close'].iloc[0]
        features[name] = (prices_now - prices_n_ago) / prices_n_ago
    
    # 简化版 RSI / RSRS（实际应用展开完整逻辑）
    features['rsi_14'] = compute_rsi_batch(stocks, date, 14)
    features['rsrs'] = compute_rsrs_batch(stocks, date)
    
    # 2. 交易摩擦类（5）
    features['tvr_1m'] = compute_turnover_batch(stocks, date, n=21)
    features['tvr_6m'] = compute_turnover_batch(stocks, date, n=126)
    features['amihud_illiq'] = compute_amihud_batch(stocks, date)
    features['stom_barra'] = compute_stom_barra_batch(stocks, date)
    features['mom_reversal_1m'] = -features['ret_1m']
    
    # 3. 风险类（5）
    features['ivol'] = compute_ivol_batch(stocks, date)
    features['beta'] = compute_beta_batch(stocks, date)
    features['hv_21'] = compute_hv_batch(stocks, date, n=21)
    features['dastd'] = compute_dastd_batch(stocks, date)
    features['high_low_1m'] = compute_high_low_batch(stocks, date, n=21)
    
    # 4. 基本面类（5）
    fundamentals = get_fundamentals(
        query(valuation.code, valuation.pe_ratio,
              indicator.gross_profit_margin, indicator.roe, indicator.roa,
              valuation.market_cap)
        .filter(valuation.code.in_(stocks)),
        date=date
    )
    features['ep']  = 1 / fundamentals.set_index('code')['pe_ratio'].reindex(stocks)
    features['gp']  = fundamentals.set_index('code')['gross_profit_margin'].reindex(stocks)
    features['roe'] = fundamentals.set_index('code')['roe'].reindex(stocks)
    features['roa'] = fundamentals.set_index('code')['roa'].reindex(stocks)
    features['ag']  = compute_asset_growth_batch(stocks, date)
    
    # 5. 质量类（5）
    features['f_score']       = compute_f_score_batch(stocks, date)
    features['debt_ratio']    = compute_debt_ratio_batch(stocks, date)
    features['cfo_to_ni']     = compute_cfo_ni_batch(stocks, date)
    features['quality_score'] = compute_quality_score_batch(stocks, date)
    features['mom_industry_neutral'] = compute_industry_neutral_mom_batch(stocks, date)
    
    return features


def compute_label(stocks, date, lookforward=5, up_threshold=0.05, down_threshold=-0.03):
    """计算二分类标签
    
    未来 lookforward 日：
      最高涨幅 > up_threshold 且最大跌幅 > down_threshold → 标 1
      其他 → 标 0
    """
    next_period = get_price(
        stocks, start_date=date, count=lookforward,
        fields=['high', 'low']
    )
    
    labels = pd.Series(0, index=stocks)
    for stock in stocks:
        if stock not in next_period.columns:
            continue
        
        prices = next_period[stock]
        if prices.empty:
            continue
        
        current_price = get_price(stock, end_date=date, count=1)['close'].iloc[0]
        max_high = prices['high'].max()
        min_low = prices['low'].min()
        
        max_up = (max_high - current_price) / current_price
        max_down = (min_low - current_price) / current_price
        
        if max_up > up_threshold and max_down > down_threshold:
            labels[stock] = 1
    
    return labels


def prepare_training_data(start_date='2015-01-01', end_date='2020-12-31'):
    """准备训练数据"""
    # 月度日期
    dates = pd.date_range(start_date, end_date, freq='ME')
    
    all_features = []
    all_labels = []
    
    for date in dates:
        # 获取该月初有效股票池
        stocks = get_index_stocks('000300.XSHG', date=date.strftime('%Y-%m-%d'))
        stocks = filter_stocks(stocks, date)  # 剔除 ST / 新股 / 停牌
        
        # 计算特征
        features = compute_features(stocks, date.strftime('%Y-%m-%d'))
        
        # 计算标签
        labels = compute_label(stocks, date.strftime('%Y-%m-%d'))
        
        # 添加日期列
        features['date'] = date
        features['stock'] = features.index
        
        all_features.append(features)
        all_labels.append(labels)
    
    X = pd.concat(all_features).reset_index(drop=True)
    y = pd.concat(all_labels).reset_index(drop=True)
    
    return X, y


def train_lightgbm_model():
    """完整训练流程"""
    # 1. 准备数据（3 段切分）
    print("Loading training data (2015-2020)...")
    X_train_full, y_train_full = prepare_training_data('2015-01-01', '2020-12-31')
    
    print("Loading validation data (2021-2022)...")
    X_val, y_val = prepare_training_data('2021-01-01', '2022-12-31')
    
    print("Loading test data (2023-2024)...")
    X_test, y_test = prepare_training_data('2023-01-01', '2024-12-31')
    
    # 2. 特征工程
    feature_cols = [c for c in X_train_full.columns if c not in ['date', 'stock']]
    
    # 处理 NaN
    for col in feature_cols:
        X_train_full[col] = X_train_full[col].fillna(X_train_full[col].median())
        X_val[col] = X_val[col].fillna(X_train_full[col].median())  # 用训练集 median
        X_test[col] = X_test[col].fillna(X_train_full[col].median())
    
    # Winsorize（防止异常值）
    from scipy.stats.mstats import winsorize
    for col in feature_cols:
        X_train_full[col] = winsorize(X_train_full[col], limits=[0.01, 0.01])
    
    # 3. 标准化
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_full[feature_cols])
    X_val_scaled = scaler.transform(X_val[feature_cols])
    X_test_scaled = scaler.transform(X_test[feature_cols])
    
    # 4. LightGBM 训练（二分类）
    train_data = lgb.Dataset(X_train_scaled, label=y_train_full)
    val_data = lgb.Dataset(X_val_scaled, label=y_val)
    
    params = {
        'objective': 'binary',
        'metric': 'binary_logloss',
        'num_leaves': 31,
        'learning_rate': 0.05,
        'feature_fraction': 0.8,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'min_data_in_leaf': 20,
        'lambda_l1': 0.1,
        'lambda_l2': 0.1,
        'verbose': -1,
    }
    
    model = lgb.train(
        params,
        train_data,
        num_boost_round=500,
        valid_sets=[train_data, val_data],
        callbacks=[lgb.early_stopping(50)],
    )
    
    # 5. 评估
    train_pred = model.predict(X_train_scaled)
    val_pred = model.predict(X_val_scaled)
    test_pred = model.predict(X_test_scaled)
    
    # IC（用预测概率与实际标签的相关性）
    train_ic = pd.Series(train_pred).corr(pd.Series(y_train_full))
    val_ic = pd.Series(val_pred).corr(pd.Series(y_val))
    test_ic = pd.Series(test_pred).corr(pd.Series(y_test))
    
    print(f"Train IC: {train_ic:.4f}")
    print(f"Val IC: {val_ic:.4f}")
    print(f"Test IC: {test_ic:.4f}")
    print(f"OOS/IS ratio: {test_ic / train_ic:.2f}")
    
    # AUC（标准二分类指标）
    from sklearn.metrics import roc_auc_score
    print(f"Test AUC: {roc_auc_score(y_test, test_pred):.4f}")
    
    # 6. 特征重要性
    importance = pd.DataFrame({
        'feature': feature_cols,
        'importance': model.feature_importance('gain'),
    }).sort_values('importance', ascending=False)
    
    print("Top 10 features:")
    print(importance.head(10))
    
    # 7. 保存模型
    model.save_model('lightgbm_stock_selection.txt')
    # 保存 scaler
    import joblib
    joblib.dump(scaler, 'feature_scaler.pkl')
    
    return model, scaler, importance


# 运行
if __name__ == '__main__':
    model, scaler, importance = train_lightgbm_model()
```

### 3.2 推断阶段（聚宽实盘）

```python
"""
聚宽 LightGBM 选股策略（实盘）
============================
将训练好的 LightGBM 模型部署到聚宽
每月初预测 + 选股
"""
from jqdata import *
import lightgbm as lgb
import pandas as pd
import numpy as np


def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.00025,
                  close_commission=0.00025, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    g.benchmark = '000300.XSHG'
    
    # 加载训练好的模型（提前上传到聚宽研究环境）
    g.model = lgb.Booster(model_file='lightgbm_stock_selection.txt')
    
    # 加载 scaler
    import joblib
    g.scaler = joblib.load('feature_scaler.pkl')
    
    # 特征列表（必须与训练时一致）
    g.feature_cols = [
        'ret_1m', 'ret_3m', 'ret_12m', 'rsrs', 'rsi_14',
        'tvr_1m', 'tvr_6m', 'amihud_illiq', 'stom_barra', 'mom_reversal_1m',
        'ivol', 'beta', 'hv_21', 'dastd', 'high_low_1m',
        'ep', 'gp', 'roe', 'roa', 'ag',
        'f_score', 'debt_ratio', 'cfo_to_ni', 'quality_score', 'mom_industry_neutral',
    ]
    
    g.holdings_n = 30        # 持仓数
    g.rebalance_day = 1      # 每月第 1 个交易日
    
    # 月度调仓
    run_monthly(rebalance, monthday=g.rebalance_day, time='09:31')


def compute_features_for_jq(stocks, date):
    """聚宽内计算特征（简化版，实际应用展开完整逻辑）"""
    features = pd.DataFrame(index=stocks)
    
    # 这里调用 [训练阶段] 中定义的 compute_features 函数
    # 注意：jqdatasdk API 调用可能比训练时慢——可能需要预先缓存
    features = compute_features(stocks, date)  # 与训练时一致
    
    return features[g.feature_cols]


def filter_stocks(stocks, date):
    """过滤 A 股黑名单"""
    # 1. 剔除 ST
    stocks = [s for s in stocks if not get_security_info(s).display_name.startswith('*ST')]
    
    # 2. 剔除新股（上市 < 180 天）
    stocks = [
        s for s in stocks
        if (date - pd.Timestamp(get_security_info(s).start_date)).days > 180
    ]
    
    # 3. 剔除停牌
    paused = pd.Series({s: get_price(s, end_date=date, count=1).empty for s in stocks})
    stocks = [s for s in stocks if not paused.get(s, True)]
    
    # 4. 剔除涨跌停（避免开盘买入但当日停板）
    last_close = pd.Series({
        s: get_price(s, end_date=date, count=1, fields='close')['close'].iloc[0]
        if not get_price(s, end_date=date, count=1).empty else np.nan
        for s in stocks
    })
    
    return stocks


def rebalance(context):
    """每月调仓"""
    date = context.current_dt.date()
    
    # 1. 候选股票池（沪深 300）
    candidates = get_index_stocks(g.benchmark, date=date.strftime('%Y-%m-%d'))
    candidates = filter_stocks(candidates, date.strftime('%Y-%m-%d'))
    
    if len(candidates) < g.holdings_n:
        log.info(f'候选不足 {g.holdings_n}，跳过')
        return
    
    # 2. 计算特征
    features = compute_features_for_jq(candidates, date.strftime('%Y-%m-%d'))
    
    # 3. 处理 NaN
    features = features.fillna(features.median())
    
    # 4. 标准化（用训练时的 scaler）
    features_scaled = g.scaler.transform(features.values)
    
    # 5. LightGBM 预测概率
    probs = g.model.predict(features_scaled)
    
    # 6. 排序选 top N
    pred_df = pd.DataFrame({
        'stock': features.index,
        'prob': probs,
    }).sort_values('prob', ascending=False)
    
    selected = pred_df.head(g.holdings_n)['stock'].tolist()
    
    log.info(f'选股 top {g.holdings_n}: {selected[:5]}...')
    
    # 7. 清仓不在 selected 的股票
    current_positions = set(context.portfolio.positions.keys())
    for stock in current_positions:
        if stock not in selected:
            order_target_value(stock, 0)
    
    # 8. 买入 / 调整 selected 股票（等权）
    weight = 1.0 / g.holdings_n
    target_value = context.portfolio.total_value * weight
    
    for stock in selected:
        # 检查涨停 / 停牌
        if not is_buyable(stock, date):
            log.info(f'{stock} 不可买入，跳过')
            continue
        
        order_target_value(stock, target_value)
    
    log.info(f'调仓完成，持仓 {len(context.portfolio.positions)} 只')


def is_buyable(stock, date):
    """判断股票是否可买入"""
    try:
        prices = get_price(stock, end_date=date, count=2, fields=['close', 'high', 'low'])
        if prices.empty or len(prices) < 2:
            return False
        
        last_close = prices['close'].iloc[-2]
        today_open = get_current_price(stock)
        
        # 涨停 = 高于昨日收盘 9.9%
        if today_open >= last_close * 1.099:
            return False
        
        return True
    except:
        return False
```

---

## 4. 预期表现与调优

### 4.1 A 股 LightGBM 选股的预期表现

> 基于 [[empirical-multi-factor-portfolio]] § 3.1 工业级策略 + ML 增强：

| 指标 | 区间 | 备注 |
|---|---|---|
| **Train IC** | 0.10-0.15 | 过高（> 0.20）= 过拟合 |
| **Val IC** | 0.06-0.10 | 调超参用 |
| **Test IC** | **0.05-0.10** | **A 股现代水平** |
| **AUC** | 0.55-0.62 | 二分类指标 |
| **OOS/IS ratio** | **> 0.5** | 过拟合阈值 |
| **R²_OOS** | 0.5-1.5% | Gu-Kelly-Xiu 阈值 |
| **年化超额（扣成本）** | **5-10%** | 与现代沪深 300 增强基准一致 |
| **夏普** | 0.5-1.0 | |

### 4.2 超参调优清单

| 参数 | 推荐范围 | A 股建议 |
|---|---|---|
| `num_leaves` | 31-127 | **31**（不要太复杂）|
| `learning_rate` | 0.01-0.1 | **0.05**（保守）|
| `min_data_in_leaf` | 10-100 | **20+**（防过拟合）|
| `feature_fraction` | 0.6-1.0 | 0.8 |
| `bagging_fraction` | 0.6-1.0 | 0.8 |
| `lambda_l1 / l2` | 0-1.0 | **0.1+**（A 股需更强正则）|
| `num_boost_round` | 100-1000 | **500 + early stopping** |

### 4.3 特征重要性（A 股预期排名）

| 排名 | 特征 | 重要性 |
|---|---|---|
| 1 | **tvr_1m**（换手率 1 月）| 极高 |
| 2 | **stom_barra**（流动性）| 极高 |
| 3 | **ivol**（特质波动率）| 高 |
| 4 | **mom_reversal_1m**（短期反转）| 高 |
| 5 | **ep**（盈利市值比）| 中-高 |
| 6 | **gp**（毛利率）| 中 |
| 7-25 | 其他 | 中 / 低 |

**与 [[empirical-single-factor-table]] § A 股最强 5 alpha 一致**——印证 ML 模型能"学到"A 股真正的 alpha。

---

## 5. 与 1.5 ML 综述的对比

| 维度 | 1.5 综述 | 本板块（3.4） |
|---|---|---|
| **角色** | 方法论 | **策略原型** |
| **内容** | Gu-Kelly-Xiu + IPCA + 性价比清单 | **端到端 A 股代码** |
| **抽象度** | 高 | **低（可直接抄）** |
| **A 股化** | 性价比清单 | **完整 jqdatasdk 实现** |

**两者关系**：

- **先读 1.5**：建立 ML 心智模型
- **再读本板块**：抄代码直接落地

---

## 6. A 股 LightGBM 选股的"绝不"清单

> 与 [[a-share-ml-practice-and-pitfalls]] 一致：

| 绝不 | 原因 |
|---|---|
| **绝不**用随机切分时序数据 | 未来函数 |
| **绝不**在测试集上调超参 | 测试集报废 |
| **绝不**忽略 PIT（财务数据）| 未来函数最隐蔽 |
| **绝不**用 100+ 特征 + 单模型 | 必过拟合 |
| **绝不**忽略实盘交易成本 | 回测 vs 实盘差距大 |
| **绝不**单押 ML 模型 | 与经典因子集成 |
| **绝不**忽略拥挤度 | A 股 5 年崩 3 次 |
| **绝不**用 LSTM / Transformer 选股 | 信噪比太低 |

---

## 7. 综合：A 股 LightGBM 选股的 7 步落地

```python
def a_share_lightgbm_pipeline():
    """A 股 LightGBM 选股 7 步落地"""
    
    # Step 1: 数据准备（jqdatasdk）
    stocks = get_index_stocks('000300.XSHG')
    
    # Step 2: 特征工程（25 个特征）
    features = compute_25_features(stocks, dates)
    
    # Step 3: 标签设计（二分类）
    labels = compute_binary_label(stocks, dates, lookforward=5)
    
    # Step 4: 3 段切分（train / val / test）
    train, val, test = time_series_split(features, labels, ratio=[0.6, 0.2, 0.2])
    
    # Step 5: LightGBM 训练
    model = train_lightgbm_with_early_stopping(train, val)
    
    # Step 6: 评估（IC + AUC + R²_OOS）
    metrics = evaluate(model, test)
    
    # Step 7: 部署到聚宽 / 实盘
    deploy_to_joinquant(model)
    
    return model, metrics
```

---

## 综合观察

- **LightGBM 二分类选股**是 A 股工业级标配
- **标签设计创新**（5% 涨 + -3% 跌 → 标 1）：抗噪声 + 业务直观
- **25 个特征**覆盖 A 股最强 5 alpha + 增强
- **预期 Test IC 0.05-0.10**（A 股现代水平）
- **特征重要性 Top 5** 与 [[empirical-single-factor-table]] § A 股最强 5 alpha 高度一致
- **不要用 LSTM 选股**——A 股信噪比太低
- **必须严格 OOS 验证**——避免 p-hacking
- **与经典多因子集成** > 单押 ML

## 参考与延伸

- [INDEX.md](INDEX.md) — 3.4 板块索引
- [时序模型择时.md](时序模型择时.md) — ARIMA / GARCH / LSTM 时序择时
- [[ml-in-factor-investing-survey]] — Gu-Kelly-Xiu 综述
- [[a-share-ml-practice-and-pitfalls]] — A 股 ML 7 层性价比 + 6 类避坑
- [[empirical-single-factor-table]] — A 股最强 5 alpha（特征重要性的真值）
- [[empirical-multi-factor-portfolio]] — A 股现代基准
- [[multi-factor-jq-strategy]] — 工业级多因子选股（无 ML 版本）
- [[ic-test-and-combination]] — IC 加权 vs ML 集成
- [[backtest-data-pitfalls]] — A 股数据陷阱 + PIT
- [[behavioral-finance-and-investor-sentiment]] § 投资者情绪 — 可作 ML 特征
- [Whale-Quant ch08.2](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/速览_whale_quant.md) — 原文 LightGBM 选股

[← 返回 3.4 索引](INDEX.md)
