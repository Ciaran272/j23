---
name: index-03-strategy-prototypes
description: 一级分类 03_策略原型 —— 多因子选股、择时、布林带、动量轮动、全球 ETF 趋势门控、吊灯止损、统计套利与配对、ML 策略、季节性与事件
category: 03_策略原型
tags: [多因子选股, 择时, RSRS, 布林带, BOLL, 动量轮动, 全球ETF, 相对强弱, 目标权重, MA200, 吊灯止损, ATR, 统计套利, 配对交易, 协整, 机器学习, LightGBM, 季节性, PEAD]
created: 2026-05-16
updated: 2026-05-29
status: stable
---

# 03_策略原型 · 索引

本分类回答**"能照搬的完整策略长什么样"**——从 02 因子库取因子，配上 04 组合风控、05 工程，构成可落地的端到端策略。

## 范围

5 类核心策略原型，每类都给：原理 / 完整聚宽实现 / A 股化注记 / 已知坑 / 改造方向。**目标是用户复制即可跑出第一版回测**。

---

## 二级分类与内容来源

| # | 二级分类 | 一句话定位 | 主要来源 |
|---|---|---|---|
| 3.1 | 多因子选股 | 单/多因子选股 + IC 合成 + 风格中性 4 步流程 | Whale-Quant ch04 + Python 实战 ch6 + GTJA-191 ch3.6 + 因子投资 ch4 |
| 3.2 | 择时策略 | 双均线 + MACD + RSRS 四版本 + 布林带 + 动量轮动 + 目标权重趋势过滤 + 全球 ETF 双均线门控 + 吊灯止损 + SVM 多空切换 | Whale-Quant ch05 + Python 实战 ch7.2 + ch9.5 + MyInvestPilot |
| 3.3 | 统计套利与配对 | 协整 + ADF + O-U 半衰期 + 阈值进出场（A 股单边版） | Chan ch7.3 / ch7.5 + Python 实战 ch11 |
| 3.4 | 机器学习策略 | LightGBM 选股 + ARIMA/GARCH/LSTM 择时 | Whale-Quant ch08.2 / ch08.3 + 因子投资 ch6.8 |
| 3.5 | 季节性与事件 | 一月效应、PEAD（中国版业绩预告） | Chan ch7.6 / ch7.1 |

---

## 详细内容计划

### 3.1 多因子选股
- Whale-Quant ch04：市场有效性 → MPT/CAPM 推导 → APT/多因子 → 因子有效性检验 → 行业/市值中性化 → Python 多因子实践
- Python 实战 ch6：6.1 因子分类 + 6.2 **IC 值合成 4 步法** + 6.3 多因子矩阵构建 + 回测
- GTJA-191 ch3.6：**风格中性多因子选股 4 步流程**（正交标准化 → 因子收益回归 → 预测合成 → 组合优化）
- 因子投资 ch4：多因子模型在 A 股的应用（FF3 vs CH-3 等）
- **聚宽落地范例**：完整可跑的多因子选股骨架（initialize / handle_data / before_trading_start）

### 3.2 择时策略
- Whale-Quant ch05：双均线（Granville 八大法则）+ MACD 均线择时
- Python 实战 ch7.2：**RSRS 完整四版本**（标准 / 标准分 / 修正 / 右偏）—— A 股招牌择时
- Python 实战 ch9.5：SVM 选股（性质是择时多空切换；**TF1.x 代码丢弃，改用 sklearn**）
- MyInvestPilot Bollinger Bands：BOLL 中轨/上下轨/%B/带宽，作为震荡均值回归与趋势突破的波动通道模块
- MyInvestPilot Momentum Rotation：QQQ/GLD/GBTC 18 日相对动量三选一，作为跨资产 ETF 轮动的外部案例
- MyInvestPilot TargetWeightTrendFilterStrategy：固定目标权重 + MA200 月末门控 + 现金不再分配，适合跨市场 ETF / QDII / LOF 篮子的仓位控制
- MyInvestPilot Dual Moving Average Global ETF：13 个全球 ETF/资产独立金叉死叉进出，作为多资产绝对趋势门控的外部案例
- MyInvestPilot Chandelier Exit：QQQ/XLK/ARKK 等成长 ETF 独立 ATR trailing stop，作为趋势策略退出/风控模块的外部案例
- **A 股化注记**：T+1（当日买入次日才能卖）、涨跌停（停板时不能开仓 / 出场）、停复牌过滤

### 3.3 统计套利与配对
- Chan ch7.3 平稳性 / 协整 / ADF 检验（GLD/GDX 协整 t=-3.36）
- Chan ch7.5 Ornstein-Uhlenbeck 均值回归 + 半衰期 ln(2)/θ（GLD/GDX 10 天）
- Chan ch7.2 状态转换（批评马尔可夫模型固定转移概率假设 + GS 案例）
- Python 实战 ch11 完整配对：相关性 → 均值方差协方差 → ADF → OLS 求对冲比率 → 残差 ±3σ 阈值
- **A 股化注记（核心）**：
  - **不能裸做空** → 配对降级为"价差择时多头边"
  - 与经典美股双边配对的差异要写在每个段落前，避免误用
  - Python 实战 ch11 自己也"略过空腿"——参考其单边实现
- **聚宽落地范例**：建行 / 农行同业股的协整择时（statsmodels.tsa.stattools.adfuller）

### 3.4 机器学习策略
- Whale-Quant ch08.2 LightGBM 选股：把选股转化为二分类（未来 5 日最高涨 >5% 且最大跌 >-3% 标 1）
  - **A 股化注记**：原文用 tushare 拉数据，改写为 jqdatasdk
- Whale-Quant ch08.3 ARIMA / GARCH / LSTM 用于择时
- 因子投资 ch6.8 ML 在因子投资中的应用（作为方法论锚点，详细方法论在 [[index-01-methodology]] 1.5 节）
- Python 实战 ch9.5 SVM 选股（**重写**，丢 TF1.x 与掘金特有 API）
- **聚宽落地范例**：用 jqfactor 或本地 LightGBM 做选股二分类

### 3.5 季节性与事件
- Chan ch7.6 一月效应（SP600 月度回测 8.81%）+ 月度季节 + 商品期货季节性
- Chan ch7.1 PEAD（盈余公告后漂移）
- **A 股化注记**：
  - 一月效应在 A 股是否成立的实证空白点要标注 —— 春节后效应替代
  - PEAD 用 A 股**业绩预告披露日期**（聚宽 `finance.STK_INCOME_STATEMENT_PARENT.pub_date`）
  - 商品期货季节性（汽油 / 天然气）原理保留，A 股商品期货市场结构不同，需独立验证

---

## 文件清单

按二级分类的文件清单：

### 3.1_多因子选股 ([INDEX](3.1_多因子选股/INDEX.md))
- [多因子选股_方法论总览.md](3.1_多因子选股/多因子选股_方法论总览.md) — 三个流派对比（FM / 公司特征 / GTJA-191）+ 完整工作流 + GTJA-191 风格中性 4 步流程
- [IC检验与合成.md](3.1_多因子选股/IC检验与合成.md) — IC 4 种定义 + 单因子检验 + 4 种合成方法（等权/IC加权/IR加权/PCA/Logistic）+ jqfactor_analyzer
- [行业中性化_实务.md](3.1_多因子选股/行业中性化_实务.md) — 极值/标准化/行业/市值-风格 4 类中性化 + 财务 PIT 处理 + 聚宽实现
- [工业级策略_完整聚宽.md](3.1_多因子选股/工业级策略_完整聚宽.md) — 端到端可跑的工业级多因子策略（IC 加权 + 行业市值中性 + 调仓约束）

### 3.2_择时策略 ([INDEX](3.2_择时策略/INDEX.md)) ✓ 已成型
- [择时方法论总览.md](3.2_择时策略/择时方法论总览.md) — 8 种客观技术择时 + 因子投资 5 种因子择时 + Chan / 业界"因子择时很难"共识 + A 股化要点
- [A股择时实现.md](3.2_择时策略/A股择时实现.md) — Granville 八大法则双均线 + MACD + RSRS 引用 + 多重确认完整聚宽实现 + 5 大 A 股避坑（T+1 / 涨跌停 / 停复牌）
- [动量轮动策略_外部案例.md](3.2_择时策略/动量轮动策略_外部案例.md) — MyInvestPilot 外部案例：QQQ/GLD/GBTC 18 日动量三选一，含公开组合数据结构、Qlib 复现路线和 A 股化注记
- [目标权重趋势过滤策略_外部案例.md](3.2_择时策略/目标权重趋势过滤策略_外部案例.md) — MyInvestPilot 外部案例：固定目标权重 + MA200 月末门控 + 现金不再分配，含美股4号与 A 股 ETF/QDII 适配
- [双均线全球ETF策略_外部案例.md](3.2_择时策略/双均线全球ETF策略_外部案例.md) — MyInvestPilot 外部案例：13 个全球 ETF/资产独立金叉死叉进出，含公开数据库结构、参数反推路线和 A 股/QDII 适配
- [吊灯止损ETF策略_外部案例.md](3.2_择时策略/吊灯止损ETF策略_外部案例.md) — MyInvestPilot 外部案例：QQQ/XLK/ARKK 等成长 ETF 独立 ATR trailing stop，含状态机实现、公开数据库结构和 A 股/QDII 适配

### 3.3_统计套利与配对 ([INDEX](3.3_统计套利与配对/INDEX.md)) ✓ 已成型
- [协整与配对方法论.md](3.3_统计套利与配对/协整与配对方法论.md) — Chan ch7.3+7.5：协整 / ADF 检验 / OLS 对冲比率 / OU 半衰期完整推导（GLD/GDX 经典案例）
- [A股单边配对实现.md](3.3_统计套利与配对/A股单边配对实现.md) — A 股做空受限的 4 种降级方案：同业股单边 / 期货对冲 / 可转债套利 / ETF 跨市场 + 完整聚宽实现

### 3.4_机器学习策略 ([INDEX](3.4_机器学习策略/INDEX.md)) ✓ 已成型
- [LightGBM选股完整实现.md](3.4_机器学习策略/LightGBM选股完整实现.md) — Whale-Quant ch08.2 端到端 A 股 LightGBM 二分类选股 + 25 特征 + jqdatasdk 改写 + 完整聚宽代码
- [时序模型择时.md](3.4_机器学习策略/时序模型择时.md) — ARIMA / GARCH / LSTM 用于大盘择时 + Statsmodels 实现 + LSTM 在 A 股不推荐的原因

### 3.5_季节性与事件 ([INDEX](3.5_季节性与事件/INDEX.md)) ✓ 已成型
- [季节性策略.md](3.5_季节性与事件/季节性策略.md) — Chan ch7.6 一月效应 / 跨年趋势 / 商品期货季节性 + A 股春节效应 + 月度季节性
- [事件驱动_PEAD.md](3.5_季节性与事件/事件驱动_PEAD.md) — PEAD 完整原理 + A 股 8 类业绩预告 + 聚宽 finance.STK_FIN_FORECAST 实现 + 11 类事件机会

---

[← 返回主索引](../INDEX.md)
