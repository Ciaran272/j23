---
name: a-stock-position-management
description: A 股仓位管理实务 —— 个人 / 私募的仓位策略、聚宽凯利仓位实现、动态调仓示例、波动率定额、硬止损
category: 04_组合与风控/4.2_凯利公式与仓位管理
tags: [A股, 仓位管理, 凯利, 聚宽, 波动率定额, 止损, 实务]
created: 2026-05-17
updated: 2026-05-17
status: with-jq-impl
---

# A 股仓位管理实务与聚宽实现

## TL;DR

把凯利公式 + 半凯利 + 风险传染 + 厚尾防御组合成 A 股可执行的仓位管理体系。本文给出：**5 种 A 股仓位管理范式** + **聚宽凯利仓位完整实现** + **动态仓位调整示例**（结合波动率定额 + 硬止损 + 拥挤监控）。**承接 4.1 组合优化（"股票面"），4.2 是"资金面"——决定用多少资金参与**。

## 来源

- 综合 [[kelly-single-strategy]] / [[kelly-multi-strategy]] / [[kelly-risk-tail]] 三文档
- A 股实务参考：Chan ch6 + GTJA-191 ch3.6.4 + 因子投资 ch7.3

---

## 5 种 A 股仓位管理范式

| 范式 | 仓位决定方式 | 适用 |
|---|---|---|
| **固定仓位** | 始终满仓 / 始终 80% | 入门 / Demo |
| **凯利仓位** | $f^* = m/s^2$ 反推 | 严肃量化 |
| **波动率定额** | 调整 $f$ 使组合年化波动 = 目标 | 大型资管 |
| **风险预算** | 资金分配给多策略，每策略一个风险预算 | 多策略组合 |
| **动态止损** | 月度亏损 > 阈值时减仓 | 实战防御 |

实务中**多种组合使用**——例如：基础是凯利 + 加波动率定额 + 加硬止损。

---

## 范式 1：固定仓位

### 公式

$$f = \text{const}$$ 

常见 $f \in \{0.5, 0.7, 0.8, 1.0\}$。

### 聚宽实现

```python
# 在 initialize 中决定固定仓位
def initialize(context):
    g.target_position = 0.8  # 80% 仓位

# 在 rebalance 中应用
def rebalance(context):
    target_securities = select_stocks(context)
    n = len(target_securities)
    target_weight = g.target_position / n  # 每只股票权重
    
    for security in target_securities:
        order_target_percent(security, target_weight)
```

### 优劣

- **优点**：极简，无任何估计 / 优化
- **缺点**：忽略市场状态、组合风险、夏普变化

---

## 范式 2：凯利仓位

### 公式

```python
f_kelly = (excess_return / variance) * kelly_fraction
```

其中 `kelly_fraction` 通常 0.25-0.5（半凯利或更保守）。

### A 股化注记

- **个人账户不能加杠杆**：$f \in [0, 1]$
- **预期收益 $m$ 用滚动均值**：60-120 日平均日收益 × 252
- **方差 $s^2$ 用滚动估计**：60-120 日方差

### 聚宽实现

```python
def kelly_position(returns: pd.Series, kelly_fraction=0.5, max_position=1.0):
    """凯利仓位计算
    
    Args:
        returns: 策略历史日收益序列
        kelly_fraction: 半凯利系数（0.5 推荐，0.25 更保守）
        max_position: 仓位上限（A 股个人账户 = 1.0）
    
    Returns: 推荐仓位（0-1）
    """
    if len(returns) < 30:
        return 0.5  # 数据不足时默认 50%
    
    annual_return = returns.mean() * 252
    annual_var = returns.var() * 252
    
    if annual_var <= 0:
        return 0.0
    
    # 假设无风险利率 3%
    r_f = 0.03
    f_full = (annual_return - r_f) / annual_var
    f_kelly = f_full * kelly_fraction
    
    # 截断到 [0, max_position]
    return max(0, min(f_kelly, max_position))


# 在策略中应用
def rebalance(context):
    # 1. 选股
    target_securities = select_stocks(context)
    
    # 2. 计算凯利仓位
    portfolio_returns = compute_portfolio_returns(context)  # 历史组合收益
    target_position = kelly_position(portfolio_returns, kelly_fraction=0.5)
    log.info(f'凯利仓位：{target_position:.2%}')
    
    # 3. 应用仓位（每只股票 target_position / N）
    n = len(target_securities)
    weight_per_stock = target_position / n
    for security in target_securities:
        order_target_percent(security, weight_per_stock)
```

### 实务效果

- 高夏普期（如 2017-2020 量化指增黄金期）：凯利推 1.0× 仓位
- 低夏普期（如 2024 量化阴跌）：凯利推 0.3-0.5× 仓位
- **隐含的"风险敏感"特性**——策略表现差时自动减仓

---

## 范式 3：波动率定额（Volatility Targeting）

### 公式

设目标年化波动 $\sigma_{\text{target}}$，组合实际年化波动 $\sigma_{\text{port}}$，则：

$$f = \frac{\sigma_{\text{target}}}{\sigma_{\text{port}}}$$

### A 股建议

| 目标波动 | 投资者类型 |
|---|---|
| 5% | 极保守（接近债券） |
| 10% | 保守 |
| **15%** | **稳健**（推荐） |
| 20% | 中度激进 |
| 25% | 激进 |
| 30%+ | 极度激进 |

### 聚宽实现

```python
def volatility_targeting_position(returns: pd.Series, target_vol=0.15, max_position=1.0):
    """波动率定额仓位
    
    Args:
        returns: 历史日收益序列
        target_vol: 目标年化波动
        max_position: 最大仓位倍数（个人账户 = 1.0，融资融券账户可 1.5-2.0）
    
    Returns: 推荐仓位
    """
    if len(returns) < 30:
        return 0.5
    
    realized_vol = returns.std() * np.sqrt(252)
    if realized_vol <= 0:
        return 0.0
    
    f = target_vol / realized_vol
    return max(0, min(f, max_position))  # 默认不加杠杆；融资账户传 max_position=1.5
```

### 优劣

- **优点**：组合波动稳定，**回撤受控**
- **缺点**：低波动期增仓 → 可能在"风险已积累但未爆发"时加杠杆

---

## 范式 4：风险预算

### 概念

把总组合分给多个策略，**每个策略分配一个"风险预算"**：

```
策略 A 风险预算：30%（贡献 30% 组合波动）
策略 B 风险预算：50%（贡献 50%）
策略 C 风险预算：20%（贡献 20%）
```

### 与风险平价的区别

| | 风险平价 | 风险预算 |
|---|---|---|
| 风险分配 | 每只股票平等 | 按预算分配 |
| 适用范围 | 单一策略内 | 多策略组合 |

### 实现

```python
def risk_budget_allocation(
    strategies: dict,  # {name: 日收益序列}
    risk_budgets: dict,  # {name: 0~1，所有和为 1}
) -> dict:
    """根据风险预算分配资金"""
    # 计算每个策略的波动率
    vols = {name: r.std() * np.sqrt(252) for name, r in strategies.items()}
    
    # 风险预算转资金权重
    # 思路：策略 i 的资金权重 ∝ 风险预算_i / 波动率_i
    # 然后归一化使总和 = 1
    weights = {name: risk_budgets[name] / vols[name] for name in strategies}
    total = sum(weights.values())
    if total > 0:
        weights = {name: w / total for name, w in weights.items()}
    return weights
```

---

## 范式 5：动态止损

### 多层止损规则

```python
def dynamic_stop_loss(context, recent_returns, drawdown_threshold=-0.05):
    """动态止损 - 多层规则"""
    current_value = context.portfolio.total_value
    starting_cash = context.portfolio.starting_cash
    
    # 1. 总回撤止损
    total_return = current_value / starting_cash - 1
    if total_return < -0.20:  # 总回撤 20%
        log.warning(f'总回撤 {total_return:.2%}，触发清仓')
        return 'all_out'
    
    # 2. 月度回撤止损
    if len(recent_returns) >= 21:
        monthly_return = (1 + recent_returns.tail(21)).prod() - 1
        if monthly_return < drawdown_threshold:  # 月度回撤 5%
            log.warning(f'月度回撤 {monthly_return:.2%}，减仓 50%')
            return 'reduce_half'
    
    # 3. 周度回撤止损
    if len(recent_returns) >= 5:
        weekly_return = (1 + recent_returns.tail(5)).prod() - 1
        if weekly_return < -0.03:  # 周回撤 3%
            log.warning(f'周回撤 {weekly_return:.2%}，减仓 25%')
            return 'reduce_quarter'
    
    return 'normal'


# 在调仓中应用
def rebalance(context):
    recent_returns = compute_recent_returns(context, days=30)
    action = dynamic_stop_loss(context, recent_returns)
    
    if action == 'all_out':
        for s, p in context.portfolio.positions.items():
            if p.total_amount > 0:
                order_target_percent(s, 0)
        return  # 不再开仓
    
    target_position = 1.0
    if action == 'reduce_half':
        target_position = 0.5
    elif action == 'reduce_quarter':
        target_position = 0.75
    
    # 应用 target_position 到选股
    target_securities = select_stocks(context)
    weight_per_stock = target_position / len(target_securities)
    for security in target_securities:
        order_target_percent(security, weight_per_stock)
```

---

## 完整综合示例：升级版工业级策略

把"凯利仓位 + 波动率定额 + 硬止损 + 4.1 组合优化"组合：

```python
"""
完整仓位管理 + 多因子选股 + 风险平价配权
= 4.1 + 4.2 集成
"""
from jqdata import *
import pandas as pd
import numpy as np

def initialize(context):
    set_benchmark('000300.XSHG')
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_slippage(FixedSlippage(0.002))
    set_order_cost(
        OrderCost(close_tax=0.0005, open_commission=0.0003,
                  close_commission=0.0003, min_commission=5),
        type='stock',
    )
    log.set_level('order', 'error')
    
    g.target_count = 30
    g.target_vol = 0.15      # 目标年化波动 15%
    g.kelly_fraction = 0.5   # 半凯利
    g.max_drawdown = -0.20   # 总回撤上限 20%
    
    run_daily(before_market_open, time='before_open')
    run_monthly(rebalance, monthday=1, time='9:31')
    run_daily(after_market_close, time='after_close')


def compute_position_size(context, returns_history) -> float:
    """计算目标总仓位（组合 + 仓位管理）"""
    if len(returns_history) < 30:
        return 0.5
    
    # 1. 凯利仓位
    annual_ret = returns_history.mean() * 252
    annual_var = returns_history.var() * 252
    r_f = 0.03
    kelly = max(0, (annual_ret - r_f) / annual_var if annual_var > 0 else 0)
    kelly_position = min(kelly * g.kelly_fraction, 1.0)
    
    # 2. 波动率定额
    realized_vol = returns_history.std() * np.sqrt(252)
    vol_target = min(g.target_vol / realized_vol if realized_vol > 0 else 1.0, 1.0)
    
    # 3. 取两者较小（更保守）
    position = min(kelly_position, vol_target)
    
    # 4. 硬止损 - 总回撤检查
    total_return = context.portfolio.total_value / context.portfolio.starting_cash - 1
    if total_return < g.max_drawdown:
        log.warning(f'总回撤 {total_return:.2%}，触发清仓')
        return 0.0
    
    # 5. 月度回撤检查
    if len(returns_history) >= 21:
        monthly = (1 + returns_history.tail(21)).prod() - 1
        if monthly < -0.05:
            position *= 0.5  # 减仓一半
    
    return max(0, position)


def rebalance(context):
    log.info(f'==== 调仓开始：{context.current_dt.date()} ====')
    
    # 1. 计算历史组合收益（用 attribute_history 等方式）
    # 简化：用基准近似
    benchmark = '000300.XSHG'
    bench_data = attribute_history(benchmark, count=60, unit='1d', fields=['close'])
    returns_history = bench_data['close'].pct_change().dropna()
    
    # 2. 计算目标仓位
    target_total_position = compute_position_size(context, returns_history)
    log.info(f'目标总仓位：{target_total_position:.2%}')
    
    if target_total_position < 0.05:  # 仓位过低就清仓
        for s, p in context.portfolio.positions.items():
            if p.total_amount > 0:
                order_target_percent(s, 0)
        log.info('仓位过低，清空')
        return
    
    # 3. 选股（来自 3.1 多因子选股）
    target_securities = select_top_factors(context)  # 假设已实现
    if not target_securities:
        return
    
    # 4. 配权（来自 4.1 组合优化，简化为等权）
    weight_per_stock = target_total_position / len(target_securities)
    
    # 5. 调仓
    current_data = get_current_data()
    
    # 卖出
    held = [s for s, p in context.portfolio.positions.items() if p.total_amount > 0]
    for s in held:
        if s in target_securities:
            continue
        info = current_data[s]
        if info.paused or info.low_limit == info.last_price:
            continue
        order_target_percent(s, 0)
    
    # 买入 / 调到目标
    for s in target_securities:
        info = current_data[s]
        if info.paused or info.high_limit == info.last_price:
            continue
        order_target_percent(s, weight_per_stock)
    
    log.info(f'调仓完成，总仓位 ≈ {target_total_position:.2%}')
```

---

## A 股仓位管理的决策树

```
Q1: 你能加杠杆吗？
├── 是 → 用完整凯利公式（含杠杆）
└── 否 → 仓位 ∈ [0, 1]

Q2: 你的策略夏普稳定吗？
├── 是 → 用凯利公式 + 半凯利系数
└── 否 → 用波动率定额（更稳健）

Q3: 你能承受多少回撤？
├── < 10% → 0.25× 凯利 / 目标波动 10%
├── < 20% → 0.5× 凯利 / 目标波动 15%
└── < 30% → 1.0× 凯利 / 目标波动 20%

Q4: 是否多策略？
├── 是 → 加风险预算（不同策略不同预算）
└── 否 → 不需要

Q5: 是否需要止损？
├── 一定 → 加月度 / 总回撤硬止损
└── （永远是 是）
```

---

## 综合观察

- **4.1 + 4.2 完整覆盖**：4.1 是"股票面"（哪些股票，权重多少）；4.2 是"资金面"（用多少资金做这些事）
- **A 股推荐组合**：半凯利（0.5×）+ 波动率定额（15%）+ 硬止损（总回撤 20% / 月度 5%）
- **凯利公式的核心价值**：把"夏普稳定性"自动转为"仓位变化"——好策略多投，差策略少投
- **波动率定额的简洁**：不需要估计预期收益，只用波动率——更稳健
- **风险预算适合多策略组合**：A 股私募常用——不同策略不同风险贡献
- **硬止损不可忽视**：理论最优 ≠ 个人可执行；硬止损是"理论 vs 心理"的桥梁

## 参考与延伸

- [[kelly-single-strategy]] — 凯利公式单策略推导
- [[kelly-multi-strategy]] — 多策略矩阵形式
- [[kelly-risk-tail]] — 半凯利 / 风险传染 / 厚尾
- [[portfolio-optimization-overview]] — 4.1 组合优化（配合 4.2 使用）
- [[multi-factor-jq-strategy]] — 3.1 工业级策略（可加 4.2 的仓位管理）
- [[backtest-pitfalls-statistical]] — 5.4 回测陷阱（含极端市场表现检查）
