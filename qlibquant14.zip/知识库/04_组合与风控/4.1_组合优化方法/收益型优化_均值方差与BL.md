---
name: mean-variance-and-bl
description: 均值方差优化（Markowitz）+ Black-Litterman 模型 —— 含预期收益估计、贝叶斯结合、cvxopt 实现、与多因子策略的衔接
category: 04_组合与风控/4.1_组合优化方法
tags: [组合优化, 均值方差, markowitz, black-litterman, 主动管理, cvxopt]
created: 2026-05-17
updated: 2026-05-17
status: with-jq-impl
---

# 收益型组合优化：均值方差与 Black-Litterman

## TL;DR

**均值方差（MV）**是经典 Markowitz 框架，目标是最大化"收益 - λ·风险"；**Black-Litterman（BL）**是 MV 的贝叶斯改进，结合"市场隐含收益"和"投资者观点"。两种方法都需要**预期收益 $\mu$ 估计**——这是它们的能力来源也是难点。本文给出推导 + cvxopt 实现 + 与多因子策略的衔接。

## 来源

- **Whale-Quant ch06**：[ch06](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/_github_source/docs/) —— 均值方差教学
- **因子投资 ch4**：[因子投资方法与实践.md ch4](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) —— Markowitz / MPT / CAPM 理论
- **Black-Litterman 论文**：Black & Litterman (1992) "Global Portfolio Optimization"

---

## 1. 均值方差（Mean-Variance）

### 经典 Markowitz 目标

最大化"效用函数"（线性组合收益与风险）：

$$\max_w \quad w' \mu - \frac{\lambda}{2} w' \Sigma w$$

$$\text{s.t.} \quad \sum_i w_i = 1$$

其中：
- $\mu$ = 预期收益向量
- $\Sigma$ = 协方差矩阵
- $\lambda$ = **风险厌恶系数**（越大越保守）

### 无约束闭式解

$$w^* = \frac{1}{\lambda} \Sigma^{-1} \mu$$

含 $\sum_i w_i = 1$ 约束：

$$w^* = \frac{\Sigma^{-1} \mu}{\mathbf{1}' \Sigma^{-1} \mu}$$

### λ 的选择

$\lambda$ 的经验取值（个人 vs 机构）：

| 投资者类型 | $\lambda$ |
|---|---|
| 极度保守 | 10-20 |
| 中度保守 | 5-10 |
| 中度激进 | 1-3 |
| 极度激进 | 0.1-0.5 |

**实务**：与其设 $\lambda$，不如设**目标风险**（如组合年化波动 15%）然后反推 $\lambda$。

### cvxopt 实现

```python
import cvxopt
import numpy as np


def mean_variance(mu, cov, lam=2.0, w_lower=0.0, w_upper=1.0):
    """均值方差优化
    
    mu: (N,) 预期收益向量（年化）
    cov: (N, N) 协方差矩阵（年化）
    lam: 风险厌恶系数
    """
    N = len(mu)
    
    # min 0.5 lam w' Sigma w - mu' w
    # → 0.5 w' (lam Sigma) w + (-mu)' w
    P = cvxopt.matrix(lam * cov)
    q = cvxopt.matrix(-mu)
    
    # 不等式：w_lower <= w_i <= w_upper
    G = cvxopt.matrix(np.vstack([-np.eye(N), np.eye(N)]))
    h = cvxopt.matrix(np.hstack([-np.full(N, w_lower), np.full(N, w_upper)]))
    
    # 等式：sum(w) = 1
    A = cvxopt.matrix(np.ones(N).reshape(1, -1))
    b = cvxopt.matrix([1.0])
    
    cvxopt.solvers.options['show_progress'] = False
    sol = cvxopt.solvers.qp(P, q, G, h, A, b)
    return np.array(sol['x']).flatten()
```

### 预期收益 $\mu$ 的估计（核心难点）

均值方差的关键挑战 = 估计 $\mu$。可用方法：

#### 方法 1：历史平均（最简单）

$$\hat{\mu}_i = \bar{r}_i \cdot 252$$

**问题**：历史不代表未来，**噪声极大**。Markowitz 优化用样本均值会得到极端权重（"角点解"）。

#### 方法 2：多因子模型（最推荐）

$$\hat{\mu}_i = \alpha_i + \beta_i' \hat{\lambda}$$

其中 $\hat{\lambda}$ 是从历史回归得到的**因子溢价**。这是 [[index-03-01-multi-factor-selection]] 3.1 节的主要工作产出。

```python
def mu_from_multi_factor(
    factor_values: pd.DataFrame,  # 当期因子值
    factor_returns: pd.DataFrame,  # 历史因子收益（DataFrame）
    lookback: int = 60,
) -> pd.Series:
    """从多因子模型预测预期收益
    
    Args:
        factor_values: (N, K) 当期各股票的 K 个因子值
        factor_returns: (T, K) 历史 T 期的 K 个因子收益
        lookback: 估计因子溢价的窗口
    
    Returns:
        (N,) 各股票的预期收益
    """
    # 因子溢价 = 过去 lookback 期因子收益均值
    factor_premium = factor_returns.tail(lookback).mean()
    
    # 预期收益 = 因子暴露 × 因子溢价
    expected_returns = factor_values @ factor_premium
    return expected_returns
```

#### 方法 3：IC 加权信号（中频策略）

```python
def mu_from_ic_weighted_signal(
    combined_factor: pd.Series,  # 已 IC 加权合成的信号
    target_annual_return: float = 0.1,  # 目标年化超额
) -> pd.Series:
    """把因子信号转为预期收益
    
    简化做法：把信号 rank 后线性映射到预期年化收益
    """
    rank = combined_factor.rank(pct=True)
    # 把 rank 0.5 映射为 0，rank 1.0 映射为 target_annual_return
    return 2 * target_annual_return * (rank - 0.5)
```

#### 方法 4：BL 模型（最严谨）—— 见下文

### 实证表现

| 指标 | 等权 | 均值方差（用真实 $\mu$） | 均值方差（用历史 $\mu$） |
|---|---|---|---|
| 年化收益 | ~ 5.5% | ~ 15% | ~ 3%（不稳定） |
| 夏普 | ~ 0.35 | ~ 1.0 | ~ 0.2 |
| 权重集中度 | 低 | 中 | **高（极端权重）** |

**关键发现**：MV 表现强烈依赖 $\mu$ 估计质量。**用历史均值会得到极差结果**——这就是为什么需要 Black-Litterman。

### 均值方差的"角点解"问题

MV 优化对 $\mu$ 的微小估计误差极其敏感。例如：

```
两只股票，相关性 0.5，年化波动 20%
mu_A = 8%, mu_B = 7%（真实差异小）

MV 优化结果：w_A = 1.5, w_B = -0.5（杠杆 + 做空）
```

**对策**：
1. 加约束（$w_i \in [0, 0.1]$）→ 见 [[portfolio-constraints]]
2. 用 BL 模型对 $\mu$ 做收缩 → 见下文
3. 在 $\mu$ 估计上做正则化（Ridge 回归）

---

## 2. Black-Litterman 模型

### 核心思想

**结合两种信息源**：

1. **市场隐含均衡收益**（reverse-engineered from market cap weights）：默认市场是有效的
2. **投资者观点**（subjective views）：你认为某些股票 / 因子有 alpha

通过**贝叶斯框架**结合，得到更稳健的 $\mu$ 估计。

### 三步流程

#### 步骤 1：计算市场隐含均衡收益 $\Pi$

如果市场是有效的，市场组合权重 $w_{mkt}$ 应该是均值方差最优——反推：

$$\Pi = \lambda \Sigma w_{mkt}$$

这是"如果你认为市场有效，市场组合背后的预期收益"。

#### 步骤 2：表达投资者观点

投资者有 K 个观点，每个观点是"某个股票组合的预期收益是 q"：

$$P \mu = q + \epsilon, \quad \epsilon \sim N(0, \Omega)$$

其中：
- $P$ = (K, N) 矩阵，每行是一个组合（如"股票 1 - 股票 2 的收益 = 2%"）
- $q$ = (K,) 观点收益值
- $\Omega$ = (K, K) 观点不确定性矩阵（小 = 更确定）

#### 步骤 3：贝叶斯结合

最终 $\mu$ 的后验估计：

$$\hat{\mu}^{BL} = [(\tau \Sigma)^{-1} + P' \Omega^{-1} P]^{-1} [(\tau \Sigma)^{-1} \Pi + P' \Omega^{-1} q]$$

其中 $\tau$ 是"市场先验的不确定性"（通常 0.025-0.05）。

### Python 实现

```python
import numpy as np


def black_litterman_mu(
    w_market: np.ndarray,   # (N,) 市场权重
    cov: np.ndarray,         # (N, N) 协方差矩阵
    P: np.ndarray,           # (K, N) 观点矩阵
    q: np.ndarray,           # (K,) 观点收益
    omega: np.ndarray = None,  # (K, K) 观点不确定性（None 时自动计算）
    tau: float = 0.025,      # 市场先验不确定性
    lam: float = 2.5,        # 风险厌恶系数
) -> np.ndarray:
    """计算 Black-Litterman 后验预期收益
    
    Returns: (N,) 后验预期收益向量
    """
    # 市场隐含收益
    pi = lam * cov @ w_market
    
    # 观点不确定性默认：与 P @ Sigma @ P' 对齐
    if omega is None:
        omega = tau * np.diag(np.diag(P @ cov @ P.T))
    
    # 贝叶斯组合
    tau_cov_inv = np.linalg.inv(tau * cov)
    omega_inv = np.linalg.inv(omega)
    
    mu_bl = np.linalg.inv(tau_cov_inv + P.T @ omega_inv @ P) @ \
            (tau_cov_inv @ pi + P.T @ omega_inv @ q)
    
    return mu_bl


# 然后把 mu_bl 喂给 mean_variance 求最优权重
def black_litterman_optimize(
    securities, market_cap, cov, P, q, tau=0.025, lam=2.5,
    w_lower=0.0, w_upper=0.10,
):
    """完整 Black-Litterman 流程"""
    # 1. 市场权重（按市值）
    w_market = market_cap / market_cap.sum()
    
    # 2. 计算后验 mu
    mu_bl = black_litterman_mu(w_market, cov, P, q, tau=tau, lam=lam)
    
    # 3. 均值方差优化
    weights = mean_variance(mu_bl, cov, lam=lam, w_lower=w_lower, w_upper=w_upper)
    return dict(zip(securities, weights))
```

### 观点表达的例子

#### 例 1：绝对观点
"股票 A 年化收益 10%"

```python
N = 5  # 5 只股票
P = np.zeros((1, N))
P[0, 0] = 1  # 第一行：选股票 A（索引 0）
q = np.array([0.10])  # 10%
```

#### 例 2：相对观点
"股票 A 比股票 B 多 2%"

```python
P = np.zeros((1, N))
P[0, 0] = 1
P[0, 1] = -1  # A 减 B
q = np.array([0.02])
```

#### 例 3：因子观点
"动量 top 30 比 bottom 30 多 5%"

```python
# 假设动量 top 30 和 bottom 30 已确定
top_indices = [3, 7, 12, ...]  # top 30
bot_indices = [1, 5, 9, ...]   # bottom 30

P = np.zeros((1, N))
P[0, top_indices] = 1.0 / 30
P[0, bot_indices] = -1.0 / 30
q = np.array([0.05])  # 5% 月度超额（注意单位）
```

### BL 的优势

| 优势 | 说明 |
|---|---|
| **稳定的权重** | 不会出现 MV 的"角点解" |
| **观点可灵活表达** | 绝对 / 相对 / 因子 / 风格观点都行 |
| **可控的"激进度"** | $\Omega$ 矩阵控制观点权重 |
| **与多因子完美融合** | 每个因子可表达为一个 BL 观点 |

### BL 的劣势

- **复杂度高**：需要选 $\tau$ / $\Omega$ / 表达观点矩阵 P / q
- **观点矩阵设计需要技巧**：错误的 P 会导致后验偏差
- **隐含市场是有效的假设**：在某些极端市场情况下不成立

---

## 与多因子策略的衔接

均值方差 / BL 与 [[index-03-01-multi-factor-selection]] 3.1 的多因子策略可以无缝衔接：

### 流水线
```
1. 多因子选股 → 候选股票池（如 top 100）
2. 多因子信号合成（IC 加权）→ 预期收益向量 μ
3. 估计协方差 Σ（Ledoit-Wolf 60 日）
4. 均值方差 / BL 优化 → 最优权重
5. 加约束（行业 / 市值 / 跟踪误差）→ 见 [[portfolio-constraints]]
6. 调仓
```

### 完整集成代码

```python
def multi_factor_with_mv(securities, context):
    """多因子 + 均值方差 + 行业约束"""
    # 1. 加载数据
    returns = load_returns_for_cov(securities, context.previous_date, days=120)
    securities = list(returns.columns)
    cov = estimate_covariance(returns, method='ledoit-wolf').values
    
    # 2. 从多因子合成预期收益
    combined_factor = compute_combined_factor(securities, context)  # 来自 3.1 节
    mu = mu_from_ic_weighted_signal(combined_factor.loc[securities], target_annual_return=0.10).values
    
    # 3. 均值方差优化
    weights = mean_variance(mu, cov, lam=2.0, w_lower=0.0, w_upper=0.05)
    
    return dict(zip(securities, weights))
```

---

## 综合观察

- **均值方差是最经典框架**——但对 $\mu$ 估计极敏感，**用历史均值往往得到极差结果**
- **Black-Litterman 是 MV 的贝叶斯改进**——结合市场隐含与投资者观点，更稳健
- **预期收益 $\mu$ 的估计是关键**——多因子模型 / IC 加权信号 / BL 都是从不同角度估计
- **多因子选股 + 均值方差**是中级量化的标准流程
- **BL 适合复杂的多因子组合**——每个因子可作为一个"观点"，灵活度高
- **与 [[risk-based-optimization]] 风险型方法对比**：MV/BL 利用 $\mu$ 信息，但牺牲稳健性；风险型放弃 $\mu$，换取稳健

## 参考与延伸

- [[portfolio-optimization-overview]] — 6 种方法总览
- [[risk-based-optimization]] — 风险型方法（不依赖 $\mu$）
- [[portfolio-constraints]] — 七种约束与交易成本
- [[portfolio-jq-implementation]] — 聚宽完整实现
- [[index-03-01-multi-factor-selection]] — 多因子选股（产生 $\mu$ 的过程）
- [因子投资 ch4](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — Markowitz / MPT / CAPM 推导
- [Whale-Quant ch06](../../../原始资料文件/量化开源课程（项目代号：Whale-Quant）/_github_source/docs/) — 教学
