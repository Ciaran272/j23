---
name: pathway-robustness-test
description: Pathway 鲁棒性测试 —— 通过偏移调仓起始日检验策略收益对调仓时点的敏感度，识别"只在特定日期有效"的过拟合策略
category: 05_工程与回测/5.4_回测陷阱清单
tags: [pathway, 鲁棒性, 调仓日偏移, 过拟合检测, 回测陷阱, 聚宽实现]
created: 2026-05-19
updated: 2026-05-19
status: with-jq-impl
---

# Pathway 鲁棒性测试

## TL;DR

把调仓日偏移 0 ~ N-1 天（N = 调仓周期天数），跑 N 条独立净值曲线。如果最优 pathway 与最差 pathway 的年化差 > 5%，说明策略对调仓时点过度敏感——很可能是过拟合或流动性幻觉。

## 来源

- ShenzhenLime/quant `factor_analyze.py` § `evaluate_factor_pathways`（MIT 协议）
- 概念等价于 Marcos López de Prado《Advances in Financial Machine Learning》ch12 "Combinatorial Purged Cross-Validation" 的简化版

## 1. 为什么需要 Pathway 测试

### 问题

月度调仓策略通常选"每月第 1 个交易日"调仓。但如果换成第 5 / 10 / 15 个交易日，收益可能完全不同。

| 场景 | 含义 |
|---|---|
| 所有 pathway 收益接近 | 策略对时点不敏感 → **鲁棒** |
| 最优 vs 最差差距 > 5% 年化 | 策略对时点敏感 → **可能过拟合** |
| 只有 1-2 条 pathway 有正超额 | 策略本质是"碰巧在那天调仓" → **不可信** |

### 根因

- 月初/月末有资金流效应（基金申赎、指数调仓）
- 某些因子在特定日期有信息优势（如财报发布后第 1 天 vs 第 5 天）
- 小盘股流动性在不同日期差异大

**A 股化注记**：A 股月初效应（1-5 日）和月末效应（最后 3 日）比美股更显著，pathway 测试在 A 股尤其必要。

## 2. 方法论

### 2.1 算法

```
输入：因子值序列、调仓频率 freq（如 "月度"）
输出：N 条净值曲线（N = freq 内交易日数）

for offset in 0, 1, ..., N-1:
    1. 把交易日历按 freq 分段，每段起始日偏移 offset 天
    2. 每段末尾取因子值 → 排序 → 选股
    3. 下一段持有 → 计算日度收益
    4. 拼接成一条完整净值曲线
```

### 2.2 评估指标

| 指标 | 公式 | 判断标准 |
|---|---|---|
| **Pathway 离散度** | max(年化) - min(年化) | < 3% 优秀 / 3-5% 可接受 / > 5% 危险 |
| **平均 Pathway 夏普** | mean(SR across pathways) | 比单一 pathway 更可信 |
| **最差 Pathway 超额** | min(excess_ret) | 如果 < 0 则策略不可信 |
| **Pathway 胜率** | count(excess > 0) / N | > 80% 才算鲁棒 |

## 3. 聚宽落地实现

```python
"""
Pathway 鲁棒性测试 —— 聚宽研究环境实现
在聚宽研究（Research）环境中运行，不是策略回测框架
"""
import numpy as np
import pandas as pd
from jqdata import *
from jqfactor import get_factor_values


def pathway_robustness_test(
    universe="000906.XSHG",
    factor_name="market_cap",
    start_date="2018-01-01",
    end_date="2023-12-31",
    freq_days=20,
    n_top=50,
    ascending=True,
):
    """
    Pathway 鲁棒性测试

    Args:
        universe: 股票池指数代码
        factor_name: jqfactor 因子名
        start_date/end_date: 回测区间
        freq_days: 调仓周期（交易日数）
        n_top: 每期持仓数
        ascending: True=因子越小越好

    Returns:
        DataFrame: 每条 pathway 的日度收益
    """
    # 获取交易日历
    trade_days = get_trade_days(start_date, end_date)
    trade_days = list(trade_days)

    all_pathways = {}

    for offset in range(freq_days):
        # 按 offset 切分调仓周期
        rebal_indices = list(range(offset, len(trade_days), freq_days))
        if len(rebal_indices) < 3:
            continue

        pathway_rets = []

        for i in range(len(rebal_indices) - 1):
            rebal_day = trade_days[rebal_indices[i]]
            # 持有期: 从调仓日到下一个调仓日
            hold_start = rebal_indices[i]
            hold_end = rebal_indices[i + 1]
            hold_days = trade_days[hold_start:hold_end]

            # T-1 选股（用调仓日前一天的因子值）
            calc_date = get_trade_days(end_date=rebal_day, count=2)[0]
            pool = get_index_stocks(universe, date=calc_date)

            # 取因子
            factor_df = get_factor_values(
                pool, factors=[factor_name],
                end_date=calc_date, count=1
            )[factor_name]
            scores = factor_df.iloc[-1].dropna()
            ranked = scores.sort_values(ascending=ascending)
            selected = ranked.index[:n_top].tolist()

            if not selected:
                continue

            # 持有期日度收益（等权）
            prices = get_price(
                selected,
                start_date=hold_days[0],
                end_date=hold_days[-1],
                fields=["close"],
                panel=False,
            )
            if prices.empty:
                continue

            pivot = prices.pivot(index="time", columns="code", values="close")
            daily_ret = pivot.pct_change().iloc[1:]  # 第一天无收益
            eq_ret = daily_ret.mean(axis=1)
            pathway_rets.append(eq_ret)

        if pathway_rets:
            all_pathways[f"offset_{offset}"] = pd.concat(pathway_rets)

    result = pd.DataFrame(all_pathways)
    return result


def pathway_summary(result_df):
    """汇总 pathway 测试结果"""
    annual_rets = result_df.apply(lambda s: (1 + s).prod() ** (242 / len(s)) - 1)
    sharpes = result_df.apply(lambda s: s.mean() / s.std() * np.sqrt(242) if s.std() > 0 else 0)

    summary = {
        "pathway_count": len(result_df.columns),
        "mean_annual_ret": annual_rets.mean(),
        "best_annual_ret": annual_rets.max(),
        "worst_annual_ret": annual_rets.min(),
        "dispersion": annual_rets.max() - annual_rets.min(),
        "mean_sharpe": sharpes.mean(),
        "win_rate": (annual_rets > 0).mean(),
    }

    # 判断
    if summary["dispersion"] < 0.03:
        summary["verdict"] = "鲁棒 (离散度 < 3%)"
    elif summary["dispersion"] < 0.05:
        summary["verdict"] = "可接受 (离散度 3-5%)"
    else:
        summary["verdict"] = "危险 (离散度 > 5%)，策略对调仓时点过度敏感"

    return summary


def pathway_plot(result_df, title="Pathway 鲁棒性测试"):
    """可视化：最优/最差/平均净值 + 阴影区间"""
    import matplotlib.pyplot as plt

    nav = (1 + result_df).cumprod()
    avg_nav = nav.mean(axis=1)
    best_nav = nav.max(axis=1)
    worst_nav = nav.min(axis=1)

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.fill_between(nav.index, worst_nav, best_nav, alpha=0.2, color="blue", label="最优-最差区间")
    ax.plot(avg_nav.index, avg_nav, color="blue", linewidth=2, label="平均 Pathway")
    ax.plot(best_nav.index, best_nav, color="green", linewidth=0.8, linestyle="--", label="最优")
    ax.plot(worst_nav.index, worst_nav, color="red", linewidth=0.8, linestyle="--", label="最差")
    ax.set_title(title)
    ax.legend()
    ax.set_ylabel("累计净值")
    plt.tight_layout()
    plt.show()
```

## 4. 使用建议

### 何时用

| 场景 | 是否需要 Pathway 测试 |
|---|---|
| 月度调仓多因子策略 | **必须** |
| 周度调仓 | 推荐（N=5，快速跑完） |
| 日度调仓 | 不需要（每天都调，无偏移空间） |
| 事件驱动策略（如 PEAD） | 不适用（调仓时点由事件决定） |

### 结果解读

```
pathway_count: 20
mean_annual_ret: 0.12
best_annual_ret: 0.18
worst_annual_ret: 0.06
dispersion: 0.12          ← > 5%，危险信号
mean_sharpe: 1.2
win_rate: 1.0             ← 所有 pathway 都正，但离散度大
verdict: "危险 (离散度 > 5%)，策略对调仓时点过度敏感"
```

**解读**：虽然所有 pathway 都赚钱，但最优 18% vs 最差 6% 差距太大。说明策略收益中有一部分来自"恰好在某天调仓"的运气成分，实盘可能落在最差 pathway 附近。

### 修复方向

1. **分散调仓日**：把资金分 N 份，每份在不同 offset 调仓（等价于取平均 pathway）
2. **降低调仓频率**：月度 → 季度，减少时点敏感性
3. **检查因子信号衰减**：如果因子 IC 在 lag 1-5 天内急剧衰减，说明信号太短命

## 参考与延伸

- [[backtest-checklist]] — 30 条自检清单（本方法可作为第 31 条补充）
- [[backtest-pitfalls-statistical]] — 前视偏差 / 数据迁就（Pathway 测试是另一种过拟合检测）
- [[backtest-factor-decay]] — 因子失效与拥挤（Pathway 离散度大可能是因子衰减的早期信号）
- [[index-04-04-trading-cost-capacity]] — 成本与容量（分散调仓日会增加交易次数，需权衡成本）
