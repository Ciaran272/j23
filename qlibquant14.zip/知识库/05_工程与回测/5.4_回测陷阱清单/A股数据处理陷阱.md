---
name: backtest-data-pitfalls
description: A 股数据处理类回测陷阱 —— PIT 财务数据 / 复权选择 / ST 摘帽 / 新股次新股 / 退市股 / 行业切换 / 指数成分变动
category: 05_工程与回测/5.4_回测陷阱清单
tags: [A股, 数据陷阱, PIT, 复权, ST, 新股, 退市, 行业切换]
created: 2026-05-16
updated: 2026-05-16
status: with-jq-impl
---

# A 股数据处理类回测陷阱

## TL;DR

数据处理类陷阱**比交易制度类更隐蔽**——错误不会立刻报错，而是悄悄污染回测结果。本文给出 7 个 A 股特有的数据陷阱：**PIT 财务 / 复权 / ST 摘帽 / 新股次新股 / 退市股 / 行业切换 / 指数成分变动**——每个给出聚宽实现的正确做法。

## 来源

- **因子投资 ch3.1**：[因子投资方法与实践.md ch3.1](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) —— A 股财务数据处理规范
- 聚宽官方文档 + 上交所 / 深交所规则
- 配套 [[backtest-trading-rules]] A 股交易制度陷阱

---

## 1. PIT 财务数据

详见 [[neutralization-practice]] § A 股财务数据 PIT 处理。**摘要**：

### 财报披露规则

| 报告 | 截止日 | 法定披露窗口 |
|---|---|---|
| 一季报 | 3-31 | 4-30 前 |
| 中报 | 6-30 | 8-31 前 |
| 三季报 | 9-30 | 10-31 前 |
| 年报 | 12-31 | 4-30 前 |

### 陷阱

**用 2023 年报数据在 2023-12-31 做回测**——年报披露日是 2024-04-30，**未来函数**。

### 聚宽如何处理

```python
# 聚宽 get_fundamentals 默认按公告日 + 1 个交易日提供
fundamentals = get_fundamentals(
    query(valuation.code, indicator.roe),
    date='2023-06-30',  # 在此日期回看，自动用公告日 + 1 之前的数据
)
```

**聚宽 / jqdatasdk 默认做 PIT**。tushare / akshare 需自查。

### 自检方法

```python
# 取 2023 年报 EPS（披露 2024-04 月底前）
eps_2023_annual = get_fundamentals(
    query(income.code, income.basic_eps).filter(
        income.statDate == '2023-12-31'
    ),
    date='2023-12-31',  # 注意：date < pub_date，应取不到 2023 年报数据
)
print(eps_2023_annual)  # 期望：空 / 取到的是 2022 年报数据
```

---

## 2. 复权方式选择

### 三种复权方式

| 方式 | 公式 | 用途 |
|---|---|---|
| **不复权（none）** | 显示真实历史价格 | 看真实价位（如"茅台跌破 1000 元"） |
| **前复权（pre）** | 用最新分红信息倒推过去价格 | **回测 / 因子计算** |
| **后复权（post）** | 用历史分红向前展开未来价格 | 长期收益对比（基金净值） |

### 陷阱：复权方式不一致

**错误案例**：

```python
# ❌ close 用前复权，但 vwap 用不复权
close = get_price(..., fields=['close'], fq='pre')['close']
vwap = get_price(..., fields=['avg'])['avg']  # 默认不复权

# close / vwap 比值就会是错的（如 close=10, vwap=100 在某分红日）
```

**正确**：**全部用前复权**：

```python
data = get_price(
    securities, start_date, end_date,
    fields=['open', 'close', 'high', 'low', 'volume', 'money', 'avg'],
    fq='pre',  # 全部前复权
    panel=False,
)
```

### 陷阱：复权因子的"未来函数"

**前复权依赖未来分红信息**——理论上"用未来数据"。

```python
# 假设股票 X 在 2024-06 分红 1 元
# 用 fq='pre' 取数据，2024-01-01 的"前复权 close" 已经包含了 6 月的分红效应

# 因子计算中：
# 2024-01-01 close (pre) = 9 (实际真实价 10，减去 6 月的 1 元分红影响)
# 2024-01-01 真实历史价 = 10
# → 如果你的因子值是 "close" 本身，会得到比真实历史价小的值
```

**实务**：
- **接受这一点**——前复权是行业标准，几乎所有量化平台都这么做
- **避免在因子中使用绝对价格**——用 `close.pct_change()`（收益率）、`rank`（截面排序）、`log(close)`（价格水平）等**复权不敏感**的形式
- 配合 `set_option('use_real_price', True)`——聚宽下单时用真实价（不复权）

---

## 3. ST 摘帽 / 戴帽

### ST 状态变化

| 状态 | 含义 |
|---|---|
| **正常** | 一般股票 |
| **ST** | 财务异常（亏损 / 警告） |
| **\*ST** | 退市风险警示（更严重） |
| **摘帽** | ST → 正常（财务恢复） |
| **戴帽** | 正常 → ST（财务恶化） |

### 陷阱

**当前是"正常"的股票，历史上可能是 ST**——回测时按"今天非 ST"剔除，会错误地保留它的历史。

```python
# ❌ 错误：用当前 ST 状态过滤
all_stocks = get_all_securities(types=['stock'])
non_st = [s for s in all_stocks if not is_st_currently(s)]  # 今天的 ST 状态
# 用 non_st 做 2020 年回测 → 历史上的 ST 股票被错误保留
```

```python
# ✓ 正确：用历史 ST 状态过滤
def filter_st_at_date(securities, date):
    """剔除 date 时点为 ST 的股票"""
    st = get_extras('is_st', securities, end_date=date, count=1)
    if st.empty:
        return securities
    return [s for s in securities if not st.iloc[-1].get(s, False)]
```

### 摘帽溢价

**摘帽前后 3-5 个交易日股价通常异常上涨**（事件驱动效应）——可以做摘帽事件交易，但**不应混入正常因子检验**。

---

## 4. 新股次新股

### 定义

| 期间 | 定义 |
|---|---|
| **新股** | 上市后 60 天内 |
| **次新股** | 上市 60-180 天 |

### 陷阱

**新股上市初期波动极大**：

- 沪深主板：首日 ±44%、次日起 ±10%
- 创业板 / 科创板：前 5 个交易日不设限
- 北交所：首日不设限

**实务**：新股的"高收益 / 高波动"会被任何包含上市日的因子**计算捕捉到**——但这些**不是 alpha，是首日溢价**。

### 处理建议

```python
def filter_new_stocks(securities, end_date, min_days=180):
    """剔除上市 < min_days 天的股票"""
    result = []
    for s in securities:
        info = get_security_info(s)
        if info is None:
            continue
        if (end_date - info.start_date.date()).days >= min_days:
            result.append(s)
    return result
```

**经验阈值**：

| min_days | 严格度 | 适用 |
|---|---|---|
| 60 | 宽松 | 短期 / 量价策略 |
| 180 | 标准 | 多因子选股（**推荐**） |
| 365 | 严格 | 长周期 / 基本面策略 |

---

## 5. 退市股

### A 股退市率

| 时期 | 年均退市率 |
|---|---|
| 2010-2018 | < 0.1% |
| 2019-2022 | ~ 0.2% |
| 2023-2024 | ~ 0.5%（新退市规则后） |

### 陷阱

详见 [[backtest-pitfalls-statistical]] § 存活偏差。**关键**：聚宽 `get_all_securities` 默认**不包含**已退市股票（截至查询日）。

```python
# ❌ 错误：今天查 get_all_securities
all_stocks = get_all_securities(types=['stock'])  # 只返回今天还在的
# 用这个 universe 做 2018 年回测 → 排除了 2019-2024 期间退市的股票


# ✓ 正确：用历史时点查
all_stocks_at_2018 = get_all_securities(
    types=['stock'], 
    date='2018-01-01',  # 关键：用历史日期
)
```

**注**：聚宽数据有截止日期，**特别早的历史可能仍有部分缺失**。

---

## 6. 行业切换

### 陷阱

**个股可能切换行业**——常见情形：

- 借壳上市后业务变化
- 主营业务转型（如传统行业转新能源）
- 行业分类口径变化（如申万 2021 修订）

**问题**：

```python
# ❌ 错误：用当前行业做历史中性化
industry_today = get_industry(securities)
# 用今天的行业做 2018 年的行业中性化 → 错位
```

### 处理

```python
# ✓ 正确：用历史时点的行业
industry_at_date = get_industry(securities, date='2018-01-01')
```

**实务**：行业切换频率低（多数股票几年不变），所以**每月初取一次** + 期间 `ffill`：

```python
def get_industry_panel(securities, dates, level='sw_l1'):
    """每月初取一次行业分类，期间 ffill"""
    result = pd.DataFrame(index=dates, columns=securities, dtype=object)
    sample_dates = pd.date_range(dates[0], dates[-1], freq='MS')
    for date in sample_dates:
        ind = get_industry(securities, date=date)
        for code, info in ind.items():
            if level in info:
                result.loc[date:, code] = info[level]['industry_code']
    return result.fillna(method='ffill')
```

---

## 7. 指数成分变动

### A 股主流指数的成分调整频率

| 指数 | 调整频率 |
|---|---|
| 上证 50 | 半年（6 月 / 12 月） |
| 沪深 300 | 半年（6 月 / 12 月） |
| 中证 500 | 半年（6 月 / 12 月） |
| 中证 1000 | 半年（6 月 / 12 月） |
| 中证 800 | 半年（6 月 / 12 月） |

### 陷阱

```python
# ❌ 错误：用最新的成分股做历史回测
hs300 = get_index_stocks('000300.XSHG')  # 今天的沪深 300
# 用 hs300 做 2018 年回测 → 错误地用了 2018 年后才纳入的股票


# ✓ 正确：每月（或调整频率）刷新成分股
def before_trading_start(context, data):
    securities = list(get_index_stocks('000300.XSHG', context.previous_date))
    set_universe(securities)
```

### 成分股调整的"被动效应"

每次成分股调整都会引发**指数跟踪资金**的被动调仓——**新纳入的股票在调整日附近被买入，剔除的被卖出**。

**实务**：可以做"成分股调整事件交易"——但不应混入正常因子检验。

---

## 综合观察

- **数据陷阱 7 类**：PIT / 复权 / ST 摘帽 / 新股次新股 / 退市 / 行业切换 / 指数成分变动
- **聚宽的默认处理**：
  - ✓ PIT 财务（`get_fundamentals` 默认）
  - ✓ 前复权（`fq='pre'`）
  - ✓ 退市股保留（用历史日期查 `get_all_securities`）
  - ✗ ST 状态（需手动用 `get_extras('is_st', ...)` 过滤）
  - ✗ 新股次新股（需手动用 `get_security_info` 过滤）
  - ✗ 历史行业（用 `get_industry(security, date)` 而非 `get_industry(security)`）
  - ✓ 历史成分股（用 `get_index_stocks(index, date)`）
- **复权陷阱**：前复权依赖未来分红——**避免在因子中使用绝对价格**，用收益率 / rank / log 等
- **行业切换 / 指数成分**：每月初取一次即可，期间用 ffill；**频率不要太高**（开销大）
- **ST 摘帽 / 新股事件 / 指数成分调整**：可以做事件交易，但**不应混入正常因子检验**

## 参考与延伸

- [[backtest-pitfalls-statistical]] — 统计陷阱（存活偏差与本文 § 5 退市股相关）
- [[backtest-factor-decay]] — 因子样本外失效
- [[backtest-trading-rules]] — A 股交易制度陷阱
- [[backtest-checklist]] — 综合自检清单
- [[neutralization-practice]] § A 股 PIT — 财务数据 PIT 详解
- [因子投资 ch3.1](../../../原始资料文件/因子投资方法与实践/因子投资方法与实践.md) — 财务数据处理规范
- [聚宽 API - 历史数据接口](https://www.joinquant.com/help/api/help#JQData)
