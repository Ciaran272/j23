---
name: mlops-engineering
description: MLOps 全景与 A 股个人量化的"轻量 MLOps" —— 6 大模块 + 工具链对比 + Marti ch9.2 6 类技能 + MLflow / DVC 端到端实战 + A 股市场监控
category: 05_工程与回测/5.5_MLOps与特征存储
tags: [MLOps, MLflow, DVC, Airflow, Prefect, 工具链, 6类技能, 监控, A股]
created: 2026-05-17
updated: 2026-05-17
source: 原始资料文件/从数据到交易量化交易的机器学习方法/从数据到交易量化交易的机器学习方法.md ch9.2
status: with-jq-impl
---

# MLOps 全景与工程化

## TL;DR

**MLOps（Machine Learning Operations）** = ML 模型从开发到生产的**完整生命周期管理**。Marti ch9.2 列了 4 项核心（**协作 / 自动化 / 监控 / 版本控制**）+ MLOps 工程师的 **6 类技能**（ML / 软开 / DevOps / 数据工程 / 云计算 / 沟通）。本文按"**6 大模块详解** → **工具链对比** → **A 股个人量化的轻量 MLOps**"展开。

**核心结论**：

- **个人量化 95% 不需要完整 MLOps**——单机 + Python + cron 已足够
- **必选 = MLflow（实验追踪）+ DVC（数据版本）**—— 投入 1 天学习，受益数年
- **复杂工具 = 团队场景**—— Feast / Airflow / SageMaker 个人用不起 / 不需要
- **A 股市场剧烈变化** → MLOps 的最大价值不在"上线"，在**"持续监控 + 滚动重训"**

## 来源

- **Marti 综述 ch9.2**：[从数据到交易量化交易的机器学习方法.md ch9.2](../../../原始资料文件/从数据到交易量化交易的机器学习方法/从数据到交易量化交易的机器学习方法.md)（行 1281-1339）
- MLflow / DVC / Feast / Airflow 官方文档
- 业界 MLOps 实践（Google MLOps Maturity Model / Microsoft MLOps）
- 配套 [[feature-store-principles]] 特征存储 / [[backtest-data-pitfalls]] 回测陷阱

**OCR 校对注记**：Marti ch9.2 正文 OCR 基本可读，存在三处问题（不影响理解）：
- 行 1289 "MLOps" 被识别为数学符号 `$\mathrm { M L O p s }$`
- 行 1291-1293 "这可以帮助减少错误风险..."连写三次（OCR 重复 / 原文重复）
- 6 类技能段落 OCR 完整 ✓

---

## 1. MLOps 的真假需求（先问"要不要做"）

### 1.1 什么是 MLOps（Marti 定义）

> MLOps（机器学习运营）是**一组实践和工具**，旨在改善数据科学家和 IT 专业人员在机器学习模型开发和部署中的**协作和合作**。
>
> MLOps 涵盖的活动：
> - **协作**：数据科学家 + IT 从开发开始就合作
> - **自动化**：自动化工具简化开发/测试/部署
> - **监控**：跟踪生产环境的模型性能
> - **版本控制**：跟踪模型/数据/代码的变化

—— Marti ch9.2.1

### 1.2 个人量化的"过度工程"陷阱

**很多人把"工程化"做成了目的，而非手段**。MLOps 的工业级方案对个人**过度设计**：

| 工业级 MLOps 工作流 | A 股个人量化是否需要 |
|---|---|
| Kubernetes 集群 | ❌ 一台机器足够 |
| 多环境（dev / staging / prod）| ❌ 一个目录就行 |
| CI/CD pipelines | ❌ git push 已经够 |
| 监控告警系统 | ⚠️ 简易脚本足够 |
| 在线特征服务 | ❌ 日频策略不需要 ms 响应 |
| 模型 A/B 测试 | ❌ 个人量化 A/B 没意义 |
| 团队协作工具 | ❌ 单人作战 |

### 1.3 个人量化的"真需求"

```
个人量化的 MLOps 真需求
├── ✅ 实验追踪（"上次哪组参数最好？"）
├── ✅ 数据版本（"昨天的数据 vs 今天的数据有什么变化？"）
├── ✅ 代码版本（git 已解决）
├── ✅ 模型版本（"哪个模型在哪个数据上跑出哪个结果"）
├── ⚠️ 流水线自动化（数据更新→重新训练→自动调度，进阶可选）
├── ⚠️ 监控告警（实盘运行后 alpha 衰减监控，进阶可选）
└── ❌ 团队协作 / 在线推理 / 多环境（不需要）
```

**对应工具**：

```
✅ MLflow（实验追踪 + 模型版本）
✅ DVC（数据版本）
✅ git（代码版本，已有）
⚠️ cron / Prefect（流水线，进阶）
⚠️ 简单 Python 脚本 + 邮件（监控，进阶）
```

---

## 2. MLOps 6 大模块详解

工业级 MLOps 通常包含 6 个模块。下面给出每个模块的**工业级方案**和**个人量化方案**。

### 2.1 实验追踪（Experiment Tracking）

**目标**：记录每次实验的"参数 / 指标 / 模型 / 环境"，**可复现 + 可对比**。

| 维度 | 工业级（MLflow / W&B / Neptune） | 个人量化（MLflow）|
|---|---|---|
| 记录内容 | 全自动 + 团队协作 | 手动 + 自己看 |
| UI | Cloud + 协作 | 本地 mlflow ui |
| 价格 | $200-2000/月 / 团队 | $0（开源） |

**MLflow 入门**：

```python
# pip install mlflow
import mlflow

mlflow.set_experiment('hs300_multi_factor_strategy')

with mlflow.start_run(run_name='alpha101_combine_v1'):
    # 记录参数
    mlflow.log_params({
        'factor_set': ['alpha101_42', 'alpha101_6', 'gtja_20'],
        'rebalance_freq': 'monthly',
        'top_n': 30,
        'universe': 'HS300',
    })
    
    # 跑回测...（省略）
    
    # 记录指标
    mlflow.log_metrics({
        'sharpe': 1.45,
        'annualized_return': 0.18,
        'max_drawdown': -0.12,
        'win_rate': 0.55,
    })
    
    # 记录模型（如果用 sklearn / xgboost）
    # mlflow.sklearn.log_model(model, 'lgb_model')
    
    # 记录回测图
    mlflow.log_artifact('backtest_curve.png')

# 后续查询：mlflow ui → 浏览器 localhost:5000
```

**为什么个人量化必装 MLflow**：

```
没装 MLflow：
"上次回测夏普 1.45 用的什么参数？"
"在哪个文件夹里？要翻 backtest_log_20240515_3.json"
"哦找到了，但格式不一样，对比起来很麻烦"

装了 MLflow：
mlflow ui → 一眼看到 100 次回测的参数 / 指标 / 图，可排序可对比
```

### 2.2 数据版本（Data Versioning）

**目标**：给数据打"版本号"，**回溯 + 对比 + 重现**。

| 维度 | 工业级（LakeFS / Delta Lake） | 个人量化（DVC） |
|---|---|---|
| 数据规模 | TB-PB | GB |
| 集成 | S3 / Spark | git |
| 学习曲线 | 陡 | 平 |

**DVC（git for data）入门**：

```bash
# pip install dvc

# 1. 初始化（在 git 仓库中）
dvc init
git commit -m '初始化 DVC'

# 2. 把 data_cache 加入 DVC 跟踪
dvc add data_cache/features_hs300.parquet
git add data_cache/features_hs300.parquet.dvc data_cache/.gitignore
git commit -m '加入 v1 特征'

# 3. 数据更新后（如新增了一个月数据）
# 重新计算 features_hs300.parquet
dvc add data_cache/features_hs300.parquet  # DVC 检测变化
git commit -am '更新到 v2: 含 2024-12 数据'

# 4. 回到 v1
git checkout HEAD~1
dvc checkout  # DVC 拉回旧版本数据
# 这时 data_cache/features_hs300.parquet 是 v1 版本

# 5. 推送到远程（可选）
dvc remote add -d storage s3://my-bucket/dvc-store
dvc push  # 数据推到 S3 / OSS
git push  # 元数据推到 GitHub
```

**为什么个人量化必装 DVC**：

```
没装 DVC：
"两周前的回测结果 vs 今天的回测结果——夏普为什么从 1.5 跌到 1.1？"
"是因为数据更新了？因子定义改了？还是回测逻辑改了？"
"无法回到两周前的状态，永远说不清楚"

装了 DVC：
git checkout 2_weeks_ago && dvc checkout
回到两周前的数据和代码状态，直接对比
```

### 2.3 模型版本（Model Versioning）

**目标**：管理多个模型版本，**追踪 + 部署 + 回滚**。

| 维度 | 工业级（MLflow Model Registry） | 个人量化（MLflow）|
|---|---|---|
| 模型注册 | 自动 + 阶段管理 | 手动注册 |
| 部署 | One-click 到 prod | 复制文件 |
| 回滚 | 一键 | git revert |

**MLflow Model Registry**：

```python
# 注册模型
mlflow.register_model(
    model_uri='runs:/abc123/model',
    name='HS300_MomReversal_LGB',
)

# 切换到生产
client = mlflow.tracking.MlflowClient()
client.transition_model_version_stage(
    name='HS300_MomReversal_LGB',
    version=2,
    stage='Production',
)

# 加载生产模型
production_model = mlflow.pyfunc.load_model(
    model_uri='models:/HS300_MomReversal_LGB/Production',
)
```

**个人量化的实用建议**：

- **简单模型（IC 加权 / OLS / 弹性网络）**：直接 pickle / joblib 保存
- **复杂模型（XGBoost / LightGBM）**：用 MLflow 注册
- **不要装 K8s / SageMaker**：个人用不起

### 2.4 流水线编排（Pipeline Orchestration）

**目标**：**自动调度** + **依赖管理** + **失败重试**。

| 维度 | 工业级（Airflow / Prefect / Dagster） | 个人量化（cron + Python）|
|---|---|---|
| 学习曲线 | 陡 | 0 |
| DAG 可视化 | ✓ | ✗ |
| 失败重试 | 自动 | 手动 |
| 时间 | 1 周 | 30 分钟 |

**个人量化的"cron + Python"方案**：

```python
# scripts/daily_pipeline.py
"""每日数据更新 + 特征计算 + 回测 + 报告"""
import subprocess
import smtplib
from datetime import datetime

def run_daily_pipeline():
    today = datetime.now().strftime('%Y-%m-%d')
    
    try:
        # 1. 拉数据
        subprocess.run(['python', 'scripts/fetch_data.py'], check=True)
        
        # 2. 计算特征
        subprocess.run(['python', 'scripts/precompute_features.py'], check=True)
        
        # 3. 跑回测
        subprocess.run(['python', 'scripts/run_backtest.py'], check=True)
        
        # 4. 生成报告
        subprocess.run(['python', 'scripts/generate_report.py'], check=True)
        
        # 5. 数据落 DVC + git 提交
        subprocess.run(['dvc', 'add', 'data_cache/'], check=True)
        subprocess.run(['git', 'commit', '-am', f'daily_pipeline {today}'], check=True)
        
        send_email(f'流水线成功 {today}')
    except Exception as e:
        send_email(f'流水线失败 {today}: {e}')


def send_email(message):
    # 简单邮件发送（可用更稳定的告警工具）
    pass


if __name__ == '__main__':
    run_daily_pipeline()
```

**Windows 任务计划程序** / **Linux crontab**：

```bash
# Linux: 每天 18:00 跑
crontab -e
# 添加：
0 18 * * 1-5 cd /path/to/project && /usr/bin/python scripts/daily_pipeline.py
```

```powershell
# Windows: 任务计划程序，每天 18:00 跑
# 通过 GUI 配置 schtasks
```

**何时升级到 Airflow / Prefect**：

- 多个相互依赖的任务（10+ 个）
- 需要 DAG 可视化
- 需要失败自动重试
- 需要 SLA 监控

**A 股个人量化基本不需要**——cron 足够。

### 2.5 部署服务（Model Serving）

**目标**：把训练好的模型**部署到生产环境**，提供 API / 实时预测。

| 维度 | 工业级（TorchServe / TF Serving / Seldon）| 个人量化 |
|---|---|---|
| 实时预测 | < 10ms | 不需要 |
| 高并发 | 数千 QPS | 1 QPS |
| 监控 | 内置 | 不需要 |

**个人量化的"部署"**：

- **聚宽在线 IDE 实盘**：写完策略代码 → 直接绑定模拟盘 / 实盘
- **掘金 / 同花顺**：作为聚宽的备用平台
- **完全不需要**：FastAPI / TorchServe / 容器化

**聚宽在线 IDE 的"实盘部署"流程**：

```
1. 本地用 jqdatasdk 研究 + 训练
2. 把策略代码贴到聚宽在线 IDE
3. 设置回测 → 验证 → 模拟盘 → 实盘
4. 实盘运行（聚宽托管）
```

**这就是个人量化的完整"模型部署"**——比 K8s 简单 100 倍。

### 2.6 监控告警（Monitoring & Alerting）

**目标**：实盘运行后**持续跟踪模型性能** + 失效时告警。

**这是个人量化 MLOps 的最大真需求**——A 股市场结构剧烈变化，alpha 衰减很快。

#### 个人量化的"轻量监控"

```python
# scripts/monitor.py
"""每日实盘监控 + 失效告警"""
import smtplib
import pandas as pd
from datetime import datetime
import mlflow


def monitor_strategy(strategy_name: str):
    """监控策略的关键指标"""
    today = datetime.now().date()
    
    # 1. 拉最近 30 天的实盘收益（聚宽 API / 自记日志）
    recent_returns = get_recent_strategy_returns(strategy_name, days=30)
    
    # 2. 关键指标
    metrics = {
        'sharpe_30d': calc_sharpe(recent_returns),
        'max_drawdown_30d': calc_max_dd(recent_returns),
        'win_rate_30d': (recent_returns > 0).mean(),
        'avg_daily_return': recent_returns.mean(),
    }
    
    # 3. 记录到 MLflow
    with mlflow.start_run(run_name=f'monitor_{today}'):
        mlflow.log_metrics(metrics)
    
    # 4. 告警条件
    alerts = []
    if metrics['sharpe_30d'] < 0.5:
        alerts.append(f'⚠️ 30 日夏普 = {metrics["sharpe_30d"]:.2f} (< 0.5)')
    if metrics['max_drawdown_30d'] < -0.10:
        alerts.append(f'⚠️ 30 日最大回撤 = {metrics["max_drawdown_30d"]:.2%} (< -10%)')
    if metrics['win_rate_30d'] < 0.45:
        alerts.append(f'⚠️ 30 日胜率 = {metrics["win_rate_30d"]:.2%} (< 45%)')
    
    if alerts:
        send_alert(strategy_name, alerts)


def send_alert(strategy_name, alerts):
    """发邮件 / 短信 / 微信告警"""
    body = f'策略 {strategy_name} 告警：\n' + '\n'.join(alerts)
    # 使用邮件 / Server酱 / 钉钉机器人等
    print(body)


if __name__ == '__main__':
    monitor_strategy('hs300_multi_factor_v2')
```

**告警工具推荐（个人友好）**：

- **邮件**：smtplib（最简单）
- **Server酱**：微信推送，开发简单
- **钉钉 / 飞书机器人**：免费 + 推送方便
- **PushPlus**：微信通知服务

**详见**：[[backtest-factor-decay]] 因子失效监控 / [[backtest-checklist]] 实盘可信度自检。

---

## 3. Marti 列的 MLOps 工程师 6 类技能（个人量化解读）

> Marti ch9.2.2 列了 MLOps 工程师的 6 类技能：

| 技能 | Marti 原文 | A 股个人量化是否需要 |
|---|---|---|
| **机器学习知识** | ML 概念 / 算法 / 部署经验 | ✅ 必需 → [[index-01-05-ml-and-factors]] |
| **软件开发** | Python / Java / C++ / 版本控制 / 测试 / 调试 | ✅ 必需 → 至少会 Python + git |
| **DevOps** | CI/CD / 容器化 / 基础设施即代码 / Docker / Jenkins | ❌ 不需要（**95% 的个人没必要学**）|
| **数据工程** | 数据摄取 / 转换 / 存储 / Spark / Flink / Hadoop | ⚠️ 部分（pandas + parquet 已经覆盖 80%）|
| **云计算** | AWS / Azure / GCP / SageMaker | ❌ 不需要（**个人用不起 / 数据出境合规问题**）|
| **沟通技巧** | 与数据科学家 / IT / 业务沟通 | ❌ 单人作战不需要 |

**个人量化的"反 Marti"建议**：

| 技能 | 投入时间 | 优先级 |
|---|---|---|
| Python + pandas | 3 个月 | **必须** |
| 量化金融知识 | 6 个月 | **必须** → [[index-01-01-unified-view]] |
| 因子工程 | 3 个月 | **必须** → [[index-02-01-operator-dictionary]] |
| ML 基础（GBDT / 弹性网络）| 1 个月 | **推荐** → [[ml-in-factor-investing-survey]] |
| MLflow + DVC | 1 天 | **强推** |
| git | 1 天 | **必须** |
| Linux / Docker / K8s | 1 周+ | **不需要** |
| AWS / GCP | 1 周+ | **不需要** |
| Airflow / Prefect | 1 周 | **不需要** |

**核心建议**：**把时间花在算法 + 因子上，不要花在工程工具链的"完美追求"上**。

---

## 4. A 股个人量化的"轻量 MLOps"端到端实战

### 4.1 项目结构

```
my_quant_project/
├── .git/                    # git 版本控制
├── .dvc/                    # DVC 配置
├── mlruns/                  # MLflow 实验记录
│
├── data/                    # 原始数据
│   ├── raw/                 # jqdatasdk 拉的原始数据
│   └── features/            # 计算后的特征
│
├── features/                # 特征定义模块
│   ├── __init__.py
│   ├── price_features.py
│   └── fundamental.py
│
├── models/                  # 模型代码
│   ├── ic_combine.py
│   └── lgb_factor_model.py
│
├── scripts/                 # 脚本
│   ├── fetch_data.py        # 拉数据
│   ├── precompute.py        # 算特征
│   ├── train.py             # 训练模型
│   ├── backtest.py          # 回测
│   └── daily_pipeline.py    # 每日流水线
│
├── notebooks/               # 研究笔记本
├── requirements.txt         # Python 依赖
└── README.md
```

### 4.2 端到端流程（一次完整迭代）

```python
# 1. 拉数据 + DVC 跟踪
python scripts/fetch_data.py
dvc add data/raw/

# 2. 算特征
python scripts/precompute.py
dvc add data/features/

# 3. 跑回测（含 MLflow 追踪）
python scripts/backtest.py
# 内部：
# mlflow.set_experiment('hs300_research')
# with mlflow.start_run(run_name='exp_001_v1'):
#     mlflow.log_params(...)
#     mlflow.log_metrics(...)
#     mlflow.log_artifact('backtest_curve.png')

# 4. 看实验结果
mlflow ui  # localhost:5000
# 浏览器对比所有实验

# 5. 选最佳实验 → 部署到聚宽在线 IDE
# 复制 scripts/backtest.py → 聚宽 IDE → 模拟盘

# 6. 实盘监控
crontab：每天 18:30 跑 scripts/monitor.py
# 邮件告警：sharpe < 0.5 / drawdown > 10%
```

### 4.3 实验对比的真实案例

**目标**：对比 3 个因子组合方案。

```python
# 方案 A：单因子（基线）
with mlflow.start_run(run_name='exp_001_single_mom'):
    mlflow.log_params({'factors': ['mom_20d'], 'method': 'rank'})
    mlflow.log_metrics({'sharpe': 0.8, 'mdd': -0.15})

# 方案 B：3 因子等权 rank
with mlflow.start_run(run_name='exp_002_equal_weight'):
    mlflow.log_params({'factors': ['mom_20d', 'vol_20d', 'ep'], 'method': 'equal_weight'})
    mlflow.log_metrics({'sharpe': 1.2, 'mdd': -0.12})

# 方案 C：3 因子 IC 加权
with mlflow.start_run(run_name='exp_003_ic_weighted'):
    mlflow.log_params({'factors': ['mom_20d', 'vol_20d', 'ep'], 'method': 'ic_weighted'})
    mlflow.log_metrics({'sharpe': 1.45, 'mdd': -0.10})

# MLflow UI：一眼看出方案 C 最好
```

### 4.4 数据更新后的版本对比

**场景**：周末数据更新，周一回测结果变了，要找原因。

```bash
# 1. 看新结果
python scripts/backtest.py  # 夏普从 1.45 跌到 1.1

# 2. 回到旧数据
git stash  # 保存当前代码改动
git checkout HEAD~1  # 回到上周
dvc checkout  # 拉回上周的数据

# 3. 用相同代码跑
python scripts/backtest.py  # 夏普仍是 1.45 → 说明是数据问题

# 4. 调查数据变化
git diff HEAD HEAD~1 -- data/  # 看 .dvc 文件变化
# 输出：新增了 2024-12-30 / 31 两天数据 + 某只股票退市

# 5. 决策：
# - 如果是退市股影响 → 加 ST 过滤
# - 如果是新数据噪声 → 用滚动窗口平滑
git checkout main
dvc checkout
```

### 4.5 简易告警脚本

```python
# scripts/monitor.py
"""每日实盘监控 + 失效告警"""
import requests  # 用 PushPlus / Server酱
from datetime import datetime


def calc_recent_metrics(strategy_name):
    """从聚宽 API / 本地日志拉最近 30 天指标"""
    # 简化：假设已经有数据
    return {
        'sharpe_30d': 0.42,  # 警戒线 0.5
        'mdd_30d': -0.12,    # 警戒线 -0.10
        'win_rate_30d': 0.50,
    }


def send_pushplus(message):
    """用 PushPlus 推送到微信"""
    token = 'your_pushplus_token'
    requests.post(
        f'http://www.pushplus.plus/send',
        json={'token': token, 'title': '量化告警', 'content': message},
    )


def main():
    today = datetime.now().strftime('%Y-%m-%d')
    metrics = calc_recent_metrics('hs300_multi_factor_v2')
    
    alerts = []
    if metrics['sharpe_30d'] < 0.5:
        alerts.append(f'夏普 30d = {metrics["sharpe_30d"]:.2f} (低于 0.5)')
    if metrics['mdd_30d'] < -0.10:
        alerts.append(f'回撤 30d = {metrics["mdd_30d"]:.2%} (低于 -10%)')
    
    if alerts:
        send_pushplus(
            f'{today} 策略告警:\n' + '\n'.join(alerts)
        )

if __name__ == '__main__':
    main()
```

**crontab 调度**：

```bash
# 每天 18:30（收盘后 1 小时）
30 18 * * 1-5 cd /path/to/project && python scripts/monitor.py
```

---

## 5. 进阶：何时升级到工业级 MLOps

### 5.1 升级时机表

| 信号 | 建议升级 |
|---|---|
| 跑 > 10 个策略并行 | Prefect / Airflow（流水线编排） |
| 团队 ≥ 3 人 | MLflow Cloud + Feast |
| 多人协作的特征 ≥ 50 个 | Feast（特征共享） |
| 实盘资金 > 100 万 | 监控系统升级（Prometheus / Grafana） |
| 模型 > 5 个并行运行 | MLflow Model Registry + CI/CD |
| 数据 > 100GB | LakeFS / Delta Lake |
| 实时预测需求（< 100ms） | TorchServe + Redis |

### 5.2 工业级"完整 MLOps"参考架构

```
                    ┌──────────────┐
                    │  数据源       │
                    │  jqdatasdk / │
                    │  tushare /   │
                    │  Wind        │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 数据流水线    │
                    │  Airflow     │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 数据版本控制  │
                    │  DVC / LakeFS│
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ Feature Store│
                    │  Feast       │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 模型训练     │
                    │  + MLflow    │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 模型注册     │
                    │  MLflow Reg  │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 模型部署     │
                    │  TorchServe  │
                    │  / 聚宽      │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 监控告警     │
                    │ Prometheus +  │
                    │ Grafana       │
                    └──────────────┘
```

**A 股个人量化 95% 的需求**：

```
                    ┌──────────────┐
                    │  jqdatasdk    │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ Python + DVC │
                    │  + parquet   │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ MLflow       │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ 聚宽在线 IDE │
                    └──────┬───────┘
                           ↓
                    ┌──────────────┐
                    │ Python 脚本  │
                    │ + 邮件告警   │
                    └──────────────┘
```

---

## 6. A 股市场的"持续监控"哲学

A 股市场比美股**结构变化更剧烈**，alpha 衰减更快——这使得 MLOps 的"监控告警"模块**对 A 股个人量化的价值远高于美股**。

### 6.1 A 股的 4 大失效案例（提醒）

详见 [[backtest-factor-decay]]。**速查**：

| 因子 | 失效时间 | 触发原因 |
|---|---|---|
| **小市值** | 2017 | 监管政策 + 风格切换 |
| **白马股**（高 ROE） | 2021 | 估值见顶 + 抱团瓦解 |
| **DMA / 量化对冲** | 2024 | 监管限制 + 市场冲击 |
| **长期动量** | 多次 | 状态转换频繁 |

### 6.2 监控指标清单

```python
# 每日实盘监控的标准指标
DAILY_METRICS = {
    'sharpe_30d': '近 30 日夏普',
    'sharpe_90d': '近 90 日夏普',
    'mdd_30d': '近 30 日最大回撤',
    'mdd_since_start': '上线以来最大回撤',
    'win_rate_30d': '近 30 日胜率',
    'turnover_30d': '近 30 日换手',
    'ic_30d': '因子近 30 日 IC',
    'icir_30d': '近 30 日 ICIR',
    'rank_corr_30d': '横截面排序相关性',
}

# 告警阈值（参考）
ALERT_THRESHOLDS = {
    'sharpe_30d': 0.5,      # 低于报警
    'sharpe_30d_decay': 0.5,  # 比上线初期下降 50% 报警
    'mdd_30d': -0.10,       # 低于报警（即回撤 > 10%）
    'win_rate_30d': 0.45,   # 低于报警
    'icir_30d': 0.3,        # 低于报警
}
```

### 6.3 滚动重训（Online Learning Light）

**A 股市场结构变化** → **滚动重训** 比"完美模型"更重要：

```python
# 每月滚动重训（不是高频在线学习）
def monthly_retrain():
    """每月第一个交易日重训模型"""
    # 1. 用最近 60 个月的数据训练
    end_date = today
    start_date = end_date - relativedelta(months=60)
    
    train_data = load_features(universe='HS300', start=start_date, end=end_date)
    
    # 2. 训练 LightGBM
    model = train_lgb(train_data)
    
    # 3. 用 MLflow 注册新版本
    mlflow.log_model(model, f'lgb_model_{today}')
    
    # 4. 切换生产模型
    client.transition_model_version_stage(
        name='HS300_LGB',
        version=new_version,
        stage='Production',
    )
```

**关键**：**不要做"每日重训"**——金融数据信噪比低，频繁重训会过拟合最近噪声。月度 / 季度足够。

---

## 7. 综合观察

- **MLOps 的 4 项核心**（Marti ch9.2）：协作 / 自动化 / 监控 / 版本控制
- **个人量化的"真需求"**：实验追踪（MLflow） + 数据版本（DVC） + 监控告警（Python 脚本）
- **不要陷入"完美工程"陷阱**：把时间花在算法 + 因子上，不要花在工具链
- **Marti 的 6 类技能**（ML / 软开 / DevOps / 数据工程 / 云计算 / 沟通）—— 个人量化只需 ML + 软开
- **A 股的特殊价值**：市场剧烈变化 → 监控告警 + 滚动重训比"完美模型"更重要
- **轻量 MLOps 三件套**：MLflow（必装）+ DVC（必装）+ git（必装），1 天学完，**受益数年**
- **聚宽在线 IDE = 个人量化的"简易 MLOps"** —— 内置回测追踪 + 策略版本 + 实盘部署
- **何时升级到工业级**：团队 ≥ 3 人 / 资金 > 100 万 / 模型 ≥ 5 个 / 实时预测

## 参考与延伸

- [[index-05-05-mlops]] 5.5 索引 — 本板块入口
- [[feature-store-principles]] — 特征存储原理与工具
- [[index-01-05-ml-and-factors]] 1.5 ML 与因子的协同 — 算法层（用什么模型）
- [[index-03-04-ml-strategies]] 3.4 ML 策略 — 生产化的具体落地
- [[backtest-data-pitfalls]] — A 股数据陷阱
- [[backtest-factor-decay]] — A 股因子失效案例
- [[backtest-checklist]] — 30 条回测自检清单
- [[jq-complete-example]] 5.3 完整示例 — 可直接套上 MLflow 追踪
- [Marti 综述 ch9.2](../../../原始资料文件/从数据到交易量化交易的机器学习方法/从数据到交易量化交易的机器学习方法.md) — MLOps 原文（信息密度低，本文已抽取精华）
- [MLflow 官方文档](https://mlflow.org/) — 开源 MLOps 标准
- [DVC 官方文档](https://dvc.org/) — 数据版本控制
- [Google MLOps 成熟度模型](https://cloud.google.com/architecture/mlops-continuous-delivery-and-automation-pipelines-in-machine-learning) — 工业级参考
