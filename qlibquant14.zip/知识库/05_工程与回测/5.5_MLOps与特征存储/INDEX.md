---
name: index-05-05-mlops
description: 二级分类 5.5_MLOps与特征存储 的索引 —— 特征存储 / MLOps 全景 / 6 类技能 / A 股个人量化的"轻量 MLOps"实操
category: 05_工程与回测/5.5_MLOps与特征存储
tags: [MLOps, FeatureStore, Feast, MLflow, DVC, Airflow, A股, 工程化, 索引]
created: 2026-05-17
updated: 2026-05-17
status: stable
---

# 5.5 MLOps 与特征存储 · 索引

## 这个板块的定位

回答**"A 股个人量化的 ML 系统怎么工程化"**——05 工程与回测的"高阶收尾"。

读完这个板块，应该建立：

- **MLOps = ML 模型从开发到生产的完整生命周期管理**
- **Feature Store = ML 模型的"数据共享层"**——一处定义，多处复用
- **MLOps 6 大模块**：实验追踪 / 数据版本 / 模型版本 / 流水线编排 / 部署服务 / 监控告警
- **A 股个人量化的"轻量 MLOps"**：MLflow + parquet + git + cron 已经够 95% 场景

**核心 A 股化结论**：

- **个人量化 95% 不需要完整 MLOps**——一台机器 + 几个 parquet + git 提交记录已足够
- **个人量化的 5% 进阶需求**：MLflow（实验追踪）+ DVC（数据版本）—— **强烈推荐**
- **复杂工具 = 团队场景**：Feast / Tecton / Kubeflow / SageMaker 需要团队 / 云 / 多模型场景
- **A 股市场结构剧烈变化**（2017 小市值 / 2024 DMA）→ **持续监控 + 滚动重训** 比"完美模型"更重要

## 与 1.5 的区别

**1.5 ML 与因子的协同** = **算法层**（用什么模型、怎么调参、性价比清单）  
**5.5 MLOps 与特征存储** = **工程层**（模型怎么管、数据怎么版本、生产怎么部署）

两者**正交且互补**：算法决定 alpha 上限，工程决定可持续性。

## 文件清单

| # | 文件 | 一句话定位 | 状态 |
|---|---|---|---|
| 1 | [特征存储原理与工具.md](特征存储原理与工具.md) | Feature Store 是什么 + 主流工具（Feast / Tecton / Hopsworks）+ A 股个人量化的"DataFrame 即特征仓库"轻量方案 | with-jq-impl |
| 2 | [MLOps全景与工程化.md](MLOps全景与工程化.md) | MLOps 6 大模块 + 工具链（MLflow / DVC / Airflow / Prefect）+ A 股个人量化的"轻量 MLOps" 端到端实践 | with-jq-impl |

## 阅读路径建议

### 个人量化（业余）：要不要做 MLOps？

1. 读本 INDEX § "个人量化的轻量 MLOps 三件套" —— **30 秒决定要不要做**
2. 读 [MLOps全景与工程化.md § 1 MLOps 的真假需求](MLOps全景与工程化.md) —— 看自己是否落入"过度工程"陷阱
3. 如果需要 → 读 [MLOps全景与工程化.md § 4 轻量 MLOps 实战](MLOps全景与工程化.md)

### 团队 / 公司：建研究平台

1. 读 [特征存储原理与工具.md § 主流工具横向对比](特征存储原理与工具.md)
2. 读 [MLOps全景与工程化.md § 6 大模块详解](MLOps全景与工程化.md)
3. 选 Feast + MLflow + Airflow 组合（开源 + 个人友好）

### 进阶研究：从 1.5 ML 衔接

1. 先读 [[index-01-05-ml-and-factors]] 1.5 INDEX —— 算法决策
2. 再读 [MLOps全景与工程化.md § 4 轻量 MLOps 实战](MLOps全景与工程化.md) —— 工程落地
3. 整合 [[jq-complete-example]] 完整示例 + MLflow 追踪

## 关键 A 股化要点（必读）

- **个人量化不需要"完整 MLOps"**——95% 场景一台机器 + parquet 缓存 + git 提交 + Python 脚本足够
- **必选 = MLflow（实验追踪）**——为什么这次回测夏普 1.5 上次 1.2？没记录就只能瞎猜
- **强推 = DVC（数据版本）**——数据更新后回测结果变了，没版本控制就找不回原状态
- **不推 = Feast / Tecton**（个人场景过度设计）/ **不推 = SageMaker / Vertex AI**（个人用不起价格）
- **A 股市场结构剧烈变化** → MLOps 的最大价值不是"上线"，而是"**持续监控 + 滚动重训 + 失效报警**"
- **聚宽在线平台 ≈ 简易 MLOps**——内置回测追踪 / 策略版本 / 实盘部署，**对个人是最低成本起点**

## 与其他板块的关系

| 二级 | 关系 |
|---|---|
| [[index-01-05-ml-and-factors]] 1.5 ML 与因子 | **正交互补**——1.5 = 算法层（用什么模型），5.5 = 工程层（怎么管模型）|
| [[index-05-01-data-access]] 5.1 数据接入 | **上游依赖**——MLOps 的"特征存储"建立在数据接入之上 |
| [[index-05-04-backtest-pitfalls]] 5.4 回测陷阱 | **下游应用**——MLOps 的"流水线"内嵌防陷阱机制 |
| [[index-03-04-ml-strategies]] 3.4 ML 策略 | **生产化落地**——3.4 ML 策略需要 MLOps 工程化才能持续运行 |
| [[index-02-07-alternative-data]] 2.7 替代数据 | **上游依赖**——替代数据接入需要 Feature Store 管理 |
| [[index-05-03-jq-sdk-template]] 5.3 聚宽 SDK | **简易 MLOps**——聚宽在线平台对个人是最低成本 MLOps |

## 个人量化的"轻量 MLOps 三件套"（核心推荐）

```
┌───────────────────────────────────────────────┐
│  1. MLflow（实验追踪）                       │
│     - 记录每次回测的参数 / 指标 / 模型        │
│     - 安装：pip install mlflow                │
│     - 启动：mlflow ui                         │
│     - 价值：永远记得"上次什么参数好用"        │
└───────────────────────────────────────────────┘
                  ↓
┌───────────────────────────────────────────────┐
│  2. DVC（数据版本）                          │
│     - 给数据文件打 git tag                   │
│     - 安装：pip install dvc                   │
│     - 命令：dvc add data/*.parquet            │
│     - 价值：数据更新后能回到旧版本对比        │
└───────────────────────────────────────────────┘
                  ↓
┌───────────────────────────────────────────────┐
│  3. parquet + git（特征 + 代码版本）         │
│     - 特征：本地 parquet 缓存                │
│     - 代码：git 提交 + 分支管理              │
│     - 价值：完整可重现 + 几乎零成本           │
└───────────────────────────────────────────────┘
```

**3 件套覆盖个人量化 95% 的工程需求**。**剩余 5%**：考虑 Feast（多机共享）/ Airflow（自动调度）/ Prometheus（实盘监控）。

## MLOps 工具链速查表

| 模块 | 推荐工具（个人）| 推荐工具（团队）| 备注 |
|---|---|---|---|
| **实验追踪** | **MLflow** | MLflow / W&B / Neptune | MLflow 是开源标准 |
| **数据版本** | **DVC** | DVC / LakeFS / Delta Lake | DVC = git for data |
| **模型版本** | **MLflow Model Registry** | MLflow / DVC / SageMaker | 集成进 MLflow |
| **流水线编排** | **cron + Python** | Airflow / Prefect / Dagster | 个人 cron 够用 |
| **特征存储** | **本地 parquet** | Feast / Tecton / Hopsworks | 个人不需要专门工具 |
| **部署服务** | **聚宽在线 / 掘金** | FastAPI / TorchServe / Seldon | 量化部署直接用平台 |
| **监控告警** | **简单 Python 脚本 + 邮件** | Prometheus / Grafana / Sentry | 个人简易脚本够 |
| **A/B 测试** | 不需要 | Optuna / Comet | 个人量化 A/B 没意义 |

---

[← 返回 05_工程与回测 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
