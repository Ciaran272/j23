---
name: index-05-03-jq-sdk-template
description: 二级分类 5.3_聚宽SDK模板 的索引 —— 策略骨架 / 下单持仓 / 配置 / 完整示例 / 掘金对照 五个组件
category: 05_工程与回测/5.3_聚宽SDK模板
tags: [聚宽, SDK, 策略骨架, 模板, 索引]
created: 2026-05-16
updated: 2026-05-16
status: stable
---

# 5.3 聚宽 SDK 模板 · 索引

## 一句话定位

聚宽策略开发的**工程基底**——把"五段式主流程 + 上下文对象 + 调度 + 下单 + 配置"五大组件文档化为可直接套用的模板，并配一个完整可跑的端到端示例。掘金 gm.api 作为备用平台对照。

## 文件清单

| 文件 | 描述 | 状态 |
|---|---|---|
| [策略骨架_主流程.md](策略骨架_主流程.md) | 五段式主流程（initialize / before / handle / after / process_initialize）+ context 对象 + run_daily/weekly/monthly 调度 | with-jq-impl |
| [下单与持仓.md](下单与持仓.md) | order 五函数对比 + Position 对象 + A 股 T+1 / 涨跌停 / 停牌 三大陷阱 | with-jq-impl |
| [配置_universe_benchmark.md](配置_universe_benchmark.md) | set_universe / set_benchmark / set_order_cost / set_slippage / set_option 配置 + A 股标准配置模板 | with-jq-impl |
| [完整示例_多因子框架.md](完整示例_多因子框架.md) | 端到端可跑的多因子月度调仓策略（Alpha-101 #42 + #6 + GTJA Alpha20 三因子等权） | with-jq-impl |
| [掘金备用对照.md](掘金备用对照.md) | 聚宽 vs 掘金 gm.api 接口映射 + 掘金三段式骨架（Python 实战 ch4 OCR 校对版） | with-jq-impl |

## 阅读路径建议

### 新用户：从零开始写聚宽策略

1. [策略骨架_主流程.md](策略骨架_主流程.md) —— 理解五段式与 context 对象
2. [配置_universe_benchmark.md](配置_universe_benchmark.md) —— 复制"A 股标准配置模板"
3. [下单与持仓.md](下单与持仓.md) —— 学 order_target_percent 与三大陷阱处理
4. [完整示例_多因子框架.md](完整示例_多因子框架.md) —— 复制到聚宽 IDE 直接跑

### 老用户：查具体问题

- **"如何按月调仓"** → [策略骨架_主流程.md § 调度系统](策略骨架_主流程.md)
- **"order vs order_target_percent 区别"** → [下单与持仓.md § 五个下单函数对比](下单与持仓.md)
- **"涨跌停 / 停牌怎么过滤"** → [下单与持仓.md § A 股三大陷阱](下单与持仓.md)
- **"手续费 / 滑点怎么配"** → [配置_universe_benchmark.md § set_order_cost / set_slippage](配置_universe_benchmark.md)
- **"context.portfolio.positions 怎么用"** → [策略骨架_主流程.md § context 对象详解](策略骨架_主流程.md)
- **"切换到掘金需要改什么"** → [掘金备用对照.md § 接口映射表](掘金备用对照.md)

## 关键 A 股化要点（必读）

- **聚宽优先**：本知识库全部策略默认用聚宽；掘金只在期货 / 实盘部署等场景使用
- **`set_option('use_real_price', True)` 必开**：用真实价格而非前复权价
- **`set_option('avoid_future_data', True)` 必开**：聚宽自动检测未来函数
- **T+1 透明处理**：聚宽通过 `position.closeable_amount` 自动区分今日可平仓数，调仓时不必显式处理
- **涨跌停 / 停牌必过滤**：用 `get_current_data()` 检查 `paused / high_limit / low_limit`，避免无效订单
- **调度优先用 `run_daily` 系列**：不要在 `handle_data` 中写主逻辑
- **`order_target_percent` 是多因子策略的首选下单函数**——其他 4 个是它的衍生

## 与其他二级的关系

| 二级 | 关系 |
|---|---|
| [[index-05-01-data-access]] 5.1 数据接入 | 5.3 策略中调用的 `get_price` / `get_fundamentals` 详解 |
| [[index-05-02-backtest-frameworks]] 5.2 回测框架对比 | 5.3 是聚宽的专题；5.2 是平台间的横向对比 |
| [[index-05-04-backtest-pitfalls]] 5.4 回测陷阱 | 5.3 配置中的"防未来函数"在 5.4 有更全面的陷阱清单 |
| [[index-02-02-price-volume-factors]] 2.2 因子库 | 因子计算结果在 5.3 完整示例中用作选股信号 |
| [[index-03-01-multi-factor-selection]] 3.1 多因子选股 | 5.3 完整示例是 3.1 多因子策略的工程实现 |

---

[← 返回 05_工程与回测 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
