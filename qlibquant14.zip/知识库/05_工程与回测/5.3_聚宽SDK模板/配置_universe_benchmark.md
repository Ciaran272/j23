---
name: jq-config-universe
description: 聚宽全局配置 —— set_universe / set_benchmark / set_order_cost / set_slippage / set_option 五大配置函数 + A 股标准配置模板
category: 05_工程与回测/5.3_聚宽SDK模板
tags: [聚宽, 配置, 股票池, benchmark, 手续费, 滑点, set_option, 真实价格]
created: 2026-05-16
updated: 2026-05-16
status: with-jq-impl
---

# 聚宽全局配置

## TL;DR

`initialize(context)` 中的五大配置函数：`set_universe` / `set_benchmark` / `set_order_cost` / `set_slippage` / `set_option`。本文档给出每个的用法、A 股标准取值、常见坑。**所有 A 股回测都应有一份标准配置模板**，详见末尾。

---

## 1. set_universe（股票池）

```python
set_universe(securities)
# securities: list[str] 股票代码列表
```

**作用**：设置当前可交易的股票池。后续 `handle_data` 中 `context.universe` 就是这个列表。

**何时调用**：通常在 `before_trading_start` 中根据当日成分股动态设置：

```python
def before_trading_start(context, data):
    # 用上一交易日的成分股（避免未来函数）
    securities = list(get_index_stocks('000300.XSHG', context.previous_date))
    set_universe(securities)
```

**A 股化注记**：
- `set_universe` 不持久化跨日——每天都要重设
- 想"全市场"做策略：传 `get_all_securities(types=['stock'])` 的全部股票代码
- `set_universe` **不影响数据可取性**——`get_price` 仍能取池外股票

---

## 2. set_benchmark（基准指数）

```python
set_benchmark(security)
```

**作用**：设置回测对比基准。聚宽页面会显示策略累计净值 vs 基准的对比曲线。

**A 股常用基准**：

| 标的 | 代码 | 适用场景 |
|---|---|---|
| 沪深 300 | `000300.XSHG` | 大盘选股策略 |
| 中证 500 | `000905.XSHG` | 中盘选股策略 |
| 中证 1000 | `000852.XSHG` | 中小盘选股策略 |
| 中证 800 | `000906.XSHG` | 大中盘组合 |
| 创业板指 | `399006.XSHE` | 创业板策略 |
| 中证全指 | `000985.XSHG` | 全市场选股策略 |
| 国债指数 | `511010.XSHG` | 债券或固收+ |

**实务**：基准应**与策略目标匹配**——一个针对小盘股的策略对标沪深 300 会显得"超额很高"，但其实只是市值因子的暴露。

---

## 3. set_order_cost（手续费）

```python
set_order_cost(
    OrderCost(
        open_tax=0,                # 买入印花税
        close_tax=0.001,           # 卖出印花税 1‰
        open_commission=0.0003,    # 买入佣金 0.03%
        close_commission=0.0003,   # 卖出佣金 0.03%
        close_today_commission=0,  # 当日卖出佣金（A 股 T+1 不适用）
        min_commission=5,          # 最低佣金 5 元
    ),
    type='stock',
)
```

**A 股标准取值**：

| 项目 | 标准值 | 说明 |
|---|---|---|
| `close_tax` | **0.001** | 卖出印花税 1‰，**A 股法定不可改** |
| `open_commission` | 0.00025-0.0003 | 买入佣金 0.025-0.03%，**散户实际开户通常 0.025-0.03%** |
| `close_commission` | 0.00025-0.0003 | 同上 |
| `min_commission` | **5** | 单笔最低 5 元，**A 股标准** |
| `open_tax` | 0 | 买入无印花税 |
| `close_today_commission` | 0 | T+1 无当日卖出 |

**`type` 参数**：

| 类型 | 用途 |
|---|---|
| `'stock'` | A 股股票（含 ETF） |
| `'index_futures'` | 股指期货 |
| `'fund'` | 公募基金 |
| `'mmf'` | 货币基金 |

### 过户费（特别说明）

A 股交易**还有过户费 0.02‰**（仅沪市，深市无），聚宽默认**不包含**在 `OrderCost` 里。如果做精细回测，需要单独建模：

```python
# 在 after_trading_end 中估算过户费（简化版）
def after_trading_end(context, data):
    # 取当日成交记录（聚宽暂不提供 trade log 接口，需用 portfolio diff）
    # 简化：用日成交额 * 0.00002 估算过户费
    pass
```

---

## 4. set_slippage（滑点）

```python
# 固定滑点（A 股最常用）
set_slippage(FixedSlippage(0.002))  # 买卖各 0.2%

# 价格相关滑点
set_slippage(PriceRelatedSlippage(0.002))

# 按 tick 步进
set_slippage(StepRelatedSlippage(0.002))
```

**A 股建议取值**（参见 [[jq-order-position]] § 滑点的影响）：

| 标的市值 | 建议固定滑点 |
|---|---|
| 大盘股 > 500 亿 | 0.05% - 0.1% |
| 中盘 100-500 亿 | 0.1% - 0.2% |
| 小盘 < 100 亿 | 0.2% - 0.5% |
| 微盘股 < 30 亿 | 0.5% - 1% |

**实务**：**做不同市值策略要分别测试不同滑点**——一个"在大盘股上滑点 0.05%能盈利"的策略在小盘股上用 0.05% 是不可信的。

---

## 5. set_option（回测精度选项）

`set_option(key, value)` 控制回测引擎的多个细节。**最重要的 3 个**：

```python
set_option('use_real_price', True)
set_option('avoid_future_data', True)
set_option('order_volume_ratio', 1)
```

### use_real_price（推荐 True）

```python
set_option('use_real_price', True)
```

| 值 | 含义 |
|---|---|
| `False`（默认） | 回测用前复权价 |
| `True` | 回测用真实价 + 自动加复权因子 |

**实务**：**强烈推荐 `True`**——真实价更接近实盘的下单价位（避免出现"用前复权价 5 元下单，实际真实价 50 元只能买 100 股"这种问题）。

### avoid_future_data（推荐 True）

```python
set_option('avoid_future_data', True)
```

让聚宽**自动检测未来函数**——若策略代码中用到未来数据，回测引擎会报错。

### order_volume_ratio（推荐 1）

```python
set_option('order_volume_ratio', 0.25)  # 默认 0.25
```

**含义**：策略单笔订单**最多占当日成交量的 X 比例**。默认 0.25 即 25%，超出部分聚宽会自动拆单或拒绝。

| 值 | 适用 |
|---|---|
| `1`（不限制） | 小资金回测，假设市场流动性充足 |
| `0.25`（默认） | 中小资金，避免高估流动性 |
| `0.1` | 大资金回测，保守估计 |
| `0.05` | 实盘对接，极保守 |

**A 股化注记**：设 `order_volume_ratio=0.25` 意味着**回测时单只股票最多买当日成交量 25%**——超出后聚宽会"成交不了"，导致权重不达预期。**做小市值策略时要降低这个值**或**降低 `set_universe` 中股票池的覆盖范围**。

### 其他常用 set_option

```python
set_option('match_by_signal', True)  # 按信号撮合（默认 False 按 tick 撮合）
set_option('side', 'long')  # 单边做多（A 股默认）
```

---

## A 股标准配置模板（推荐直接复制）

```python
def initialize(context):
    """A 股回测的标准配置 - 适用于绝大多数中频策略"""
    
    # === 1. 基准与股票池 ===
    set_benchmark('000300.XSHG')  # 沪深 300（视策略调整）
    
    # === 2. 真实价格 + 防未来函数 ===
    set_option('use_real_price', True)
    set_option('avoid_future_data', True)
    set_option('order_volume_ratio', 0.25)  # 默认值，按资金规模调
    
    # === 3. 滑点（按市值范围调整）===
    set_slippage(FixedSlippage(0.002))  # 0.2% 默认；小盘策略改 0.005
    
    # === 4. 手续费（A 股标准）===
    set_order_cost(
        OrderCost(
            close_tax=0.001,
            open_commission=0.0003,
            close_commission=0.0003,
            min_commission=5,
        ),
        type='stock',
    )
    
    # === 5. 日志级别 ===
    log.set_level('order', 'error')  # 减少订单 INFO 日志
    
    # === 6. 调度 ===
    run_daily(before_market_open, time='before_open')  # 盘前刷池
    run_monthly(rebalance, monthday=1, time='9:31')    # 每月调仓
    run_daily(after_market_close, time='after_close')  # 盘后报告
    
    log.info(f'策略初始化完成，初始资金 {context.portfolio.total_value:.0f}')


def before_market_open(context):
    """盘前 09:00 前：刷新股票池"""
    securities = list(get_index_stocks('000300.XSHG', context.previous_date))
    set_universe(securities)


def rebalance(context):
    """每月调仓：见 [[jq-complete-example]]"""
    pass


def after_market_close(context):
    """盘后报告"""
    log.info(
        f'{context.current_dt.date()}: 总资产 {context.portfolio.total_value:.0f}, '
        f'持仓 {len([p for p in context.portfolio.positions.values() if p.total_amount > 0])} 只'
    )
```

---

## 综合观察

- **A 股标准配置基本是"使用真实价 + 防未来 + 0.2% 滑点 + 标准印花税佣金"**——绝大多数策略不需改动
- **`set_option('use_real_price', True)` 必开**：除非你确实有理由用复权价（极少见）
- **`order_volume_ratio` 是大资金策略的关键参数**——**小资金可忽略，大资金一定要调**
- **手续费的 `min_commission=5` 在小资金策略中影响显著**——10000 元 × 0.03% = 3 元，但实际收 5 元，相当于 0.05% 手续费
- **`set_universe` 在 `before_trading_start` 中每天刷新**——不要在 `initialize` 一次性设固定列表（指数成分股会动态变）

## 参考与延伸

- [[jq-skeleton-main-flow]] — initialize / before / handle / after 主流程
- [[jq-order-position]] — 下单接口与滑点的影响
- [[jq-complete-example]] — 把这些配置嵌入完整策略
- [聚宽 API - set_option](https://www.joinquant.com/help/api/help#set_option) — 全部 set_option 选项
- [[index-04-portfolio-risk]] 4.4 — 交易成本与容量的方法论
