---
name: index-05-engineering-backtest
description: 一级分类 05_工程与回测 —— A 股数据接入、回测框架对比、聚宽 SDK 模板、回测陷阱、MLOps 与特征存储
category: 05_工程与回测
tags: [jqdatasdk, baostock, tushare, akshare, 聚宽, backtrader, bigquant, 掘金, 回测陷阱, mlops]
created: 2026-05-16
updated: 2026-05-17
status: stable
---

# 05_工程与回测 · 索引

本分类回答**"代码怎么落地"**——数据从哪拉、回测怎么跑、聚宽 SDK 怎么写、有哪些陷阱、生产化与特征存储。**聚宽为主线，掘金为备用平台**。

## 范围

5 个二级分类覆盖"数据 → 平台 → SDK → 陷阱 → 生产化"完整工程链路。**所有代码默认聚宽**，必要时给掘金 / Backtrader 对照。

---

## 二级分类与内容来源

| # | 二级分类 | 一句话定位 | 主要来源 |
|---|---|---|---|
| 5.1 | A 股数据接入 | 聚宽 jqdatasdk 主线 + tushare/baostock/akshare 备用 + 财务数据 PIT 处理 | Whale-Quant ch03 + 因子投资 ch3.1 |
| 5.2 | 回测框架对比 | 聚宽（主）+ Backtrader（备）+ pandas 手写 + BigQuant + 掘金 | Whale-Quant ch07 |
| 5.3 | 聚宽 SDK 模板 | initialize/handle_data/before_trading_start/after_trading_end + run_daily + order_target_percent | 聚宽官方文档 + 新写；掘金作为备用对照 |
| 5.4 | 回测陷阱清单 | 前视/数据迁就/存活偏差 + A 股特有陷阱（涨跌停/停复牌/ST/分红/北交所） | Chan ch3.4 + 因子投资 ch6.5/6.6 + 新写 A 股清单 |
| 5.5 | MLOps 与特征存储 | Feature Store + MLOps 工程师 6 类技能 + jqfactor 平台能力 | Marti ch9 |

---

## 详细内容计划

### 5.1 A 股数据接入
- **聚宽主线（jqdatasdk）**：
  - `get_price` 行情
  - `get_fundamentals` 财务
  - `get_history_constituents` 指数成分股
  - `get_index_stocks` 当前成分
  - `get_security_info` 标的元信息
  - `get_trade_days` 交易日
  - 复权方式（前复权 / 后复权 / 不复权）
- **备用数据源**：
  - Whale-Quant ch03 Baostock 基础数据获取
  - tushare（专业版收费）
  - akshare（免费）
  - 注：Python 实战 ch4 的掘金 SDK 不在此节，归 5.3
- 因子投资 ch3.1 **A 股财务数据处理**：
  - 报告期 / 财务报表 / 基准报告期
  - 调整和更正（重述）
  - 单季度数据构造
  - TTM 数据构造
  - PIT（point-in-time）避免未来函数

### 5.2 回测框架对比
- Whale-Quant ch07 完整四种对比：
  - pandas 从零实现评估指标（年化 / 波动率 / 最大回撤 / 夏普 / Calmar）
  - **聚宽**（在线 IDE）—— **主线**
  - Backtrader（开源）—— 备选
  - BigQuant（图形化）—— 备选
  - 手写回测代码
- **聚宽 vs Backtrader vs 掘金的选型对照表**（新写）：
  - 数据成本 / API 设计 / 撮合精度 / 灵活度 / 学习曲线
- **A 股化注记**：聚宽 minute / daily / tick 数据可用；Backtrader 默认无 A 股数据需自接
- **取舍**：BigQuant 在 Whale-Quant ch08.5/8.6 的代码绑定其私有 API，**不入策略原型库**

### 5.3 聚宽 SDK 模板
- **主：聚宽策略骨架**
  - `initialize(context)` —— 全局配置
  - `before_trading_start(context, data)` —— 盘前
  - `handle_data(context, data)` —— 主循环
  - `after_trading_end(context, data)` —— 盘后
  - `run_daily` / `run_weekly` / `run_monthly` 调度
  - 下单：`order` / `order_target` / `order_value` / `order_target_value` / `order_target_percent`
  - 持仓查询：`context.portfolio.positions`
- **备用：掘金 gm.api 三段式**（Python 实战 ch4）
  - `init` / `algo` / `on_backtest_finished`
  - `schedule(date_rule='1m', time_rule='09:31:00')`
  - `history_n` / `get_fundamentals_n` / `get_history_constituents`
  - `run(strategy_id=..., mode=MODE_BACKTEST, token=..., backtest_start_time=..., backtest_initial_cash=..., backtest_adjust=ADJUST_PREV)`
  - **OCR 校对注记**：Python 实战的所有掘金代码均需回 `Python量化交易实战_origin.pdf` 校对（0→o、1→l、`==` 丢失、中英文标点、`import *` 变 `★`、`__name__ == '__main__'` 错误等密集）
- **聚宽 vs 掘金接口映射表**（新写）

### 5.4 回测陷阱清单
- Chan ch3.4：
  - 前视偏差（用滞后数据、"砍掉最后 N 天再跑"检查法）
  - 数据迁就偏差（含"无参数交易模型"——参数全在移动窗口动态优化）
  - **例 3.3 玩具策略**：买 1000 只市值最大股票中最便宜的 10 只，无存活偏差 -42% vs 有存活偏差 388%
  - 最高/最低价不可靠（极端时点的虚假报价）
- 因子投资 ch6.5：风险 / 错误定价 / 数据窥探三框架
- 因子投资 ch6.6：曝光 / 拥挤 / 交易成本三种因子样本外失效
- **A 股特有陷阱清单（新写）**：
  - **涨跌停**：停板时无法开 / 平仓 → 委托单状态处理
  - **停复牌**：数据缺失、复牌后跳价 → `is_st` / `is_paused` 字段
  - **ST / 退市**：生存偏差 → 历史回测时不应包含未来 ST 的处理
  - **新股次新股**：上市初期价格波动剧烈 → 上市 N 日内剔除（建议 N=60 或 N=180）
  - **分红送股**：前复权 / 后复权选择
  - **科创板 / 创业板 / 北交所**：涨跌停规则 20% / 30%、最小买卖单位差异
  - **T+1**：当日买入次日才能卖
  - **印花税**：仅卖出端 1‰

### 5.5 MLOps 与特征存储
- Marti ch9.1 特征存储（Feature Store）：定义、对量化的价值
- Marti ch9.2 MLOps：定义、为何重要
- Marti ch9.2.1 MLOps 工程师 6 类技能：ML / 软开 / DevOps / 数据工程 / 云计算 / 沟通
- **A 股落地**：聚宽 jqfactor 平台的特征存储能力（如适用）
- **取舍**：Marti 第 9.3 节团队建设建议**不入库**（过于普适）

---

## 文件清单

按二级分类的文件清单：

### 5.1_A股数据接入 ([INDEX](5.1_A股数据接入/INDEX.md))
- [数据API全景对比.md](5.1_A股数据接入/数据API全景对比.md) — 5 大主流 A 股数据 API 横向对比（聚宽 / akshare / baostock / tushare pro / Wind）+ 选型决策树 + 5 类数据全景
- [jqdatasdk实操与陷阱.md](5.1_A股数据接入/jqdatasdk实操与陷阱.md) — jqdatasdk 完整使用指南：认证 / 行情 / 财务 / 因子 / finance 高级接口 / 调用统计 / PIT 处理 / 端到端示例

### 5.2_回测框架对比 ([INDEX](5.2_回测框架对比/INDEX.md))
- [回测框架横向对比.md](5.2_回测框架对比/回测框架横向对比.md) — 5 大主流回测框架横向对比（聚宽 / 掘金 / Backtrader / BigQuant / pandas 手写）+ 选型决策树 + Python 生态扩展（vectorbt / qlib）+ 4 类框架陷阱
- [评估指标全集.md](5.2_回测框架对比/评估指标全集.md) — 12 个核心指标完整公式 + pandas 实现 + A 股化警戒线 + 统计骗局识别 + 一站式 evaluate 函数

### 5.3_聚宽SDK模板 ([INDEX](5.3_聚宽SDK模板/INDEX.md))
- [策略骨架_主流程.md](5.3_聚宽SDK模板/策略骨架_主流程.md) — 五段式（initialize/before/handle/after/process_initialize）+ context 对象 + run_daily/weekly/monthly 调度
- [下单与持仓.md](5.3_聚宽SDK模板/下单与持仓.md) — order 五函数 + Position 对象 + T+1/涨跌停/停牌三大陷阱处理
- [配置_universe_benchmark.md](5.3_聚宽SDK模板/配置_universe_benchmark.md) — set_universe / set_benchmark / set_order_cost / set_slippage / set_option + A 股标准配置模板
- [完整示例_多因子框架.md](5.3_聚宽SDK模板/完整示例_多因子框架.md) — 端到端多因子月度调仓策略（直接复制可跑）
- [掘金备用对照.md](5.3_聚宽SDK模板/掘金备用对照.md) — 聚宽 vs 掘金接口映射 + Python 实战 ch4 掘金骨架（OCR 校对）

### 5.4_回测陷阱清单 ([INDEX](5.4_回测陷阱清单/INDEX.md))
- [统计陷阱_前视数据迁就存活.md](5.4_回测陷阱清单/统计陷阱_前视数据迁就存活.md) — 三大经典陷阱 + Chan ch3.4 例 3.3 玩具策略反例
- [因子失效_拥挤与样本外.md](5.4_回测陷阱清单/因子失效_拥挤与样本外.md) — 失效三大原因 + A 股 4 个典型案例 + 防御策略
- [A股交易制度陷阱.md](5.4_回测陷阱清单/A股交易制度陷阱.md) — 涨跌停 / 停复牌 / T+1 / 印花税 / 板块差异 等 8 个陷阱
- [A股数据处理陷阱.md](5.4_回测陷阱清单/A股数据处理陷阱.md) — PIT / 复权 / ST / 新股 / 退市 / 行业切换 等 7 个陷阱
- [回测可信度自检清单.md](5.4_回测陷阱清单/回测可信度自检清单.md) — **30 条 checklist** + 完整自检流程

### 5.5_MLOps与特征存储 ([INDEX](5.5_MLOps与特征存储/INDEX.md))
- [特征存储原理与工具.md](5.5_MLOps与特征存储/特征存储原理与工具.md) — Feature Store 原理 + 主流工具对比（Feast / Tecton / Hopsworks）+ A 股个人量化的 DataFrame 轻量方案 + 训练-推理一致性
- [MLOps全景与工程化.md](5.5_MLOps与特征存储/MLOps全景与工程化.md) — MLOps 6 大模块 + 工具链对比 + Marti 6 类技能 + MLflow / DVC 端到端实战 + A 股市场监控

### 全部完成 ⭐⭐⭐⭐⭐

05_工程与回测 5/5 板块全成。

---

[← 返回主索引](../INDEX.md)
