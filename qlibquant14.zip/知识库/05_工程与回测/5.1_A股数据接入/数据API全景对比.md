---
name: data-api-comparison
description: A 股个人量化的 5 大主流数据 API 横向对比 —— 聚宽 jqdatasdk / akshare / baostock / tushare pro / Wind + 选型决策树 + 5 类数据全景
category: 05_工程与回测/5.1_A股数据接入
tags: [jqdatasdk, akshare, baostock, tushare, Wind, 数据API, 横向对比, 选型, A股]
created: 2026-05-17
updated: 2026-05-17
status: with-jq-impl
---

# 数据 API 全景对比与选型

## TL;DR

A 股个人量化的数据 API 选择**没有"最好"只有"最合适"**。本文用 5 大主流 API（聚宽 jqdatasdk / akshare / baostock / tushare pro / Wind）做横向对比，给出**3 分钟选型决策树**，并梳理 5 类核心数据（量价 / 财务 / 宏观 / 市场情报 / 替代）的全景图。

**核心结论**：

- **个人量化首选 = 聚宽 jqdatasdk**（PIT 默认 + 接口全 + 文档好）
- **akshare 是无脑补充**（完全免费 + 接口全 + 但数据质量参差）
- **tushare pro 是专业进阶**（数据更全 + 但部分接口需 5000+ 积分）
- **不要自己爬数据**（爬虫工程量大 + 反爬严重 + 数据校验难）

## 来源

- 聚宽官方文档：https://www.joinquant.com/help/api/help
- tushare pro 官方文档：https://tushare.pro/document/2
- akshare 官方文档：https://akshare.akfamily.xyz/
- baostock 官方文档：http://baostock.com/baostock/index.php
- 综合：[[backtest-data-pitfalls]] § PIT / 复权 / ST + [[index-02-07-alternative-data]] 2.7 替代数据

---

## 1. 5 大主流 API 横向对比

### 1.1 总览表

| 维度 | 聚宽 jqdatasdk | akshare | baostock | tushare pro | Wind / iFinD |
|---|---|---|---|---|---|
| **是否免费** | 免费 + 付费 | **完全免费** | **完全免费** | 免费 + 积分 | 付费机构 |
| **价格** | 试用 1 年免费 / 正式需联系商务 | 0 | 0 | 部分接口需 5000+ 积分（约 200/年） | 数万元/年 |
| **量价** | ✅ | ✅ | ✅ | ✅ | ✅ |
| **财务** | ✅ PIT 默认 | ✅ 部分 PIT | ✅ 基本财报 | ✅ PIT | ✅ 最全 |
| **因子** | ✅ get_factor_values | ❌ | ❌ | 部分（fina_indicator）| ✅ |
| **龙虎榜** | ✅ finance.STK_LIST | ✅ | ❌ | ✅ | ✅ |
| **北向资金** | ✅ finance.STK_HK_HOLD_INFO | ✅ | ❌ | ✅ | ✅ |
| **行业** | ✅ get_industry | ✅ | ❌ | ✅ | ✅ |
| **宏观** | ✅ macro.* | ✅ macro_* | ❌ | ✅ | ✅ |
| **可转债** | ✅ finance.BOND_* | ✅ | ❌ | ✅ | ✅ |
| **指数成分** | ✅ get_index_stocks（含历史）| ✅（部分历史） | ✅ | ✅ | ✅ |
| **PIT 处理** | ✅ 默认 | ⚠️ 部分 | ⚠️ 需自查 | ✅ PIT 字段 | ✅ |
| **存活偏差** | ✅ 历史日期查 | ⚠️ 需自查 | ⚠️ 需自查 | ✅ | ✅ |
| **调用限制** | 试用 100 万条/天（1 年）/ 正式 2 亿条/天 | 无显式限制（看源站）| 无显式 | 积分制（5000+ 限频）| 无 |
| **数据起点** | 2005-01-04 | 各源差异 | 1990-12-19 | 1990 起 | 1990 起 |
| **接口语言** | Python | Python | Python | Python | Python / Matlab / Excel |
| **稳定性** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **文档质量** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **社区活跃** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **个人推荐指数** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐ |

### 1.2 各 API 详解

#### 1.2.1 聚宽 jqdatasdk（**推荐主线**）

**优势**：

- **PIT 默认**：`get_fundamentals` 自动按公告日 + 1 个交易日提供，**避免未来函数**
- **存活偏差 ✓**：`get_all_securities(date=)` / `get_index_stocks(index, date)` 可查历史时点
- **接口最全**：量价 / 财务 / 因子 / 龙虎榜 / 北向 / 融资融券 / 可转债 / 期货 / 期权 全覆盖
- **数据质量高**：与聚宽在线平台一致，回测结果可复现
- **官方维护**：聚宽公司维护，**长期稳定**
- **聚宽在线 IDE 与 jqdatasdk 接口几乎一致**，本地开发与线上策略**无缝迁移**

**劣势**：

- **试用账号配额很大**：每天 100 万条数据（1 年有效期），对个人量化日常研究**基本够用**——但配额单位是"**条**"（数据条数），不是"调用次数"，一次 `get_price` 拉 300 只 × 252 天就消耗 75600 条
- **试用账号 1 年到期**：到期后需要重新申请试用或升级正式账号（每天 2 亿条），正式账号需联系商务
- **部分高级接口需付费**：如 `jqfactor.get_factor_values` 的完整因子库

**适用场景**：

- 个人量化从入门到进阶（**首选**）
- 与聚宽在线平台对接的策略开发
- 严肃的因子研究 / 回测（PIT 是命脉）

**入门示例**：

```python
# pip install jqdatasdk
from jqdatasdk import auth, get_price, get_fundamentals, query, valuation

# 认证（用聚宽账号）
auth('your_phone', 'your_password')

# 拉行情
df = get_price(
    '000001.XSHE',
    start_date='2024-01-01', end_date='2024-12-31',
    fields=['open', 'close', 'high', 'low', 'volume', 'money', 'avg'],
    fq='pre',  # 前复权
)
print(df.head())

# 拉财务
fund = get_fundamentals(
    query(valuation.code, valuation.market_cap, valuation.pe_ratio)
    .filter(valuation.code == '000001.XSHE'),
    date='2024-06-30',
)
print(fund)
```

---

#### 1.2.2 akshare（**推荐补充**）

**优势**：

- **完全免费 + 开源**：MIT 协议，没有任何商业限制
- **接口全**：量价 / 龙虎榜 / 北向 / 期货 / 加密 / 宏观 / 公募基金 / 银行间利率 等
- **社区活跃**：GitHub 11k+ stars，Bug 修复快
- **多源汇总**：背后聚合了**新浪 / 东方财富 / 同花顺 / 央行 / 国家统计局**等多源
- **不需要注册**：直接 `pip install` 即用

**劣势**：

- **数据质量参差**：依赖各源稳定性，**某些接口偶尔返回空 / 错误**
- **存活偏差未处理**：需自己用历史时点过滤
- **PIT 未默认**：财务数据需自查 `pub_date` 字段
- **反爬风险**：底层是爬虫，**频繁调用可能被源站限频**
- **接口名复杂**：大量 `stock_zh_a_hist` / `stock_lhb_jgmmtj_em` 之类的"约定俗成名"，记忆负担大

**适用场景**：

- 聚宽试用账号配额用完后的**补充**
- 不想付费 / 学生 / 小规模研究
- 替代数据获取（龙虎榜 / 北向 / 行业 / 宏观）

**入门示例**：

```python
# pip install akshare
import akshare as ak

# 拉行情（前复权）
df = ak.stock_zh_a_hist(
    symbol='000001',
    period='daily',
    start_date='20240101', end_date='20241231',
    adjust='qfq',  # qfq=前复权 hfq=后复权 ''=不复权
)
print(df.head())

# 拉龙虎榜（按日）
lhb = ak.stock_lhb_detail_em(start_date='20240101', end_date='20240105')
print(lhb.head())

# 拉北向资金（每日资金流向）
hsgt = ak.stock_hsgt_hist_em(symbol='北向资金')
print(hsgt.tail())
```

---

#### 1.2.3 baostock（**基础免费**）

**优势**：

- **完全免费 + 无需注册**
- **稳定性好**：自有数据库，不依赖第三方源
- **数据起点最早**：1990-12-19（上证 50 起点）
- **接口简洁**：登录 → 查询 → 登出三段式

**劣势**：

- **接口窄**：仅量价 + 基础财报 + 行业 + 指数成分；**没有龙虎榜 / 北向 / 因子**
- **PIT 未默认**：财报数据需自查 `pubDate`
- **更新频率慢**：T+1 数据，**不支持当日实时**
- **接口风格陈旧**：返回的是 `rs.next()` 迭代器而非 DataFrame，需手动转换

**适用场景**：

- 学生 / 入门学习
- 只需要量价数据的回测
- 不想注册任何账号

**入门示例**：

```python
# pip install baostock
import baostock as bs
import pandas as pd

bs.login()

rs = bs.query_history_k_data_plus(
    'sz.000001',
    'date,open,close,high,low,volume,amount,turn',
    start_date='2024-01-01', end_date='2024-12-31',
    frequency='d',
    adjustflag='2',  # 1=后复权 2=前复权 3=不复权
)

data_list = []
while (rs.error_code == '0') & rs.next():
    data_list.append(rs.get_row_data())
df = pd.DataFrame(data_list, columns=rs.fields)

bs.logout()
print(df.head())
```

---

#### 1.2.4 tushare pro（**专业进阶**）

**优势**：

- **数据全面**：量价 / 财务 / 龙虎榜 / 北向 / 期货 / 港股美股 / 基金 / 可转债 / 宏观 全覆盖
- **PIT 处理良好**：`fina_indicator` 等接口有 `ann_date`（公告日）字段
- **官方维护**：tushare 团队（waditu）维护
- **接口风格 pythonic**：返回 DataFrame，链式调用清晰
- **部分接口免费**：基础量价 / 指数 / 财报基础数据

**劣势**：

- **积分门槛**：高级接口需要 5000+ 积分（约 200 元/年）/ 部分接口需 8000+
- **积分获取方式**：付费 / 邀请新用户 / 完善信息 / 社区贡献——**对普通用户略繁琐**
- **限频**：高积分用户每分钟 500 次 / 低积分 200 次
- **数据起点**：1990 起，但**前期数据稀疏**

**适用场景**：

- 严肃的多市场量化研究（A 股 / 港股 / 美股 / 期货）
- 因子研究的"二选一"补充（与聚宽对照验证）
- 需要更全宏观 / 行业 / 替代数据时

**入门示例**：

```python
# pip install tushare
import tushare as ts

# 用 token 登录（注册 tushare.pro 获取）
pro = ts.pro_api('your_token_here')

# 拉行情
df = pro.daily(
    ts_code='000001.SZ',
    start_date='20240101', end_date='20241231',
)
print(df.head())

# 拉财务（PIT）
fina = pro.fina_indicator(
    ts_code='000001.SZ',
    period='20240630',  # 报告期
)
print(fina[['ts_code', 'ann_date', 'end_date', 'roe', 'eps']].head())
```

---

#### 1.2.5 Wind / iFinD（**机构专业**）

**优势**：

- **业界最权威**：金融机构 / 公募 / 私募的标配
- **数据最全**：覆盖全球市场 + 历史最久 + 接口最稳定
- **专业研究员**：Wind 研究院 / 同花顺研究院的研报与数据深度集成
- **多语言支持**：Python / Matlab / Excel / WebAPI

**劣势**：

- **价格不友好**：Wind ≈ 4 万元/年（基础版）/ iFinD ≈ 2-3 万元/年（基础版）
- **个人难以承担**：仅适合机构购买
- **必须装客户端**：Wind 需要装 Wind 客户端配合 WindPy 使用
- **接口风格**：偏 Matlab 风格，对 Python 用户略不适应

**适用场景**：

- 机构 / 公司有 Wind 终端账号
- 个人量化**不推荐** —— 用聚宽付费版完全够用

**入门示例（仅供参考，需 Wind 终端）**：

```python
from WindPy import w
w.start()

# 拉行情
data = w.wsd(
    '000001.SZ',
    'open,close,high,low,volume',
    '2024-01-01', '2024-12-31',
    'PriceAdj=F',  # F=前复权
)
print(data.Data)

w.stop()
```

---

## 2. 选型决策树

```
你是？
│
├─ 学生 / 完全免费需求
│  ├─ 只要量价 → baostock（最简单）
│  └─ 要龙虎榜/北向/行业 → akshare（功能全）
│
├─ 个人量化（业余但严肃）
│  ├─ 入门阶段（每天数据消耗 < 10 万条）
│  │   ├─ 主：聚宽 jqdatasdk（试用账号 100 万条/天，1 年免费）
│  │   └─ 补：akshare（替代数据 + 突破限频）
│  │
│  └─ 进阶阶段（每天数据消耗 > 50 万条 / 接近 100 万条上限 / 研究复杂因子）
│      ├─ 主：聚宽 jqdatasdk 正式账号（2 亿条/天，需联系商务）
│      ├─ 补：akshare（持续免费补充）
│      └─ 高级：tushare pro（如需港股 / 美股 / 多市场）
│
├─ 机构 / 公司
│  ├─ 有 Wind 账号 → Wind 主线
│  ├─ 无 Wind 账号 → 聚宽企业版 / tushare pro 高积分版
│  └─ 还要建特征仓库 → 详见 [[index-05-05-mlops]] 5.5 MLOps
│
└─ 仅做策略验证（一次性）
   └─ akshare + baostock 双源对照足够
```

### 个人量化的标准方案：聚宽 + akshare 双源

```python
# 标准工作流
# 1. 聚宽 jqdatasdk 作主线（PIT 默认 / 存活偏差处理 ✓ / 因子接口全）
from jqdatasdk import auth, get_price, get_fundamentals
auth('phone', 'password')

# 2. akshare 作补充（突破限频 + 替代数据）
import akshare as ak

# 3. 双源校验（关键时刻交叉验证）
df_jq = get_price('000001.XSHE', start_date='2024-01-01', end_date='2024-01-31', fq='pre')
df_ak = ak.stock_zh_a_hist('000001', start_date='20240101', end_date='20240131', adjust='qfq')

# 字段名不同，但关键值（close / volume）应该对得上
print(df_jq['close'].head())
print(df_ak['收盘'].head())
```

---

## 3. 5 类核心数据全景

### 3.1 量价行情

| 字段 | 含义 | jqdatasdk | akshare | tushare |
|---|---|---|---|---|
| open / 开盘 | 开盘价 | `get_price(fields=['open'])` | `stock_zh_a_hist` | `daily` |
| close / 收盘 | 收盘价 | `get_price(fields=['close'])` | `stock_zh_a_hist` | `daily` |
| high / 最高 | 最高价 | `get_price(fields=['high'])` | `stock_zh_a_hist` | `daily` |
| low / 最低 | 最低价 | `get_price(fields=['low'])` | `stock_zh_a_hist` | `daily` |
| volume / 成交量 | 成交量（股）| `get_price(fields=['volume'])` | `stock_zh_a_hist` | `daily` |
| money / 成交额 | 成交额（元）| `get_price(fields=['money'])` | `stock_zh_a_hist`（含）| `daily` |
| avg / vwap | 当日均价 | `get_price(fields=['avg'])` | ⚠️ 不直接提供 | `daily_basic` |
| turnover | 换手率 | `get_valuation` | `stock_zh_a_hist` | `daily_basic` |
| 复权 | 前/后/不 | `fq='pre' / 'post' / None` | `adjust='qfq' / 'hfq' / ''` | 字段控制 |
| 频率 | 日/分钟/Tick | `frequency='1d' / '1m' / 'tick'` | 日为主 | `daily` / `minute` |

**A 股化注记**：

- **复权选择**：回测 / 因子计算用**前复权**（fq='pre' / adjust='qfq'）
- **vwap 在 akshare 不直接给** → 用 `money / volume` 手动计算
- **分钟数据**：聚宽试用账号下消耗条数较快（240 条/股/天）/ akshare 部分提供 / tushare 高积分

### 3.2 基本面财务

| 字段类型 | jqdatasdk | tushare pro | akshare |
|---|---|---|---|
| **估值（PE/PB/PS/股息率）** | `get_valuation` / `valuation.*` | `daily_basic` | `stock_a_lg_indicator` |
| **利润表** | `query(income).filter(...)` 或 `finance.STK_INCOME_STATEMENT_PARENT` | `income` | `stock_financial_report_sina` |
| **资产负债表** | `query(balance).filter(...)` 或 `finance.STK_BALANCE_SHEET_PARENT` | `balancesheet` | `stock_financial_report_sina` |
| **现金流量表** | `query(cash_flow).filter(...)` 或 `finance.STK_CASHFLOW_STATEMENT_PARENT` | `cashflow` | `stock_financial_report_sina` |
| **财务指标（ROE/ROA/毛利率等）** | `query(indicator).filter(...)` | `fina_indicator` | `stock_financial_analysis_indicator` |
| **TTM / 单季** | 聚宽提供 `*_q*` 字段（如 `eps_q1`）| 需手动构造 | 部分接口提供 |

**A 股化注记**：

- **报告期 vs 公告日的区别命脉**：用 `end_date / period` = 报告期，用 `ann_date / pub_date` 控制 PIT
- **聚宽 query 范式**：与 SQL 类似，需用 `query / filter / order_by / limit`
- **更详细的 PIT 处理**：见 [[financial-data-pit]] § A 股 PIT 实践

### 3.3 宏观经济

| 数据 | jqdatasdk | akshare | tushare |
|---|---|---|---|
| **CPI** | `macro.MAC_CPI_MONTH` | `macro_china_cpi` | `cn_cpi` |
| **PPI** | `macro.MAC_PPI_MONTH` | `macro_china_ppi_yearly` | `cn_ppi` |
| **GDP** | `macro.MAC_GDP_QUARTER` | `macro_china_gdp` | `cn_gdp` |
| **M0/M1/M2** | `macro.MAC_MONEY_SUPPLY_MONTH` | `macro_china_money_supply` | `cn_m` |
| **PMI** | `macro.MAC_MANUFACTURING_PMI` | `macro_china_pmi` | - |
| **基准利率** | `macro.MAC_LOAN_RATE_*` | `macro_china_lpr` | `cn_loan` |
| **汇率** | `macro.MAC_RMB_*` | `macro_china_fx_gold` | `fx_daily` |

**A 股化注记**：

- **宏观数据频率低**（月度 / 季度）—— **不需要每天拉**，缓存到本地即可
- **PMI / LPR 等政策类数据**：发布日通常滞后于报告期 → PIT 处理用 `ann_date`

### 3.4 市场情报

| 数据 | jqdatasdk | akshare | tushare |
|---|---|---|---|
| **龙虎榜** | `finance.STK_LIST` | `stock_lhb_detail_em` | `top_list` |
| **北向资金（沪深港通）** | `finance.STK_HK_HOLD_INFO` | `stock_hsgt_hist_em` | `hsgt_top10` |
| **融资融券** | `finance.STK_MARGIN` | `stock_margin_*` | `margin_detail` |
| **股东户数** | `finance.STK_SHAREHOLDER_TOP10` | `stock_zh_a_gdhs` | `stk_holder_number` |
| **限售解禁** | `finance.STK_LIMIT_RELEASE` | `stock_em_jjcg` | `share_float` |
| **股份回购** | `finance.STK_REPURCHASE` | - | `repurchase` |
| **业绩预告** | `finance.STK_FIN_FORECAST` | `stock_em_yjbb` | `forecast` |
| **业绩快报** | `finance.STK_FIN_EXPRESS` | `stock_em_yjkb` | `express` |

**A 股化注记**：

- **市场情报数据 = A 股 alpha 的"黄金矿"**——尤其是龙虎榜 / 北向资金 / 业绩预告
- **业绩预告与 PEAD**：见 [[index-03-05-seasonality-events]] § PEAD 完整实现
- **北向资金的"聪明钱效应"**：见 [[index-02-07-alternative-data]] 2.7 § 替代数据 30 类

### 3.5 替代数据

详见 [[index-02-07-alternative-data]] 2.7 替代数据 30 类清单。本节仅列**主流 API 的入口**：

| 数据 | jqdatasdk | akshare | 其他 |
|---|---|---|---|
| **新闻情绪（NLP）** | ❌ | `stock_news_em` | 同花顺 NLP API / 雪球 API（限频）|
| **公司公告** | ❌ | `stock_notice_report` | 巨潮资讯网（自爬）|
| **概念板块** | ❌ | `stock_board_concept_name_em` | - |
| **雪球热度** | ❌ | `stock_individual_basic_info_xq` | 雪球开放 API（限频）|
| **东方财富热度** | ❌ | `stock_hot_rank_em` | - |
| **可转债** | `finance.BOND_*` | `bond_zh_cov` | tushare `cb_basic` |
| **期货** | `get_dominant_future` | `futures_zh_daily_sina` | tushare `fut_daily` |
| **期权** | `opt.OPT_*` | - | - |
| **加密** | - | `crypto_*` | - |

**A 股化注记**：

- **替代数据 A 股个人量化的可行方向**：NLP（财经新闻 / 公司公告 / 雪球）+ 量化指数热度 + 北向 + 龙虎榜
- **不推荐**：卫星 / 信用卡 / 物联网 / 地理位置（中国合规与可获取性都很差）

---

## 4. 数据存储与缓存策略

### 4.1 为什么必须缓存

聚宽试用版每天 100 万条 / akshare 看源站心情 / tushare 积分制 —— **每次调用都消耗"条数"配额**。本地缓存是**降低 90% 重复请求**的核心，能把 100 万条/天的配额用得更久。

### 4.2 推荐方案：parquet + 增量更新

```python
import pandas as pd
import os
from pathlib import Path
from datetime import datetime, timedelta

CACHE_DIR = Path('./data_cache')
CACHE_DIR.mkdir(exist_ok=True)


def get_price_cached(security, start_date, end_date, fq='pre'):
    """带缓存的 get_price"""
    cache_file = CACHE_DIR / f'{security}_{fq}.parquet'

    # 1. 读缓存
    if cache_file.exists():
        cached = pd.read_parquet(cache_file)
        cached_start = cached.index.min()
        cached_end = cached.index.max()
    else:
        cached = pd.DataFrame()
        cached_start = cached_end = None

    # 2. 决定需要拉的区间
    need_pull = []
    if cached.empty:
        need_pull.append((start_date, end_date))
    else:
        # 拉缓存之前的
        if pd.Timestamp(start_date) < cached_start:
            need_pull.append((start_date, cached_start - timedelta(days=1)))
        # 拉缓存之后的
        if pd.Timestamp(end_date) > cached_end:
            need_pull.append((cached_end + timedelta(days=1), end_date))

    # 3. 增量拉数据
    from jqdatasdk import get_price
    new_dfs = [cached]
    for s, e in need_pull:
        df = get_price(security, start_date=s, end_date=e, fq=fq)
        if not df.empty:
            new_dfs.append(df)
    
    # 4. 合并 + 落盘
    result = pd.concat(new_dfs).drop_duplicates().sort_index()
    result.to_parquet(cache_file)
    
    return result[(result.index >= pd.Timestamp(start_date)) & (result.index <= pd.Timestamp(end_date))]
```

**关键优化**：

- **parquet 格式**：比 CSV 快 10 倍 + 文件小 1/3
- **按股票 + 复权方式分文件**：避免读全表
- **增量更新**：只拉缓存之外的日期段

### 4.3 进阶方案：HDF5 / DuckDB / 时序数据库

| 方案 | 适用规模 | 优点 | 缺点 |
|---|---|---|---|
| **parquet 文件** | < 5000 只股票 | 简单 / 读写快 / 跨语言 | 索引能力弱 |
| **HDF5** | 5000-数万只 | 单文件管理 / 索引快 | 写并发差 |
| **DuckDB** | 万只以上 | SQL 查询 / OLAP | 不支持流式 |
| **InfluxDB / TimescaleDB** | 实时 + 历史 | 时序专用 / 高并发 | 部署复杂 |

**个人量化 95% 的需求 = parquet 已经够**——不要过早优化。

---

## 5. A 股数据的"陷阱清单"（速查）

> 详见 [[backtest-data-pitfalls]] 与 [[backtest-trading-rules]]。本节仅列**与数据 API 选型直接相关**的陷阱。

| 陷阱 | jqdatasdk | akshare | tushare | 处理建议 |
|---|---|---|---|---|
| **PIT 财务** | ✅ 默认 | ⚠️ 需自查 pub_date | ✅ 默认 | 用聚宽 / tushare，akshare 需手动 |
| **存活偏差** | ✅ 历史日期查 | ⚠️ 默认返回今天活的 | ⚠️ 默认返回今天活的 | 用聚宽 `get_all_securities(date=)` |
| **复权方式** | `fq='pre'` 全字段统一 | `adjust='qfq'` | 字段控制 | **同一回测内全部用前复权** |
| **指数成分历史** | ✅ `get_index_stocks(index, date)` | ⚠️ 部分历史 | ⚠️ 需自查 | 用聚宽，需精确历史时点 |
| **ST 状态历史** | ✅ `get_extras('is_st', ...)` | ⚠️ 仅当前 | ⚠️ 仅当前 | 用聚宽，需精确历史时点 |
| **新股次新股** | `get_security_info` 取上市日 | `stock_individual_info_em` | `stock_basic` | 任何 API 都能取上市日，但需自己过滤 |
| **退市股** | ✅ 历史日期查 `get_all_securities(date=)` | ⚠️ 默认排除 | ⚠️ 默认排除 | 用聚宽 |
| **行业切换** | ✅ `get_industry(securities, date)` | ⚠️ 仅当前 | ⚠️ 仅当前 | 用聚宽，每月初取一次 |
| **复权因子的"未来函数"** | 都有 | 都有 | 都有 | **避免因子用绝对价**，用收益率 / rank / log |

**结论**：聚宽 jqdatasdk 在 A 股数据陷阱处理上**完胜其他 API**——这是为什么本知识库**强烈推荐聚宽**的根本原因。

---

## 6. 综合观察

- **聚宽 jqdatasdk 是个人量化的"理性首选"**——PIT / 存活偏差 / 历史成分 / 历史行业全自动处理，省下来的"自检时间"远大于年费
- **akshare 是"免费补充"**——突破聚宽试用账号的 100 万条限制（如需更多）+ 替代数据来源（龙虎榜 / 北向 / 雪球热度）
- **tushare pro 是"专业进阶"**——多市场（A 股 / 港股 / 美股 / 期货）+ 部分接口的细粒度比聚宽更好
- **不要自己爬数据**——爬虫工程量大 + 反爬升级快 + 数据质量难校验 + 法律风险
- **Wind / iFinD 不适合个人**——年费过高 + 个人需求用聚宽完全够
- **数据缓存必须做**——本地 parquet 增量更新可以降低 90% 重复请求
- **A 股数据陷阱 9 大类**：聚宽**默认处理 7 类**，akshare / tushare 需要**全部手动处理**

## 参考与延伸

- [[index-05-01-data-access]] 5.1 索引 — 本板块入口
- [[jqdatasdk-practice]] — jqdatasdk 数据层 API 详细实操与陷阱处理
- [[index-05-03-jq-sdk-template]] 5.3 聚宽 SDK 模板 — 策略层 API（区别于本文的数据层 API）
- [[index-05-04-backtest-pitfalls]] 5.4 回测陷阱 — 数据陷阱与交易制度陷阱完整清单
- [[backtest-data-pitfalls]] — A 股数据处理 7 大陷阱（PIT / 复权 / ST / 新股 / 退市 / 行业切换 / 成分变动）
- [[financial-data-pit]] — 财务数据 PIT 完整处理
- [[index-02-07-alternative-data]] 2.7 — 替代数据 30 类清单
- [聚宽官方文档](https://www.joinquant.com/help/api/help)
- [tushare pro 文档](https://tushare.pro/document/2)
- [akshare 文档](https://akshare.akfamily.xyz/)
- [baostock 文档](http://baostock.com/baostock/index.php)
