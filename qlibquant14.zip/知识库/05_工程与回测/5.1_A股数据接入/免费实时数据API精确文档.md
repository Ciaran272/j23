---
name: free-realtime-api-reference
description: A 股免费实时数据 API 精确文档 —— 东方财富 datacenter/push2 + 腾讯财经 + 新浪财经三表 + 巨潮公告 的 URL/参数/字段/坑点
category: 05_工程与回测/5.1_A股数据接入
tags: [免费API, 东方财富, 腾讯财经, 新浪财经, 巨潮, 实时数据, datacenter, push2]
created: 2026-05-19
updated: 2026-05-19
source: github.com/simonlin1212/a-stock-data (Apache 2.0)
status: with-jq-impl
---

# 免费实时数据 API 精确文档

## TL;DR

聚宽 jqdatasdk 是回测首选，但**实盘信号验证 / 盘中监控 / 非聚宽环境研究**需要免费公开 API。本文精确记录 4 个主要免费数据源的 URL、参数、字段映射、编码坑——可直接 `requests.get()` 调用，**零第三方封装依赖**。

**核心结论**：
- **东方财富 datacenter** = A 股免费数据的"瑞士军刀"（龙虎榜 / 融资融券 / 大宗交易 / 股东户数 / 分红 / 限售解禁 全覆盖）
- **东方财富 push2** = 实时资金流向 + 行业排名
- **腾讯财经** = 实时行情最佳（PE/PB/市值/涨跌停价 一次返回）
- **新浪财经** = 三大财务报表（资产负债 / 利润 / 现金流）
- **巨潮 cninfo** = 公告全文检索 + PDF 下载

**适用场景**：
- 聚宽回测之外的**实时数据获取**
- **实盘信号确认**（盘中资金流、北向资金、龙虎榜）
- **非聚宽环境**的研究脚本

## 来源

- simonlin1212/a-stock-data V3.1（Apache 2.0）—— 28 端点全部经 600519（贵州茅台）验证
- 各数据源官方接口逆向

---

## 1. 东方财富 datacenter 统一接口

### 1.1 通用 Helper

东方财富 datacenter 是一个**统一的 RESTful 接口**，通过 `reportName` 参数区分不同数据类型。

```python
import requests
import pandas as pd

DATACENTER_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get"

def eastmoney_datacenter(report_name, columns="ALL", filter_str="",
                         page_size=50, sort_columns="", sort_types="-1"):
    """东方财富 datacenter 统一查询接口
    
    Args:
        report_name: 报表名（见下方清单）
        columns: 返回字段，"ALL" 返回全部
        filter_str: 筛选条件，如 '(SECURITY_CODE="600519")'
        page_size: 每页条数（最大 500）
        sort_columns: 排序字段
        sort_types: "-1" 降序 / "1" 升序
    
    Returns:
        list[dict]: 数据记录列表
    """
    params = {
        "reportName": report_name,
        "columns": columns,
        "filter": filter_str,
        "pageSize": page_size,
        "sortColumns": sort_columns,
        "sortTypes": sort_types,
        "source": "WEB",
        "client": "WEB",
    }
    resp = requests.get(DATACENTER_URL, params=params, timeout=10)
    data = resp.json()
    if data.get("success") and data.get("result"):
        return data["result"].get("data", [])
    return []
```

### 1.2 Report Name 清单

| Report Name | 用途 | 典型 filter |
|---|---|---|
| `RPT_DAILYBILLBOARD_DETAILSNEW` | 龙虎榜上榜记录 | `(SECURITY_CODE="600519")` |
| `RPT_BILLBOARD_DAILYDETAILSBUY` | 龙虎榜买入席位 | `(SECURITY_CODE="600519")(TRADE_DATE='2024-01-15')` |
| `RPT_BILLBOARD_DAILYDETAILSSELL` | 龙虎榜卖出席位 | 同上 |
| `RPT_LIFT_STAGE` | 限售解禁日历 | `(SECURITY_CODE="600519")` |
| `RPTA_WEB_RZRQ_GGMX` | 融资融券明细 | `(SCODE="600519")` |
| `RPT_DATA_BLOCKTRADE` | 大宗交易 | `(SECURITY_CODE="600519")` |
| `RPT_HOLDERNUMLATEST` | 股东户数变化 | `(SECURITY_CODE="600519")` |
| `RPT_SHAREBONUS_DET` | 分红送转历史 | `(SECURITY_CODE="600519")` |

### 1.3 使用示例

```python
# 获取茅台最近 20 条融资融券数据
margin_data = eastmoney_datacenter(
    report_name="RPTA_WEB_RZRQ_GGMX",
    filter_str='(SCODE="600519")',
    page_size=20,
    sort_columns="TRADE_DATE",
    sort_types="-1",
)
df = pd.DataFrame(margin_data)
# 字段：TRADE_DATE, RZYE(融资余额), RZMRE(融资买入), RZCHE(融资偿还),
#       RQYE(融券余额), RQMCL(融券卖出量), RQCHL(融券偿还量), RZRQYE(合计)
```

### 1.4 坑点

- **无需认证**：不需要 API key，直接 GET
- **IP 限频**：正常使用不会触发（每秒 < 5 次即可）
- **字段名不稳定**：东方财富偶尔改字段名，建议用 `columns="ALL"` 先看返回结构
- **分页**：超过 page_size 需翻页（`pageNumber` 参数）

---

## 2. 东方财富 push2（实时资金流向 + 行业排名）

### 2.1 个股分钟级资金流向

```python
def eastmoney_fund_flow_minute(code):
    """个股分钟级资金流向（主力/大单/中单/小单/超大单）
    
    Args:
        code: 6 位股票代码（如 "600519"）
    
    Returns:
        list[dict]: 分钟级资金流向
    """
    # 市场代码：6/9 开头 → 1（沪）；其他 → 0（深）
    market = "1" if code[0] in ("6", "9") else "0"
    secid = f"{market}.{code}"
    
    url = "https://push2.eastmoney.com/api/qt/stock/fflow/kline/get"
    params = {
        "secid": secid,
        "klt": 1,  # 1=分钟
        "fields1": "f1,f2,f3,f7",
        "fields2": "f51,f52,f53,f54,f55,f56,f57",
        "lmt": 0,
        "ut": "fa5fd1943c7b386f172d6893dbbd1",
    }
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    
    results = []
    klines = data.get("data", {}).get("klines", [])
    for line in klines:
        parts = line.split(",")
        results.append({
            "time": parts[0],
            "main_net": float(parts[1]),      # 主力净流入（元）
            "small_net": float(parts[2]),      # 小单净流入
            "mid_net": float(parts[3]),        # 中单净流入
            "large_net": float(parts[4]),      # 大单净流入
            "super_net": float(parts[5]),      # 超大单净流入
        })
    return results
```

### 2.2 个股 120 日资金流向（日频）

```python
def stock_fund_flow_120d(code):
    """个股 120 日资金流向（日频）"""
    market = "1" if code[0] in ("6", "9") else "0"
    secid = f"{market}.{code}"
    
    url = "https://push2his.eastmoney.com/api/qt/stock/fflow/daykline/get"
    params = {
        "secid": secid,
        "lmt": 120,
        "fields1": "f1,f2,f3,f7",
        "fields2": "f51,f52,f53,f54,f55,f56,f57",
        "ut": "fa5fd1943c7b386f172d6893dbbd1",
    }
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    
    results = []
    klines = data.get("data", {}).get("klines", [])
    for line in klines:
        parts = line.split(",")
        results.append({
            "date": parts[0],
            "main_net": float(parts[1]),
            "small_net": float(parts[2]),
            "mid_net": float(parts[3]),
            "large_net": float(parts[4]),
            "super_net": float(parts[5]),
        })
    return results
```

### 2.3 行业板块排名

```python
def industry_ranking(top_n=20):
    """东方财富行业板块排名（~100 个行业）"""
    url = "https://push2.eastmoney.com/api/qt/clist/get"
    params = {
        "fs": "m:90+t:2",  # 行业板块
        "fields": "f2,f3,f4,f12,f14,f104,f105,f128,f140,f141",
        "fid": "f3",
        "po": 1,  # 降序
        "pn": 1,
        "pz": 200,
        "ut": "fa5fd1943c7b386f172d6893dbbd1",
    }
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    
    items = data.get("data", {}).get("diff", [])
    results = []
    for item in items:
        results.append({
            "code": item.get("f12"),
            "name": item.get("f14"),
            "change_pct": item.get("f3"),
            "up_count": item.get("f104"),
            "down_count": item.get("f105"),
            "leader": item.get("f140"),
            "leader_change": item.get("f141"),
        })
    
    sorted_results = sorted(results, key=lambda x: x["change_pct"] or 0, reverse=True)
    return {"top": sorted_results[:top_n], "bottom": sorted_results[-top_n:]}
```

### 2.4 坑点

- **金额单位是"元"**（不是万元），使用时注意转换
- **secid 格式**：`1.600519`（沪）/ `0.000001`（深）/ `0.300001`（创业板）
- **ut 参数**：固定值，不需要动态获取
- **北交所**：8 开头代码 → market = "0"

---

## 3. 腾讯财经实时行情

### 3.1 接口

```python
def tencent_quote(codes):
    """腾讯财经实时行情（支持股票/指数/ETF）
    
    Args:
        codes: list[str], 6 位代码列表（如 ["600519", "000001", "399001"]）
    
    Returns:
        dict[str, dict]: 代码 → 行情字段
    """
    # 前缀转换
    prefixed = []
    for code in codes:
        if code.startswith(("6", "9")):
            prefixed.append(f"sh{code}")
        elif code.startswith("8"):
            prefixed.append(f"bj{code}")
        else:
            prefixed.append(f"sz{code}")
    
    url = f"https://qt.gtimg.cn/q={','.join(prefixed)}"
    resp = requests.get(url, timeout=10)
    resp.encoding = "gbk"
    
    results = {}
    for line in resp.text.strip().split("\n"):
        if "~" not in line:
            continue
        # 提取代码
        var_name = line.split("=")[0]  # v_sh600519
        raw_code = var_name.split("_")[1][2:]  # 600519
        
        fields = line.split("=")[1].strip('";\n').split("~")
        if len(fields) < 50:
            continue
        
        results[raw_code] = {
            "name": fields[1],
            "price": float(fields[3]) if fields[3] else 0,
            "last_close": float(fields[4]) if fields[4] else 0,
            "open": float(fields[5]) if fields[5] else 0,
            "change_amt": float(fields[31]) if fields[31] else 0,
            "change_pct": float(fields[32]) if fields[32] else 0,
            "high": float(fields[33]) if fields[33] else 0,
            "low": float(fields[34]) if fields[34] else 0,
            "amount_wan": float(fields[37]) if fields[37] else 0,
            "turnover_pct": float(fields[38]) if fields[38] else 0,
            "pe_ttm": float(fields[39]) if fields[39] else 0,
            "amplitude_pct": float(fields[43]) if fields[43] else 0,
            "mcap_yi": float(fields[44]) if fields[44] else 0,
            "float_mcap_yi": float(fields[45]) if fields[45] else 0,
            "pb": float(fields[46]) if fields[46] else 0,
            "limit_up": float(fields[47]) if fields[47] else 0,
            "limit_down": float(fields[48]) if fields[48] else 0,
            "vol_ratio": float(fields[49]) if fields[49] else 0,
            "pe_static": float(fields[52]) if fields[52] else 0,
        }
    return results
```

### 3.2 关键字段映射（重要）

| 索引 | 字段 | 说明 |
|---|---|---|
| 1 | name | 股票名称 |
| 3 | price | 最新价 |
| 4 | last_close | 昨收 |
| 5 | open | 今开 |
| 31 | change_amt | 涨跌额 |
| 32 | change_pct | 涨跌幅(%) |
| 33 | high | 最高 |
| 34 | low | 最低 |
| 37 | amount_wan | 成交额(万) |
| 38 | turnover_pct | 换手率(%) |
| **39** | **pe_ttm** | **市盈率(TTM)** |
| **43** | **amplitude_pct** | **振幅(%)** |
| **44** | **mcap_yi** | **总市值(亿)** |
| **45** | **float_mcap_yi** | **流通市值(亿)** |
| **46** | **pb** | **市净率** |
| 47 | limit_up | 涨停价 |
| 48 | limit_down | 跌停价 |
| 49 | vol_ratio | 量比 |
| 52 | pe_static | 静态市盈率 |

### 3.3 坑点

- **编码 = GBK**：必须 `resp.encoding = "gbk"`
- **分隔符 = `~`**：不是逗号
- **字段 88 个**：很多教程映射错误——**index 43 是振幅不是 PB**，PB 在 index 46
- **批量查询**：一次最多约 50 只（URL 长度限制）
- **指数代码**：`sh000001`（上证）/ `sz399001`（深成指）/ `sh000300`（沪深300）

---

## 4. 新浪财经三大报表

### 4.1 接口

```python
def sina_financial_statements(code, report_type="BalanceSheet"):
    """新浪财经三大财务报表
    
    Args:
        code: 6 位代码
        report_type: "BalanceSheet" / "ProfitStatement" / "CashFlow"
    
    Returns:
        pd.DataFrame: 财务报表数据
    """
    prefix = "sh" if code.startswith(("6", "9")) else "sz"
    symbol = f"{prefix}{code}"
    
    url = f"https://quotes.sina.cn/cn/api/openapi.php/CompanyFinanceService.get{report_type}"
    params = {
        "symbol": symbol,
        "dateType": "0",  # 0=按报告期
        "reportType": "0",  # 0=合并报表
        "num": 10,  # 最近 10 期
    }
    resp = requests.get(url, params=params, timeout=10)
    data = resp.json()
    
    # 解析返回结构
    result = data.get("result", {}).get("data", {})
    # 具体字段因报表类型而异
    return result
```

### 4.2 三种报表类型

| report_type | 含义 | 关键字段 |
|---|---|---|
| `BalanceSheet` | 资产负债表 | 总资产 / 总负债 / 净资产 / 货币资金 |
| `ProfitStatement` | 利润表 | 营收 / 毛利 / 净利润 / 扣非净利 |
| `CashFlow` | 现金流量表 | 经营现金流 / 投资现金流 / 筹资现金流 |

### 4.3 坑点

- **返回 JSON 嵌套较深**：需要逐层解析
- **数据更新有延迟**：财报发布后 1-2 天才更新
- **不支持 PIT**：返回的是最新修订版，不是历史时点版——**回测不能用**，仅供实时查看

---

## 5. 巨潮 cninfo 公告接口

### 5.1 接口

```python
def cninfo_announcements(code, org_id=None, page_size=30):
    """巨潮资讯网公告全文检索
    
    Args:
        code: 6 位代码
        org_id: 机构 ID（如 "gssh0600519"）
        page_size: 每页条数
    
    Returns:
        list[dict]: 公告列表
    """
    url = "http://www.cninfo.com.cn/new/hisAnnouncement/query"
    
    # stock 参数格式（V3.1 后）："{code},{orgId}"
    stock_param = f"{code},{org_id}" if org_id else code
    
    data = {
        "stock": stock_param,
        "tabName": "fulltext",
        "pageSize": page_size,
        "pageNum": 1,
        "column": "szse",  # szse=深交所 / sse=上交所 / bse=北交所
        "category": "",
        "seDate": "",
    }
    headers = {
        "User-Agent": "Mozilla/5.0",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    resp = requests.post(url, data=data, headers=headers, timeout=10)
    result = resp.json()
    
    announcements = []
    for item in result.get("announcements", []):
        announcements.append({
            "title": item.get("announcementTitle"),
            "date": item.get("announcementTime"),
            "type": item.get("announcementTypeName"),
            "pdf_url": f"http://static.cninfo.com.cn/{item.get('adjunctUrl')}",
        })
    return announcements
```

### 5.2 坑点

- **V3.1 格式变更**：`stock` 参数从 `"{code},{plate}"` 改为 `"{code},{orgId}"`（如 `600519,gssh0600519`）
- **column 参数**：沪市用 `sse`，深市用 `szse`，北交所用 `bse`
- **POST 请求**：不是 GET
- **PDF 下载**：拼接 `http://static.cninfo.com.cn/` + `adjunctUrl`

---

## 6. 数据源优先级与选型

### 按场景选数据源

| 场景 | 推荐数据源 | 原因 |
|---|---|---|
| **回测 / 因子研究** | 聚宽 jqdatasdk | PIT + 存活偏差处理 + 历史数据完整 |
| **实时行情（PE/PB/市值）** | 腾讯财经 | 一次返回 20+ 字段，无需认证 |
| **盘中资金流向** | 东方财富 push2 | 分钟级主力/散户资金流 |
| **龙虎榜 / 融资融券 / 大宗** | 东方财富 datacenter | 统一接口，字段全 |
| **财务报表（实时查看）** | 新浪财经 | 三表完整，免费 |
| **公告全文** | 巨潮 cninfo | 官方源，PDF 可下载 |
| **行业板块排名** | 东方财富 push2 | ~100 行业实时排名 |

### IP 封禁风险

| 数据源 | 风险等级 | 建议频率 |
|---|---|---|
| 东方财富 datacenter | 极低 | < 5 次/秒 |
| 东方财富 push2 | 极低 | < 5 次/秒 |
| 腾讯财经 | 极低 | < 10 次/秒 |
| 新浪财经 | 低 | < 3 次/秒 |
| 巨潮 cninfo | 低-中 | < 2 次/秒 + 间隔随机 |

---

## 7. 与聚宽的配合使用

### 典型工作流

```
聚宽 jqdatasdk（离线研究 + 回测）
    ↓ 策略上线后
免费 API（实盘信号确认 + 盘中监控）
    ↓ 具体分工
    ├── 腾讯财经 → 实时估值（PE/PB/市值）
    ├── 东方财富 push2 → 资金流向确认
    ├── 东方财富 datacenter → 龙虎榜/融资融券
    └── 巨潮 → 公告事件触发
```

### 数据一致性注意

| 维度 | 聚宽 | 免费 API |
|---|---|---|
| PIT 处理 | ✅ 默认 | ❌ 无（仅最新值） |
| 历史数据 | ✅ 2005 起 | ⚠️ 有限（通常 1-2 年） |
| 存活偏差 | ✅ 历史时点 | ❌ 仅当前存续股 |
| 数据频率 | 日/分钟 | 实时/分钟 |

**关键**：免费 API **不能替代聚宽做回测**——没有 PIT、没有历史存活偏差处理。它的价值是**实盘环境的实时数据补充**。

## 综合观察

- 东方财富 datacenter 是 A 股免费数据的"统一入口"——一个 helper 函数覆盖 8+ 种数据类型
- 腾讯财经的字段映射**很多教程都写错**（PB 在 index 46 不是 43）——本文已校正
- 这些 API 全部**无需认证**、**无需 akshare 等封装库**——直接 requests 调用
- **回测用聚宽，实盘用免费 API**——两者互补，不是替代

## 参考与延伸

- [[data-api-comparison]] — 5 大 API 横向对比（含聚宽/tushare/akshare）
- [[jqdatasdk-practice]] — jqdatasdk 实操与陷阱
- [[index-02-07-alternative-data]] — 另类数据（本文数据源属于"传统数据的免费获取渠道"）
- [[capital-flow-signal-factors]] — 资金面信号因子（本文 API 的下游应用）
