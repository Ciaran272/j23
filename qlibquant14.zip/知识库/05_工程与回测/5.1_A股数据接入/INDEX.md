---
name: index-05-01-data-access
description: 二级分类 5.1_A股数据接入 的索引 —— A 股个人量化的数据 API 全景对比（聚宽 / tushare / akshare / baostock / Wind）+ jqdatasdk 数据层 API 实操与陷阱
category: 05_工程与回测/5.1_A股数据接入
tags: [jqdatasdk, tushare, akshare, baostock, Wind, 数据API, 数据接入, A股, 索引]
created: 2026-05-17
updated: 2026-05-17
status: stable
---

# 5.1 A 股数据接入 · 索引

## 一句话定位

**回答"A 股个人量化用哪些数据 API / 各自优劣 / 如何选"**——这是策略的"地基"，地基不牢一切回测结果都是噪声。本板块定位**数据层 API**（区别于 [[index-05-03-jq-sdk-template]] 5.3 的**策略层 API**），横向对比主流数据源 + 深度展开聚宽 jqdatasdk 数据层接口。

## 板块定位（重要）

```
                 ┌──────────────────────────────────┐
                 │ 5.1 数据层 API（本板块）        │
                 │ get_price / get_fundamentals    │
                 │ get_factor_values / finance.*    │
                 └──────────────────────────────────┘
                              ↓ 数据流入
                 ┌──────────────────────────────────┐
                 │ 5.3 策略层 API                  │
                 │ initialize / handle_data /        │
                 │ order_target_percent             │
                 └──────────────────────────────────┘
                              ↓ 策略落地
                 ┌──────────────────────────────────┐
                 │ 02 因子库 / 03 策略原型         │
                 └──────────────────────────────────┘
```

**核心结论**：

- **个人量化首选 = 聚宽 jqdatasdk**（PIT 默认 / 存活偏差最少 / 接口友好）
- **次选 = akshare（开源免费）+ baostock（免费稳定）+ tushare pro（部分付费）**
- **专业研究 = 聚宽付费版 + Wind / iFinD（如能负担）**
- **不推荐 = 自爬数据**（爬虫工程量大 + 数据质量难保证 + 容易触发反爬）

## 文件清单

| # | 文件 | 一句话定位 | 状态 |
|---|---|---|---|
| 1 | [数据API全景对比.md](数据API全景对比.md) | 5 大主流 A 股数据 API 横向对比 + 选型决策树 + 5 类数据全景（量价 / 财务 / 宏观 / 龙虎榜 / 替代） | with-jq-impl |
| 2 | [jqdatasdk实操与陷阱.md](jqdatasdk实操与陷阱.md) | jqdatasdk 完整使用指南：认证 / 行情 / 财务 / 因子 / 龙虎榜 / 北向资金 + 调用统计 + 数据陷阱处理 | with-jq-impl |
| 3 | [免费实时数据API精确文档.md](免费实时数据API精确文档.md) | 东方财富 datacenter/push2 + 腾讯财经 + 新浪三表 + 巨潮公告 的 URL/参数/字段/坑点（零依赖直连） | with-jq-impl |

## 阅读路径建议

### 新手：第一次接入 A 股数据

1. 读 [数据API全景对比.md § 选型决策树](数据API全景对比.md) —— 用 30 秒决定用哪个
2. 读 [jqdatasdk实操与陷阱.md § 1. 认证与基础调用](jqdatasdk实操与陷阱.md) —— 装 jqdatasdk + 第一次调用
3. 跑 [jqdatasdk实操与陷阱.md § 5. 端到端示例](jqdatasdk实操与陷阱.md) —— 拉一只票一年数据看看

### 进阶：要做研究框架

1. 读 [数据API全景对比.md § 5 类数据全景图](数据API全景对比.md) —— 知道哪些数据可获取
2. 读 [jqdatasdk实操与陷阱.md § 3. 财务数据接口](jqdatasdk实操与陷阱.md) + [§ 4. finance 高级接口](jqdatasdk实操与陷阱.md)
3. 跑 [jqdatasdk实操与陷阱.md § 5. 端到端示例](jqdatasdk实操与陷阱.md)

### 老用户：查具体问题

- **"get_price 怎么用 / 复权"** → [jqdatasdk实操与陷阱.md § 2. 行情接口](jqdatasdk实操与陷阱.md)
- **"财务数据 PIT 怎么处理"** → [jqdatasdk实操与陷阱.md § 6. PIT 与未来函数](jqdatasdk实操与陷阱.md)
- **"获取北向资金"** → [jqdatasdk实操与陷阱.md § 4.2 北向资金](jqdatasdk实操与陷阱.md)
- **"调用次数超限怎么办"** → [jqdatasdk实操与陷阱.md § 7. 调用统计与频次管理](jqdatasdk实操与陷阱.md)
- **"聚宽对比 tushare 选哪个"** → [数据API全景对比.md § 横向对比表](数据API全景对比.md)
- **"akshare 怎么用"** → [数据API全景对比.md § akshare](数据API全景对比.md)

## 关键 A 股化要点（必读）

- **PIT 是 A 股数据的"红线"**——任何研究都必须确保用的是"当日可知"的数据，否则就是未来函数。聚宽 `get_fundamentals` 默认 PIT，tushare / akshare 需自查
- **复权选择 = 前复权（`fq='pre'`）**——回测 / 因子的工业标准（**例外**：聚宽下单要 `set_option('use_real_price', True)` 用真实价）
- **存活偏差 = 三大死穴之首**——`get_all_securities` 要带 `date=` 参数取**历史时点**的全集，不要用今天的池子做历史回测
- **配额单位是"条数"不是"次数"**——聚宽试用账号每天 **100 万条**（1 年有效期）/ 正式账号每天 **2 亿条** / tushare 积分制 / akshare 完全免费但稳定性参差；个人量化日常**建议本地缓存**
- **A 股数据时间起点**：聚宽 2005-01-04 起 / tushare 1990 起（但前期数据稀疏）/ akshare 各源差异大
- **OCR 校对注记不适用本板块**——所有内容均来自聚宽 / tushare / akshare 等**官方文档** + 实战经验，未涉及 PDF 转文档的 OCR 噪声

## 与其他二级的关系

| 二级 | 关系 |
|---|---|
| [[index-05-03-jq-sdk-template]] 5.3 聚宽 SDK 模板 | **互补关系**——本板块讲数据层（拉数据），5.3 讲策略层（用数据下单）|
| [[index-05-04-backtest-pitfalls]] 5.4 回测陷阱 | **数据陷阱的根源**——5.4 列出的 PIT / 复权 / ST / 退市等陷阱，本板块给出 jqdatasdk 的正确处理 |
| [[index-02-07-alternative-data]] 2.7 另类数据 | **数据源延伸**——2.7 是替代数据"清单"，本板块是"传统数据的 API 实操" |
| [[index-02-02-price-volume-factors]] 2.2 价量公式因子 | **下游应用**——因子计算的输入数据来自本板块的 `get_price` / `get_factor_values` |
| [[index-02-04-fundamental-factors]] 2.4 基本面因子 | **下游应用**——基本面因子的输入数据来自本板块的 `get_fundamentals` + `finance.*` |
| [[index-03-01-multi-factor-selection]] 3.1 多因子选股 | **完整链路** —— 数据接入 → 因子计算 → 多因子合成 → 选股 |

## A 股数据 API 全景速查表

| API | 类型 | 价格 | 适合场景 | 推荐指数 |
|---|---|---|---|---|
| **聚宽 jqdatasdk** | 免费试用 + 付费 | 试用账号 1 年免费（100 万条/天）/ 正式账号需联系商务（2 亿条/天） | **个人量化首选**——全功能 / PIT / 行情 / 财务 / 因子 / 龙虎榜 | ⭐⭐⭐⭐⭐ |
| **akshare** | 开源免费 | 0 | **补充**——量价 / 龙虎榜 / 北向 / 行业 / 宏观 | ⭐⭐⭐⭐ |
| **baostock** | 开源免费 | 0 | **基础量价**——稳定但接口窄 | ⭐⭐⭐ |
| **tushare pro** | 免费 + 积分 | 部分接口需 5000+ 积分（约 200 元/年）| **专业研究**——数据全面但部分接口收费 | ⭐⭐⭐⭐ |
| **Wind / iFinD** | 付费专业 | 数万元/年 | **机构专业** —— 个人不推荐 | ⭐⭐⭐⭐⭐（机构）/ ⭐（个人）|

## 5 类核心数据全景

| 类别 | 数据示例 | 主要来源 |
|---|---|---|
| **量价行情** | 开高低收 / 成交量 / 成交额 / vwap / 分钟 K 线 | 聚宽 `get_price` + akshare / baostock |
| **基本面财务** | 三大报表 / TTM / 估值 / 单季 | 聚宽 `get_fundamentals` + tushare pro `fina_*` |
| **宏观经济** | CPI / PPI / GDP / M2 / 利率 / 汇率 | 聚宽 `macro.*` + akshare `macro_*` |
| **市场情报** | 龙虎榜 / 北向资金 / 融资融券 / 股东户数 / 限售解禁 | 聚宽 `finance.*` + akshare 同名接口 |
| **替代数据** | 财经新闻 / 公告 / 雪球热度 / 卫星 / 信用卡 | 自爬 + 第三方 NLP API（详见 [[index-02-07-alternative-data]] 2.7）|

---

[← 返回 05_工程与回测 INDEX](../INDEX.md) · [← 返回主索引](../../INDEX.md)
