---
name: jqdatasdk-practice
description: jqdatasdk 数据层 API 完整实操与陷阱处理 —— 认证 / 行情 / 财务 / 因子 / finance 高级接口 / 调用统计 / PIT 处理 / 端到端示例
category: 05_工程与回测/5.1_A股数据接入
tags: [jqdatasdk, 聚宽, 数据API, get_price, get_fundamentals, finance, 北向资金, 龙虎榜, PIT, 实操]
created: 2026-05-17
updated: 2026-05-17
status: with-jq-impl
---

# jqdatasdk 数据层 API 实操与陷阱

## TL;DR

**jqdatasdk** 是聚宽官方 SDK，是**A 股个人量化的数据接入命脉**。本文按 **认证 → 行情 → 财务 → 因子 → finance 高级接口 → 调用统计 → PIT 陷阱**七大模块完整展开，配端到端可跑示例。**与 [[index-05-03-jq-sdk-template]] 5.3 的区别**：5.3 讲策略层（initialize / handle_data / order_target_percent），本文讲**数据层 API**——本地拉数据、做研究、构建特征库。

**核心原则**：

- **本地用 jqdatasdk**（拉数据 / 研究 / 因子开发），**线上用聚宽在线 IDE**（回测 / 实盘）
- **接口一致**：jqdatasdk 与聚宽在线 IDE 的 90% 接口同名，**无缝迁移**
- **配额优化**：试用账号每天 100 万**条数据**（1 年有效期，注意单位是"条"不是"次"），**必须用本地缓存**延长配额耐用度

## 来源

- 聚宽官方文档：https://www.joinquant.com/help/api/help
- 聚宽 jqdatasdk GitHub：https://github.com/JoinQuant/jqdatasdk
- 配套 [[backtest-data-pitfalls]] § A 股数据陷阱 + [[financial-data-pit]] § PIT 处理

---

## 1. 认证与基础调用

### 1.1 安装

```bash
pip install jqdatasdk
# 或更新到最新版
pip install --upgrade jqdatasdk
```

### 1.2 认证

#### 方式 1：手机号 + 密码（推荐本地长期使用）

```python
from jqdatasdk import auth, logout

# 注册聚宽账号后用手机号登录
auth('13800138000', 'your_password')

# 查询登录状态
from jqdatasdk import is_auth
print('已登录:', is_auth())  # True

# 登出
logout()
```

#### 方式 2：Token（推荐线上服务）

```python
from jqdatasdk import auth_by_token

# Token 在聚宽 https://www.joinquant.com/data 页面获取
auth_by_token('your_token_string_here')
```

### 1.3 第一次调用验证

```python
from jqdatasdk import get_trade_days

# 拉 2024 年所有交易日
days = get_trade_days(start_date='2024-01-01', end_date='2024-12-31')
print(f'2024 年共 {len(days)} 个交易日')
print(f'第一个交易日: {days[0]}')
print(f'最后一个交易日: {days[-1]}')
# 输出：
# 2024 年共 242 个交易日
# 第一个交易日: 2024-01-02
# 最后一个交易日: 2024-12-31
```

### 1.4 查询调用次数

```python
from jqdatasdk import get_query_count

count = get_query_count()
print(f'剩余条数: {count["spare"]}, 总额度: {count["total"]}')
# 试用账号输出：剩余条数: 999857, 总额度: 1000000
```

**陷阱**：`get_query_count` 本身**不消耗次数**，但**频繁调用** API 会消耗。

---

## 2. 行情接口

### 2.1 get_price —— 主力函数

```python
from jqdatasdk import get_price

# 单只股票 + 日频 + 前复权
df = get_price(
    '000001.XSHE',                          # 平安银行
    start_date='2024-01-01',
    end_date='2024-12-31',
    frequency='daily',                      # daily / minute / 1m / 5m / 15m / 30m / 60m
    fields=['open', 'close', 'high', 'low', 'volume', 'money', 'avg'],
    fq='pre',                               # pre / post / None
    panel=False,                            # False=DataFrame, True=Panel（已弃用）
)
print(df.head())
# 输出：
#              open   close    high     low      volume         money       avg
# 2024-01-02  12.93  12.84  13.01  12.81  127548700  1.643867e+09  12.89
# ...
```

### 2.2 关键参数详解

| 参数 | 取值 | 说明 |
|---|---|---|
| `security` | str / list | 单只代码或列表（一次最多 200 只） |
| `start_date` / `end_date` | str / datetime | 起止日期，含端点 |
| `count` | int | 与 `end_date` 配合，取最后 N 个交易日 |
| `frequency` | `'daily'` / `'1m'` / `'5m'` 等 | 日 / 分钟 / 多分钟 |
| `fields` | list | `'open'` / `'close'` / `'high'` / `'low'` / `'volume'` / `'money'` / `'avg'` / `'high_limit'` / `'low_limit'` / `'pre_close'` / `'paused'` / `'factor'` |
| `fq` | `'pre'` / `'post'` / `None` | **前复权 / 后复权 / 不复权** |
| `panel` | bool | 已弃用，固定 `False`（返回 DataFrame） |
| `skip_paused` | bool | 跳过停牌日，**默认 False** |

### 2.3 多只股票一次取（性能优化）

```python
# 一次取多只股票（节省调用次数）
securities = ['000001.XSHE', '600519.XSHG', '000858.XSHE']  # 平安银行 / 茅台 / 五粮液

df = get_price(
    securities,
    start_date='2024-01-01', end_date='2024-12-31',
    fields=['open', 'close', 'volume'],
    fq='pre',
    panel=False,
)

# 多只股票返回 long 格式
print(df.head())
# 输出：
#              security    open    close      volume
# 2024-01-02  000001.XSHE  12.93   12.84  127548700
# 2024-01-02  600519.XSHG  1640.0  1635.5    1834500
# 2024-01-02  000858.XSHE  175.0   175.5    8542300
```

**陷阱**：一次调用最多 **200 只股票**——超出需要分批。

### 2.4 分钟数据

```python
# 1 分钟 K 线
df_min = get_price(
    '000001.XSHE',
    start_date='2024-12-30 09:30:00',
    end_date='2024-12-30 15:00:00',
    frequency='1m',
    fields=['open', 'close', 'volume'],
    fq='pre',
)
print(df_min.head())
# 输出：每分钟一行
```

**A 股化注记**：

- **交易时段**：上午 09:30-11:30 / 下午 13:00-15:00 → 每天 240 个 1m K 线
- **分钟数据每天消耗**：1 次调用 = 1 只股票 1 天（240 根 K 线）
- **试用账号限制**：分钟数据接口消耗条数较快（240 条/股/天），需注意配额，**先查官方文档**

### 2.5 复权方式选择

| 方式 | 含义 | 用途 | 计算逻辑 |
|---|---|---|---|
| `fq='pre'` | **前复权** | **回测 / 因子计算（推荐）** | 用最新分红信息倒推过去价格 |
| `fq='post'` | **后复权** | 长期收益对比 | 用历史分红向前展开未来价格 |
| `fq=None` | **不复权** | 看真实历史价 | 不调整 |

**陷阱**：见 [[backtest-data-pitfalls]] § 2 复权方式选择——**全部字段必须用同一复权方式**。

### 2.6 get_bars —— 取最后 N 根 K 线

```python
from jqdatasdk import get_bars

# 取最后 60 个交易日的 K 线（用于因子计算）
bars = get_bars(
    '000001.XSHE',
    count=60,                                # 取最后 N 根
    unit='1d',                               # 单位
    fields=['date', 'open', 'close', 'high', 'low', 'volume'],
    include_now=False,                       # 是否包含当日（盘中调用时关键）
    end_dt='2024-12-31',
    fq_ref_date=None,                        # 复权基准日
)
print(bars.tail())
```

**与 get_price 的区别**：

- `get_price` 用**起止日期**取
- `get_bars` 用 **count + end_dt** 取（适合"取最近 N 天"场景）
- `get_bars` 返回时**保留日期列**而非作 index

### 2.7 get_ticks —— 取 Tick 数据

```python
from jqdatasdk import get_ticks

ticks = get_ticks(
    '000001.XSHE',
    start_dt='2024-12-30 09:30:00',
    end_dt='2024-12-30 10:00:00',
    fields=['time', 'current', 'volume', 'money', 'a1_p', 'a1_v', 'b1_p', 'b1_v'],
)
print(ticks.head())
# 输出：每 3 秒一根 tick + 5 档买卖盘
```

**注意**：Tick 数据**仅付费版可用**，且消耗次数极快——慎用。

---

## 3. 财务数据接口

### 3.1 get_fundamentals —— 主力函数

```python
from jqdatasdk import get_fundamentals, query, valuation, indicator

# 拉 2024-06-30 时点的所有股票市值 + ROE + PE
df = get_fundamentals(
    query(
        valuation.code,
        valuation.market_cap,                 # 总市值（亿）
        valuation.circulating_market_cap,     # 流通市值
        valuation.pe_ratio,                   # PE
        valuation.pb_ratio,                   # PB
        indicator.roe,                        # ROE %
        indicator.gross_profit_margin,        # 毛利率
    ).filter(
        valuation.code.in_(['000001.XSHE', '600519.XSHG'])
    ),
    date='2024-06-30',                        # 查询日期，PIT
)
print(df)
# 输出：
#           code  market_cap  circulating_market_cap  pe_ratio  pb_ratio   roe  gross_profit_margin
# 0  000001.XSHE     2500.45                 2480.12      5.23      0.62  3.45             45.23
# 1  600519.XSHG    20000.78                19800.56     32.45      8.34  9.87             91.34
```

### 3.2 query 范式（SQL-like）

```python
# 等价于 SQL: SELECT code, market_cap FROM valuation 
# WHERE market_cap > 100 ORDER BY market_cap DESC LIMIT 10

q = query(
    valuation.code,
    valuation.market_cap,
).filter(
    valuation.market_cap > 100,
).order_by(
    valuation.market_cap.desc(),
).limit(10)

df = get_fundamentals(q, date='2024-06-30')
print(df.head(10))
```

### 3.3 三大报表表名

| 报表 | jqdatasdk 表 | finance 表 | 说明 |
|---|---|---|---|
| **利润表** | `income` | `finance.STK_INCOME_STATEMENT_PARENT` | 母公司报表 |
| **资产负债表** | `balance` | `finance.STK_BALANCE_SHEET_PARENT` | 母公司报表 |
| **现金流量表** | `cash_flow` | `finance.STK_CASHFLOW_STATEMENT_PARENT` | 母公司报表 |
| **估值** | `valuation` | - | 估值指标 |
| **财务指标** | `indicator` | - | 财务比率 |
| **银行业务** | `bank_indicator` | - | 银行专用 |
| **证券业务** | `security_indicator` | - | 证券公司专用 |

### 3.4 拿单季度数据

```python
# query(income).filter(...) 默认取累计值
# 想要单季度数据：用 finance.STK_INCOME_STATEMENT_PARENT_PRE 或手动构造
from jqdatasdk import income

# 取所有股票 2024Q2（中报）的净利润
df_q2 = get_fundamentals(
    query(income.code, income.net_profit, income.statDate)
    .filter(income.code == '000001.XSHE'),
    statDate='2024-06-30',                    # 报告期 vs date 参数
)
print(df_q2)

# 想要 2024Q2 单季净利润 = 2024H1 - 2024Q1
df_q1 = get_fundamentals(
    query(income.code, income.net_profit)
    .filter(income.code == '000001.XSHE'),
    statDate='2024-03-31',
)
single_q2 = df_q2['net_profit'].iloc[0] - df_q1['net_profit'].iloc[0]
print(f'2024Q2 单季净利润: {single_q2 / 1e8:.2f} 亿')
```

### 3.5 PIT 处理（关键）

**聚宽 `get_fundamentals` 默认 PIT**——按 `date` 参数自动取**公告日 + 1 个交易日**之前的最新报告期数据。

```python
# 在 2024-06-30 回看，自动取的是 2024Q1（已披露）的数据
# 而不是 2024H1（要 8 月底才披露）

df = get_fundamentals(
    query(valuation.code, valuation.pe_ratio)
    .filter(valuation.code == '000001.XSHE'),
    date='2024-06-30',     # ← 查询日期
)
# 这个 PE 用的是 2024Q1 已披露的净利润，不会用未披露的 H1 净利润
```

**用 statDate 参数 ≠ PIT**！

```python
# ⚠️ 用 statDate 参数会取该报告期的数据，无论是否已披露
df_h1 = get_fundamentals(
    query(income.code, income.net_profit)
    .filter(income.code == '000001.XSHE'),
    statDate='2024-06-30',  # ← 报告期参数
)
# 注：statDate 用于"事后分析"，不应用于"回测"
```

**完整 PIT 实践**：见 [[financial-data-pit]]。

---

## 4. finance 高级接口

### 4.1 finance.run_query —— 通用查询入口

```python
from jqdatasdk import finance, query

# 拉所有龙虎榜（2024-12 月）
df = finance.run_query(
    query(finance.STK_LIST)
    .filter(finance.STK_LIST.day >= '2024-12-01')
    .filter(finance.STK_LIST.day <= '2024-12-31')
    .order_by(finance.STK_LIST.day)
    .limit(100),
)
print(df.head())
```

### 4.2 北向资金（沪深港通持股）

```python
# 拉北向资金对某股的持股变化
df_hk = finance.run_query(
    query(finance.STK_HK_HOLD_INFO)
    .filter(finance.STK_HK_HOLD_INFO.code == '600519')
    .filter(finance.STK_HK_HOLD_INFO.day >= '2024-01-01')
    .filter(finance.STK_HK_HOLD_INFO.day <= '2024-12-31')
    .order_by(finance.STK_HK_HOLD_INFO.day),
)
print(df_hk[['day', 'name', 'share_number', 'share_ratio']].tail())
# 输出：
#            day  name  share_number  share_ratio
# 240  2024-12-27  贵州茅台    104522345         8.32
# 241  2024-12-30  贵州茅台    104678901         8.33
```

**A 股化注记**：北向资金被誉为"聪明钱"——持股比例的增加可能预示个股短期上涨。

### 4.3 龙虎榜

```python
# 拉某日所有上龙虎榜的股票
df_lhb = finance.run_query(
    query(finance.STK_LIST)
    .filter(finance.STK_LIST.day == '2024-12-30'),
)
print(df_lhb[['code', 'name', 'reason', 'amount']].head())
# 输出：
#          code  name              reason    amount
# 0  600519.XSHG  贵州茅台  日跌幅偏离值达 7% 的证券  ...
# 1  ...
```

### 4.4 业绩预告

```python
# 拉业绩预告（用于 PEAD 策略）
df_forecast = finance.run_query(
    query(finance.STK_FIN_FORECAST)
    .filter(finance.STK_FIN_FORECAST.pub_date >= '2024-01-01')
    .filter(finance.STK_FIN_FORECAST.pub_date <= '2024-12-31')
    .filter(finance.STK_FIN_FORECAST.type == 1),  # 1=预增 2=预减 ...
)
print(df_forecast[['code', 'name', 'pub_date', 'type', 'profit_min', 'profit_max']].head())
```

**详细使用**：见 [[index-03-05-seasonality-events]] § PEAD 完整实现。

### 4.5 融资融券

```python
# 拉融资融券余额变化
df_margin = finance.run_query(
    query(finance.STK_MT_TOTAL)
    .filter(finance.STK_MT_TOTAL.date >= '2024-12-01')
    .filter(finance.STK_MT_TOTAL.date <= '2024-12-31')
    .order_by(finance.STK_MT_TOTAL.date),
)
print(df_margin.head())
```

### 4.6 限售解禁

```python
# 拉某月内的所有限售解禁
df_release = finance.run_query(
    query(finance.STK_LIMIT_RELEASE)
    .filter(finance.STK_LIMIT_RELEASE.list_date >= '2024-12-01')
    .filter(finance.STK_LIMIT_RELEASE.list_date <= '2024-12-31'),
)
print(df_release[['code', 'name', 'list_date', 'release_amount']].head())
```

### 4.7 可转债

```python
# 拉可转债基本信息
df_bond = finance.run_query(
    query(finance.BOND_BASIC_INFO)
    .filter(finance.BOND_BASIC_INFO.bond_type_id == 703001)  # 可转债
    .filter(finance.BOND_BASIC_INFO.list_status_id == 301001)  # 上市
    .limit(20),
)
print(df_bond[['code', 'short_name', 'list_date']].head())
```

### 4.8 finance 接口完整清单（A 股个人量化常用 12 个）

| finance 表 | 内容 |
|---|---|
| `finance.STK_LIST` | 龙虎榜 |
| `finance.STK_HK_HOLD_INFO` | 北向资金（沪深港通持股）|
| `finance.STK_MT_TOTAL` | 融资融券（全市场）|
| `finance.STK_MT_DETAIL` | 融资融券（个股）|
| `finance.STK_FIN_FORECAST` | 业绩预告 |
| `finance.STK_FIN_EXPRESS` | 业绩快报 |
| `finance.STK_LIMIT_RELEASE` | 限售解禁 |
| `finance.STK_REPURCHASE` | 股份回购 |
| `finance.STK_SHAREHOLDER_TOP10` | 十大股东 |
| `finance.STK_SHAREHOLDER_FLOATING_TOP10` | 十大流通股东 |
| `finance.STK_HOLDER_NUM` | 股东户数 |
| `finance.BOND_BASIC_INFO` | 可转债基本信息 |

**详细字段**：见 [聚宽官方文档 - finance 接口](https://www.joinquant.com/help/api/help#finance)。

---

## 5. 因子接口（get_factor_values）

### 5.1 基础调用

```python
from jqdatasdk import get_factor_values

# 拉聚宽因子库的多个因子
df = get_factor_values(
    securities=['000001.XSHE', '600519.XSHG'],
    factors=['size', 'beta', 'momentum_15', 'liquidity'],
    start_date='2024-01-01',
    end_date='2024-12-31',
)
# 返回 dict[factor_name] = DataFrame[date, security]
print(df['size'].head())
```

### 5.2 因子库分类

| 因子大类 | 示例 |
|---|---|
| **风格因子（Barra）** | `size` / `beta` / `momentum_*` / `liquidity` / `volatility` / `growth` / `value` / `quality` |
| **技术因子** | `MACD` / `RSI` / `KDJ` / `BBI` |
| **基本面因子** | `pe_ratio` / `pb_ratio` / `roe_ttm` / `gross_profit_margin` |
| **资金流因子** | `money_flow_*` |
| **alpha 因子（聚宽内置）** | `alpha101_*` / `alpha191_*` |

**完整清单**：https://www.joinquant.com/help/api/help#factor_values

### 5.3 与 Alpha-101 / GTJA-191 对比

```python
# 用聚宽内置 alpha101 因子（**付费版**）
df = get_factor_values(
    securities=['000001.XSHE'],
    factors=['alpha101_001', 'alpha101_006', 'alpha101_042'],
    start_date='2024-01-01',
    end_date='2024-12-31',
)
print(df['alpha101_001'].head())
```

**自己实现 vs 调用聚宽接口**：

- **自己实现**：参考 [[index-02-01-operator-dictionary]] 算子词典 + [[index-02-02-price-volume-factors]] 公式因子库
- **聚宽接口**：付费版直接调，更快，但**因子表达式不透明**
- **个人量化推荐**：自己实现（便于改造 / 与原文比对）

---

## 6. PIT 与未来函数（陷阱速查）

### 6.1 PIT 是 A 股回测的命脉

详见 [[backtest-data-pitfalls]] § 1 PIT 财务数据 + [[financial-data-pit]] § A 股 PIT 完整实践。

### 6.2 jqdatasdk 哪些接口默认 PIT

| 接口 | PIT 默认？ | 备注 |
|---|---|---|
| `get_price` | ✅ | 行情数据天然 PIT |
| `get_fundamentals(date=...)` | ✅ | 按公告日 + 1 个交易日 |
| `get_fundamentals(statDate=...)` | ❌ | 按报告期，**仅做事后分析** |
| `finance.run_query(... STK_INCOME_STATEMENT ...)` | ⚠️ | 需自己用 `pub_date` 过滤 |
| `get_factor_values` | ✅ | 因子库默认 PIT |
| `finance.STK_FIN_FORECAST` | ⚠️ | 业绩预告，**披露日 = pub_date** |
| `finance.STK_HK_HOLD_INFO` | ✅ | 北向资金按日发布 |

### 6.3 finance.* 的 PIT 自检模板

```python
# 拉财务数据时，用 pub_date 过滤
df = finance.run_query(
    query(finance.STK_INCOME_STATEMENT_PARENT)
    .filter(finance.STK_INCOME_STATEMENT_PARENT.code == '000001.XSHE')
    .filter(finance.STK_INCOME_STATEMENT_PARENT.pub_date <= '2024-06-30')  # ← 关键
    .order_by(finance.STK_INCOME_STATEMENT_PARENT.pub_date.desc())
    .limit(1),
)
# 这样取的就是 2024-06-30 之前最新发布的财报
```

---

## 7. 调用统计与频次管理

### 7.1 配额消耗计算规则

聚宽配额单位是"**数据条数**"——一次 API 调用消耗的条数 = 返回数据行数（具体规则以聚宽官方文档为准）。

| 操作 | 估算消耗 |
|---|---|
| 单只股票 1 年日 K 线 | ~252 条 |
| 200 只股票 1 年日 K 线 | ~50,400 条（批量调用合并请求）|
| 1 只股票 1 年分钟 K 线 | ~60,480 条（240 根/天 × 252 天）|
| `get_fundamentals` 单次查询 | 按返回行数计 |
| `finance.run_query` 单次查询 | 按返回行数计 |

**关键优化**：**批量调用 + 本地缓存**——合理批量调用可大幅延长 100 万条/天的耐用度，等效于把"原始配额"用出几倍的价值。

### 7.2 查询配额

```python
from jqdatasdk import get_query_count

# 查剩余条数
print(get_query_count())
# 输出（试用账号）：{'spare': 987432, 'total': 1000000}
```

### 7.3 个人量化的"100 万条/天"配额策略

```python
# 1. 一次性拉所有股票池数据（1 次调用）
from jqdatasdk import get_all_securities, get_price

stocks = get_all_securities(types=['stock'], date='2024-12-31').index.tolist()  # 0 次（已缓存）

# 2. 分批拉行情，每批 200 只
batch_size = 200
all_dfs = []
for i in range(0, len(stocks), batch_size):
    batch = stocks[i:i+batch_size]
    df = get_price(
        batch,
        start_date='2024-01-01', end_date='2024-12-31',
        fields=['close', 'volume'],
        panel=False,
    )
    all_dfs.append(df)
    # 每批 1 次调用，5000 只股票约 25 次
result = pd.concat(all_dfs)

# 3. 落盘缓存（下次免调用）
result.to_parquet('cache/all_stocks_2024.parquet')
```

### 7.4 缓存策略推荐

详见 [[data-api-comparison]] § 4 数据存储与缓存策略 —— **本地 parquet 增量更新** 可以让个人量化的研究效率提升 10 倍。

---

## 8. 端到端示例：拉数据 → 算因子 → 排序选股

把本文学到的接口组装成**一个完整的研究工作流**。

```python
"""
端到端示例：用 jqdatasdk 拉沪深 300 数据 → 算简单因子 → 截面排序选股
"""
from jqdatasdk import (
    auth, get_index_stocks, get_price, get_fundamentals,
    query, valuation, indicator, get_query_count,
)
import pandas as pd
import numpy as np

# ============================================================
# 1. 认证
# ============================================================
auth('your_phone', 'your_password')
print(f'剩余次数: {get_query_count()["spare"]}')

# ============================================================
# 2. 获取沪深 300 成分股（PIT，2024-06-30 时点）
# ============================================================
hs300 = get_index_stocks('000300.XSHG', date='2024-06-30')
print(f'沪深 300 成分: {len(hs300)} 只')

# ============================================================
# 3. 一次拉所有成分股的近 6 个月行情（PIT）
# ============================================================
df_price = get_price(
    hs300,
    start_date='2024-01-01', end_date='2024-06-30',
    fields=['close', 'volume', 'money'],
    fq='pre',
    panel=False,
)
df_price = df_price.set_index(['time', 'code'])
print(f'行情数据 shape: {df_price.shape}')
# 1 次调用，覆盖 300 只股票 × 122 个交易日

# ============================================================
# 4. 拉所有成分股的 PE / PB / ROE（PIT，2024-06-30）
# ============================================================
df_fund = get_fundamentals(
    query(
        valuation.code,
        valuation.pe_ratio,
        valuation.pb_ratio,
        indicator.roe,
    ).filter(
        valuation.code.in_(hs300)
    ),
    date='2024-06-30',
)
df_fund = df_fund.set_index('code')
print(f'基本面数据 shape: {df_fund.shape}')
# 1 次调用，覆盖 300 只股票

# ============================================================
# 5. 计算简单因子
# ============================================================
# 因子 1: 近 20 日动量
close_pivot = df_price['close'].unstack()  # date × security
momentum_20d = close_pivot.pct_change(20).iloc[-1]  # 2024-06-30 的值

# 因子 2: 近 20 日波动率（倒数 —— 低波因子）
vol_20d = close_pivot.pct_change().rolling(20).std().iloc[-1]
neg_vol = -vol_20d

# 因子 3: 估值（PB 倒数）
neg_pb = -df_fund['pb_ratio']

# ============================================================
# 6. 因子合成（等权 + 截面 rank）
# ============================================================
factors = pd.DataFrame({
    'momentum': momentum_20d.rank(pct=True),
    'low_vol': neg_vol.rank(pct=True),
    'value': neg_pb.rank(pct=True),
})

factors['combined'] = factors.mean(axis=1)

# ============================================================
# 7. 选前 30 只
# ============================================================
top30 = factors['combined'].nlargest(30)
print('\n选股结果（按合成因子 rank 降序）：')
print(top30.head(10))

# ============================================================
# 8. 落盘缓存
# ============================================================
factors.to_parquet('cache/factors_20240630.parquet')
df_price.to_parquet('cache/hs300_price_2024H1.parquet')
df_fund.to_parquet('cache/hs300_fund_20240630.parquet')

print(f'\n剩余次数: {get_query_count()["spare"]}')
# 总共 3 次调用（成分股 + 行情 + 基本面）
# 完成端到端的"拉数据 → 因子 → 选股"
```

**关键设计**：

- **批量调用**：300 只股票 1 次调用，而非 300 次（减少请求次数 + 减少每条 fixed overhead）
- **PIT 严守**：所有 `date=` 参数对齐 2024-06-30
- **本地缓存**：拉完立刻落盘，**避免重复调用**
- **总调用次数 = 3**，消耗条数约 ~10 万条（300 只 × 122 日行情 + 300 只基本面），相对 100 万条/天的试用配额**绰绰有余**

---

## 9. 综合观察

- **jqdatasdk 9 大模块**：认证 / 行情 / 财务 / 因子 / finance / 调用统计 / PIT / 缓存 / 端到端
- **PIT 是命脉**：聚宽默认处理，但 `statDate` vs `date` 参数要分清
- **批量调用 + 本地缓存 + parquet**：合理批量调用可大幅延长 100 万条/天试用配额的耐用度
- **finance.run_query 是 A 股个人量化的"宝藏"**：龙虎榜 / 北向 / 业绩预告等都在这里
- **复权方式**：回测 / 因子用 `fq='pre'`，下单用 `set_option('use_real_price', True)`
- **接口一致性**：jqdatasdk 与聚宽在线 IDE 的 90% 接口同名，研究 → 实盘**无缝迁移**
- **个人量化的标准工作流**：本地 jqdatasdk 研究 + 聚宽在线 IDE 回测 + 实盘部署

## 参考与延伸

- [[index-05-01-data-access]] 5.1 索引 — 本板块入口
- [[data-api-comparison]] — 数据 API 全景对比与选型
- [[index-05-03-jq-sdk-template]] 5.3 聚宽 SDK 模板 — 策略层 API（initialize / handle_data / order）
- [[jq-skeleton-main-flow]] — 聚宽策略骨架（五段式主流程）
- [[index-05-04-backtest-pitfalls]] 5.4 回测陷阱 — 完整陷阱清单
- [[backtest-data-pitfalls]] — A 股数据陷阱（PIT / 复权 / ST / 退市 / 行业切换）
- [[financial-data-pit]] — 财务数据 PIT 完整处理
- [[index-03-05-seasonality-events]] — PEAD 策略中 finance.STK_FIN_FORECAST 的完整应用
- [[index-02-07-alternative-data]] 2.7 — 替代数据 30 类清单（部分可通过 finance.* 获取）
- [聚宽官方 API 文档](https://www.joinquant.com/help/api/help)
- [jqdatasdk GitHub](https://github.com/JoinQuant/jqdatasdk)
