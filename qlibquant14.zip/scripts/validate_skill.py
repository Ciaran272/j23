#!/usr/bin/env python3
# encoding: utf-8
"""validate_skill.py — jinrongskill 仓库健康度检查 (MVP)

检查项:
  1. markdown 本地链接是否能解析到真实文件
  2. 知识库 [[name]] 内链是否能在 frontmatter name 字段中找到
  3. 知识库 frontmatter 完整性 + name 全局唯一
  4. .claude/commands/joinquant/ 旧副本漂移监控
  5. SKILL.md Reference Map ↔ references/ 实际文件双向对账

用法:
  python scripts/validate_skill.py            默认彩色报告
  python scripts/validate_skill.py --strict   WARN 升级为 ERROR
  python scripts/validate_skill.py --json     机器可读输出
退出码: 0 = 通过, 1 = 有 ERROR
"""
import argparse
import ctypes
import json
import re
import sys
import urllib.parse
from pathlib import Path

# === 路径配置 ===
ROOT = Path(__file__).resolve().parent.parent
KB_DIR = ROOT / "知识库"
REFERENCES_DIR = ROOT / "skills" / "joinquant" / "references"
SKILL_FILE = ROOT / "skills" / "joinquant" / "SKILL.md"
CLAUDE_FILE = ROOT / "CLAUDE.md"
COMMANDS_JOINQUANT = ROOT / ".claude" / "commands" / "joinquant"

FRONTMATTER_REQUIRED = [
    "name", "description", "category", "tags",
    "created", "updated", "status",
]

# === ANSI 颜色 ===
class C:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    RED = "\033[91m"
    YELLOW = "\033[93m"
    GREEN = "\033[92m"
    CYAN = "\033[96m"
    GRAY = "\033[90m"

def color(text, c):
    return f"{c}{text}{C.RESET}"


# === Issue 数据结构 ===
class Issue:
    __slots__ = ("level", "check", "file", "line", "message")

    def __init__(self, level, check, file, line, message):
        self.level = level
        self.check = check
        self.file = file
        self.line = line
        self.message = message

    def to_dict(self):
        return {
            "level": self.level,
            "check": self.check,
            "file": str(self.file.relative_to(ROOT)).replace("\\", "/") if self.file else None,
            "line": self.line,
            "message": self.message,
        }

    def format_console(self):
        colors = {"ERROR": C.RED, "WARN": C.YELLOW, "INFO": C.CYAN}
        c = colors.get(self.level, C.GRAY)
        loc = ""
        if self.file:
            try:
                rel = str(self.file.relative_to(ROOT)).replace("\\", "/")
            except ValueError:
                rel = str(self.file)
            loc = color(rel, C.GRAY)
            if self.line:
                loc += color(":" + str(self.line), C.GRAY)
            loc += "  "
        return f"  {color(self.level.ljust(5), c)} {loc}{self.message}"


# === 正则 ===
FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.DOTALL)
WIKILINK_RE = re.compile(r"\[\[([^\]\|\n]+?)(?:\|[^\]\n]*)?\]\]")
MDLINK_RE = re.compile(r"(?<!!)\[([^\]\n]*?)\]\(([^)\n]+)\)")
INLINE_CODE_RE = re.compile(r"`[^`\n]+`")


# === 解析工具 ===
def parse_frontmatter(text):
    """返回 (frontmatter dict 或 None)"""
    m = FRONTMATTER_RE.match(text)
    if not m:
        return None
    fm = {}
    for line in m.group(1).split("\n"):
        if ":" not in line:
            continue
        # 跳过缩进的子字段 (例如 nested yaml), 顶层 key-value 已够 MVP
        if line.startswith((" ", "\t")):
            continue
        key, _, value = line.partition(":")
        fm[key.strip()] = value.strip().strip('"').strip("'")
    return fm


def strip_code(text):
    """剥 frontmatter + 代码块 + 行内代码, 用空行/空字符串替换以保留行号对齐"""
    # 先剥 frontmatter (frontmatter 里的 [[name]] 是字面元数据, 不是链接)
    m = FRONTMATTER_RE.match(text)
    if m:
        fm_lines = text[:m.end()].count("\n")
        text = "\n" * fm_lines + text[m.end():]

    out = []
    in_block = False
    for line in text.split("\n"):
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            in_block = not in_block
            out.append("")
            continue
        if in_block:
            out.append("")
        else:
            out.append(INLINE_CODE_RE.sub("", line))
    return "\n".join(out)


def find_line(text, offset):
    return text[:offset].count("\n") + 1


# === 范围 ===
def iter_kb_md():
    if not KB_DIR.exists():
        return
    for p in sorted(KB_DIR.rglob("*.md")):
        yield p


def iter_all_md():
    seen = set()
    for p in iter_kb_md():
        if p not in seen:
            seen.add(p)
            yield p
    if REFERENCES_DIR.exists():
        for p in sorted(REFERENCES_DIR.glob("*.md")):
            if p not in seen:
                seen.add(p)
                yield p
    for extra in (SKILL_FILE, CLAUDE_FILE):
        if extra.exists() and extra not in seen:
            seen.add(extra)
            yield extra


# === Check 1: markdown 本地链接 ===
def check_links():
    issues = []
    for path in iter_all_md():
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as e:
            issues.append(Issue("ERROR", "links", path, 0, f"读文件失败: {e}"))
            continue
        clean = strip_code(text)
        for m in MDLINK_RE.finditer(clean):
            url = m.group(2).strip()
            if url.startswith(("http://", "https://", "mailto:", "#", "tel:")):
                continue
            url_path = url.split("#", 1)[0].strip()
            if not url_path:
                continue
            # URL 解码 (%20 → 空格 等)
            url_path = urllib.parse.unquote(url_path)
            target = (path.parent / url_path).resolve()
            if not target.exists():
                line = find_line(clean, m.start())
                issues.append(Issue(
                    "ERROR", "links", path, line,
                    f"链接目标不存在: [{m.group(1)}]({url})"
                ))
    return issues


# === Check 2: [[name]] 内链 ===
def collect_kb_names():
    names = {}
    for path in iter_kb_md():
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            continue
        fm = parse_frontmatter(text)
        if fm and "name" in fm:
            names.setdefault(fm["name"], path)
    return names


def check_wikilinks(kb_names):
    issues = []
    for path in iter_kb_md():
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            continue
        clean = strip_code(text)
        for m in WIKILINK_RE.finditer(clean):
            raw = m.group(1).strip()
            # 处理 [[name#anchor]] 形式: 用 # 前的部分查找
            name = raw.split("#", 1)[0].strip()
            line = find_line(clean, m.start())
            # 误用文件名 [[xxx.md]] 而非 name slug
            if name.endswith(".md"):
                issues.append(Issue(
                    "WARN", "wikilinks", path, line,
                    f"误用文件名: [[{raw}]] 应使用 frontmatter 的 name slug"
                ))
                continue
            if name not in kb_names:
                issues.append(Issue(
                    "WARN", "wikilinks", path, line,
                    f"未解析的 [[{raw}]]"
                ))
    return issues


# === Check 3: frontmatter ===
def check_frontmatter():
    issues = []
    name_to_files = {}
    for path in iter_kb_md():
        try:
            text = path.read_text(encoding="utf-8")
        except Exception as e:
            issues.append(Issue("ERROR", "frontmatter", path, 0, f"读文件失败: {e}"))
            continue
        fm = parse_frontmatter(text)
        if fm is None:
            issues.append(Issue("WARN", "frontmatter", path, 1, "缺 frontmatter"))
            continue
        missing = [k for k in FRONTMATTER_REQUIRED if k not in fm]
        if missing:
            issues.append(Issue(
                "WARN", "frontmatter", path, 1,
                f"frontmatter 缺字段: {', '.join(missing)}"
            ))
        if "name" in fm and fm["name"]:
            name_to_files.setdefault(fm["name"], []).append(path)
    for name, paths in name_to_files.items():
        if len(paths) > 1:
            for p in paths:
                others = [
                    str(x.relative_to(ROOT)).replace("\\", "/")
                    for x in paths if x != p
                ]
                issues.append(Issue(
                    "ERROR", "frontmatter", p, 1,
                    f"name='{name}' 重复, 其他位置: {', '.join(others)}"
                ))
    return issues


# === Check 4: 旧副本漂移 ===
def check_drift():
    issues = []
    if not COMMANDS_JOINQUANT.exists():
        return issues
    for p in sorted(COMMANDS_JOINQUANT.glob("*.md")):
        if p.name == "SKILL.md":
            continue
        issues.append(Issue(
            "ERROR", "drift", p, 0,
            f"旧副本漂移: 此目录只允许 SKILL.md (pointer)"
        ))
    return issues


# === Check 5: Reference Map 对账 ===
REFMAP_REF_RE = re.compile(r"`references/([^`\s]+\.md)`")


def check_refmap():
    issues = []
    if not SKILL_FILE.exists() or not REFERENCES_DIR.exists():
        return issues
    try:
        text = SKILL_FILE.read_text(encoding="utf-8")
    except Exception as e:
        issues.append(Issue("ERROR", "refmap", SKILL_FILE, 0, f"读取 SKILL.md 失败: {e}"))
        return issues

    refs_in_skill = set(REFMAP_REF_RE.findall(text))
    actual_files = {p.name for p in REFERENCES_DIR.glob("*.md")}

    for name in sorted(refs_in_skill - actual_files):
        issues.append(Issue(
            "ERROR", "refmap", SKILL_FILE, 0,
            f"SKILL.md 引用了不存在的 references/{name}"
        ))
    for name in sorted(actual_files - refs_in_skill):
        issues.append(Issue(
            "WARN", "refmap", REFERENCES_DIR / name, 0,
            f"references/{name} 存在但未在 SKILL.md Reference Map 中列出"
        ))
    return issues


# === 报告 ===
CHECK_TITLES = {
    "links": "1. Markdown 本地链接",
    "wikilinks": "2. 知识库 [[name]] 内链",
    "frontmatter": "3. Frontmatter 完整性 + name 唯一",
    "drift": "4. 旧副本漂移监控",
    "refmap": "5. Reference Map 对账",
}


def apply_strict(issues):
    for i in issues:
        if i.level == "WARN":
            i.level = "ERROR"


def report_console(issues):
    by_check = {}
    for i in issues:
        by_check.setdefault(i.check, []).append(i)

    n_error = sum(1 for i in issues if i.level == "ERROR")
    n_warn = sum(1 for i in issues if i.level == "WARN")

    print()
    print(color("=" * 60, C.GRAY))
    print(color(" jinrongskill 健康度检查报告 (MVP)", C.BOLD))
    print(color("=" * 60, C.GRAY))

    for check in ["links", "wikilinks", "frontmatter", "drift", "refmap"]:
        items = by_check.get(check, [])
        print()
        if not items:
            print(f"{color('[PASS]', C.GREEN)} {CHECK_TITLES[check]}")
            continue
        n_err_c = sum(1 for i in items if i.level == "ERROR")
        n_warn_c = sum(1 for i in items if i.level == "WARN")
        status = color("[FAIL]", C.RED) if n_err_c else color("[WARN]", C.YELLOW)
        print(f"{status} {CHECK_TITLES[check]}  ({n_err_c} error, {n_warn_c} warn)")
        for i in items:
            print(i.format_console())

    print()
    print(color("-" * 60, C.GRAY))
    summary_color = C.RED if n_error else (C.YELLOW if n_warn else C.GREEN)
    print(color(f"总计: {n_error} ERROR, {n_warn} WARN", summary_color))
    print()
    return n_error


def report_json(issues):
    print(json.dumps(
        [i.to_dict() for i in issues],
        ensure_ascii=False, indent=2,
    ))
    return sum(1 for i in issues if i.level == "ERROR")


# === 主流程 ===
def enable_windows_ansi():
    if sys.platform != "win32":
        return
    try:
        kernel32 = ctypes.windll.kernel32
        STD_OUTPUT_HANDLE = -11
        ENABLE_VT = 0x0004
        handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | ENABLE_VT)
    except Exception:
        pass


def ensure_utf8_stdout():
    """Windows 终端默认 GBK, 强制 stdout/stderr 用 UTF-8"""
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, Exception):
            pass


def main():
    parser = argparse.ArgumentParser(
        description="jinrongskill 仓库健康度检查 (MVP)"
    )
    parser.add_argument("--strict", action="store_true",
                        help="WARN 升级为 ERROR")
    parser.add_argument("--json", action="store_true",
                        help="JSON 输出 (机器可读)")
    args = parser.parse_args()

    ensure_utf8_stdout()
    enable_windows_ansi()

    issues = []
    issues += check_links()
    kb_names = collect_kb_names()
    issues += check_wikilinks(kb_names)
    issues += check_frontmatter()
    issues += check_drift()
    issues += check_refmap()

    if args.strict:
        apply_strict(issues)

    if args.json:
        n_error = report_json(issues)
    else:
        n_error = report_console(issues)

    sys.exit(1 if n_error else 0)


if __name__ == "__main__":
    main()
