---
name: joinquant
description: Use when working with Qlib, qlib, pyqlib, Microsoft Qlib, A-share quant strategies, Alpha158, Alpha360, Expression Engine, qrun, DataHandler, model training, backtesting, factor research, Alpha101/Alpha191 factors, technical indicators, or Qlib error/debugging questions.
---

# Qlib Skill

Use this skill to write, review, debug, and explain Qlib strategy code, factor research, model training, and data workflows. Treat the bundled references as the source of platform-specific API details, and load only the files needed for the user's task.

## Core Workflow

1. Classify the task: workflow setup, data handling, factor/expression, model training, strategy/backtest, troubleshooting, or knowledge-base research.
2. Read the smallest relevant reference file from `references/` before giving exact API signatures, parameters, or examples.
3. Prefer `rg` searches inside `references/` for large files instead of loading whole documents.
4. When writing Qlib code, always include `qlib.init()` and realistic A-share trading constraints.
5. If the answer depends on current Qlib behavior beyond these bundled docs, say the local references are dated 2026-05 and suggest checking official docs or source code.

## Reference Map

| User need | Read/search |
| --- | --- |
| Installation, data download (community/Yahoo/custom), qlib.init(), environment setup | `references/setup.md` |
| Architecture overview, qrun CLI, workflow_by_code, YAML config, experiment management, rolling train | `references/workflow_core.md` |
| DataHandler, DatasetH, TSDatasetH, Alpha158/360, Processors, data_loader config, segments, labels | `references/data_handler.md` |
| D.instruments(), D.features(), D.calendar(), stock code format, instruments files, custom data, caching | `references/data_source.md` |
| Built-in models (LightGBM/XGBoost/LSTM/Transformer/GRU), custom model interface, hyperparams, GPU | `references/model_zoo.md` |
| TopkDropoutStrategy, WeightStrategy, SimulatorExecutor, backtest_daily, exchange_kwargs, analysis | `references/strategy_backtest.md` |
| Expression Engine syntax, all operators, Alpha101 Qlib expressions, GTJA-191 Qlib expressions, custom factors, IC analysis | `references/factors.md` |
| Technical indicators via Qlib expressions: MA, EMA, MACD, KDJ, RSI, BOLL, ATR, volume indicators | `references/technical_analysis.md` |
| A-share constraints, future data prevention, data leakage, capacity, turnover, model selection | `references/best_practices.md` |
| Common errors, installation issues, data problems, model training issues, backtest issues, performance | `references/faq.md` |
| Complete runnable examples: YAML workflow, Python script, Alpha101 strategy, multi-model comparison | `references/strategy_examples.md` |

## Extended Knowledge Base (按需调用，默认不加载)

Location: `../../知识库/` (relative to this SKILL.md). This is a **deep, on-demand** knowledge layer separate from `references/`. The `references/` layer above is for day-to-day API/operational questions; the knowledge base is for in-depth research, strategy thinking, factor derivations, market structure analysis, case studies, etc.

**Knowledge base structure** (7 top-level categories, 27+ subdirectories):

| 一级 | 内容 |
|---|---|
| **00_速通教程** | 整库门户 + 端到端可跑策略 + 综合化专题（A 股 alpha 本质 / 因子失效 / 凯利仓位）|
| 01_方法论与世界观 | 1.1-1.5：统一视角 / 检验方法 / 独立交易员 / 行为金融 / ML 协同 |
| 02_因子库 | 2.1-2.7：算子 / Alpha-101 / GTJA-191 / Barra / 基本面 / 技术 / 实证 / 替代数据 |
| 03_策略原型 | 3.1-3.5：多因子 / 择时 / 配对 / ML / 季节性事件 |
| 04_组合与风控 | 4.1-4.4：组合优化 / 凯利 / 风险归因 / 成本与容量 |
| 05_工程与回测 | 5.1-5.5：数据接入 / 框架对比 / Qlib SDK / 回测陷阱 / MLOps |
| 99_skill入口 | 触发关键词 + 路由 + 引用规范 |

### When to access

The knowledge base is **only** entered on explicit user consent. Do not auto-fallback into it.

**Enter** when the user explicitly says one of: "查知识库", "用知识库", "用扩展资料", "深入研究 X", "知识库里有没有 X", or names a knowledge-base file directly.

**Do NOT enter** in any other situation, including:
- A question can be answered from `references/` — answer from there.
- `references/` lacks an answer — tell the user the answer is not in `references/` and **ask** whether to escalate to the knowledge base. Do not enter on your own.
- The user asks for an end-to-end strategy, a "why" question about market structure, or a deep theory topic — these still require explicit consent before entering. You may suggest relevant knowledge-base files (e.g. `00_速通教程/A股多因子端到端_完整教程.md` for end-to-end requests) and ask the user to confirm.
- The user asks a routine coding / API question.

### How to access

Mandatory three-step retrieval. Never load the directory wholesale.

1. **Grep the master index first**: `知识库/INDEX.md` lists categories. Identify the relevant category.
2. **Glob or grep the category index**: each category folder has its own `INDEX.md` mapping topic → file. Narrow to candidate files.
3. **Read only the matched files**, ideally with line ranges. If a file is large, grep it for the specific term before reading.

### Knowledge base code adaptation

The knowledge base was originally written with JoinQuant (聚宽) code examples. When presenting knowledge-base content to the user:
- **Automatically translate** any JoinQuant Python code into equivalent Qlib code (Expression Engine syntax, DataHandler config, or workflow script)
- If a direct translation is not possible (e.g., JoinQuant-specific data API with no Qlib equivalent), explain the gap and suggest alternatives
- Factor formulas (Alpha101/191) should be presented in Qlib Expression Engine syntax as documented in `references/factors.md`

### Hard rules

- Never `Read` a knowledge-base file without first locating it via INDEX or grep.
- Never read more than ~3 knowledge-base files in one answer unless the user explicitly asks for a survey.
- If a knowledge-base file contradicts `references/`, treat the knowledge base as the deeper authority for theory and `references/` as the authority for current API behavior; surface the conflict to the user.
- Knowledge-base content is not a substitute for verifying current platform behavior.

## Search Hints

Use targeted searches before loading large references:

```bash
rg -n "qlib.init|provider_uri|region" references/setup.md
rg -n "Alpha158|Alpha360|DataHandlerLP|QlibDataLoader" references/data_handler.md
rg -n "D.features|D.instruments|D.calendar" references/data_source.md
rg -n "LGBModel|LSTM|Transformer|XGBModel|CatBoost" references/model_zoo.md
rg -n "TopkDropout|backtest_daily|exchange_kwargs|limit_threshold" references/strategy_backtest.md
rg -n "Ref|Mean|Std|Rank|Corr|EMA|TsRank|Alpha101|GTJA" references/factors.md
rg -n "MACD|KDJ|RSI|BOLL|ATR|MA|EMA" references/technical_analysis.md
rg -n "未来数据|future|leakage|涨跌停|T\+1|换手" references/best_practices.md
rg -n "FileNotFoundError|NaN|CUDA|MemoryError" references/faq.md
```

## Qlib Coding Rules

- Every script must start with `import qlib; qlib.init(provider_uri=..., region="cn")`.
- Use Expression Engine syntax for factor definitions: `$field`, `Ref()`, `Mean()`, `Rank()`, etc.
- Labels use negative Ref: `Ref($close, -2) / Ref($close, -1) - 1` (this is NOT future data leakage — Qlib handles alignment).
- Features must NEVER use negative Ref — only positive Ref (historical) or zero-lag operators.
- Always include `infer_processors` (at minimum `RobustZScoreNorm` + `Fillna`) and `learn_processors` (at minimum `DropnaLabel`).
- Use `CSRankNorm` on labels for ranking-based learning (recommended for most tasks).
- Prefer YAML configs for reproducibility; use Python scripts for custom logic.
- Store experiment results via `R.start()` / `R.save_objects()` for tracking.

## Trading Constraints

Always consider these when configuring backtest:

- A-share T+1: cannot sell same-day purchases (Qlib daily executor handles this automatically).
- Lot size: 100 shares minimum (`trade_unit: 100` in exchange_kwargs).
- Limit up/down: set `limit_threshold: 0.095` (10% with margin) and `forbid_all_trade_at_limit: True`.
- Transaction costs: `open_cost: 0.0005` (commission), `close_cost: 0.0015` (commission + stamp tax).
- Minimum commission: `min_cost: 5` (5 yuan).
- Deal price: prefer `"vwap"` or `"close"` for realistic simulation.

## Data Safety

Common future-data failures in Qlib context:

- Using `Ref($close, -n)` in feature expressions (only allowed in labels).
- Setting `fit_end_time` beyond the training period end date.
- Using current index constituents to backtest historical periods.
- Not accounting for financial statement publication lag in custom fundamental data.
- Computing cross-sectional statistics using the full time range instead of point-in-time.

## Code Style

- Return complete runnable Qlib code when the user asks for a strategy.
- Include `qlib.init()`, full handler/dataset/model config, and backtest with realistic costs.
- Keep parameters configurable: topk, n_drop, model hyperparams, time segments.
- Use clear variable names matching Qlib conventions (handler, dataset, model, pred).
- Do not present strategy output as investment advice.

## Troubleshooting

For errors:

1. Identify whether the code runs as qrun YAML, Python script, or Jupyter notebook.
2. Search `references/faq.md` for the exact error text.
3. Check: data path, stock code format (SH/SZ prefix), time range, expression syntax, model dependencies.
4. Common issues: missing data directory, wrong code format, pandas version conflict, GPU memory.
