# 技术指标 Qlib 表达式实现

## 概述

Qlib 没有内置技术分析函数库，但其 Expression Engine 可以直接表达所有常见技术指标。本文档提供可直接使用的表达式。

## 均线类

### MA（简单移动平均）

```python
"Mean($close, 5)"    # MA5
"Mean($close, 10)"   # MA10
"Mean($close, 20)"   # MA20
"Mean($close, 60)"   # MA60
"Mean($close, 120)"  # MA120
"Mean($close, 250)"  # MA250（年线）
```

### EMA（指数移动平均）

```python
"EMA($close, 5)"     # EMA5
"EMA($close, 12)"    # EMA12
"EMA($close, 26)"    # EMA26
"EMA($close, 60)"    # EMA60
```

### WMA（加权移动平均）

```python
"WMA($close, 5)"     # WMA5
"WMA($close, 10)"    # WMA10
```

### 均线交叉信号

```python
# 金叉/死叉（MA5 vs MA20）
"Mean($close, 5) - Mean($close, 20)"                    # > 0 为金叉状态
"Mean($close, 5) / Mean($close, 20) - 1"                # 偏离度

# 价格相对均线位置
"$close / Mean($close, 20) - 1"                          # 价格偏离 MA20 的程度
"($close - Mean($close, 20)) / Std($close, 20)"         # 布林通道位置
```

## MACD

```python
# DIF = EMA12 - EMA26
"EMA($close, 12) - EMA($close, 26)"

# DEA = EMA(DIF, 9)  — 需要嵌套，Qlib 不支持直接嵌套 EMA
# 近似方式：使用 DIF 的 9 日均值
"Mean(EMA($close, 12) - EMA($close, 26), 9)"

# MACD 柱 = 2 * (DIF - DEA)
"2 * (EMA($close, 12) - EMA($close, 26) - Mean(EMA($close, 12) - EMA($close, 26), 9))"
```

注意：严格的 MACD DEA 是 DIF 的 EMA，但 Qlib 表达式不支持对表达式结果再做 EMA。上面用 Mean 近似。如需精确 MACD，建议用 Python 函数计算后作为自定义字段导入。

## KDJ

```python
# RSV = (Close - LLV(Low, N)) / (HHV(High, N) - LLV(Low, N)) * 100
# N = 9
"($close - Min($low, 9)) / (Max($high, 9) - Min($low, 9)) * 100"

# K 值近似（用 EMA 代替传统的 2/3 平滑）
"EMA(($close - Min($low, 9)) / (Max($high, 9) - Min($low, 9)), 3)"

# 简化版 KDJ 信号（RSV 本身就有很好的信号性）
"($close - Min($low, 9)) / (Max($high, 9) - Min($low, 9))"  # 0~1 范围
```

## RSI

```python
# RSI 的 Qlib 近似
# 传统 RSI = 100 - 100/(1 + RS)，RS = 平均涨幅/平均跌幅

# 上涨幅度
# If(Close > Ref(Close,1), Close - Ref(Close,1), 0) 的 N 日均值
"Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 14)"

# 下跌幅度
"Mean(If($close < Ref($close, 1), Ref($close, 1) - $close, 0), 14)"

# RSI 近似（用 SMA 代替 Wilder 平滑）
# RSI = AvgGain / (AvgGain + AvgLoss)
"Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 14) / (Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 14) + Mean(If($close < Ref($close, 1), Ref($close, 1) - $close, 0), 14))"

# 简化版（6日/12日/24日）
"Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 6) / (Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 6) + Mean(If($close < Ref($close, 1), Ref($close, 1) - $close, 0), 6))"
```

## 布林带（BOLL）

```python
# 中轨 = MA20
"Mean($close, 20)"

# 上轨 = MA20 + 2 * STD20
"Mean($close, 20) + 2 * Std($close, 20)"

# 下轨 = MA20 - 2 * STD20
"Mean($close, 20) - 2 * Std($close, 20)"

# 布林带宽度（衡量波动率）
"4 * Std($close, 20) / Mean($close, 20)"

# 价格在布林带中的位置（%B）
"($close - Mean($close, 20) + 2 * Std($close, 20)) / (4 * Std($close, 20))"

# 简化版 %B
"($close - Mean($close, 20)) / Std($close, 20)"  # 标准化后的位置
```

## ATR（平均真实波幅）

```python
# True Range 近似（Qlib 无法直接取 max of 3 values，用分步近似）
# TR = max(High-Low, |High-PrevClose|, |Low-PrevClose|)
# 近似：用 High-Low 作为主要成分（大多数情况下最大）

# ATR14 近似
"Mean($high - $low, 14)"

# 更精确的 TR（考虑跳空）
"Mean(If($high - $low > Abs($high - Ref($close, 1)), If($high - $low > Abs($low - Ref($close, 1)), $high - $low, Abs($low - Ref($close, 1))), If(Abs($high - Ref($close, 1)) > Abs($low - Ref($close, 1)), Abs($high - Ref($close, 1)), Abs($low - Ref($close, 1)))), 14)"

# ATR 百分比（相对价格的波动率）
"Mean($high - $low, 14) / $close"
```

## 成交量指标

### OBV（能量潮）近似

```python
# OBV 是累积量，表达式引擎无法直接实现累积
# 用 N 日带方向成交量之和近似
"Sum(If($close > Ref($close, 1), $volume, If($close < Ref($close, 1), -1*$volume, 0)), 20)"
```

### 量比

```python
# 当日成交量 / 过去 N 日平均成交量
"$volume / Mean($volume, 5)"    # 5日量比
"$volume / Mean($volume, 20)"   # 20日量比
```

### 成交额变化

```python
"$volume * $close / Mean($volume * $close, 20)"  # 成交额相对均值
```

## 动量指标

### ROC（变动率）

```python
"$close / Ref($close, 12) - 1"    # 12日ROC
"$close / Ref($close, 20) - 1"    # 20日ROC
```

### MTM（动量）

```python
"$close - Ref($close, 10)"        # 10日动量
"Delta($close, 10)"               # 等价写法
```

### 威廉指标（WR）

```python
# WR = (HHV(High,N) - Close) / (HHV(High,N) - LLV(Low,N))
"(Max($high, 14) - $close) / (Max($high, 14) - Min($low, 14))"
```

## 趋势指标

### DMA（平均线差）

```python
# DMA = MA(short) - MA(long)
"Mean($close, 10) - Mean($close, 50)"
```

### TRIX

```python
# TRIX 近似（三重 EMA 的变化率）
# 用单 EMA 的变化率近似
"EMA($close, 12) / Ref(EMA($close, 12), 1) - 1"
```

### CCI（商品通道指数）

```python
# CCI = (TP - MA(TP, N)) / (0.015 * MeanDev(TP, N))
# TP = (High + Low + Close) / 3
# 近似（用 Std 代替 MeanDev）
"(($high + $low + $close) / 3 - Mean(($high + $low + $close) / 3, 14)) / (0.015 * Std(($high + $low + $close) / 3, 14))"
```

## 综合因子模板

将多个技术指标组合为 DataHandler：

```python
TA_FACTORS = {
    "feature": (
        [
            # 均线
            "$close / Mean($close, 5) - 1",
            "$close / Mean($close, 20) - 1",
            "$close / Mean($close, 60) - 1",
            "Mean($close, 5) / Mean($close, 20) - 1",
            # MACD
            "EMA($close, 12) - EMA($close, 26)",
            # RSV/KDJ
            "($close - Min($low, 9)) / (Max($high, 9) - Min($low, 9))",
            # RSI
            "Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 14) / (Mean(If($close > Ref($close, 1), $close - Ref($close, 1), 0), 14) + Mean(If($close < Ref($close, 1), Ref($close, 1) - $close, 0), 14))",
            # BOLL %B
            "($close - Mean($close, 20)) / Std($close, 20)",
            # ATR%
            "Mean($high - $low, 14) / $close",
            # 量比
            "$volume / Mean($volume, 20)",
            # 动量
            "$close / Ref($close, 5) - 1",
            "$close / Ref($close, 20) - 1",
            # WR
            "(Max($high, 14) - $close) / (Max($high, 14) - Min($low, 14))",
        ],
        ["ma5_dev", "ma20_dev", "ma60_dev", "ma_cross",
         "macd_dif", "rsv", "rsi14", "boll_pct_b",
         "atr_pct", "vol_ratio", "mom5", "mom20", "wr14"]
    ),
    "label": (
        ["Ref($close, -2) / Ref($close, -1) - 1"],
        ["label"]
    )
}
```

## 注意事项

1. **EMA 嵌套限制**：Qlib 表达式不支持对表达式结果再做 EMA/Mean 等滚动操作的嵌套超过一层。如 `EMA(EMA($close, 12) - EMA($close, 26), 9)` 可能不被支持，需用 `Mean` 近似或 Python 计算。

2. **精度差异**：用 Mean 近似 EMA、用 Std 近似 MeanDev 等会与传统 TA 库（如 talib）有数值差异，但作为 ML 特征输入，排序一致性比绝对值更重要。

3. **NaN 处理**：窗口期内数据不足时会产生 NaN，确保在 Processor 中使用 `Fillna`。

4. **性能**：复杂嵌套表达式首次计算较慢，但会被缓存。建议将常用因子集固定下来避免频繁重算。
