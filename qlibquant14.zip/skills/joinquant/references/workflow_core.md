# Qlib 工作流与核心架构

## 架构总览

Qlib 采用松耦合模块化设计，核心流程：

```
Data → DataHandler → Dataset → Model → Prediction → Strategy → Executor → Backtest → Analysis
```

每个模块可独立使用，也可通过 YAML 配置串联为完整 workflow。

## 两种运行方式

### 方式一：qrun CLI（YAML 驱动）

```bash
qrun workflow_config.yaml
```

一条命令完成：数据加载 → 模型训练 → 预测 → 回测 → 报告。适合快速实验和模型对比。

### 方式二：workflow_by_code（Python 脚本）

```python
import qlib
from qlib.workflow import R
from qlib.utils import init_instance_by_config

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

with R.start(experiment_name="my_exp"):
    model = init_instance_by_config(model_config)
    dataset = init_instance_by_config(dataset_config)
    model.fit(dataset)
    predictions = model.predict(dataset, segment="test")
    # ... 后续回测
```

适合需要自定义逻辑、条件分支、多步骤组合的场景。

## 关键抽象

### DataHandler

负责原始数据 → 特征矩阵的转换：

```python
from qlib.contrib.data.handler import Alpha158

handler = Alpha158(
    instruments="csi300",
    start_time="2008-01-01",
    end_time="2020-08-01",
    fit_start_time="2008-01-01",
    fit_end_time="2014-12-31",
    infer_processors=[...],
    learn_processors=[...]
)
```

### Dataset

将 DataHandler 的输出按时间切分为 train/valid/test：

```python
from qlib.data.dataset import DatasetH

dataset = DatasetH(
    handler=handler,
    segments={
        "train": ("2008-01-01", "2014-12-31"),
        "valid": ("2015-01-01", "2016-12-31"),
        "test": ("2017-01-01", "2020-08-01"),
    }
)
```

### Model

统一接口：`fit(dataset)` + `predict(dataset, segment)`

```python
from qlib.contrib.model.gbdt import LGBModel

model = LGBModel(loss="mse", num_leaves=210, max_depth=8)
model.fit(dataset)
pred = model.predict(dataset, segment="test")  # pd.Series, MultiIndex(datetime, instrument)
```

### Strategy

将模型预测转化为交易决策：

```python
from qlib.contrib.strategy.signal_strategy import TopkDropoutStrategy

strategy = TopkDropoutStrategy(
    signal=predictions,
    topk=50,
    n_drop=5
)
```

### Executor

执行交易决策，模拟撮合：

```python
executor_config = {
    "class": "SimulatorExecutor",
    "module_path": "qlib.backtest.executor",
    "kwargs": {
        "time_per_step": "day",
        "generate_portfolio_metrics": True
    }
}
```

## YAML 配置结构

```yaml
qlib_init:
    provider_uri: "~/.qlib/qlib_data/cn_data"
    region: cn

market: &market csi300
benchmark: &benchmark SH000300

data_handler_config: &data_handler_config
    start_time: "2008-01-01"
    end_time: "2020-08-01"
    fit_start_time: "2008-01-01"
    fit_end_time: "2014-12-31"
    instruments: *market

task:
    model:
        class: LGBModel
        module_path: qlib.contrib.model.gbdt
        kwargs:
            loss: mse
            colsample_bytree: 0.8879
            learning_rate: 0.0421
            subsample: 0.8789
            lambda_l1: 205.6999
            lambda_l2: 580.9768
            max_depth: 8
            num_leaves: 210
            num_threads: 20

    dataset:
        class: DatasetH
        module_path: qlib.data.dataset
        kwargs:
            handler:
                class: Alpha158
                module_path: qlib.contrib.data.handler
                kwargs: *data_handler_config
            segments:
                train: ["2008-01-01", "2014-12-31"]
                valid: ["2015-01-01", "2016-12-31"]
                test: ["2017-01-01", "2020-08-01"]

    record:
        - class: SignalRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              model: <MODEL>
              dataset: <DATASET>

        - class: SigAnaRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              ana_long_short: False
              ann_scaler: 252

        - class: PortAnaRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              config:
                  strategy:
                      class: TopkDropoutStrategy
                      module_path: qlib.contrib.strategy.signal_strategy
                      kwargs:
                          signal: <PRED>
                          topk: 50
                          n_drop: 5
                  backtest:
                      start_time: "2017-01-01"
                      end_time: "2020-08-01"
                      account: 100000000
                      benchmark: *benchmark
                      exchange_kwargs:
                          freq: day
                          limit_threshold: 0.095
                          deal_price: close
                          open_cost: 0.0005
                          close_cost: 0.0015
                          min_cost: 5
```

### YAML 中的对象实例化模式

Qlib 统一使用 `class` / `module_path` / `kwargs` 三元组来声明可实例化对象：

```yaml
some_component:
    class: ClassName
    module_path: qlib.module.submodule
    kwargs:
        param1: value1
        param2: value2
```

等价于 Python：

```python
from qlib.module.submodule import ClassName
obj = ClassName(param1=value1, param2=value2)
```

### 特殊占位符

- `<MODEL>` — 自动引用当前 task 中训练好的 model
- `<DATASET>` — 自动引用当前 task 中的 dataset
- `<PRED>` — 自动引用 SignalRecord 产出的预测结果

## 实验管理

Qlib 集成 MLflow 进行实验追踪：

```python
from qlib.workflow import R

# 列出所有实验
experiments = R.list_experiments()

# 获取某次实验的 recorder
recorder = R.get_recorder(experiment_name="my_exp")

# 加载保存的对象
model = recorder.load_object("model.pkl")
predictions = recorder.load_object("pred.pkl")
```

### 实验目录结构

```
./mlruns/
├── 0/                          # 默认实验
│   ├── meta.yaml
│   └── <run_id>/
│       ├── artifacts/
│       │   ├── model.pkl
│       │   └── pred.pkl
│       └── metrics/
└── 1/                          # 自定义实验
```

## init_instance_by_config 工具函数

在 Python 代码中实例化 YAML 风格配置：

```python
from qlib.utils import init_instance_by_config

config = {
    "class": "LGBModel",
    "module_path": "qlib.contrib.model.gbdt",
    "kwargs": {"loss": "mse", "num_leaves": 210}
}

model = init_instance_by_config(config)
```

## Rolling Train（滚动训练）

用于模拟真实场景中的定期重训练：

```python
from qlib.workflow.task.gen import RollingGen
from qlib.workflow.task.manage import TaskManager

# 生成滚动任务
rolling_gen = RollingGen(
    step=20,            # 每 20 个交易日滚动一次
    rtype="expanding"   # expanding window（或 "sliding"）
)

tasks = rolling_gen(task_config)
# tasks 是一组 task，每个 task 的 train/valid/test 时间窗口不同
```
