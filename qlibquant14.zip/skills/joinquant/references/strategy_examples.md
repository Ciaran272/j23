# 策略示例代码

> **导览**：
> - §1 完整 YAML workflow（LightGBM + Alpha158，可直接 qrun）
> - §2 Python 脚本 workflow（自定义因子 + 回测）
> - §3 自定义因子策略
> - §4 多模型对比
> - 完整端到端教程见知识库 **[00_速通教程/A股多因子端到端_完整教程.md](../../../知识库/00_速通教程/A股多因子端到端_完整教程.md)**

## 1. 完整 YAML Workflow

可直接保存为 `workflow_config.yaml` 并用 `qrun workflow_config.yaml` 运行：

```yaml
qlib_init:
    provider_uri: "~/.qlib/qlib_data/cn_data"
    region: cn

market: &market csi300
benchmark: &benchmark SH000300

data_handler_config: &data_handler_config
    start_time: "2008-01-01"
    end_time: "2020-08-01"
    fit_start_time: "2008-01-01"
    fit_end_time: "2014-12-31"
    instruments: *market
    infer_processors:
        - class: RobustZScoreNorm
          kwargs:
              fields_group: feature
              clip_outlier: true
        - class: Fillna
          kwargs:
              fields_group: feature
    learn_processors:
        - class: DropnaLabel
        - class: CSRankNorm
          kwargs:
              fields_group: label
    label:
        - "Ref($close, -2) / Ref($close, -1) - 1"

task:
    model:
        class: LGBModel
        module_path: qlib.contrib.model.gbdt
        kwargs:
            loss: mse
            colsample_bytree: 0.8879
            learning_rate: 0.0421
            subsample: 0.8789
            lambda_l1: 205.6999
            lambda_l2: 580.9768
            max_depth: 8
            num_leaves: 210
            num_threads: 20

    dataset:
        class: DatasetH
        module_path: qlib.data.dataset
        kwargs:
            handler:
                class: Alpha158
                module_path: qlib.contrib.data.handler
                kwargs: *data_handler_config
            segments:
                train: ["2008-01-01", "2014-12-31"]
                valid: ["2015-01-01", "2016-12-31"]
                test: ["2017-01-01", "2020-08-01"]

    record:
        - class: SignalRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              model: <MODEL>
              dataset: <DATASET>

        - class: SigAnaRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              ana_long_short: false
              ann_scaler: 252

        - class: PortAnaRecord
          module_path: qlib.workflow.record_temp
          kwargs:
              config:
                  strategy:
                      class: TopkDropoutStrategy
                      module_path: qlib.contrib.strategy.signal_strategy
                      kwargs:
                          signal: <PRED>
                          topk: 50
                          n_drop: 5
                  backtest:
                      start_time: "2017-01-01"
                      end_time: "2020-08-01"
                      account: 100000000
                      benchmark: *benchmark
                      exchange_kwargs:
                          freq: day
                          limit_threshold: 0.095
                          deal_price: close
                          open_cost: 0.0005
                          close_cost: 0.0015
                          min_cost: 5
                          trade_unit: 100
```

运行：
```bash
qrun workflow_config.yaml
```

## 2. Python 脚本 Workflow

```python
"""
Qlib 多因子策略完整流程（Python 脚本版）
- 自定义因子 + LightGBM + TopK 回测
- 直接运行：python my_strategy.py
"""
import qlib
from qlib.data import D
from qlib.data.dataset import DatasetH
from qlib.data.dataset.handler import DataHandlerLP
from qlib.contrib.model.gbdt import LGBModel
from qlib.contrib.evaluate import backtest_daily, risk_analysis
from qlib.workflow import R
import pandas as pd

# ============ 1. 初始化 ============
qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

# ============ 2. 定义因子 ============
feature_config = {
    "feature": (
        [
            "$close / Ref($close, 1) - 1",           # 1日动量
            "$close / Ref($close, 5) - 1",           # 5日动量
            "$close / Ref($close, 20) - 1",          # 20日动量
            "Mean($close, 5) / Mean($close, 20) - 1",  # 均线交叉
            "Std($close / Ref($close, 1) - 1, 20)",  # 20日波动率
            "$volume / Mean($volume, 20)",            # 量比
            "Corr($close, $volume, 10)",             # 价量相关
            "($close - Min($low, 20)) / (Max($high, 20) - Min($low, 20))",  # 价格位置
            "Rank($close / Ref($close, 5) - 1)",     # 动量排名
            "TsRank($volume, 20)",                   # 成交量时序排名
        ],
        ["ret1", "ret5", "ret20", "ma_cross", "vol20",
         "vol_ratio", "pv_corr", "price_pos", "mom_rank", "vol_tsrank"]
    ),
    "label": (
        ["Ref($close, -2) / Ref($close, -1) - 1"],
        ["label"]
    )
}

# ============ 3. 构建 DataHandler ============
handler = DataHandlerLP(
    instruments="csi300",
    start_time="2010-01-01",
    end_time="2020-12-31",
    fit_start_time="2010-01-01",
    fit_end_time="2017-12-31",
    data_loader={
        "class": "QlibDataLoader",
        "module_path": "qlib.data.dataset.loader",
        "kwargs": {"config": feature_config, "freq": "day"}
    },
    infer_processors=[
        {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
        {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
    ],
    learn_processors=[
        {"class": "DropnaLabel"},
        {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
    ]
)

# ============ 4. 构建 Dataset ============
dataset = DatasetH(
    handler=handler,
    segments={
        "train": ("2010-01-01", "2017-12-31"),
        "valid": ("2018-01-01", "2018-12-31"),
        "test": ("2019-01-01", "2020-12-31"),
    }
)

# ============ 5. 训练模型 ============
model = LGBModel(
    loss="mse",
    num_leaves=128,
    max_depth=8,
    learning_rate=0.05,
    colsample_bytree=0.85,
    subsample=0.85,
    lambda_l1=100,
    lambda_l2=200,
    num_threads=8
)

with R.start(experiment_name="custom_factor_lgb"):
    model.fit(dataset)
    predictions = model.predict(dataset, segment="test")
    R.save_objects(**{"model.pkl": model, "pred.pkl": predictions})

# ============ 6. 回测 ============
portfolio_metric_dict, indicator_dict = backtest_daily(
    pred=predictions,
    strategy={
        "class": "TopkDropoutStrategy",
        "module_path": "qlib.contrib.strategy.signal_strategy",
        "kwargs": {
            "signal": predictions,
            "topk": 30,
            "n_drop": 3,
            "forbid_all_trade_at_limit": True
        }
    },
    executor={
        "class": "SimulatorExecutor",
        "module_path": "qlib.backtest.executor",
        "kwargs": {"time_per_step": "day", "generate_portfolio_metrics": True}
    },
    account=100000000,
    benchmark="SH000300",
    freq="day",
    exchange_kwargs={
        "freq": "day",
        "limit_threshold": 0.095,
        "deal_price": "close",
        "open_cost": 0.0005,
        "close_cost": 0.0015,
        "min_cost": 5,
        "trade_unit": 100
    }
)

# ============ 7. 结果分析 ============
report_df = portfolio_metric_dict["1day"]
analysis = risk_analysis(report_df[["return"]].dropna())
print("\n===== 回测结果 =====")
print(analysis)
print(f"\n日均换手: {report_df['turnover'].mean():.2%}")
print(f"年化换手: {report_df['turnover'].mean() * 252:.1f} 倍")
```

## 3. 自定义 Alpha101 因子策略

```python
"""使用 Alpha101 因子子集 + LightGBM"""
import qlib
from qlib.data.dataset import DatasetH
from qlib.data.dataset.handler import DataHandlerLP
from qlib.contrib.model.gbdt import LGBModel
from qlib.contrib.evaluate import backtest_daily, risk_analysis

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

# Alpha101 精选因子
alpha101_exprs = [
    "-1 * Corr(Rank(Delta(Log($volume), 2)), Rank(($close - $open) / $open), 6)",
    "-1 * Corr(Rank($open), Rank($volume), 10)",
    "-1 * TsRank(Rank($low), 9)",
    "Rank($open - Mean($vwap, 10)) * (-1 * Abs(Rank($close - $vwap)))",
    "-1 * Corr($open, $volume, 10)",
    "Sign(Delta($volume, 1)) * (-1 * Delta($close, 1))",
    "-1 * Rank(Cov(Rank($close), Rank($volume), 5))",
    "-1 * Rank(Delta($close/Ref($close,1)-1, 3)) * Corr($open, $volume, 10)",
    "-1 * Rank(Std(Abs($close - $open), 5) + ($close - $open) + Corr($close, $open, 10))",
    "-1 * Delta(Corr($high, $volume, 5), 5) * Rank(Std($close, 20))",
]
alpha101_names = [f"alpha{i:03d}" for i in [2, 3, 4, 5, 6, 12, 13, 14, 18, 22]]

handler = DataHandlerLP(
    instruments="csi500",
    start_time="2010-01-01",
    end_time="2020-12-31",
    fit_start_time="2010-01-01",
    fit_end_time="2017-12-31",
    data_loader={
        "class": "QlibDataLoader",
        "module_path": "qlib.data.dataset.loader",
        "kwargs": {
            "config": {
                "feature": (alpha101_exprs, alpha101_names),
                "label": (["Ref($close, -2) / Ref($close, -1) - 1"], ["label"])
            },
            "freq": "day"
        }
    },
    infer_processors=[
        {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
        {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
    ],
    learn_processors=[
        {"class": "DropnaLabel"},
        {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
    ]
)

dataset = DatasetH(handler=handler, segments={
    "train": ("2010-01-01", "2017-12-31"),
    "valid": ("2018-01-01", "2018-12-31"),
    "test": ("2019-01-01", "2020-12-31"),
})

model = LGBModel(loss="mse", num_leaves=128, max_depth=6, learning_rate=0.05)
model.fit(dataset)
pred = model.predict(dataset, segment="test")

portfolio_metric_dict, _ = backtest_daily(
    pred=pred,
    strategy={"class": "TopkDropoutStrategy", "module_path": "qlib.contrib.strategy.signal_strategy",
              "kwargs": {"signal": pred, "topk": 50, "n_drop": 5, "forbid_all_trade_at_limit": True}},
    executor={"class": "SimulatorExecutor", "module_path": "qlib.backtest.executor",
              "kwargs": {"time_per_step": "day", "generate_portfolio_metrics": True}},
    account=100000000, benchmark="SH000905", freq="day",
    exchange_kwargs={"freq": "day", "limit_threshold": 0.095, "deal_price": "close",
                     "open_cost": 0.0005, "close_cost": 0.0015, "min_cost": 5, "trade_unit": 100}
)

print(risk_analysis(portfolio_metric_dict["1day"][["return"]].dropna()))
```

## 4. 多模型对比

```python
"""对比 LightGBM / XGBoost / Linear 在相同因子集上的表现"""
import qlib
from qlib.data.dataset import DatasetH
from qlib.contrib.data.handler import Alpha158
from qlib.contrib.evaluate import backtest_daily, risk_analysis
from qlib.utils import init_instance_by_config

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

# 共用 dataset
handler = Alpha158(
    instruments="csi300",
    start_time="2008-01-01", end_time="2020-08-01",
    fit_start_time="2008-01-01", fit_end_time="2014-12-31",
    infer_processors=[
        {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
        {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
    ],
    learn_processors=[{"class": "DropnaLabel"}, {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}],
    label=["Ref($close, -2) / Ref($close, -1) - 1"]
)

dataset = DatasetH(handler=handler, segments={
    "train": ("2008-01-01", "2014-12-31"),
    "valid": ("2015-01-01", "2016-12-31"),
    "test": ("2017-01-01", "2020-08-01"),
})

# 模型配置
models = {
    "LightGBM": {"class": "LGBModel", "module_path": "qlib.contrib.model.gbdt",
                 "kwargs": {"loss": "mse", "num_leaves": 210, "max_depth": 8, "learning_rate": 0.05}},
    "XGBoost": {"class": "XGBModel", "module_path": "qlib.contrib.model.xgboost",
                "kwargs": {"max_depth": 8, "learning_rate": 0.05, "n_estimators": 500}},
    "Linear": {"class": "LinearModel", "module_path": "qlib.contrib.model.linear",
               "kwargs": {"estimator": "ridge"}},
}

# 逐个训练和回测
results = {}
for name, config in models.items():
    print(f"\n===== {name} =====")
    model = init_instance_by_config(config)
    model.fit(dataset)
    pred = model.predict(dataset, segment="test")

    portfolio_metric_dict, _ = backtest_daily(
        pred=pred,
        strategy={"class": "TopkDropoutStrategy", "module_path": "qlib.contrib.strategy.signal_strategy",
                  "kwargs": {"signal": pred, "topk": 50, "n_drop": 5, "forbid_all_trade_at_limit": True}},
        executor={"class": "SimulatorExecutor", "module_path": "qlib.backtest.executor",
                  "kwargs": {"time_per_step": "day", "generate_portfolio_metrics": True}},
        account=100000000, benchmark="SH000300", freq="day",
        exchange_kwargs={"freq": "day", "limit_threshold": 0.095, "deal_price": "close",
                         "open_cost": 0.0005, "close_cost": 0.0015, "min_cost": 5, "trade_unit": 100}
    )

    analysis = risk_analysis(portfolio_metric_dict["1day"][["return"]].dropna())
    results[name] = analysis
    print(analysis)

# 汇总对比
print("\n===== 模型对比 =====")
for name, analysis in results.items():
    print(f"{name}: 年化={analysis.loc['annualized_return'].values[0]:.2%}, "
          f"IR={analysis.loc['information_ratio'].values[0]:.3f}, "
          f"MaxDD={analysis.loc['max_drawdown'].values[0]:.2%}")
```
