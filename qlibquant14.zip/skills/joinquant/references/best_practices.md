# A 股量化最佳实践

## 1. 避免未来数据

### Qlib 中的未来数据防护

Qlib 的设计天然避免了大部分未来数据问题：
- 表达式引擎中 `Ref($close, n)` 当 n > 0 时取历史值，n < 0 时取未来值
- 未来值（负 Ref）只应出现在 **label 定义**中，绝对不能出现在 feature 中
- DataHandler 的 `fit_start_time` / `fit_end_time` 确保标准化统计量不使用未来信息

### 常见未来数据陷阱

| 陷阱 | 说明 | 正确做法 |
|------|------|----------|
| 特征中使用负 Ref | `Ref($close, -1)` 在 feature 中 | 只在 label 中使用负 Ref |
| 全样本标准化 | 用全部数据计算均值/标准差 | 设置 `fit_end_time` ≤ train 结束时间 |
| 未来成分股 | 用当前的沪深 300 成分回测历史 | 使用 instruments 文件中的历史成分 |
| 财报发布日 | 用报告期而非实际发布日 | 确保数据源标注了实际可得日期 |
| 复权因子 | 用最新复权因子回算历史 | 社区数据源已处理，自建数据需注意 |

### 检查方法

```python
# 检查 feature 表达式中是否有负 Ref
import re
for expr in feature_expressions:
    if re.search(r'Ref\([^,]+,\s*-\d+\)', expr):
        print(f"WARNING: 未来数据! {expr}")
```

## 2. A 股交易约束

### 涨跌停

- 主板/中小板：±10%
- 创业板/科创板：±20%
- ST 股票：±5%
- 新股上市首日：±44%（注册制无限制但有临停）

Qlib 回测中通过 `limit_threshold` 处理：

```python
"exchange_kwargs": {
    "limit_threshold": 0.095,  # 设为 9.5%，留 0.5% 余量
}
```

### T+1 制度

A 股当日买入不能当日卖出。Qlib 的 `SimulatorExecutor` 默认按日频执行，天然满足 T+1。

### 整数手（100 股）

```python
"exchange_kwargs": {
    "trade_unit": 100,  # A 股最小交易单位
}
```

### 停牌股

Qlib 数据中停牌日无行情数据（NaN），回测引擎自动跳过无法交易的股票。

## 3. 数据泄漏防护

### 时间段划分原则

```
|-------- train --------|-- valid --|---- test ----|
2008                   2015       2017           2020
```

- train 和 valid 之间不需要 gap（Qlib 的 label 已经考虑了前瞻）
- 如果 label 是 `Ref($close, -5) / $close - 1`（5 日收益），则 train 最后 5 天的 label 会用到 valid 期间的数据——这是正常的，Qlib 会自动处理
- 但如果用滚动统计（如 60 日均值）作为特征，test 开始时需要 60 天的 warm-up 数据

### 截面标准化 vs 时序标准化

- `RobustZScoreNorm`：时序标准化（用 fit 期间的统计量）
- `CSRankNorm`：截面标准化（每日独立排名）——无泄漏风险
- 推荐：feature 用 `RobustZScoreNorm`，label 用 `CSRankNorm`

## 4. 股票池构建

### 过滤不可交易标的

Qlib 的 instruments 文件已经处理了退市股票（end_date 标注了退市日期），但以下情况需要额外注意：

```python
# 自定义过滤器（在 DataHandler 外部处理）
def filter_stocks(instruments, date):
    """过滤 ST、次新股等"""
    # Qlib 本身不提供 ST/次新标记
    # 需要自建数据或外部数据源
    pass
```

### 社区数据源的局限

chenditc/investment_data 提供的是纯行情数据，不包含：
- ST 标记
- 停牌状态
- 上市日期（需从 instruments 文件推断）
- 行业分类
- 基本面数据

如需这些数据，需要自行补充（如从 tushare/akshare 获取后 dump_bin）。

## 5. 容量与换手

### 换手率控制

TopkDropoutStrategy 的 `n_drop` 参数直接控制换手：

```python
# 低换手配置
"topk": 50, "n_drop": 3    # 每日最多换 3 只，年化换手 ~15 倍

# 高换手配置
"topk": 50, "n_drop": 50   # 不限制，完全按信号调仓
```

### 容量估算

```python
# 粗略容量 = topk * 单只平均持仓 * 日均成交额占比
# 假设 topk=50, 账户 1 亿, 单只 200 万
# 如果目标股票日均成交额 5000 万，则占比 4%——可接受
# 如果目标股票日均成交额 500 万，则占比 40%——冲击成本巨大

# 在回测中观察换手成本
report_df["turnover"]  # 每日换手率
report_df["cost"]      # 每日交易成本
```

### 小盘股策略的容量问题

- CSI300 成分股：容量充足，适合大资金
- CSI500：中等容量
- CSI1000 / 全市场小盘：容量有限，回测收益可能无法实现

## 6. 回测陷阱

### 过拟合

- 不要在 test 集上调参
- 使用 rolling train 验证策略稳定性
- IC 衰减分析：如果 IC 在 test 期间显著低于 valid，可能过拟合

### 幸存者偏差

- 使用包含退市股票的 instruments 文件
- 社区数据源通常已包含退市股票

### 成交价假设

```python
# "close" 成交：假设能以收盘价成交（乐观）
# "vwap" 成交：假设以当日均价成交（更现实）
# "open" 成交：假设以次日开盘价成交（最保守）

"deal_price": "vwap"  # 推荐用 vwap 或 open
```

### 费率设置

```python
# 过于乐观的费率（不推荐）
"open_cost": 0.0001, "close_cost": 0.0001

# 现实费率（推荐）
"open_cost": 0.0005, "close_cost": 0.0015

# 保守费率（压力测试）
"open_cost": 0.001, "close_cost": 0.002
```

## 7. 模型选择建议

| 场景 | 推荐模型 | 原因 |
|------|----------|------|
| 快速验证因子 | LightGBM | 训练快，效果稳定 |
| 因子数 < 20 | LinearModel / LightGBM | 简单模型不易过拟合 |
| 因子数 > 100 | LightGBM / XGBoost | 树模型擅长高维特征选择 |
| 时序模式 | LSTM / GRU | 捕捉时间依赖 |
| 大规模因子 + 时序 | Transformer | 注意力机制 + 时序 |
| 集成 | DEnsemble | 多模型投票，更稳定 |

## 8. 实验管理建议

```python
# 每次实验记录关键信息
with R.start(experiment_name="factor_v2_lgb"):
    # 记录超参
    recorder = R.get_recorder()
    recorder.log_params(model_config["kwargs"])
    recorder.log_params({"topk": 50, "n_drop": 5})

    # 训练 + 预测
    model.fit(dataset)
    pred = model.predict(dataset, segment="test")

    # 保存
    R.save_objects(**{"model.pkl": model, "pred.pkl": pred})
```

命名规范建议：
- `{因子集}_{模型}_{日期}`: 如 `alpha158_lgb_20240101`
- `{策略名}_{参数}`: 如 `topk50_drop5_vwap`
