# 策略与回测参考

## 策略类

### TopkDropoutStrategy

最常用的信号策略，按预测值排序选 Top-K 持仓：

```python
strategy_config = {
    "class": "TopkDropoutStrategy",
    "module_path": "qlib.contrib.strategy.signal_strategy",
    "kwargs": {
        "signal": "<PRED>",         # 预测信号（或 (model, dataset) 元组）
        "topk": 50,                  # 持仓股票数
        "n_drop": 5,                 # 每次调仓最多替换的股票数
        "method_sell": "bottom",     # 卖出方式：bottom（排名最低的先卖）
        "method_buy": "top",         # 买入方式：top（排名最高的先买）
        "hold_thresh": 1,            # 持仓阈值
        "forbid_all_trade_at_limit": True  # 涨跌停禁止交易
    }
}
```

参数说明：
- `topk`: 目标持仓数量。越大越分散，换手越低
- `n_drop`: 控制换手率。每次调仓最多卖出 n_drop 只，买入 n_drop 只
- `forbid_all_trade_at_limit`: A 股必须设为 True（涨停买不进，跌停卖不出）

### WeightStrategyBase

按权重分配仓位的策略基类：

```python
from qlib.contrib.strategy.signal_strategy import WeightStrategyBase

class MyWeightStrategy(WeightStrategyBase):
    def generate_target_weight_position(self, score, current, trade_exchange, trade_date):
        """
        根据信号生成目标权重
        score: pd.Series, 当日各股票的预测分数
        current: 当前持仓
        trade_exchange: 交易所对象（含涨跌停信息）
        trade_date: 交易日期
        """
        # 选 top 50，等权
        selected = score.nlargest(50)
        weights = pd.Series(1.0 / len(selected), index=selected.index)
        return weights
```

### 自定义策略

```python
from qlib.contrib.strategy.signal_strategy import TopkDropoutStrategy

class MyStrategy(TopkDropoutStrategy):
    def __init__(self, min_score=0, **kwargs):
        super().__init__(**kwargs)
        self.min_score = min_score

    def generate_trade_decision(self, execute_result=None):
        # 可以在这里添加额外过滤逻辑
        decision = super().generate_trade_decision(execute_result)
        return decision
```

## 回测引擎

### backtest_daily（简单回测）

```python
from qlib.contrib.evaluate import backtest_daily, risk_analysis

portfolio_metric_dict, indicator_dict = backtest_daily(
    pred=predictions,               # pd.Series/DataFrame，模型预测结果
    strategy=strategy_config,
    executor={
        "class": "SimulatorExecutor",
        "module_path": "qlib.backtest.executor",
        "kwargs": {
            "time_per_step": "day",
            "generate_portfolio_metrics": True
        }
    },
    account=100000000,              # 初始资金（1 亿）
    benchmark="SH000300",           # 基准（沪深 300）
    freq="day"
)

# 分析结果
report_df = portfolio_metric_dict.get("1day")
analysis = risk_analysis(report_df[["return"]].dropna())
print(analysis)
```

### exchange_kwargs（交易成本配置）

```python
exchange_kwargs = {
    "freq": "day",
    "limit_threshold": 0.095,       # 涨跌停阈值（9.5% 留余量）
    "deal_price": "close",          # 成交价："close" 或 "open" 或 "vwap"
    "open_cost": 0.0005,            # 买入成本（佣金，万五）
    "close_cost": 0.0015,           # 卖出成本（佣金 + 印花税，千一点五）
    "min_cost": 5,                  # 最低佣金（5 元）
    "trade_unit": 100,              # 交易单位（A 股 100 股）
}
```

A 股费率参考：
- 佣金：万 2.5 ~ 万 5（双向）
- 印花税：千 1（仅卖出）
- 过户费：万 0.2（上交所，双向）
- 合计买入：~万 3，卖出：~万 13

### 完整回测配置

```python
backtest_config = {
    "start_time": "2017-01-01",
    "end_time": "2020-08-01",
    "account": 100000000,
    "benchmark": "SH000300",
    "exchange_kwargs": {
        "freq": "day",
        "limit_threshold": 0.095,
        "deal_price": "close",
        "open_cost": 0.0005,
        "close_cost": 0.0015,
        "min_cost": 5,
        "trade_unit": 100
    }
}
```

## Executor（执行器）

### SimulatorExecutor

模拟执行器，处理订单撮合：

```python
executor_config = {
    "class": "SimulatorExecutor",
    "module_path": "qlib.backtest.executor",
    "kwargs": {
        "time_per_step": "day",              # 执行频率
        "generate_portfolio_metrics": True,   # 生成组合指标
        "verbose": True,                      # 详细日志
        "indicator_config": {
            "show_indicator": True            # 显示交易指标
        }
    }
}
```

### 嵌套执行器（Nested Executor）

用于日内执行优化：

```python
# 外层：日频决策
# 内层：日内分时执行（如 TWAP/VWAP）
executor_config = {
    "class": "SimulatorExecutor",
    "module_path": "qlib.backtest.executor",
    "kwargs": {
        "time_per_step": "day",
        "inner_executor": {
            "class": "SimulatorExecutor",
            "module_path": "qlib.backtest.executor",
            "kwargs": {
                "time_per_step": "30min",
                "generate_portfolio_metrics": False
            }
        },
        "inner_strategy": {
            "class": "TWAPStrategy",
            "module_path": "qlib.contrib.strategy.executor_strategy"
        }
    }
}
```

## 分析与报告

### risk_analysis

```python
from qlib.contrib.evaluate import risk_analysis

analysis = risk_analysis(report_df[["return"]].dropna())
```

输出指标：
- `mean`: 日均收益
- `std`: 日收益标准差
- `annualized_return`: 年化收益率
- `information_ratio`: 信息比率（年化收益/年化波动）
- `max_drawdown`: 最大回撤

### 通过 Record 自动分析

```yaml
record:
    - class: SigAnaRecord
      module_path: qlib.workflow.record_temp
      kwargs:
          ana_long_short: True     # 多空分析
          ann_scaler: 252          # 年化天数

    - class: PortAnaRecord
      module_path: qlib.workflow.record_temp
      kwargs:
          config:
              strategy: ...
              backtest: ...
```

SigAnaRecord 输出：
- IC / Rank IC 时间序列
- ICIR
- 多空组合收益

PortAnaRecord 输出：
- 组合净值曲线
- 超额收益
- 换手率
- 持仓集中度

### 可视化

```python
import matplotlib.pyplot as plt
from qlib.contrib.report import analysis_model, analysis_position

# 模型分析（IC、收益分组等）
analysis_model.model_performance_graph(recorder)

# 持仓分析（净值、回撤、换手等）
analysis_position.report_graph(recorder)
```

## benchmark 代码格式

| 指数 | Qlib 代码 | 说明 |
|------|-----------|------|
| 沪深 300 | SH000300 | 最常用基准 |
| 中证 500 | SH000905 | 中盘基准 |
| 中证 800 | SH000906 | 宽基 |
| 中证 1000 | SH000852 | 小盘基准 |
| 上证指数 | SH000001 | 上交所综合 |
| 创业板指 | SZ399006 | 创业板 |

## 回测结果解读

```python
# portfolio_metric_dict 结构
{
    "1day": pd.DataFrame  # columns: return, turnover, cost, bench, excess_return
}

# indicator_dict 结构
{
    "1day": {
        "ffr": float,      # 满仓率 (Full Fill Rate)
        "pa": float,       # 价格优势 (Price Advantage)
        "pos": float       # 持仓比例
    }
}
```
