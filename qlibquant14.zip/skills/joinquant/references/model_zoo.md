# 模型库参考

## 模型接口

所有 Qlib 模型遵循统一接口：

```python
class Model:
    def fit(self, dataset: DatasetH, reweighter=None):
        """训练模型"""
        ...

    def predict(self, dataset: DatasetH, segment="test"):
        """预测，返回 pd.Series，MultiIndex(datetime, instrument)"""
        ...
```

## 内置模型

### LGBModel（LightGBM）

最常用的基线模型，训练快、效果好：

```python
model_config = {
    "class": "LGBModel",
    "module_path": "qlib.contrib.model.gbdt",
    "kwargs": {
        "loss": "mse",
        "colsample_bytree": 0.8879,
        "learning_rate": 0.0421,
        "subsample": 0.8789,
        "lambda_l1": 205.6999,
        "lambda_l2": 580.9768,
        "max_depth": 8,
        "num_leaves": 210,
        "num_threads": 20
    }
}
```

关键超参：
- `loss`: "mse"（回归）或 "binary"（分类）
- `num_leaves`: 叶子数，越大越复杂（推荐 128~256）
- `max_depth`: 最大深度（-1 不限制，推荐 6~10）
- `learning_rate`: 学习率（推荐 0.01~0.1）
- `num_threads`: 并行线程数

### XGBModel（XGBoost）

```python
model_config = {
    "class": "XGBModel",
    "module_path": "qlib.contrib.model.xgboost",
    "kwargs": {
        "max_depth": 8,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "n_estimators": 1000,
        "early_stopping_rounds": 50,
        "eval_metric": "rmse"
    }
}
```

### CatBoostModel

```python
model_config = {
    "class": "CatBoostModel",
    "module_path": "qlib.contrib.model.catboost_model",
    "kwargs": {
        "loss_function": "RMSE",
        "depth": 8,
        "learning_rate": 0.05,
        "iterations": 1000,
        "verbose": False
    }
}
```

### LinearModel

```python
model_config = {
    "class": "LinearModel",
    "module_path": "qlib.contrib.model.linear",
    "kwargs": {
        "estimator": "ols"  # "ols", "ridge", "lasso"
    }
}
```

### LSTM

需要 TSDatasetH（时序数据集）：

```python
model_config = {
    "class": "LSTM",
    "module_path": "qlib.contrib.model.pytorch_lstm",
    "kwargs": {
        "d_feat": 158,          # 特征维度（Alpha158 = 158）
        "hidden_size": 64,
        "num_layers": 2,
        "dropout": 0.0,
        "n_epochs": 200,
        "lr": 0.001,
        "early_stop": 20,
        "batch_size": 800,
        "metric": "loss",
        "loss": "mse",
        "GPU": 0               # GPU 编号，-1 为 CPU
    }
}

# 配套 TSDatasetH
dataset_config = {
    "class": "TSDatasetH",
    "module_path": "qlib.data.dataset",
    "kwargs": {
        "handler": handler_config,
        "segments": {...},
        "step_len": 20          # 回溯窗口
    }
}
```

### GRU

```python
model_config = {
    "class": "GRU",
    "module_path": "qlib.contrib.model.pytorch_gru",
    "kwargs": {
        "d_feat": 158,
        "hidden_size": 64,
        "num_layers": 2,
        "dropout": 0.0,
        "n_epochs": 200,
        "lr": 0.001,
        "early_stop": 20,
        "batch_size": 800,
        "metric": "loss",
        "GPU": 0
    }
}
```

### Transformer

```python
model_config = {
    "class": "Transformer",
    "module_path": "qlib.contrib.model.pytorch_transformer",
    "kwargs": {
        "d_feat": 158,
        "d_model": 64,
        "nhead": 2,
        "num_layers": 2,
        "dropout": 0.0,
        "n_epochs": 200,
        "lr": 0.0001,
        "early_stop": 20,
        "batch_size": 800,
        "metric": "loss",
        "GPU": 0
    }
}
```

### 双重集成模型（DEnsemble）

```python
model_config = {
    "class": "DEnsembleModel",
    "module_path": "qlib.contrib.model.double_ensemble",
    "kwargs": {
        "base_model": "gbm",
        "loss": "mse",
        "num_models": 6,
        "enable_sr": True,
        "enable_fs": True,
        "alpha1": 1,
        "alpha2": 1,
        "bins_sr": 10,
        "bins_fs": 5
    }
}
```

## 自定义模型

### 基本模板

```python
from qlib.model.base import Model
from qlib.data.dataset import DatasetH
import pandas as pd
import numpy as np

class MyModel(Model):
    def __init__(self, param1=10, param2=0.01, **kwargs):
        self.param1 = param1
        self.param2 = param2
        self._model = None

    def fit(self, dataset: DatasetH, reweighter=None):
        df_train = dataset.prepare("train", col_set=["feature", "label"], data_key="learn")
        X_train = df_train["feature"].values
        y_train = df_train["label"].iloc[:, 0].values

        # 可选：使用 validation set 做 early stopping
        df_valid = dataset.prepare("valid", col_set=["feature", "label"], data_key="learn")
        X_valid = df_valid["feature"].values
        y_valid = df_valid["label"].iloc[:, 0].values

        # 训练你的模型
        self._model = train_my_model(X_train, y_train, X_valid, y_valid)
        return self

    def predict(self, dataset: DatasetH, segment="test"):
        df_test = dataset.prepare(segment, col_set="feature", data_key="infer")
        if isinstance(df_test, dict):
            X_test = df_test["feature"]
        else:
            X_test = df_test
        predictions = self._model.predict(X_test.values)
        return pd.Series(predictions, index=X_test.index)
```

### 注册自定义模型

在 YAML 中使用自定义模型：

```yaml
task:
    model:
        class: MyModel
        module_path: my_package.my_module
        kwargs:
            param1: 20
            param2: 0.005
```

确保 `my_package.my_module` 在 Python path 中可导入。

## 模型训练技巧

### Early Stopping

所有深度学习模型支持 `early_stop` 参数：

```python
"kwargs": {
    "n_epochs": 200,
    "early_stop": 20,    # 20 个 epoch 无改善则停止
    "metric": "loss"     # 监控指标
}
```

### GPU 使用

```python
"kwargs": {
    "GPU": 0    # 使用第 0 号 GPU
    # "GPU": -1  # 使用 CPU
}
```

### 样本加权（Reweighter）

```python
from qlib.model.trainer import task_train

# 使用时间衰减加权（近期样本权重更高）
reweighter_config = {
    "class": "Reweighter",
    "module_path": "qlib.model.trainer",
    "kwargs": {
        "method": "time_decay",
        "decay": 0.99
    }
}
```

## Rolling Train（滚动训练）

模拟真实场景中的定期重训练：

```python
from qlib.workflow.task.gen import RollingGen

rolling_gen = RollingGen(
    step=20,                # 每 20 个交易日滚动一次
    rtype="expanding"       # "expanding"（扩展窗口）或 "sliding"（滑动窗口）
)

# 生成多个 task
base_task = {
    "model": model_config,
    "dataset": dataset_config,
    "record": record_config
}

tasks = rolling_gen(base_task)
# 每个 task 的 train/valid/test 时间窗口自动调整
```

### 滚动训练完整流程

```python
from qlib.workflow import R
from qlib.workflow.task.gen import RollingGen
from qlib.workflow.task.manage import TaskManager
from qlib.model.trainer import task_train

# 1. 生成滚动任务
rolling_gen = RollingGen(step=20, rtype="expanding")
tasks = rolling_gen(base_task)

# 2. 逐个训练
for task in tasks:
    with R.start(experiment_name="rolling_exp"):
        model = init_instance_by_config(task["model"])
        dataset = init_instance_by_config(task["dataset"])
        model.fit(dataset)
        pred = model.predict(dataset, segment="test")
        R.save_objects(**{"pred.pkl": pred})
```

## 模型对比基准

Qlib 官方 benchmark（CSI300，2017-2020 测试期）：

| 模型 | IC | ICIR | 年化收益 | 年化超额 | 最大回撤 |
|------|-----|------|----------|----------|----------|
| Linear | 0.020 | 0.15 | - | - | - |
| LightGBM | 0.040 | 0.35 | ~15% | ~10% | ~15% |
| XGBoost | 0.038 | 0.33 | ~14% | ~9% | ~16% |
| CatBoost | 0.039 | 0.34 | ~14% | ~9% | ~15% |
| LSTM | 0.035 | 0.30 | ~12% | ~7% | ~18% |
| GRU | 0.036 | 0.31 | ~13% | ~8% | ~17% |
| Transformer | 0.038 | 0.33 | ~14% | ~9% | ~16% |
| ALSTM | 0.042 | 0.37 | ~16% | ~11% | ~14% |

注意：以上为参考值，实际结果受数据源、时间段、超参影响。
