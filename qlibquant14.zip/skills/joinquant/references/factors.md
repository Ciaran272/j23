# 因子研究与 Expression Engine 参考

## Expression Engine 概述

Qlib 的表达式引擎是定义因子的核心工具。使用字符串表达式描述因子计算逻辑，引擎自动处理时间对齐、缓存和并行计算。

## 字段引用

| 语法 | 含义 |
|------|------|
| `$close` | 收盘价 |
| `$open` | 开盘价 |
| `$high` | 最高价 |
| `$low` | 最低价 |
| `$volume` | 成交量 |
| `$vwap` | 成交均价 |
| `$change` | 涨跌幅 |
| `$factor` | 复权因子 |

自定义字段同样用 `$fieldname` 引用。

## 算子完整列表

### 时间序列算子

| 算子 | 语法 | 说明 |
|------|------|------|
| Ref | `Ref($close, n)` | n 天前的值（n>0 过去，n<0 未来） |
| Mean | `Mean($close, n)` | n 日滚动均值 |
| Sum | `Sum($volume, n)` | n 日滚动求和 |
| Std | `Std($close, n)` | n 日滚动标准差 |
| Var | `Var($close, n)` | n 日滚动方差 |
| Max | `Max($high, n)` | n 日滚动最大值 |
| Min | `Min($low, n)` | n 日滚动最小值 |
| Med | `Med($close, n)` | n 日滚动中位数 |
| Delta | `Delta($close, n)` | 当前值 - n 天前的值 |
| Slope | `Slope($close, n)` | n 日线性回归斜率 |
| Rsquare | `Rsquare($close, n)` | n 日线性回归 R² |
| Resi | `Resi($close, n)` | n 日线性回归残差 |
| Corr | `Corr($close, $volume, n)` | n 日滚动相关系数 |
| Cov | `Cov($close, $volume, n)` | n 日滚动协方差 |
| Skew | `Skew($close, n)` | n 日滚动偏度 |
| Kurt | `Kurt($close, n)` | n 日滚动峰度 |
| WMA | `WMA($close, n)` | 加权移动平均 |
| EMA | `EMA($close, n)` | 指数移动平均 |
| Quantile | `Quantile($close, n, q)` | n 日滚动分位数（q∈[0,1]） |
| TsRank | `TsRank($close, n)` | 时间序列排名（当前值在过去 n 日中的排名） |
| TsMax | `TsMax($close, n)` | 同 Max |
| TsMin | `TsMin($close, n)` | 同 Min |
| IdxMax | `IdxMax($close, n)` | 最大值出现的位置（距今天数） |
| IdxMin | `IdxMin($close, n)` | 最小值出现的位置 |
| Count | `Count($close > Ref($close, 1), n)` | n 日内条件为真的天数 |

### 截面算子

| 算子 | 语法 | 说明 |
|------|------|------|
| Rank | `Rank($close)` | 截面百分位排名（0~1） |
| CSRank | `CSRank($close)` | 截面排名（同 Rank） |

### 数学算子

| 算子 | 语法 | 说明 |
|------|------|------|
| Abs | `Abs(expr)` | 绝对值 |
| Sign | `Sign(expr)` | 符号函数（-1/0/1） |
| Log | `Log(expr)` | 自然对数 |
| Power | `Power(expr, n)` | 幂运算 |
| Sqrt | `Power(expr, 0.5)` | 平方根 |

### 条件算子

| 算子 | 语法 | 说明 |
|------|------|------|
| If | `If(cond, true_val, false_val)` | 条件选择 |
| Greater | `$close > $open` | 大于（返回 0/1） |
| Less | `$close < $open` | 小于 |
| And | `($close > $open) & ($volume > Mean($volume, 5))` | 逻辑与 |
| Or | `($close > $open) \| ($volume > Mean($volume, 5))` | 逻辑或 |

### 算术运算

```python
"$close + $open"          # 加
"$close - $open"          # 减
"$close * $volume"        # 乘
"$close / $open"          # 除
"$close / Ref($close, 1) - 1"  # 日收益率
```

## Alpha101 的 Qlib 表达式实现

WorldQuant 101 Alphas 的 Qlib Expression Engine 翻译。原始论文使用伪代码，下面给出可直接在 Qlib 中使用的表达式。

### 算子映射（WQ101 → Qlib）

| WQ101 伪代码 | Qlib 表达式 |
|---|---|
| `rank(x)` | `Rank(x)` |
| `delay(x, d)` | `Ref(x, d)` |
| `delta(x, d)` | `Delta(x, d)` |
| `correlation(x, y, d)` | `Corr(x, y, d)` |
| `covariance(x, y, d)` | `Cov(x, y, d)` |
| `ts_rank(x, d)` | `TsRank(x, d)` |
| `ts_min(x, d)` | `Min(x, d)` |
| `ts_max(x, d)` | `Max(x, d)` |
| `ts_argmax(x, d)` | `IdxMax(x, d)` |
| `ts_argmin(x, d)` | `IdxMin(x, d)` |
| `sum(x, d)` | `Sum(x, d)` |
| `stddev(x, d)` | `Std(x, d)` |
| `product(x, d)` | 无直接算子，用 `Log` + `Sum` + `Power` 近似 |
| `returns` | `$close / Ref($close, 1) - 1` |
| `vwap` | `$vwap` |
| `adv{d}` | `Mean($volume, d)` |
| `abs(x)` | `Abs(x)` |
| `log(x)` | `Log(x)` |
| `sign(x)` | `Sign(x)` |
| `signedpower(x, a)` | `Sign(x) * Power(Abs(x), a)` |
| `scale(x)` | 需后处理，表达式内无法实现 |
| `decay_linear(x, d)` | `WMA(x, d)` |
| `indneutralize(x, g)` | 需后处理（行业中性化） |

### Alpha101 精选实现（20 个代表性因子）

```python
ALPHA101_QLIB = {
    # Alpha#1: (rank(Ts_ArgMax(SignedPower(((returns < 0) ? stddev(returns, 20) : close), 2.), 5)) - 0.5)
    "alpha001": "Rank(IdxMax(Power(If($close/Ref($close,1)-1 < 0, Std($close/Ref($close,1)-1, 20), $close), 2), 5)) - 0.5",

    # Alpha#2: (-1 * correlation(rank(delta(log(volume), 2)), rank(((close - open) / open)), 6))
    "alpha002": "-1 * Corr(Rank(Delta(Log($volume), 2)), Rank(($close - $open) / $open), 6)",

    # Alpha#3: (-1 * correlation(rank(open), rank(volume), 10))
    "alpha003": "-1 * Corr(Rank($open), Rank($volume), 10)",

    # Alpha#4: (-1 * Ts_Rank(rank(low), 9))
    "alpha004": "-1 * TsRank(Rank($low), 9)",

    # Alpha#5: (rank((open - (sum(vwap, 10) / 10))) * (-1 * abs(rank((close - vwap)))))
    "alpha005": "Rank($open - Mean($vwap, 10)) * (-1 * Abs(Rank($close - $vwap)))",

    # Alpha#6: (-1 * correlation(open, volume, 10))
    "alpha006": "-1 * Corr($open, $volume, 10)",

    # Alpha#8: (-1 * rank(((sum(open, 5) * sum(returns, 5)) - delay((sum(open, 5) * sum(returns, 5)), 10))))
    "alpha008": "-1 * Rank(Sum($open, 5) * Sum($close/Ref($close,1)-1, 5) - Ref(Sum($open, 5) * Sum($close/Ref($close,1)-1, 5), 10))",

    # Alpha#9: if(ts_min(delta(close,1),5) > 0, delta(close,1), if(ts_max(delta(close,1),5) < 0, delta(close,1), -delta(close,1)))
    "alpha009": "If(Min(Delta($close,1), 5) > 0, Delta($close,1), If(Max(Delta($close,1), 5) < 0, Delta($close,1), -1*Delta($close,1)))",

    # Alpha#10: rank(if(ts_min(delta(close,1),4) > 0, delta(close,1), if(ts_max(delta(close,1),4) < 0, delta(close,1), -delta(close,1))))
    "alpha010": "Rank(If(Min(Delta($close,1), 4) > 0, Delta($close,1), If(Max(Delta($close,1), 4) < 0, Delta($close,1), -1*Delta($close,1))))",

    # Alpha#12: (sign(delta(volume, 1)) * (-1 * delta(close, 1)))
    "alpha012": "Sign(Delta($volume, 1)) * (-1 * Delta($close, 1))",

    # Alpha#13: (-1 * rank(covariance(rank(close), rank(volume), 5)))
    "alpha013": "-1 * Rank(Cov(Rank($close), Rank($volume), 5))",

    # Alpha#14: ((-1 * rank(delta(returns, 3))) * correlation(open, volume, 10))
    "alpha014": "-1 * Rank(Delta($close/Ref($close,1)-1, 3)) * Corr($open, $volume, 10)",

    # Alpha#15: (-1 * sum(rank(correlation(rank(high), rank(volume), 3)), 3))
    "alpha015": "-1 * Sum(Rank(Corr(Rank($high), Rank($volume), 3)), 3)",

    # Alpha#16: (-1 * rank(covariance(rank(high), rank(volume), 5)))
    "alpha016": "-1 * Rank(Cov(Rank($high), Rank($volume), 5))",

    # Alpha#17: (((-1 * rank(ts_rank(close, 10))) * rank(delta(delta(close, 1), 1))) * rank(ts_rank((volume / adv20), 5)))
    "alpha017": "-1 * Rank(TsRank($close, 10)) * Rank(Delta(Delta($close, 1), 1)) * Rank(TsRank($volume / Mean($volume, 20), 5))",

    # Alpha#18: (-1 * rank(((stddev(abs((close - open)), 5) + (close - open)) + correlation(close, open, 10))))
    "alpha018": "-1 * Rank(Std(Abs($close - $open), 5) + ($close - $open) + Corr($close, $open, 10))",

    # Alpha#20: (((-1 * rank((open - delay(high, 1)))) * rank((open - delay(close, 1)))) * rank((open - delay(low, 1))))
    "alpha020": "-1 * Rank($open - Ref($high, 1)) * Rank($open - Ref($close, 1)) * Rank($open - Ref($low, 1))",

    # Alpha#21: mean(close, 8) + std(close, 8) < mean(close, 2) 条件型
    "alpha021": "If(Mean($close, 8) + Std($close, 8) < Mean($close, 2), -1, If(Mean($close, 2) < Mean($close, 8) - Std($close, 8), 1, If($volume/Mean($volume,20) < 1, -1, 1)))",

    # Alpha#22: (-1 * (delta(correlation(high, volume, 5), 5) * rank(stddev(close, 20))))
    "alpha022": "-1 * Delta(Corr($high, $volume, 5), 5) * Rank(Std($close, 20))",

    # Alpha#24: if(delta(mean(close,100),100)/delay(close,100) <= 0.05, -(close-ts_min(close,100)), delta(close,3))
    "alpha024": "If(Delta(Mean($close,100), 100) / Ref($close, 100) <= 0.05, -1*($close - Min($close, 100)), Delta($close, 3))",
}
```

### 使用方式

```python
import qlib
from qlib.data import D

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

# 单个因子
instruments = D.instruments(market="csi300")
df = D.features(instruments, fields=[ALPHA101_QLIB["alpha001"]], start_time="2020-01-01", end_time="2020-12-31")

# 批量因子
fields = list(ALPHA101_QLIB.values())
names = list(ALPHA101_QLIB.keys())
df = D.features(instruments, fields=fields, start_time="2020-01-01", end_time="2020-12-31")
df.columns = names
```

### 构建自定义 DataHandler

```python
custom_alpha_handler = {
    "class": "DataHandlerLP",
    "module_path": "qlib.data.dataset.handler",
    "kwargs": {
        "start_time": "2010-01-01",
        "end_time": "2020-12-31",
        "fit_start_time": "2010-01-01",
        "fit_end_time": "2017-12-31",
        "instruments": "csi300",
        "data_loader": {
            "class": "QlibDataLoader",
            "kwargs": {
                "config": {
                    "feature": (
                        list(ALPHA101_QLIB.values())[:20],
                        list(ALPHA101_QLIB.keys())[:20]
                    ),
                    "label": (
                        ["Ref($close, -2) / Ref($close, -1) - 1"],
                        ["label"]
                    )
                },
                "freq": "day"
            }
        },
        "infer_processors": [
            {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
            {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
        ],
        "learn_processors": [
            {"class": "DropnaLabel"},
            {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
        ]
    }
}
```

## GTJA-191 精选实现（20 个代表性因子）

国泰君安 191 短周期价量因子的 Qlib 表达式翻译：

```python
GTJA191_QLIB = {
    # Alpha#1: (-1 * Corr(Rank(Delta(Log(Volume), 1)), Rank(((Close-Open)/Open)), 6))
    "gtja001": "-1 * Corr(Rank(Delta(Log($volume), 1)), Rank(($close - $open) / $open), 6)",

    # Alpha#2: -1 * Delta((((Close-Low)-(High-Close)) / (High-Low)), 1)
    "gtja002": "-1 * Delta(((($close-$low)-($high-$close))/($high-$low)), 1)",

    # Alpha#3: Sum(If(Close == Ref(Close,1), 0, If(Close > Ref(Close,1), Close-Min(Low,Ref(Close,1)), Close-Max(High,Ref(Close,1)))), 6)
    "gtja003": "Sum(If($close > Ref($close,1), $close - If($low < Ref($close,1), $low, Ref($close,1)), If($close < Ref($close,1), $close - If($high > Ref($close,1), $high, Ref($close,1)), 0)), 6)",

    # Alpha#4: If(Mean(Volume,8) < Mean(Volume,20) & ...) 条件型
    "gtja004": "If((Mean($volume,8) < Mean($volume,20)) & (Std($close,8) < Std($close,20)), -1, If(Mean($volume,8) >= Mean($volume,20), -1, 1))",

    # Alpha#5: -1 * TsMax(Corr(TsRank(Volume, 5), TsRank(High, 5), 5), 3)
    "gtja005": "-1 * Max(Corr(TsRank($volume, 5), TsRank($high, 5), 5), 3)",

    # Alpha#6: Rank(Sign(Delta(Open*0.85 + High*0.15, 4))) * -1
    "gtja006": "-1 * Rank(Sign(Delta($open*0.85 + $high*0.15, 4)))",

    # Alpha#7: (Rank(Max(Vwap-Close, 3)) + Rank(Min(Vwap-Close, 3))) * Rank(Delta(Volume, 3))
    "gtja007": "(Rank(Max($vwap - $close, 3)) + Rank(Min($vwap - $close, 3))) * Rank(Delta($volume, 3))",

    # Alpha#8: Rank(Delta((High+Low)/2*0.2 + Vwap*0.8, 4) * -1)
    "gtja008": "Rank(Delta(($high+$low)/2*0.2 + $vwap*0.8, 4) * -1)",

    # Alpha#9: EMA(((High+Low)/2 - (Ref(High,1)+Ref(Low,1))/2) * (High-Low) / Volume, 7)
    "gtja009": "EMA((($high+$low)/2 - (Ref($high,1)+Ref($low,1))/2) * ($high-$low) / $volume, 7)",

    # Alpha#10: Rank(Max(Power(If(Ret<0, Std(Ret,20), Close), 2), 5))
    "gtja010": "Rank(Max(Power(If($close/Ref($close,1)-1 < 0, Std($close/Ref($close,1)-1, 20), $close), 2), 5))",

    # Alpha#11: Sum(((Close-Low)-(High-Close))/(High-Low) * Volume, 6)
    "gtja011": "Sum((($close-$low)-($high-$close))/($high-$low) * $volume, 6)",

    # Alpha#12: Rank(Open - Mean(Vwap, 10)) * Rank(Abs(Close - Vwap)) * -1
    "gtja012": "Rank($open - Mean($vwap, 10)) * Rank(Abs($close - $vwap)) * -1",

    # Alpha#13: (High * Low)^0.5 - Vwap
    "gtja013": "Power($high * $low, 0.5) - $vwap",

    # Alpha#14: Close - Ref(Close, 5)
    "gtja014": "$close - Ref($close, 5)",

    # Alpha#15: Open / Ref(Close, 1) - 1
    "gtja015": "$open / Ref($close, 1) - 1",

    # Alpha#16: -1 * Rank(Cov(Rank(Volume), Rank(Close), 5))
    "gtja016": "-1 * Rank(Cov(Rank($volume), Rank($close), 5))",

    # Alpha#17: Rank(Vwap - Max(Vwap, 15))^Delta(Close, 5)
    "gtja017": "Power(Rank($vwap - Max($vwap, 15)), Delta($close, 5))",

    # Alpha#18: Close / Ref(Close, 5)
    "gtja018": "$close / Ref($close, 5)",

    # Alpha#19: If(Close == Ref(Close,5), 0, (Close - Ref(Close,5)) / Ref(Close,5))
    "gtja019": "If($close == Ref($close,5), 0, ($close - Ref($close,5)) / Ref($close,5))",

    # Alpha#20: (Close - Ref(Close, 6)) / Ref(Close, 6) * 100
    "gtja020": "($close - Ref($close, 6)) / Ref($close, 6) * 100",
}
```

## 自定义因子开发

### 方式一：表达式组合

```python
my_factors = {
    "feature": (
        [
            # 动量类
            "$close / Ref($close, 5) - 1",
            "$close / Ref($close, 20) - 1",
            "$close / Ref($close, 60) - 1",
            # 波动率类
            "Std($close / Ref($close, 1) - 1, 20)",
            "Std($close / Ref($close, 1) - 1, 60)",
            # 流动性类
            "$volume / Mean($volume, 20)",
            "Mean($volume * $close, 5) / Mean($volume * $close, 20)",
            # 价格形态
            "($close - Min($low, 20)) / (Max($high, 20) - Min($low, 20))",
            "($high - $low) / $close",
            # 价量关系
            "Corr($close, $volume, 10)",
            "Corr($close / Ref($close, 1) - 1, $volume / Ref($volume, 1) - 1, 20)",
        ],
        ["mom5", "mom20", "mom60", "vol20", "vol60",
         "liquidity", "turnover_ratio", "price_position",
         "intraday_range", "pv_corr10", "ret_vol_corr20"]
    ),
    "label": (
        ["Ref($close, -2) / Ref($close, -1) - 1"],
        ["label"]
    )
}
```

### 方式二：继承 DataHandler

```python
from qlib.contrib.data.handler import Alpha158

class MyAlphaHandler(Alpha158):
    def get_feature_config(self):
        fields, names = super().get_feature_config()
        # 添加自定义因子
        extra_fields = [
            "Corr($close, $volume, 10)",
            "$close / Mean($close, 60) - 1",
        ]
        extra_names = ["pv_corr_10", "price_to_ma60"]
        return fields + extra_fields, names + extra_names
```

### 方式三：Python 函数因子（高级）

对于表达式引擎无法表达的复杂逻辑：

```python
import numpy as np
import pandas as pd
from qlib.data import D

def compute_custom_factor(instruments, start_time, end_time):
    """计算表达式引擎无法直接表达的因子"""
    df = D.features(
        instruments,
        fields=["$close", "$volume", "$high", "$low"],
        start_time=start_time,
        end_time=end_time
    )
    # 自定义计算逻辑
    result = df.groupby(level="instrument").apply(my_complex_logic)
    return result
```

## 因子分析

### IC 分析

```python
from qlib.data import D
import pandas as pd
import numpy as np

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

instruments = D.instruments(market="csi300")

# 获取因子值和未来收益
fields = ["$close / Ref($close, 5) - 1"]  # 5日动量因子
df = D.features(instruments, fields=fields, start_time="2015-01-01", end_time="2020-12-31")
df.columns = ["factor"]

# 计算未来收益
ret_fields = ["Ref($close, -5) / $close - 1"]
df_ret = D.features(instruments, fields=ret_fields, start_time="2015-01-01", end_time="2020-12-31")
df_ret.columns = ["future_ret"]

# 合并
merged = pd.concat([df, df_ret], axis=1).dropna()

# 计算每日截面 IC
ic_series = merged.groupby(level="datetime").apply(
    lambda x: x["factor"].corr(x["future_ret"])
)

print(f"IC 均值: {ic_series.mean():.4f}")
print(f"IC 标准差: {ic_series.std():.4f}")
print(f"ICIR: {ic_series.mean() / ic_series.std():.4f}")
print(f"IC > 0 占比: {(ic_series > 0).mean():.2%}")
```

### 使用 Qlib 内置分析

通过 workflow 的 `SigAnaRecord` 自动生成：

```yaml
record:
    - class: SigAnaRecord
      module_path: qlib.workflow.record_temp
      kwargs:
          ana_long_short: True    # 多空分析
          ann_scaler: 252         # 年化系数
```

输出指标：
- IC / Rank IC（日频）
- ICIR
- 多空组合年化收益
- 多空组合夏普比率
- 信号自相关（衡量换手）

## 因子预处理最佳实践

```python
infer_processors = [
    # 1. 去极值（MAD 方法，比 3σ 更鲁棒）
    {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
    # 2. 填充缺失值
    {"class": "Fillna", "kwargs": {"fields_group": "feature", "fill_value": 0}},
]

learn_processors = [
    # 标签处理
    {"class": "DropnaLabel"},
    # 标签截面排名（将回归问题转为排序问题，通常效果更好）
    {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}},
]
```

### 行业中性化（需自定义）

Qlib 表达式引擎不直接支持行业中性化，需要在 Processor 层实现：

```python
from qlib.data.dataset.processor import Processor
import pandas as pd

class IndustryNeutralize(Processor):
    def __init__(self, industry_field="$industry", fields_group="feature"):
        self.industry_field = industry_field
        self.fields_group = fields_group

    def __call__(self, df):
        # 按行业分组去均值
        features = df[self.fields_group]
        industry = df[self.industry_field]
        neutralized = features.groupby(industry).transform(lambda x: x - x.mean())
        df[self.fields_group] = neutralized
        return df
```
