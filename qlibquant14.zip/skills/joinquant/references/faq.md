# 常见问题与排错

## 安装问题

### pip install pyqlib 失败

```
ERROR: Could not build wheels for pyqlib
```

解决：
1. 确保 Python >= 3.8
2. 安装编译工具：`pip install cython numpy` 先装
3. Windows 需要 Visual C++ Build Tools
4. 或使用 conda：`conda install -c conda-forge pyqlib`

### import qlib 报错 ModuleNotFoundError

```python
# 确认安装位置
pip show pyqlib
# 确认 Python 环境一致
which python  # 或 where python (Windows)
```

## 数据问题

### qlib.init() 报 FileNotFoundError

```
FileNotFoundError: [Errno 2] No such file or directory: '~/.qlib/qlib_data/cn_data/calendars/day.txt'
```

原因：数据目录不存在或路径错误。

解决：
```python
import os
# 检查路径是否存在
print(os.path.exists(os.path.expanduser("~/.qlib/qlib_data/cn_data")))

# Windows 下 ~ 展开可能有问题，用绝对路径
qlib.init(provider_uri=r"C:\Users\username\.qlib\qlib_data\cn_data", region="cn")
```

### D.features() 返回全 NaN

可能原因：
1. 股票代码格式错误（应为 `SH600519` 而非 `600519.XSHG`）
2. 时间范围超出数据覆盖范围
3. instruments 文件中该股票的时间范围不包含查询时间

```python
# 调试
instruments = D.list_instruments(D.instruments(market="all"), as_list=True)
print(f"数据中共 {len(instruments)} 只股票")
print(instruments[:10])  # 查看代码格式
```

### 数据更新后缓存不一致

```bash
# 清除表达式缓存
rm -rf ~/.qlib/qlib_data/cn_data/feature_cache/

# 或在代码中
import shutil
shutil.rmtree(os.path.expanduser("~/.qlib/qlib_data/cn_data/feature_cache/"), ignore_errors=True)
```

### 社区数据源下载失败

```bash
# GitHub release 下载慢，使用镜像
# 方式一：手动从 release 页面下载
# https://github.com/chenditc/investment_data/releases

# 方式二：使用代理
export https_proxy=http://127.0.0.1:7890
wget https://github.com/chenditc/investment_data/releases/latest/download/qlib_bin.tar.gz
```

## 模型训练问题

### LightGBM 训练时 warning: No further splits

原因：数据量太少或特征区分度不够。

解决：
- 增加训练数据时间跨度
- 减小 `min_data_in_leaf`
- 检查特征是否有大量 NaN

### LSTM/Transformer 训练 loss 不下降

检查项：
1. 学习率是否太大：尝试 `lr=0.0001`
2. 数据是否正确标准化：确保 `infer_processors` 包含 `RobustZScoreNorm`
3. GPU 内存是否足够：减小 `batch_size`
4. `step_len` 是否合理：通常 20~60

### GPU 内存不足 (CUDA out of memory)

```python
# 减小 batch_size
"batch_size": 400  # 从 800 减到 400

# 或使用 CPU
"GPU": -1
```

### 模型预测全为相同值

可能原因：
- 训练数据标签全为 NaN（忘了 `DropnaLabel`）
- 特征全为常数（标准化后全为 0）
- 模型未收敛

```python
# 检查数据
df = dataset.prepare("train", col_set=["feature", "label"], data_key="learn")
print(df["label"].describe())
print(df["feature"].describe())
```

## 回测问题

### backtest_daily 报 KeyError

```
KeyError: 'SH600519'
```

原因：预测结果中的股票代码与数据中的不匹配。

检查：
```python
print(predictions.index.get_level_values("instrument").unique()[:10])
# 确认格式为 SH600519 而非 600519.XSHG
```

### 回测收益异常高

检查清单：
1. 是否有未来数据（feature 中的负 Ref）
2. `limit_threshold` 是否设置（不设置 = 无涨跌停限制）
3. 费率是否设置（不设置 = 零费率）
4. 是否使用了未来成分股

### 回测换手率过高

```python
# 检查换手
print(f"日均换手: {report_df['turnover'].mean():.2%}")
print(f"年化换手: {report_df['turnover'].mean() * 252:.1f} 倍")

# 降低换手
# 方式一：减小 n_drop
"n_drop": 3  # 每日最多换 3 只

# 方式二：增大 topk
"topk": 100  # 持仓更分散
```

## 性能问题

### D.features() 计算很慢

1. 首次计算会慢（需要构建缓存），后续会快很多
2. 减少表达式复杂度（嵌套层数）
3. 缩小时间范围或股票数量进行测试
4. 增加 `kernels` 参数：`qlib.init(..., kernels=4)`

### 内存不足 (MemoryError)

```python
# 分批处理
import pandas as pd

all_preds = []
for year in range(2017, 2021):
    dataset_config["kwargs"]["segments"]["test"] = (f"{year}-01-01", f"{year}-12-31")
    dataset = init_instance_by_config(dataset_config)
    pred = model.predict(dataset, segment="test")
    all_preds.append(pred)

predictions = pd.concat(all_preds)
```

## 版本兼容

### Qlib 版本升级后代码报错

常见变更：
- `qlib.contrib.evaluate.backtest` → `qlib.contrib.evaluate.backtest_daily`（0.9+）
- `DataHandlerLP` 参数名变化
- Record 类路径变化

建议：固定版本 `pip install pyqlib==0.9.5`

### pandas 版本冲突

Qlib 对 pandas 版本有要求：
- Qlib 0.9.x：pandas >= 1.3, < 2.0
- Qlib 最新：pandas >= 1.5

```bash
pip install "pandas>=1.5,<2.0"
```

## 常见错误信息速查

| 错误 | 原因 | 解决 |
|------|------|------|
| `ValueError: No data` | 查询时间范围无数据 | 检查时间范围和 instruments |
| `KeyError: 'feature'` | DataHandler 配置错误 | 检查 data_loader config 格式 |
| `RuntimeError: CUDA error` | GPU 问题 | 设 GPU=-1 或减小 batch |
| `FileNotFoundError: calendars` | 数据目录错误 | 检查 provider_uri 路径 |
| `TypeError: unhashable type` | instruments 格式错误 | 用 D.instruments() 而非字符串 |
| `IndexError: index out of range` | step_len > 数据长度 | 减小 step_len 或增加数据 |
