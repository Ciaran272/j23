# Qlib 安装与环境配置

## 安装

### 基础安装

```bash
pip install pyqlib
```

### 从源码安装（获取最新功能）

```bash
git clone https://github.com/microsoft/qlib.git
cd qlib
pip install -e .
```

### 依赖要求

- Python >= 3.8
- numpy, pandas, scipy, scikit-learn
- PyTorch（深度学习模型需要）
- LightGBM / XGBoost / CatBoost（对应模型需要）
- matplotlib（可视化）
- mlflow（实验管理，可选）

## 数据准备

### 方式一：社区数据源（A 股推荐）

chenditc/investment_data 提供每日更新的 A 股 qlib 格式数据：

```bash
wget https://github.com/chenditc/investment_data/releases/latest/download/qlib_bin.tar.gz
mkdir -p ~/.qlib/qlib_data/cn_data
tar -zxvf qlib_bin.tar.gz -C ~/.qlib/qlib_data/cn_data --strip-components=1
```

Windows 下可用 PowerShell：

```powershell
Invoke-WebRequest -Uri "https://github.com/chenditc/investment_data/releases/latest/download/qlib_bin.tar.gz" -OutFile qlib_bin.tar.gz
New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.qlib\qlib_data\cn_data"
tar -zxvf qlib_bin.tar.gz -C "$env:USERPROFILE\.qlib\qlib_data\cn_data" --strip-components=1
```

覆盖范围：全 A 股日频 OHLCV + 复权因子，约 2005 年至今。

### 方式二：Yahoo Finance（美股/港股）

```bash
python -m qlib.contrib.data.handler yahoo --source_dir ~/.qlib/qlib_data/us_data --region US --start 2000-01-01
```

或使用 Qlib 自带 collector：

```python
from qlib.contrib.data.collector.yahoo.collector import YahooCollector
# 详见 qlib/scripts/data_collector/yahoo/
```

### 方式三：自定义数据接入

将自有数据转为 Qlib 二进制格式：

```python
# 1. 准备 CSV 文件，每只股票一个文件，格式：
#    date, open, high, low, close, volume, factor (复权因子)
#    文件名为股票代码，如 SH600519.csv

# 2. 使用 dump_bin 工具转换
python scripts/dump_bin.py dump_all \
    --csv_path ./my_csv_data \
    --qlib_dir ~/.qlib/qlib_data/my_data \
    --freq day \
    --include_fields open,high,low,close,volume,factor \
    --date_field_name date \
    --symbol_field_name filename
```

CSV 格式要求：
- 必须包含 date 列（YYYY-MM-DD）
- 字段名小写：open, high, low, close, volume
- 复权因子字段 factor（前复权 = close * factor）
- 每只股票单独一个 CSV 文件，文件名即代码

### 方式四：从其他数据源转换

```python
import qlib
from qlib.data import D

# 如果已有 tushare/akshare/wind 数据，先导出为 CSV 再 dump_bin
# 关键：确保代码格式与 instruments 文件一致
# A 股代码格式：SH600519（上交所）、SZ000001（深交所）
```

## qlib.init() 初始化

每个脚本/notebook 开头必须调用：

```python
import qlib
qlib.init(
    provider_uri="~/.qlib/qlib_data/cn_data",  # 数据目录
    region="cn",                                  # "cn" 或 "us"
)
```

### 完整参数

```python
qlib.init(
    provider_uri="~/.qlib/qlib_data/cn_data",
    region="cn",
    exp_manager={
        "class": "MLflowExpManager",
        "module_path": "qlib.workflow.expm",
        "kwargs": {
            "uri": "file:./mlruns",
            "default_exp_name": "Experiment"
        }
    },
    redis_host="",              # Redis 缓存（可选，加速重复查询）
    redis_port=6379,
    kernels=1,                  # 数据处理并行数
    logging_level=20,           # logging.INFO = 20
)
```

### region 参数影响

| region | 交易日历 | 代码格式 | 涨跌停 |
|--------|----------|----------|--------|
| `"cn"` | A 股交易日 | SH600519 / SZ000001 | 10%/20%(创业板/科创板) |
| `"us"` | NYSE 交易日 | AAPL / MSFT | 无 |

## instruments 配置

Qlib 使用 instruments 文件定义股票池：

```
# ~/.qlib/qlib_data/cn_data/instruments/csi300.txt
# 格式：代码\t起始日期\t结束日期
SH600519	2005-01-01	2099-12-31
SZ000001	2005-01-01	2099-12-31
...
```

内置 instruments（cn_data）：
- `csi300` — 沪深 300 成分股
- `csi500` — 中证 500 成分股
- `csi800` — 中证 800
- `all` — 全 A 股

## 目录结构

```
~/.qlib/qlib_data/cn_data/
├── calendars/          # 交易日历
│   └── day.txt
├── instruments/        # 股票池定义
│   ├── all.txt
│   ├── csi300.txt
│   └── csi500.txt
├── features/           # 行情数据（二进制）
│   ├── SH600519/
│   │   ├── open.day.bin
│   │   ├── close.day.bin
│   │   ├── high.day.bin
│   │   ├── low.day.bin
│   │   └── volume.day.bin
│   └── ...
└── feature_cache/      # 表达式缓存（自动生成）
```

## 环境验证

```python
import qlib
from qlib.data import D

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

# 验证数据可用
instruments = D.instruments(market="csi300")
df = D.features(instruments, fields=["$close", "$volume"], start_time="2020-01-01", end_time="2020-01-10")
print(df.head())
print(f"数据形状: {df.shape}")
```

预期输出：MultiIndex DataFrame，index 为 (instrument, datetime)，columns 为 $close, $volume。
