# 数据源与数据查询参考

## D 模块（qlib.data.D）

`D` 是 Qlib 数据访问的统一入口，提供 instruments 查询和特征计算。

### D.instruments()

获取股票池：

```python
from qlib.data import D

# 获取内置股票池
instruments = D.instruments(market="csi300")
instruments = D.instruments(market="csi500")
instruments = D.instruments(market="all")  # 全 A 股

# 带时间过滤（只返回该时间段内存续的股票）
instruments = D.instruments(market="csi300", filter_pipe=[...])
```

返回值是 Qlib 内部的 instruments 对象，可直接传给 `D.features()`。

### D.features()

计算特征/因子值：

```python
df = D.features(
    instruments=instruments,       # instruments 对象或股票列表
    fields=["$close", "$volume", "Mean($close, 5)"],  # 表达式列表
    start_time="2020-01-01",
    end_time="2020-12-31",
    freq="day"                     # "day" 或 "1min"
)
```

返回值：`pd.DataFrame`，MultiIndex 为 `(instrument, datetime)`。

```python
# 也可以传股票列表
df = D.features(
    instruments=["SH600519", "SZ000001"],
    fields=["$close", "$volume"],
    start_time="2020-01-01",
    end_time="2020-12-31"
)
```

### D.calendar()

获取交易日历：

```python
cal = D.calendar(start_time="2020-01-01", end_time="2020-12-31", freq="day")
# 返回 list of pd.Timestamp
```

### D.list_instruments()

列出股票池中的具体代码：

```python
inst_dict = D.list_instruments(
    instruments=D.instruments(market="csi300"),
    start_time="2020-01-01",
    end_time="2020-12-31",
    as_list=True
)
# 返回 list of str: ["SH600519", "SZ000001", ...]
```

带时间范围时返回 dict：

```python
inst_dict = D.list_instruments(
    instruments=D.instruments(market="csi300"),
    start_time="2020-01-01",
    end_time="2020-12-31",
    as_list=False
)
# 返回 dict: {"SH600519": [("2020-01-01", "2020-12-31")], ...}
```

## A 股代码格式

| 市场 | 前缀 | 示例 |
|------|------|------|
| 上交所 | SH | SH600519（贵州茅台） |
| 深交所 | SZ | SZ000001（平安银行） |
| 创业板 | SZ | SZ300750（宁德时代） |
| 科创板 | SH | SH688981（中芯国际） |
| 北交所 | BJ | BJ430047 |

注意：Qlib 的代码格式与聚宽不同（聚宽用 `.XSHG`/`.XSHE` 后缀）。

## instruments 文件格式

位于 `<provider_uri>/instruments/` 目录下：

```
# csi300.txt
# 格式：代码<TAB>起始日期<TAB>结束日期
SH600519	2005-01-04	2099-12-31
SZ000001	2005-01-04	2099-12-31
SH601318	2007-03-01	2099-12-31
```

### 自定义股票池

创建自己的 instruments 文件：

```python
import pandas as pd

# 方式一：直接写文件
stocks = [
    ("SH600519", "2010-01-01", "2099-12-31"),
    ("SZ000858", "2010-01-01", "2099-12-31"),
    ("SH601318", "2010-01-01", "2099-12-31"),
]
df = pd.DataFrame(stocks, columns=["instrument", "start_time", "end_time"])
df.to_csv("~/.qlib/qlib_data/cn_data/instruments/my_pool.txt",
          sep="\t", index=False, header=False)

# 方式二：使用时直接传列表
instruments = ["SH600519", "SZ000858", "SH601318"]
df = D.features(instruments, fields=["$close"], start_time="2020-01-01", end_time="2020-12-31")
```

## 数据频率

| freq | 说明 | 数据字段 |
|------|------|----------|
| `"day"` | 日频 | open, high, low, close, volume, vwap, change, factor |
| `"1min"` | 1 分钟 | open, high, low, close, volume |

分钟数据需要单独下载和存储，目录结构相同但 bin 文件后缀不同。

## 数据字段

### 日频标准字段

| 字段 | 表达式引用 | 说明 |
|------|-----------|------|
| open | `$open` | 开盘价 |
| high | `$high` | 最高价 |
| low | `$low` | 最低价 |
| close | `$close` | 收盘价 |
| volume | `$volume` | 成交量（股） |
| vwap | `$vwap` | 成交均价 |
| change | `$change` | 涨跌幅 |
| factor | `$factor` | 复权因子 |

### 复权处理

Qlib 默认存储的是**不复权**价格。复权计算：

```python
# 前复权价格
"$close * $factor"

# 但通常不需要手动复权——
# 社区数据源（chenditc）已经是前复权数据
# 如果用原始不复权数据，在表达式中用 $close * $factor
```

## 自定义数据接入

### 添加额外字段

如果需要基本面数据、另类数据等非标准字段：

```python
# 1. 准备 CSV，包含额外字段
# SH600519.csv: date, open, high, low, close, volume, pe, pb, market_cap

# 2. dump_bin 时指定所有字段
# python scripts/dump_bin.py dump_all \
#     --csv_path ./data \
#     --qlib_dir ~/.qlib/qlib_data/cn_data \
#     --include_fields open,high,low,close,volume,pe,pb,market_cap

# 3. 使用时直接引用
df = D.features(instruments, fields=["$pe", "$pb", "$market_cap"])
```

### 数据更新

```bash
# 增量更新（只添加新日期的数据）
python scripts/dump_bin.py dump_update \
    --csv_path ./new_data \
    --qlib_dir ~/.qlib/qlib_data/cn_data \
    --freq day
```

### 多数据源合并

```python
# 如果有多个数据目录，可以配置多 provider
qlib.init(
    provider_uri={
        "day": "~/.qlib/qlib_data/cn_data",       # 日频行情
        "1min": "~/.qlib/qlib_data/cn_data_1min",  # 分钟行情
    },
    region="cn"
)
```

## 数据缓存

Qlib 自动缓存计算过的表达式结果：

```
~/.qlib/qlib_data/cn_data/feature_cache/
```

- 首次计算某表达式时会较慢
- 后续相同表达式直接读缓存
- 数据更新后需要清除缓存：`rm -rf feature_cache/`

### 性能基准

Alpha158（158 因子 × 800 股 × 13 年日频）：
- 首次计算：~7.4 秒（有 ExpressionCache + DatasetCache）
- 缓存命中：< 1 秒
- 对比 HDF5：~184 秒
- 对比 MySQL：~365 秒

## 常用数据查询模式

### 获取某日全市场截面

```python
import qlib
from qlib.data import D

qlib.init(provider_uri="~/.qlib/qlib_data/cn_data", region="cn")

instruments = D.instruments(market="all")
df = D.features(
    instruments,
    fields=["$close", "$volume", "Mean($close, 20)", "Std($close, 20)"],
    start_time="2020-06-01",
    end_time="2020-06-01"
)
# 结果：当日所有股票的收盘价、成交量、20日均价、20日标准差
```

### 获取单只股票时间序列

```python
df = D.features(
    ["SH600519"],
    fields=["$close", "$volume", "$close / Ref($close, 1) - 1"],
    start_time="2020-01-01",
    end_time="2020-12-31"
)
```

### 获取交易日列表

```python
trading_days = D.calendar(start_time="2020-01-01", end_time="2020-12-31")
print(f"2020 年共 {len(trading_days)} 个交易日")
```
