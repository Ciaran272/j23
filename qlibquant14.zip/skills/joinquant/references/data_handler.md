# DataHandler 与 Dataset 参考

## DataHandler 概述

DataHandler 是 Qlib 数据管道的核心，负责：
1. 定义特征表达式（哪些因子/指标）
2. 定义标签（预测目标）
3. 数据预处理（标准化、去极值、填充缺失值）

## 内置 DataHandler

### Alpha158

158 个预构建因子，覆盖价量动量、波动率、流动性等：

```python
from qlib.contrib.data.handler import Alpha158

handler_config = {
    "class": "Alpha158",
    "module_path": "qlib.contrib.data.handler",
    "kwargs": {
        "start_time": "2008-01-01",
        "end_time": "2020-08-01",
        "fit_start_time": "2008-01-01",
        "fit_end_time": "2014-12-31",
        "instruments": "csi300",
        "infer_processors": [
            {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
            {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
        ],
        "learn_processors": [
            {"class": "DropnaLabel"},
            {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
        ],
        "label": ["Ref($close, -2) / Ref($close, -1) - 1"]
    }
}
```

Alpha158 因子分类：
- KBAR 特征（开高低收关系）：20 个
- 价格动量（多周期收益率）：18 个
- 波动率（多周期标准差）：18 个
- 成交量变化：18 个
- 价量相关性：6 个
- 滚动统计（偏度/峰度/分位数）：78 个

### Alpha360

360 个因子，使用 6 个原始字段 × 60 天回溯窗口：

```python
from qlib.contrib.data.handler import Alpha360

handler_config = {
    "class": "Alpha360",
    "module_path": "qlib.contrib.data.handler",
    "kwargs": {
        "start_time": "2008-01-01",
        "end_time": "2020-08-01",
        "fit_start_time": "2008-01-01",
        "fit_end_time": "2014-12-31",
        "instruments": "csi300",
        "infer_processors": [
            {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
            {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
        ],
        "learn_processors": [
            {"class": "DropnaLabel"},
            {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
        ]
    }
}
```

Alpha360 适合时序模型（LSTM/Transformer），因为它保留了原始时序结构。

## 自定义 DataHandler

### 使用 DataHandlerLP + QlibDataLoader

```python
from qlib.data.dataset.handler import DataHandlerLP

custom_handler_config = {
    "class": "DataHandlerLP",
    "module_path": "qlib.data.dataset.handler",
    "kwargs": {
        "start_time": "2008-01-01",
        "end_time": "2020-08-01",
        "fit_start_time": "2008-01-01",
        "fit_end_time": "2014-12-31",
        "instruments": "csi300",
        "data_loader": {
            "class": "QlibDataLoader",
            "module_path": "qlib.data.dataset.loader",
            "kwargs": {
                "config": {
                    "feature": (
                        [
                            "$close / Ref($close, 1) - 1",
                            "$close / Ref($close, 5) - 1",
                            "$close / Ref($close, 20) - 1",
                            "Mean($close, 5) / Mean($close, 20) - 1",
                            "Std($close / Ref($close, 1) - 1, 20)",
                            "$volume / Mean($volume, 20)",
                            "Corr($close, $volume, 10)",
                        ],
                        ["ret1", "ret5", "ret20", "ma_ratio", "vol20", "vol_ratio", "pv_corr"]
                    ),
                    "label": (
                        ["Ref($close, -2) / Ref($close, -1) - 1"],
                        ["label"]
                    )
                },
                "freq": "day"
            }
        },
        "infer_processors": [
            {"class": "RobustZScoreNorm", "kwargs": {"fields_group": "feature", "clip_outlier": True}},
            {"class": "Fillna", "kwargs": {"fields_group": "feature"}}
        ],
        "learn_processors": [
            {"class": "DropnaLabel"},
            {"class": "CSRankNorm", "kwargs": {"fields_group": "label"}}
        ]
    }
}
```

### data_loader config 格式

```python
"config": {
    "feature": (
        [表达式列表],    # list of expression strings
        [名称列表]       # list of column names (same length)
    ),
    "label": (
        [标签表达式],
        [标签名称]
    )
}
```

## Dataset 类

### DatasetH（横截面模型）

用于 LightGBM、XGBoost、Linear 等非时序模型：

```python
from qlib.data.dataset import DatasetH

dataset_config = {
    "class": "DatasetH",
    "module_path": "qlib.data.dataset",
    "kwargs": {
        "handler": handler_config,
        "segments": {
            "train": ("2008-01-01", "2014-12-31"),
            "valid": ("2015-01-01", "2016-12-31"),
            "test": ("2017-01-01", "2020-08-01")
        }
    }
}
```

### TSDatasetH（时序模型）

用于 LSTM、GRU、Transformer 等需要时间窗口的模型：

```python
from qlib.data.dataset import TSDatasetH

ts_dataset_config = {
    "class": "TSDatasetH",
    "module_path": "qlib.data.dataset",
    "kwargs": {
        "handler": handler_config,
        "segments": {
            "train": ("2008-01-01", "2014-12-31"),
            "valid": ("2015-01-01", "2016-12-31"),
            "test": ("2017-01-01", "2020-08-01")
        },
        "step_len": 20  # 回溯窗口长度
    }
}
```

### 从 Dataset 获取数据

```python
dataset = DatasetH(handler=handler, segments=segments)

# 获取训练数据
df_train = dataset.prepare("train", col_set=["feature", "label"], data_key="learn")
X_train = df_train["feature"]
y_train = df_train["label"].iloc[:, 0]

# 获取测试数据（使用 infer processors）
df_test = dataset.prepare("test", col_set="feature", data_key="infer")
```

`data_key` 参数：
- `"learn"` — 使用 learn_processors 处理（训练时用）
- `"infer"` — 使用 infer_processors 处理（推理时用）

## Processors 参考

### 推理阶段 Processors（infer_processors）

应用于所有数据（train/valid/test），用于特征标准化：

| Processor | 用途 | 参数 |
|-----------|------|------|
| `RobustZScoreNorm` | 鲁棒 Z-score（中位数/MAD） | `fields_group`, `clip_outlier` |
| `ZScoreNorm` | 标准 Z-score（均值/标准差） | `fields_group` |
| `MinMaxNorm` | Min-Max 归一化 | `fields_group` |
| `CSZScoreNorm` | 截面 Z-score | `fields_group` |
| `CSRankNorm` | 截面排名归一化 | `fields_group` |
| `Fillna` | 填充缺失值 | `fields_group`, `fill_value=0` |
| `ProcessInf` | 处理 inf 值 | `fields_group` |
| `FilterCol` | 按正则过滤列 | `fields_group`, `col_list` |
| `TanhProcess` | Tanh 去极值 | `fields_group` |

### 学习阶段 Processors（learn_processors）

仅应用于训练数据，用于标签处理：

| Processor | 用途 |
|-----------|------|
| `DropnaLabel` | 删除标签为 NaN 的行 |
| `DropnaFeature` | 删除特征有 NaN 的行 |
| `CSRankNorm` | 标签截面排名归一化（推荐用于分类任务） |

### Processor 执行顺序

```
原始数据 → infer_processors（顺序执行）→ 特征矩阵
                                          ↓
                              learn_processors（仅 train segment）→ 训练数据
```

### fit_start_time / fit_end_time

Processors 中需要统计量（如均值、标准差）的，在 fit 时间段上计算统计量，然后应用到全部数据：

```python
handler = Alpha158(
    start_time="2008-01-01",       # 数据起始
    end_time="2020-08-01",         # 数据结束
    fit_start_time="2008-01-01",   # 统计量计算起始
    fit_end_time="2014-12-31",     # 统计量计算结束（通常 = train 结束）
    ...
)
```

## 标签定义

### 常用标签

```python
# 次日收益率（最常用）
"Ref($close, -1) / $close - 1"

# 隔日收益率（避免当日收盘价 → 次日开盘的 gap）
"Ref($close, -2) / Ref($close, -1) - 1"

# 5 日收益率
"Ref($close, -5) / $close - 1"

# 超额收益（需要基准数据）
"Ref($close, -2) / Ref($close, -1) - 1"  # 通常用 CSRankNorm 隐式去市场
```

### 标签中的负 Ref

`Ref($close, -n)` 表示未来第 n 天的值。这是 Qlib 定义标签的标准方式——框架会自动处理对齐，不会造成未来数据泄漏（因为标签只在训练时使用，推理时不需要标签值）。

## 数据时间对齐

Qlib 的时间对齐规则：
- 特征在 T 日计算时，只使用 T 日及之前的数据
- 标签 `Ref($close, -2) / Ref($close, -1) - 1` 表示 T+1 到 T+2 的收益
- 模型在 T 日收盘后预测，T+1 开盘执行交易，T+2 收盘平仓（或持有）
- segments 的 end_time 是包含的（inclusive）
