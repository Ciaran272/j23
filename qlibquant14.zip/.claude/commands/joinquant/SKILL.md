---
name: joinquant
description: Use when working with JoinQuant, 聚宽, JQData, jqdatasdk, A-share quant strategies, backtests, simulated/live trading code, platform API usage, stock/fund/bond/index/macro data queries, Alpha101/Alpha191 factors, technical indicators, or JoinQuant error/debugging questions.
---

# JoinQuant Compatibility Pointer

The maintained skill source is at `skills/joinquant/SKILL.md`.

Use that file and the references under `skills/joinquant/references/` for all JoinQuant/聚宽 work. This compatibility file exists only so the previous `.claude/commands/joinquant/` location does not become a stale second source of truth.
