# 聚宽 JoinQuant 量化平台助手

使用项目内标准 skill：`skills/joinquant/SKILL.md`。

处理用户的聚宽、JoinQuant、JQData、jqdatasdk、A 股量化策略、回测、模拟盘、数据 API、因子、技术指标或平台报错问题时：

1. 先按 `skills/joinquant/SKILL.md` 的流程工作。
2. 只读取 `skills/joinquant/references/` 中与问题相关的参考文件。
3. 写策略代码时遵守防未来函数、T+1、100 股整数倍、停牌/ST/涨跌停过滤、手续费滑点等约束。
4. 如果问题涉及当前平台最新行为，说明本地资料主要来自 2026-05-10/2026-05-11 的整理，必要时再核对官方文档。

用户请求：

$ARGUMENTS
