# HTML to Markdown HTML内容转换

将指定的本地 HTML 文件内容（文字、图片、表格、公式等）提取并转换为结构化的 Markdown 文档。针对量化交易、技术博客、学术内容场景做了重点优化。

## 使用方式

用户提供一个或多个本地 HTML 文件路径，执行以下操作：

## 执行步骤

1. **读取 HTML 文件**：使用 Read 工具读取目标 HTML 的完整内容（大文件可分段读取）
2. **剥离无关元素**：去除以下不属于正文的内容：
   - `<script>` / `<style>` / `<noscript>` 块及其内部内容（**例外**：含数学公式源码的 `<script type="math/tex">` 必须保留，见"公式处理规则"）
   - `<nav>` / `<header>` / `<footer>` / `<aside>` 等导航、页眉、页脚、侧边栏
   - 注释 `<!-- ... -->`
   - 隐藏元素（`style="display:none"`、`hidden` 属性等）
   - 广告位、分享按钮、推荐阅读等噪声块
3. **结构化提取**：识别并转换以下元素：
   - 标题：`<h1>`-`<h6>` -> `#`-`######`
   - 段落：`<p>` -> 空行分隔的段落
   - 强调：`<strong>`/`<b>` -> `**text**`；`<em>`/`<i>` -> `*text*`
   - 链接：`<a href="...">text</a>` -> `[text](url)`
   - 图片：`<img src="..." alt="...">` -> `![alt](src)`（**注意懒加载**：现代页面常用 `data-src`、`data-original`、`data-lazy-src` 而非 `src`，优先取这些属性的真实 URL）
   - 列表：`<ul>`/`<ol>`/`<li>` -> markdown 列表（保留嵌套层级）
   - 表格：`<table>`/`<thead>`/`<tbody>`/`<tr>`/`<th>`/`<td>` -> 标准 markdown 表格
   - 行内代码：`<code>` -> `` `code` ``
   - 代码块：`<pre><code>` -> fenced code block（语言识别见"代码块语言识别"）
   - 引用：`<blockquote>` -> `>`
   - 分割线：`<hr>` -> `---`
   - 换行：`<br>` -> 行末两空格或新行
   - 公式：见"公式处理规则"
   - 图表与说明：`<figure>` + `<figcaption>` -> 转为图片 + 单独段落显示 caption（学术内容必备）
   - 上标：`<sup>` 用于脚注/引用标记 `[1]` 时保留为 `[^1]`，用于公式时保留为 `^{...}`
4. **HTML 实体解码**：`&amp;` -> `&`，`&lt;` -> `<`，`&gt;` -> `>`，`&quot;` -> `"`，`&nbsp;` -> 普通空格，`&#39;` -> `'` 等
5. **输出 Markdown 文件**：将转换结果保存为 `.md` 文件

## 公式处理规则（量化重点）

现代 HTML 公式渲染器（KaTeX、MathJax）会在 DOM 中**保留原始 LaTeX 源码**，必须按以下优先级抽取，避免靠视觉转写损失精度：

**优先级 1 — `<annotation>` 标签（KaTeX 和 MathJax v3 标准）**：

```html
<span class="katex">
  <math>...</math>
  <semantics>
    <annotation encoding="application/x-tex">x_t = \alpha + \beta r_t + \epsilon_t</annotation>
  </semantics>
</span>
```

直接抽取 `<annotation encoding="application/x-tex">` 内的文本作为 LaTeX 源。这是最高质量来源——所见即所得。

**优先级 2 — `<script type="math/tex">`（MathJax v2 旧用法）**：

```html
<script type="math/tex">x_t = \alpha + \beta r_t + \epsilon_t</script>
<script type="math/tex; mode=display">\sum_{i=1}^N w_i = 1</script>
```

`mode=display` 是块级公式（转为 `$$..$$`），无 mode 是行内（转为 `$..$`）。

**优先级 3 — `data-tex` / `data-formula` / `data-original` 属性**：

```html
<span data-tex="\sigma^2 = E[(X-\mu)^2]">σ² = E[(X-μ)²]</span>
```

**优先级 4 — MathML `<math>` 元素（不带 annotation 时）**：

保留为 `$$..$$` 块并加注释 `<!-- 来自 MathML，未含 LaTeX 源，已保留原 MathML 供核对 -->`，原 MathML 可以折叠在 HTML 注释里。

**优先级 5 — 视觉转写（兜底）**：

当上述都不可用、公式以 `<img>` 形式出现时（如带 `class="math"` 或 `alt="\sum ..."`），按 PDF 公式 OCR 规则转写，并标注 `<!-- 视觉转写，建议核对 -->`。`<img>` 的 `alt` 属性如果就是 LaTeX 源（常见于 Pandoc 输出），直接采用。

**通用 LaTeX 风格约定**：
- 行内 `$..$`，块级 `$$..$$`
- 希腊字母用 `\alpha` `\beta` 不用 unicode α β
- 多行用 `aligned`，分段用 `cases`
- 量化常用：`\mathbb{E}` `\text{Var}` `\text{Cov}` `\mathbf{w}^T \Sigma \mathbf{w}`

## SVG / Canvas 图表处理

- **图标 SVG**（小尺寸、装饰性，含 `aria-hidden="true"` 或 width/height < 32px）：跳过
- **数据图 SVG**（量化博客常见的收益曲线、回撤图、热力图）：
  - 保留原 `<svg>...</svg>` 块在 HTML 注释里：`<!-- 原 SVG 已保留 ... -->`
  - 同时加文字描述：`<!-- SVG 数据图：X=日期(2018-2023)，Y=累计收益(%)，2 条系列：策略 vs 基准 -->`
- **`<canvas>` 渲染图**：源数据通常在 JS 运行后才有，HTML 静态读取拿不到，标注 `<!-- Canvas 渲染图，无源数据；建议人工补图或截图 -->`

## 代码块语言识别

`<pre><code>` 的语言信息常在 class 中，识别以下三种主流 highlighter 模式：

| Highlighter | class 模式 |
|---|---|
| Prism / highlight.js（标准） | `class="language-python"` `class="language-r"` |
| highlight.js（非标准） | `class="hljs python"` `class="hljs lang-python"` |
| Google Code Prettify | `class="prettyprint lang-py"` `class="prettyprint lang-cpp"` |

均归一化为 fenced code block + 语言标识：` ```python `

无 class 标记时，按代码内容关键字推断（`import` `def` → python；`function ... end` → matlab；`<-` `library()` → r；`#include` `std::` → cpp）。

## 引用 / 脚注 / 参考文献

- `<sup>` 中含数字或方括号引用 `[1]` `[^abc]`：转为 markdown 脚注引用 `[^1]`
- 文末 `<ol class="footnotes">` 或 `<div class="references">` `<div class="bibliography">`：转为 `[^1]: 引文内容` 列表
- BibTeX 样式引用 `[Smith2020]` `[FF1993]`：保留原样
- 链接化的引用 `<a href="#ref-1">[1]</a>`：保留为 `[^1]` 并在文末附原链接锚点

## 输出规范

- 文件保存在当前项目的 `output/` 目录下
- 文件名格式：`{HTML文件名}_{日期}.md`（去掉 `.html`/`.htm` 扩展名，日期用 `YYYY-MM-DD`）
- 文档顶部包含元信息：

```markdown
---
source: {HTML文件路径}
date: {转换日期}
title: {<title> 标签内容或 <h1> 文本}
charset: {HTML 声明的字符集，默认 UTF-8}
math_renderer: {KaTeX | MathJax v2 | MathJax v3 | MathML | none}
---
```

- 保持原文的层级结构和逻辑顺序
- 图片路径处理：
  - 绝对 URL（`http://`/`https://`）：保留
  - 相对路径：保留原样，并在元信息下方加一行说明 `<!-- 图片相对路径基准: {HTML文件所在目录} -->`
  - `data:` URI：保留前 60 字符并加省略号注释，避免污染文件
  - 懒加载属性 `data-src` `data-original` `data-lazy-src`：取真实 URL，不要用占位 `src`
- 表格转为标准 markdown 表格；若表格过于复杂（含合并单元格、嵌套表格），保留原 `<table>` HTML 片段并加注释 `<!-- 复杂表格，保留原 HTML -->`
- 去除内联样式（`style="..."`）和与排版无关的 `class`、`id` 属性
- 如果文档过长，按 `<h1>`/`<h2>` 章节拆分并用分割线 `---` 分隔

## 字符编码

- 默认按 UTF-8 读取
- 若 HTML `<meta charset>` 标记非 UTF-8（如 `gbk`/`gb2312`），在元信息中记录 `charset` 字段；如出现乱码，提示用户确认源文件编码

## 大文件处理

- 单文件超过 ~5000 行时，先扫描整体结构（统计 `<h1>`-`<h3>` 标题），再按章节顺序读取与转换
- 转换中实时写入，避免长文档占用过多上下文
- 完成后在文件末尾标注转换状态（成功 / 部分跳过 / 警告）

## 多文件处理

如果用户提供多个 HTML 文件，为每个文件生成独立的 markdown 文件，并在 `output/` 下生成或更新 `index.md` 汇总所有转换结果的链接列表。

## 输入格式

用户输入示例：

- 单个文件：`/html-to-markdown C:\docs\page.html`
- 多个文件：`/html-to-markdown C:\docs\a.html C:\docs\b.html`
- 当前目录下：`/html-to-markdown ./my-page.html`
- 整个文件夹（递归）：`/html-to-markdown C:\docs\html_archive\`

文件夹输入时，扫描该目录下所有 `.html`/`.htm` 文件并逐一转换。

$ARGUMENTS
