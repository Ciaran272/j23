# Web to Markdown 网页内容转换

将指定网页 URL 的内容（文字、图片、表格、公式等）抓取并转换为结构化的 Markdown 文档。针对量化交易、技术博客、学术内容场景做了重点优化。

## 使用方式

用户提供一个或多个网页 URL，执行以下操作：

## WebFetch 工具的局限（先看清能不能转）

本 skill 底层用 WebFetch，以下场景**会失败或退化**：

- **付费墙 / 鉴权页**：需要登录才能看的论文站、研报站、订阅博客 → WebFetch 拿不到正文
- **JS 渲染的 SPA**：React/Vue 等前端框架渲染、需要等 JS 执行才出内容的页面 → WebFetch 通常只能拿到空 HTML 骨架
- **超长页面**：可能被截断
- **跨域重定向**：需要重新发起请求

遇到上述场景时建议：用浏览器另存为完整 HTML（Save Page As → "Webpage, Complete"），再用 `/html-to-markdown` 转。

## 执行步骤

1. **抓取网页内容**：使用 WebFetch 工具获取目标网页
2. **剥离无关元素**：去除以下不属于正文的内容：
   - 导航、页眉、页脚、侧边栏（`<nav>` `<header>` `<footer>` `<aside>`）
   - 广告位、分享按钮、推荐阅读、评论区
   - 隐藏元素（`style="display:none"`、`hidden` 属性）
3. **结构化提取**：识别并转换以下元素：
   - 标题：`<h1>`-`<h6>` -> `#`-`######`
   - 段落：`<p>` -> 空行分隔
   - 强调：`<strong>`/`<b>` -> `**text**`；`<em>`/`<i>` -> `*text*`
   - 链接：`<a href="...">text</a>` -> `[text](url)`
   - 图片：`<img>` -> `![alt](src)`，**注意懒加载**：优先取 `data-src` / `data-original` / `data-lazy-src` 而非占位 `src`
   - 列表、表格、引用、分割线：同 markdown 标准映射
   - 行内代码 `<code>` -> `` `code` ``
   - 代码块 `<pre><code>` -> fenced code block（语言识别见下）
   - 图表说明：`<figure>` + `<figcaption>` -> 图片 + 单独段落 caption
   - 公式：见"公式处理规则"
4. **HTML 实体解码**：`&amp;` -> `&` 等
5. **输出 Markdown 文件**：将转换结果保存为 `.md` 文件

## 公式处理规则（量化重点）

现代量化博客（QuantStart、米筐研报 HTML、聚宽社区帖、知乎专栏、Substack 等）大量使用 KaTeX / MathJax 渲染公式。**渲染后的 DOM 中通常保留原始 LaTeX 源码**，按以下优先级抽取：

**优先级 1 — `<annotation encoding="application/x-tex">`**（KaTeX 和 MathJax v3 标准）：

```html
<span class="katex">
  <semantics>
    <annotation encoding="application/x-tex">x_t = \alpha + \beta r_t + \epsilon_t</annotation>
  </semantics>
</span>
```

直接抽取 annotation 文本作为 LaTeX 源——最高质量来源。

**优先级 2 — `<script type="math/tex">`**（MathJax v2）：

```html
<script type="math/tex">x_t = \alpha + \beta r_t</script>
<script type="math/tex; mode=display">\sum_{i=1}^N w_i = 1</script>
```

`mode=display` 转 `$$..$$`，无 mode 转 `$..$`。

**优先级 3 — `data-tex` / `data-formula` 属性**

**优先级 4 — MathML `<math>` 元素**：保留 `$$..$$` 块 + 注释 `<!-- 来自 MathML，未含 LaTeX 源 -->`

**优先级 5 — 视觉转写（兜底）**：图片公式（`<img alt="\sum ...">`）按 OCR 规则转写，标注 `<!-- 视觉转写，建议核对 -->`。注意：很多 Pandoc 生成的网页会把 LaTeX 源放在 `<img>` 的 `alt` 属性里，可以直接采用。

**通用 LaTeX 风格约定**：
- 行内 `$..$`，块级 `$$..$$`
- 希腊字母用 `\alpha` 不用 unicode α
- 多行用 `aligned`，分段用 `cases`
- 量化记号 `\mathbb{E}` `\text{Var}` `\mathbf{w}^T \Sigma \mathbf{w}`

## SVG / Canvas 图表

- **图标 SVG**（装饰性、小尺寸、`aria-hidden="true"`）：跳过
- **数据图 SVG**（收益曲线、热力图等）：尝试保留原 SVG 块或在 HTML 注释中存底；同时加一行结构化文字描述（图表类型 / 轴标 / 系列 / 关键观察）
- **`<canvas>` 渲染图**：JS 运行后才有数据，WebFetch 静态拿不到 → 标注 `<!-- Canvas 渲染图，无源数据，建议人工补图或截图 -->`

## 代码块语言识别

`<pre><code>` 的 class 识别三种主流 highlighter：

| Highlighter | class 模式 |
|---|---|
| Prism / highlight.js 标准 | `class="language-python"` |
| highlight.js 非标准 | `class="hljs python"` |
| Google Code Prettify | `class="prettyprint lang-py"` |

均归一化为 fenced code block + 语言标识：` ```python `

无 class 标记时按关键字推断（`import` `def` → python；`function ... end` → matlab；`<-` `library()` → r；`#include` `std::` → cpp）。

## 引用 / 脚注 / 参考文献

- `<sup>` 中含数字或方括号引用 `[1]`：转为 `[^1]`
- 文末 `<ol class="footnotes">` 或 `<div class="references">`：转为 `[^1]: 引文内容` 列表
- BibTeX 样式引用 `[Smith2020]` `[FF1993]`：保留原样
- 链接化引用 `<a href="#ref-1">[1]</a>`：保留为 `[^1]` 并附原锚点

## 输出规范

- 文件保存在当前项目的 `output/` 目录下
- 文件名格式：`{网页标题或域名}_{YYYY-MM-DD}.md`
- 文档顶部包含元信息：

```markdown
---
source: {原始URL}
date: {抓取日期}
title: {页面标题}
fetched_via: WebFetch
math_renderer: {KaTeX | MathJax v2 | MathJax v3 | MathML | none}
truncated: {true | false}
---
```

- 图片以 markdown 图片语法保留原始 URL（绝对路径直接保留）
- 表格转为标准 markdown 表格；复杂表格（合并单元格）保留原 HTML 并注释
- 保持原文的层级结构和逻辑顺序
- 如果页面内容过长，按 `<h1>`/`<h2>` 章节拆分并用分割线 `---` 分隔
- 末尾加"转换说明"段落，列出：
  - 跳过 / 失真的部分（哪些图、哪些表）
  - OCR 待核对的公式位置
  - 是否疑似被截断（如 WebFetch 返回含"... [truncated]" 字样或正文明显戛然而止）
  - 是否怀疑 JS 渲染（页面 HTML 几乎空、正文区只有 `<div id="root">` 之类）

## 字符编码

- 默认按 UTF-8 处理
- 若页面 `<meta charset>` 标记非 UTF-8（如 `gbk`），在元信息中记录；乱码时提示用户

## 多链接处理

如果用户提供多个 URL，为每个链接生成独立的 markdown 文件，并在 `output/` 下生成或更新 `index.md` 汇总所有转换结果的链接列表。

## 输入格式

用户输入示例：
- 单个链接：`/web-to-markdown https://example.com/article`
- 多个链接：`/web-to-markdown https://a.com https://b.com`

$ARGUMENTS
